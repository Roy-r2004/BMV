import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutPage from './pages/AboutPage';
import ArtworkDetailPage from './pages/ArtworkDetailPage';
import ContactPage from './pages/ContactPage';
import DashboardPage from './pages/admin/DashboardPage';
import EditAboutPage from './pages/admin/EditAboutPage';
import EditArtworkPage from './pages/admin/EditArtworkPage';
import GalleryPage from './pages/GalleryPage';
import HomePage from './pages/HomePage';
import ManageArtworksPage from './pages/admin/ManageArtworksPage';
import WorksPage from './pages/WorksPage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/works" element={<WorksPage />} />
          <Route path="/works/:slug" element={<ArtworkDetailPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/admin/dashboard" element={<DashboardPage />} />
          <Route path="/admin/artworks" element={<ManageArtworksPage />} />
          <Route path="/admin/:id" element={<ManageArtworksPage />} />
          <Route path="/admin/:slug" element={<ManageArtworksPage />} />
          <Route path="/admin/artworks/edit/:id" element={<EditArtworkPage />} />
          <Route path="/admin/about" element={<EditAboutPage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/works/:id" element={<ManageArtworksPage />} />
          <Route path="/works/:slug/:id" element={<ManageArtworksPage />} />
          <Route path="/works/:slug/:slug" element={<ManageArtworksPage />} />
          <Route path="/gallery/:id" element={<ManageArtworksPage />} />
          <Route path="/gallery/:slug" element={<ManageArtworksPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}