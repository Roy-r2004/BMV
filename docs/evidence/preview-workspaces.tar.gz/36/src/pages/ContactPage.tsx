// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock'; // Assuming seed has placeholder WhatsApp number and email
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, CTABand, BrandFooter, Button, UiIcon } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const; // Removed credentials and testimonials as per brief

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const jeanneWhatsAppNumber = "+12345678900"; // Placeholder: Replace with Jeanne's actual WhatsApp number
  const jeanneEmail = "info@jeannekassab.art";

  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"Connect with Jeanne Kassab"}
        subcopy={"Inquiries & Studio Visits"}
        variant="atelier" // Using atelier for a more editorial, less "product" feel
      />
    ),
    // Removed credentials slot as it's not requested for this page layout
    showcase: (
      <div className="py-24 sm:py-32 bg-background">
        <div className="mx-auto max-w-md px-6 text-center lg:px-8">
          <ProductShowcase heading={""}> {/* Heading removed as per design, using children */}
            <div className="space-y-6">
              <a
                href={`https://wa.me/${jeanneWhatsAppNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-x-2 my-8 rounded-md px-4 py-3 text-lg font-semibold shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-brand text-white hover:bg-brand-dark"
              >
                <UiIcon name="whatsapp" className="h-6 w-6" />
                <span>Message Jeanne on WhatsApp</span>
              </a>
              <p className="text-lg text-muted">
                Email: <a href={`mailto:${jeanneEmail}`} className="text-brand hover:underline">{jeanneEmail}</a>
              </p>
              <p className="font-sans text-muted_text_color mt-6 text-base">
                Studio visits available by appointment.
              </p>
            </div>
          </ProductShowcase>
        </div>
      </div>
    ),
    // Removed testimonials slot as it's not requested for this page layout
    cta: (
      <CTABand
        heading={"Ready to discover your next piece?"}
        primaryCta={{
          label: "Start a Conversation",
          href: `https://wa.me/${jeanneWhatsAppNumber}`,
          target: "_blank",
          rel: "noopener noreferrer",
        }}
        className="bg-background py-24 sm:py-32" // Ensure CTABand uses bg-background as per overall palette
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings, timeless appeal."}
        links={[
          { label: "Home", href: "/" },
          { label: "Works", href: "/gallery" },
          { label: "About", href: "/about" },
          { label: "Contact", href: "/contact" },
        ]}
        meta={[
          { label: "Instagram", href: "https://instagram.com/jeannekassab.art", icon: "instagram" }, // Placeholder social link
          // { label: "Pinterest", href: "#", icon: "pinterest" }, // Placeholder social link
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="public-contact">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}