// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter, UiIcon, Button } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const; // Adjusted to match brief, removing credentials and testimonials for this page

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    features: (
      <FeatureBento heading={seed.featuresHeading ?? "What Jeanne Kassab Art offers"} imagePool={[images.card1, images.card2, images.card3]} items={seed.features ?? []} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    hero: (
      <MarketingHero
        brandName="Jeanne Kassab Art"
        headline="Original Oil Paintings by Jeanne Kassab"
        subcopy="Explore abstract landscapes and layered compositions that captivate and inspire, rendered with unique depth and emotion."
        primaryCta={{ label: "View Collection", href: "/works" }}
        secondaryCta={{ label: "About the Artist", href: "/about" }}
        imageSrc={images.hero} // This image should be subtle as per the brief
        imageAlt="An abstract landscape oil painting"
        className="relative after:absolute after:inset-0 after:bg-blend-multiply after:bg-text-brand/20 bg-background"
      />
    ),
    // Removed credentials and features slots as per matched skeleton contract
    showcase: (
      <>
        <div className="container mx-auto py-16 px-4 sm:px-6 lg:px-8 bg-background">
          <h2 className="font-display text-4xl text-center text-text-brand mb-12">Featured Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Sample Artworks as per brief. Use ProductShowcase items prop for these. */}
            <a href="/works/crimson-tide" className="group block bg-surface shadow-md hover:shadow-lg transition-all duration-300 rounded-lg overflow-hidden">
              <img src={images.card1} alt="Crimson Tide - Abstract Landscape Painting" className="w-full h-80 object-cover object-center rounded-t-lg bg-muted aspect-square" />
              <div className="p-6 text-center">
                <h3 className="font-display text-xl text-text-brand mt-2 group-hover:text-primary transition-colors duration-300">Crimson Tide</h3>
                <p className="text-muted mt-2 text-sm">View Artwork</p>
              </div>
            </a>
            <a href="/works/emerald-depths" className="group block bg-surface shadow-md hover:shadow-lg transition-all duration-300 rounded-lg overflow-hidden">
              <img src={images.card2} alt="Emerald Depths - Layered Oil Painting" className="w-full h-80 object-cover object-center rounded-t-lg bg-muted aspect-square" />
              <div className="p-6 text-center">
                <h3 className="font-display text-xl text-text-brand mt-2 group-hover:text-primary transition-colors duration-300">Emerald Depths</h3>
                <p className="text-muted mt-2 text-sm">View Artwork</p>
              </div>
            </a>
            <a href="/works/desert-bloom" className="group block bg-surface shadow-md hover:shadow-lg transition-all duration-300 rounded-lg overflow-hidden">
              <img src={images.card3} alt="Desert Bloom - Abstract Landscape Painting" className="w-full h-80 object-cover object-center rounded-t-lg bg-muted aspect-square" />
              <div className="p-6 text-center">
                <h3 className="font-display text-xl text-text-brand mt-2 group-hover:text-primary transition-colors duration-300">Desert Bloom</h3>
                <p className="text-muted mt-2 text-sm">View Artwork</p>
              </div>
            </a>
          </div>
        </div>

        {/* Artist Statement Snippet (contextual brief) */}
        <div className="container mx-auto py-16 px-4 sm:px-6 lg:px-8 bg-background">
          <div className="text-center max-w-prose mx-auto font-sans text-lg text-text-brand space-y-4">
            <p>Jeanne Kassab explores the profound connection between internal landscapes and natural forms, employing rich, layered oils to evoke emotion and memory. Her abstract landscapes are invitations to contemplation, urging viewers to find quiet solace within their vibrant depths.</p>
            <p>Each brushstroke is a narrative, each layer a whispered secret, culminating in a collection that resonates with both ancient echoes and contemporary grace.</p>
            <a href="/about" className="inline-block text-primary hover:underline font-sans mt-4">Read More about Jeanne Kassab &rarr;</a>
          </div>
        </div>
      </>
    ), // Removed testimonials slot as per matched skeleton contract
    cta: (
      <CTABand
        heading="Discover Your Next Masterpiece"
        primaryCta={{ label: "Browse All Works", href: "/works" }}
        className="bg-primary/50 text-text-brand py-20" // Using bg-brand-light equivalent
      />
    ),
    footer: (
      <BrandFooter
        brandName="Jeanne Kassab Art"
        description="Original works, shown plainly."
        links={[
          { label: "Contact", href: "/contact" },
          { label: "Privacy", href: "/privacy" },
        ]}
        meta={
          <div className="flex space-x-4">
            <a href="https://instagram.com/jeannekassabart" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary">
              <UiIcon name="instagram" className="h-6 w-6" />
            </a>
            <a href="https://pinterest.com/jeannekassabart" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary">
              <UiIcon name="pinterest" className="h-6 w-6" />
            </a>
          </div>
        }
        className="bg-surface text-muted py-10"
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="public-home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}