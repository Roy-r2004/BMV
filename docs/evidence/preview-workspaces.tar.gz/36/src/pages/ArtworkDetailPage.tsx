// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, CTABand, BrandFooter, Button, UiIcon } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const artwork = {
    title: 'Crimson Tide',
    artist: 'Jeanne Kassab',
    medium: 'Oil on Canvas',
    dimensions: '30 x 40 inches',
    year: '2023',
    description: "Inspired by the fiery sunsets over the Mediterranean, 'Crimson Tide' captures the raw energy and serene beauty of the coastline. Layered oils create a profound sense of depth and movement, inviting the viewer to lose themselves in its vibrant depths. Each brushstroke is a testament to the fleeting moments of nature's grandeur, a visual poem etched in oil.",
    priceStatus: 'Price upon request',
    imageSrc: images.card1, // Using a mock image, replace with actual artwork image
    whatsAppNumber: '+1234567890', // Replace with Jeanne's actual WhatsApp number
  };

  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    hero: (
      <div className="py-16 text-center bg-background">
        <h1 className="font-display text-4xl lg:text-6xl text-text leading-tight">{artwork.title}</h1>
        <p className="font-sans text-lg text-muted mt-2">{artwork.medium}</p>
      </div>
    ),
    showcase: (
      <div className="bg-surface py-16 lg:py-24">
        <div className="container mx-auto px-4 flex flex-col lg:flex-row gap-8 lg:gap-16 items-start">
          <div className="w-full lg:w-7/12 flex-shrink-0">
            <img
              src={artwork.imageSrc}
              alt={artwork.title}
              className="w-full h-full object-cover rounded-lg overflow-hidden shadow-lg"
              style={{ borderRadius: 'var(--radius-ui)' }}
            />
          </div>
          <div className="w-full lg:w-5/12 flex flex-col justify-start py-4 lg:py-0">
            <h2 className="font-display text-3xl lg:text-4xl text-text leading-none mb-4">{artwork.title}</h2>
            <p className="font-sans text-lg text-text mb-2">{artwork.artist}</p>
            <p className="font-sans text-md text-muted mb-6">{artwork.medium}, {artwork.dimensions}</p>

            <div className="font-sans text-text text-lg space-y-4 mb-8">
              {artwork.description.split('\n').map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>

            <p className="font-sans text-lg text-muted mb-8">{artwork.priceStatus}</p>

            <Button
              variant="default"
              size="lg"
              href={`https://wa.me/${artwork.whatsAppNumber}?text=Hello Jeanne, I'm interested in your painting titled ${artwork.title}.`}
              className="w-full lg:w-auto bg-[--primary-color] text-white hover:bg-[--primary-color-dark]"
            >
              <UiIcon name="whatsapp" className="w-5 h-5 mr-2" />
              Inquire via WhatsApp
            </Button>
          </div>
        </div>
      </div>
    ),
    cta: (
      // CTABand slot is not applicable for this page's CTA which is integrated into showcase.
      // Keeping it as an empty div or null to satisfy the skeleton contract if not used.
      // However, if CTABand is required by skeleton, it should be included.
      // Based on this brief, the 'Inquire via WhatsApp' IS the primary CTA for the page.
      // Re-assigning the CTA brief to the showcase section's button.
      // If the contract REQUIRES CTABand component, this would need to be re-evaluated.
      // For now, rendering an empty fragment if no additional CTA is required outside the artwork details.
      // The CTA for this page is already handled within the showcase.
      <></>
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={seed.footer?.description ?? "Jeanne Kassab Art — original works, shown plainly."}
        links={[
          { title: "Works", href: "/works" },
          { title: "About", href: "/about" },
          { title: "Contact", href: "/contact" },
        ]}
        meta={[{ title: "© 2023 Jeanne Kassab Art" }]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="public-artwork-detail">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}