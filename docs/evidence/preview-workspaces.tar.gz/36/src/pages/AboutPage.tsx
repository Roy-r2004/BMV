import React from 'react';
// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProductShowcase, BrandFooter, Button, CredentialStrip, TestimonialRail, CTABand } from '@/ui'; // Removed CredentialStrip, TestimonialRail, CTABand

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const; // Simplified order

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"About Jeanne Kassab"}
        subcopy={"Artist Statement & Background"}
        primaryCta={{ label: "", href: "#" }} // Empty CTA to remove button per brief
        secondaryCta={{ label: "", href: "#" }} // Empty CTA to remove button per brief
        imageSrc="" // No image in hero for this page
        imageAlt=""
        className="text-text-brand p-16 pb-8 bg-surface-brand" // Add padding and surface background
      >
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="font-display text-7xl mb-4 leading-tight text-text-brand-light">About Jeanne Kassab</h1>
          <p className="font-sans text-xl text-muted-brand mb-8">Artist Statement & Background</p>
        </div>
      </MarketingHero>
    ),
    // credentials slot removed as per brief (not needed for about page)
    showcase: (
      <ProductShowcase heading="" className="py-16 md:py-24 bg-background-brand">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-7xl mx-auto px-6 lg:px-8">
          {/* Left Column: Image */}
          <div className="flex justify-center items-start">
            <img
              src={images.ambient} // Placeholder for artist portrait/studio image
              alt="Jeanne Kassab working in her studio"
              className="w-full h-auto object-cover rounded-lg shadow-lg aspect-[4/5] md:aspect-[3/4] lg:aspect-[2/3]"
              style={{ borderRadius: 'var(--radius-xl)' }} // Applying token_overrides.radius_ui
            />
          </div>

          {/* Right Column: Bio and Vision */}
          <div className="max-w-prose text-text-brand leading-relaxed space-y-8">
            <p className="text-xl font-sans text-muted-brand-inverted my-4">
              "My art is a journey into the soul of the landscape, where color and texture converge to tell a story."
            </p>
            <h2 className="font-display text-4xl mb-4 text-text-brand">The Artist's Journey</h2>
            <p className="font-sans text-lg">
              Jeanne Kassab is a Lebanese-Canadian artist known for her deeply textured abstract landscapes and layered oil paintings. Her work explores the intricate connections between memory, emotion, and the natural world, transforming familiar vistas into realms of vibrant abstraction. Raised amidst the rich cultural tapestry of Beirut and later shaped by the expansive Canadian wilderness, Jeanne's art is a dialogue between urban complexity and natural serenity.
            </p>
            <h2 className="font-display text-4xl mb-4 text-text-brand">A Vision in Layers</h2>
            <p className="font-sans text-lg">
              Through a meticulous process of layering oils, Jeanne builds surfaces that invite viewers to lean in, to discover hidden depths and nuances. Her signature style emerged from years of experimental practice, where she developed techniques to imbue each piece with a sense of history and profound stillness. The abstract landscapes are not mere representations but rather evocations of internal states, reflecting both tranquility and dynamic energy. She believes art should not only be seen but felt—an experience that resonates long after the initial encounter. Her dedication to quality and unique vision has earned her a growing following among collectors and designers who seek art that connects on a visceral level.
            </p>
            <h2 className="font-display text-4xl mb-4 text-text-brand">Connect with Jeanne</h2>
            <p className="font-sans text-lg">
              For inquiries, commissions, or just to say hello, Jeanne welcomes direct conversations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mt-6">
              <Button variant="default" size="default" href="mailto:jeanne@kassabart.com" className="font-sans text-lg">
                Email Jeanne
              </Button>
              <Button variant="outline" size="default" href="https://wa.me/MESSAGE_JEANNE_KASSAB_NUMBER" target="_blank" rel="noopener noreferrer" className="font-sans text-lg">
                <UiIcon name="whatsapp" className="mr-2 h-5 w-5 fill-current" />
                WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </ProductShowcase>
    ),
    // testimonials slot removed as per brief (not needed for about page)
    // cta slot removed as per brief (contact info is integrated into showcase)
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings for discerning collectors and interior designers."}
        links={[
          { label: "Contact", href: "/contact" },
          { label: "Privacy Policy", href: "/privacy" },
          { label: "Instagram", href: "https://instagram.com/jeannekassabart", icon: "instagram" },
        ]}
        className="bg-surface-brand text-muted-brand border-t border-muted-brand-300"
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="public-about">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}

// Ensure UiIcon is imported if used. Assuming this is a shared component.
// Adding a dummy UiIcon just for compilation if not already widely available
interface UiIconProps {
  name: string;
  className?: string;
}

const UiIcon: React.FC<UiIconProps> = ({ name, className }) => (
  // This is a placeholder. In a real app, this would render an actual SVG icon.
  <span className={className} aria-hidden="true">{name}</span>
);