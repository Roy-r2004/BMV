// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, DataTable, ActivityFeed, Button, Input } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-detail" as const;

export default function EditAboutPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const sampleAboutContent = `
    Jeanne Kassab is a Lebanese-American artist, exploring the dynamic interplay of color, texture, and emotion through abstract landscapes and layered oil paintings. Her work invites viewers into a contemplative space, often evoking the serene yet powerful presence of nature.

    With a lifelong passion for art, Jeanne developed her distinctive style focusing on the expressive qualities of oil paint. Her technique involves building up layers, creating depth and a unique tactile quality that draws the eye and the imagination. Each piece is a conversation between the canvas and the artist, resulting in works that are both deeply personal and universally resonant.

    Jeanne's art has been showcased in various galleries and private collections, finding homes with collectors who appreciate the calming yet vibrant energy her paintings bring to a space. She believes in the transformative power of art to inspire, soothe, and provoke thought.

    Beyond the canvas, Jeanne Kassab is committed to sharing her artistic journey and connecting with fellow art enthusiasts. She regularly experiments with new approaches, continuously evolving her practice.
  `;

  const [aboutContent, setAboutContent] = useState(sampleAboutContent.trim());
  const [artistPhoto, setArtistPhoto] = useState<string | null>(null);

  const handleSave = () => {
    console.log("Saving changes:", { aboutContent, artistPhoto });
    // In a real application, this would dispatch an API call to save the content.
    alert("Changes saved (simulated)");
  };

  const handleCancel = () => {
    console.log("Cancelling changes");
    // In a real application, this might revert to initial content or navigate away.
    alert("Changes cancelled (simulated)");
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setArtistPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const slots = {
    header: (
      <PageHeader
        title={<span className="font-display">Edit About Page</span>}
        actions={[
          <Button key="cancel" variant="ghost" onClick={handleCancel} className="text-muted_text_color">
            Cancel
          </Button>,
          <Button key="save" variant="default" onClick={handleSave} className="bg-brand text-white">
            Save Changes
          </Button>,
        ]}
      />
    ),
    table: (
      <div className="p-6 bg-surface shadow rounded-lg max-w-4xl mx-auto">
        <h2 className="text-xl font-semibold mb-4">Artist Bio & Statement</h2>
        <div className="mb-6">
          <label htmlFor="artistPhoto" className="block text-sm font-medium text-text mb-2">
            Artist Photo
          </label>
          <div className="flex items-center space-x-4">
            {artistPhoto ? (
              <img src={artistPhoto} alt="Artist" className="w-24 h-24 rounded-full object-cover shadow-sm ring-1 ring-muted" />
            ) : (
              <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center text-muted_text_color text-sm">
                No photo
              </div>
            )}
            <Input
              id="artistPhoto"
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="px-3 py-2 border rounded-md shadow-sm text-sm focus:outline-none focus:ring-1 focus:ring-brand"
            />
          </div>
          <p className="text-xs text-muted_text_color mt-2">Upload a portrait of Jeanne Kassab.</p>
        </div>
        <label htmlFor="aboutContent" className="block text-sm font-medium text-text mb-2">
          About Content
        </label>
        <Input
          as="textarea"
          id="aboutContent"
          value={aboutContent}
          onChange={(e) => setAboutContent(e.target.value)}
          rows={20}
          className="w-full p-4 border border-muted_text_color rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-brand bg-surface text-text resize-y"
          aria-label="Rich text editor for About page content"
        />
        <p className="text-xs text-muted_text_color mt-2">
          Use simple formatting like <b>bold</b>, <i>italic</i>, and lists for clarity.
        </p>
      </div>
    ),
    activity: (
      <ActivityFeed
        heading="Recent Edits"
        items={[
          { id: "activity-1", title: "About page content updated", detail: "Minor text revision in artist statement.", time: "Just now" },
          { id: "activity-2", title: "Artist photo uploaded", detail: "New portrait added.", time: "3 days ago" },
          { id: "activity-3", title: "Initial content published", detail: "About page first went live.", time: "2 weeks ago" },
        ]}
        className="mt-8"
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-edit-about" className="bg-background min-h-screen">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}