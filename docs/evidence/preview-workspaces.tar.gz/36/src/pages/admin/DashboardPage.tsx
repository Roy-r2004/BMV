// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, Button, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function DashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Admin Dashboard - Jeanne Kassab Art"}
        description={"Overview of inquiries, available works, and recent activities."}
        actions={[
          { label: "New Artwork", href: "/admin/artworks/new", variant: "default" as const },
          { label: "Settings", href: "/admin/settings", variant: "secondary" as const }
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <StatCard
          label="New Inquiries"
          value="3"
          delta="+1"
          hint="Last 24 hours"
          className="bg-surface shadow"
        />
        <StatCard
          label="Available Works"
          value="18"
          delta="-2"
          hint="This month"
          className="bg-surface shadow"
        />
        <StatCard
          label="Sold This Month"
          value="2"
          delta="+0"
          hint="Compared to last month"
          className="bg-surface shadow"
        />
      </div>
    ),
    chart: (
      // For the admin dashboard, we can repurpose the chart slot for AI suggestions without changing its core component type,
      // as it's meant to display aggregated information.
      // This serves the "Curated Homepage Suggestions" brief as a type of data display.
      <div className="rounded-lg bg-surface p-6 shadow">
        <h3 className="font-display text-lg text-text mb-4">Homepage Spotlight Recommendations</h3>
        <ul className="space-y-4">
          <li className="flex items-center space-x-4 p-2 bg-background rounded-md">
            <img src="/placeholder-winter-solstice.jpg" alt="Winter Solstice thumbnail" className="w-16 h-16 object-cover rounded-sm" />
            <div className="flex-1">
              <p className="font-sans text-text">Winter Solstice</p>
              <p className="text-sm text-muted">High engagement last week. Consider featuring.</p>
            </div>
            <Button variant="secondary" size="sm">Feature</Button>
          </li>
          <li className="flex items-center space-x-4 p-2 bg-background rounded-md">
            <img src="/placeholder-morning-mist.jpg" alt="Morning Mist thumbnail" className="w-16 h-16 object-cover rounded-sm" />
            <div className="flex-1">
              <p className="font-sans text-text">Morning Mist</p>
              <p className="text-sm text-muted">New addition. Great for a fresh look.</p>
            </div>
            <Button variant="secondary" size="sm">Feature</Button>
          </li>
        </ul>
      </div>
    ),
    filters: (
      <FilterBar searchPlaceholder="Search artworks or activities..."
        filters={[
          { id: "all", label: "All", active: true },
          { id: "artworks", label: "Artworks", active: false },
          { id: "inquiries", label: "Inquiries", active: false }
        ]}
      />
    ),
    table: (
      // Repurposing the table slot for another admin specific task or a simple list if no proper table data exists.
      // Assuming a generic "Artwork Management" section here if needed, or keeping it empty if no direct table.
      // For this brief, the 'Homepage Curation Suggestions' has been mapped to chart slot to fit a card-like display.
      // If a table of artworks was needed here, it would be populated with dummy data.
      <div className="rounded-lg bg-surface p-6 shadow">
        <h3 className="font-display text-lg text-text mb-4">Artwork Quick Links</h3>
        <ul className="space-y-2">
          <li>
            <a href="/admin/artworks" className="text-secondary hover:underline">Manage All Artworks</a>
          </li>
          <li>
            <a href="/admin/inquiries" className="text-secondary hover:underline">View All Inquiries</a>
          </li>
          <li>
            <a href="/admin/profile" className="text-secondary hover:underline">Edit Artist Profile</a>
          </li>
        </ul>
      </div>
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "a1", name: "New inquiry for 'Autumn Depths'", detail: "From WhatsApp, Sarah C. | 10:32 AM", time: "Just now" },
          { id: "a2", name: "Artwork 'Coastal Whispers' marked as sold", detail: "Updated by Jeanne Kassab | 09:15 AM", time: "2 hours ago" },
          { id: "a3", name: "New artwork uploaded: 'Urban Reflections'", detail: "Ready for publication | Yesterday", time: "Yesterday" },
          { id: "a4", name: "Homepage updated", detail: "Featured 'Transcendent Hues' | 2 days ago", time: "2 days ago" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems} rail={rail} appearance="soft">
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard" className="bg-background">
        {main}
      </div>
    </OpsShell>
  );
}