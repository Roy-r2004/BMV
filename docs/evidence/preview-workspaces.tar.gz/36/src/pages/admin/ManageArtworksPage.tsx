// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Select, Input, UiIcon } from '@/ui';

// Mock data for artworks
const mockArtworks = [
  {
    id: '1',
    thumbnail: '/images/mock-artwork-1.jpg', // Placeholder for actual image path
    title: 'Autumn Depths',
    status: 'Available',
    medium: 'Oil on Wood Panel',
    dimensions: '24 x 36 inches',
    slug: 'autumn-depths',
  },
  {
    id: '2',
    thumbnail: '/images/mock-artwork-2.jpg',
    title: 'Coastal Whispers',
    status: 'Sold',
    medium: 'Layered Oil on Canvas',
    dimensions: '48 x 60 inches',
    slug: 'coastal-whispers',
  },
  {
    id: '3',
    thumbnail: '/images/mock-artwork-3.jpg',
    title: 'Skyline Serenade',
    status: 'Available',
    medium: 'Abstract Landscape',
    dimensions: '36 x 36 inches',
    slug: 'skyline-serenade',
  },
  {
    id: '4',
    thumbnail: '/images/mock-artwork-4.jpg',
    title: 'Verdant Ascent',
    status: 'Available',
    medium: 'Acrylic and Oil on Linen',
    dimensions: '30 x 40 inches',
    slug: 'verdant-ascent',
  },
  {
    id: '5',
    thumbnail: '/images/mock-artwork-5.jpg',
    title: 'Echoes of Dawn',
    status: 'Sold',
    medium: 'Oil on Canvas',
    dimensions: '20 x 20 inches',
    slug: 'echoes-of-dawn',
  },
];

const SKELETON_ID = "ops-list" as const;
export default function ManageArtworksPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const artworkColumns = [
    {
      key: 'thumbnail',
      header: '',
      cell: ({ row }: { row: (typeof mockArtworks)[0] }) => (
        <img src={row.thumbnail} alt={row.title} className="w-12 h-12 object-cover rounded" />
      ),
    },
    {
      key: 'title',
      header: 'Title',
      cell: ({ row }: { row: (typeof mockArtworks)[0] }) => (
        <span className="font-sans text-text">{row.title}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: ({ row }: { row: (typeof mockArtworks)[0] }) => (
        <span className={row.status === 'Available' ? 'text-green-600' : 'text-text-muted'}>
          {row.status}
        </span>
      ),
    },
    {
      key: 'medium',
      header: 'Medium',
      cell: ({ row }: { row: (typeof mockArtworks)[0] }) => (
        <span className="font-sans text-muted">{row.medium}</span>
      ),
    },
    {
      key: 'dimensions',
      header: 'Dimensions',
      cell: ({ row }: { row: (typeof mockArtworks)[0] }) => (
        <span className="font-sans text-muted">{row.dimensions}</span>
      ),
    },
    {
      key: 'actions',
      header: 'Actions',
      cell: ({ row }: { row: (typeof mockArtworks)[0] }) => (
        <div className="flex space-x-2">
          <Button variant="ghost" size="sm" href={`/admin/artworks/edit/${row.id}`}>
            Edit
          </Button>
          <Button variant="ghost" size="sm" href={`/works/${row.slug}`} target="_blank">
            View Public
          </Button>
          <Button variant="ghost" size="sm">
            {row.status === 'Available' ? 'Mark as Sold' : 'Mark as Available'}
          </Button>
          <Button variant="destructive" size="sm">
            Delete
          </Button>
        </div>
      ),
    },
  ];

  const slots = {
    header: (
      <PageHeader
        title="Manage Artworks"
        actions={[
          <Button key="add-artwork" href="/admin/artworks/new" className="bg-brand text-white">
            + Upload New Artwork
          </Button>,
        ]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search artworks by title..."
        searchValue="" // Implement state for search value
        onSearchChange={() => {}} // Implement handler for search change
        filters={[
          {
            id: 'status',
            label: 'Status:',
            element: (
              <Select
                options={[
                  { value: 'all', label: 'All' },
                  { value: 'available', label: 'Available' },
                  { value: 'sold', label: 'Sold' },
                ]}
                defaultValue="all"
                className="bg-surface border"
              />
            ),
          },
          {
            id: 'sort',
            label: 'Sort By:',
            element: (
              <Select
                options={[
                  { value: 'dateAdded', label: 'Date Added' },
                  { value: 'title', label: 'Title' },
                ]}
                defaultValue="dateAdded"
                className="bg-surface border"
              />
            ),
          },
        ]}
      />
    ),
    table: (
      <DataTable columns={artworkColumns} rows={mockArtworks} />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-manage-artworks" className="bg-background">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}