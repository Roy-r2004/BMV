export const BRAND_MANIFEST = {
  brand_name: "Jeanne Kassab Art",
  tagline: "Discover original oil paintings that evoke calm and captivate the beholder.",
  accent: "#0f766e",
  accent_dark: "#0b5853",
  accent_light: "#e0f2f1",
  font: "Source Sans 3",
  services: [
    {
      name: "Original Oil Paintings",
      description: "Abstract landscapes and layered oils, brought to life on canvas.",
      duration: null,
      badge: null,
    },
    {
      name: "Art Commission Inquiries",
      description: "Collaborate on a unique piece tailored to your vision and space.",
      duration: null,
      badge: null,
    },
    {
      name: "Collector Consultation",
      description: "Personalized guidance for acquiring a cherished work for your collection.",
      duration: null,
      badge: null,
    },
  ],
  owner_name: "Jeanne",
  client_names: ["Sarah Chen", "Michael Davis", "Eleanor Vance", "Robert Palmer", "Sophia Rodriguez", "David Lee"],
  testimonials: [
    {
      name: "Sarah Chen",
      initials: "SC",
      text: "Jeanne's painting transformed my living room. The depth and tranquility are truly remarkable.",
      service: "Original Oil Painting",
    },
    {
      name: "Michael Davis",
      initials: "MD",
      text: "The entire process was seamless, from discovery to the personalized inquiry via WhatsApp. A true professional.",
      service: "Art Acquisition",
    },
    {
      name: "Eleanor Vance",
      initials: "EV",
      text: "As an interior designer, I often recommend Jeanne's work. It perfectly complements refined spaces.",
      service: "Interior Design Collaboration",
    },
    {
      name: "Robert Palmer",
      initials: "RP",
      text: "Her abstract landscapes have a unique ability to draw you in. I'm already looking forward to my next piece.",
      service: "Original Oil Painting",
    },
    {
      name: "Sophia Rodriguez",
      initials: "SR",
      text: "Stunning work! The colors and textures are even more captivating in person. Highly recommend.",
      service: "Original Oil Painting",
    },
    {
      name: "David Lee",
      initials: "DL",
      text: "Jeanne's eye for composition is unparalleled. This piece brought exactly the calm I was looking for.",
      service: "Art Acquisition",
    },
  ],
  social_proof: "Trusted by collectors and interior designers worldwide.",
  design_system: {
    primary_color: "#0f766e",
    secondary_color: "#0369a1",
    background_color: "#f8fafc",
    surface_color: "#ffffff",
    text_color: "#042f2e",
    muted_text_color: "#5f7a78",
    font_family: "Source Sans 3",
    display_font_family: "Fraunces",
    font_import_url:
      "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
    font_display: '"Fraunces", Georgia, serif',
    brand_locked: true,
    brand_brief_version: "1.0",
    mood: "modern",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature: "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.",
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    recipe_id: "editorial",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    recipe_prompt:
      "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    style_keywords: "Editorial · Calm air",
    border_radius: "0.77rem",
    design_overlay_id: "calm_air",
    design_overlay_label: "Calm air",
    design_overlay_blurb: "Airy clinical calm — soft surfaces, quiet type, low density.",
    density: "airy",
    token_overrides: {
      radius_ui: "0.77rem",
      bg_mix: "3%",
      fg_mix: "38%",
      muted_mix: "28%",
      border_mix: "12%",
      shadow: "0 28px 56px -40px",
      shadow_alpha: "22%",
      glow: "5%",
      card: "#ffffff",
      atmosphere:
        "radial-gradient(90% 55% at 8% -5%, color-mix(in srgb, var(--color-brand) 9%, transparent), transparent 58%), linear-gradient(180deg, #fbfcfd 0%, color-mix(in srgb, var(--color-brand) 3%, #f5f7f9) 55%, #f8fafb 100%)",
    },
    font_import:
      "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700",
    design_brief_version: "1.0",
    design_brief_sealed: true,
  },
  design_brief: {
    version: "1.0",
    sealed: true,
    brand_name: "Jeanne Kassab Art",
    brand_locked: true,
    recipe_id: "editorial",
    recipe_label: "Editorial",
    recipe_blurb: "Gallery pacing, large display type, airy whitespace, soft surfaces.",
    recipe_prompt:
      "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    product_kind: "storefront",
    product_subtype: "storefront",
    product_kind_note: "Storefront — public marketing home is the product surface.",
    industry_template_id: "clinic-dental-home",
    ops_template_id: "clinic-front-desk-ops",
    template_prompt: null,
    ops_template_prompt: null,
    overlay_id: "calm_air",
    overlay_label: "Calm air",
    overlay_blurb: "Airy clinical calm — soft surfaces, quiet type, low density.",
    density: "airy",
    mood: "modern",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature: "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.",
    palette: {
      primary: "#0f766e",
      secondary: "#0369a1",
      background: "#f8fafc",
      surface: "#ffffff",
      text: "#042f2e",
      muted: "#5f7a78",
    },
    typography: {
      font_family: "Source Sans 3",
      display_font_family: "Fraunces",
      font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
      font_display: '"Fraunces", Georgia, serif',
      font_import:
        "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700",
      font_import_url:
        "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    },
    token_overrides: {
      radius_ui: "0.77rem",
      bg_mix: "3%",
      fg_mix: "38%",
      muted_mix: "28%",
      border_mix: "12%",
      shadow: "0 28px 56px -40px",
      shadow_alpha: "22%",
      glow: "5%",
      card: "#ffffff",
      atmosphere:
        "radial-gradient(90% 55% at 8% -5%, color-mix(in srgb, var(--color-brand) 9%, transparent), transparent 58%), linear-gradient(180deg, #fbfcfd 0%, color-mix(in srgb, var(--color-brand) 3%, #f5f7f9) 55%, #f8fafb 100%)",
    },
    border_radius: "0.77rem",
    section_order: ["hero", "credentials", "features", "process", "testimonials", "booking", "cta", "footer"],
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    style_keywords: "Editorial · Calm air",
    direction:
      "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid. · Editorial: Gallery pacing, large display type, airy whitespace, soft surfaces. · Calm air: Airy clinical calm — soft surfaces, quiet type, low density. · Product kind storefront/storefront: Storefront — public marketing home is the product surface.",
  },
};

export const brand = {
  name: "Jeanne Kassab Art",
  tagline: "Discover original oil paintings that evoke calm and captivate the beholder.",
  design_system: BRAND_MANIFEST.design_system,

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  services: [{"name": "Jeanne Kassab Art Signature", "title": "Jeanne Kassab Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jeanne Kassab Art clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/3845983/pexels-photo-3845983.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/6627349/pexels-photo-6627349.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/6627329/pexels-photo-6627329.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/6627350/pexels-photo-6627350.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/4269936/pexels-photo-4269936.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/6627724/pexels-photo-6627724.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const roles = [
  {
    "id": "customer",
    "label": "Collector & Visitor",
    "defaultPath": "/works",
    "icon": "users"
  },
  {
    "id": "admin",
    "label": "Artist & Manager",
    "defaultPath": "/admin/dashboard",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Jeanne Kassab"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "works",
      "path": "/works",
      "href": "/works",
      "label": "Works"
    }
  ],
  "admin": [
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "admin-artworks",
      "path": "/admin/artworks",
      "href": "/admin/artworks",
      "label": "Artworks"
    },
    {
      "id": "admin-about",
      "path": "/admin/about",
      "href": "/admin/about",
      "label": "About"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Jeanne Kassab"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "works",
      "path": "/works",
      "href": "/works",
      "label": "Works"
    }
  ]
};

export const seed = {
  hero: {
    headline: "Original Oil Paintings by Jeanne Kassab",
    subcopy:
      "Explore abstract landscapes and layered compositions that captivate and inspire, rendered with unique depth and emotion.",
    primaryCta: {
      label: "View Collection",
      href: "/works",
    },
    secondaryCta: {
      label: "About the Artist",
      href: "/about",
    },
  },
  cta: {
    heading: "Ready for your next inspired acquisition?",
    description: "Inquire about available works, discuss a commission, or arrange a private studio viewing.",
    primaryLabel: "Inquire via WhatsApp",
    primaryHref: `https://wa.me/+12345678900?text=Hello Jeanne, I'm interested in your art!`,
    secondaryLabel: "Email Jeanne",
    secondaryHref: "mailto:info@jeannekassab.art",
  },
  credentialsHeading: "Trusted by art lovers and interior designers",
  credentials: [
    {
      label: "Curated by renowned galleries",
      value: "9+",
    },
    {
      label: "Featured in design magazines",
      value: "5+",
    },
    {
      label: "Acquired by private collectors",
      value: "50+",
    },
    {
      label: "International exhibitions",
      value: "3+",
    },
  ],
  testimonialsHeading: "Voices from our cherished collectors",
  testimonials: BRAND_MANIFEST.testimonials,
  artworks: [
    {
      id: "crimson-tide",
      title: "Crimson Tide",
      artist: "Jeanne Kassab",
      medium: "Oil on Canvas",
      dimensions: "30 x 40 inches",
      year: "2023",
      description:
        "Inspired by the fiery sunsets over the Mediterranean, 'Crimson Tide' captures the raw energy and serene beauty of the coastline. Layered oils create a profound sense of depth and movement, inviting the viewer to lose themselves in its vibrant depths. Each brushstroke is a testament to the fleeting moments of nature's grandeur, a visual poem etched in oil.",
      priceStatus: "Price upon request",
      imageSrc: images.artwork1,
      imageAlt: "Crimson Tide abstract oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "emerald-horizon",
      title: "Emerald Horizon",
      artist: "Jeanne Kassab",
      medium: "Oil on Linen",
      dimensions: "48 x 36 inches",
      year: "2022",
      description:
        "A sprawling abstract landscape, 'Emerald Horizon' evokes the calm solitude of ancient forests and rolling hills. The interplay of deep greens, blues, and earth tones creates a meditative feeling, a window into a timeless natural world. This large-scale piece commands attention while offering a serene presence.",
      priceStatus: "Available",
      imageSrc: images.artwork2,
      imageAlt: "Emerald Horizon abstract oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "whispering-pines",
      title: "Whispering Pines",
      artist: "Jeanne Kassab",
      medium: "Mixed Media on Board",
      dimensions: "24 x 24 inches",
      year: "2023",
      description:
        "Textured with delicate applications of paint and natural elements, 'Whispering Pines' explores the quiet majesty of a pine forest. The muted palette and tactile surface invite close inspection, revealing intricate details that mimic the bark and needles of trees, drawing the viewer into its peaceful contemplation.",
      priceStatus: "Sold",
      imageSrc: images.artwork3,
      imageAlt: "Whispering Pines mixed media painting",
      whatsAppNumber: "+12345678900",
      status: "Sold",
    },
    {
      id: "azure-dream",
      title: "Azure Dream",
      artist: "Jeanne Kassab",
      medium: "Oil on Canvas",
      dimensions: "36 x 36 inches",
      year: "2024",
      description:
        "'Azure Dream' is a vibrant exploration of skies and celestial phenomena, rendered in a striking array of blues and whites. The dynamic brushwork suggests swirling clouds and distant galaxies, inviting imagination to take flight. This piece is a testament to the boundless beauty of the atmosphere.",
      priceStatus: "Available",
      imageSrc: images.artwork4,
      imageAlt: "Azure Dream abstract oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "golden-embers",
      title: "Golden Embers",
      artist: "Jeanne Kassab",
      medium: "Oil on Linen",
      dimensions: "20 x 20 inches",
      year: "2023",
      description:
        "A study in warmth and light, 'Golden Embers' glows with rich ochres, oranges, and deep reds. This piece captures the fleeting beauty of a twilight fire or the sun setting over a autumn field, its layered textures adding to the sense of radiant heat and subtle movement. A serene yet powerful presence.",
      priceStatus: "Available",
      imageSrc: images.artwork5,
      imageAlt: "Golden Embers oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "silent-peak",
      title: "Silent Peak",
      artist: "Jeanne Kassab",
      medium: "Oil on Canvas",
      dimensions: "30 x 30 inches",
      year: "2022",
      description:
        "Capturing the stark beauty of a mountain landscape, 'Silent Peak' uses a monochromatic palette of greys, blues, and whites to convey solitude and grandeur. The strong composition and subtle textures evoke the rugged terrain and quiet power of untouched nature. This piece offers a moment of profound contemplation.",
      priceStatus: "Available",
      imageSrc: images.artwork6,
      imageAlt: "Silent Peak abstract oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "urban-reflections",
      title: "Urban Reflections",
      artist: "Jeanne Kassab",
      medium: "Mixed Media, Acrylic & Oil",
      dimensions: "24 x 36 inches",
      year: "2024",
      description:
        "A departure into the urban landscape, 'Urban Reflections' captures the dynamic energy of city lights and bustling streets. Bold strokes and vibrant colors refract across the canvas, reminiscent of rain-slicked pavements and neon glow. It's a modern, energetic piece that pulsates with metropolitan life.",
      priceStatus: "Available",
      imageSrc: images.artwork7,
      imageAlt: "Urban Reflections mixed media painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "forests-embrace",
      title: "Forest's Embrace",
      artist: "Jeanne Kassab",
      medium: "Oil on Canvas",
      dimensions: "28 x 28 inches",
      year: "2023",
      description:
        "'Forest's Embrace' draws the viewer into the deep, calming heart of an ancient woods. Rich, layered greens and browns create a dense canopy effect, with hints of light filtering through. The textures add a tangible sense of moss and bark, inviting one to feel the cool, quiet beauty of the forest.",
      priceStatus: "Available",
      imageSrc: images.artwork8,
      imageAlt: "Forest's Embrace oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "serene-waters",
      title: "Serene Waters",
      artist: "Jeanne Kassab",
      medium: "Oil on Birch Panel",
      dimensions: "18 x 24 inches",
      year: "2024",
      description:
        "A peaceful exploration of water, 'Serene Waters' captures the gentle movement and reflective quality of a placid lake or calm ocean. Soft blues, greys, and hints of white converge to create a tranquil scene, offering a sense of escape and quiet contemplation. Ideal for spaces seeking a relaxing atmosphere.",
      priceStatus: "Available",
      imageSrc: images.artwork9,
      imageAlt: "Serene Waters oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "desert-bloom",
      title: "Desert Bloom",
      artist: "Jeanne Kassab",
      medium: "Acrylic and Oil on Canvas",
      dimensions: "24 x 30 inches",
      year: "2023",
      description:
        "'Desert Bloom' is an ode to the unexpected life and vibrant colors found in arid landscapes. Featuring earthy tones punctuated by bursts of unexpected flora, the painting celebrates resilience and beauty. The contrasting textures of sand and soft petals create a compelling visual narrative.",
      priceStatus: "Available",
      imageSrc: images.artwork10,
      imageAlt: "Desert Bloom mixed media painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "cloudscape-symphony",
      title: "Cloudscape Symphony",
      artist: "Jeanne Kassab",
      medium: "Oil on Canvas",
      dimensions: "40 x 60 inches",
      year: "2024",
      description:
        "A grand, expansive piece, 'Cloudscape Symphony' captures the drama and majesty of a vast sky. Dynamic swirls of whites, grays, and subtle blues evoke towering clouds and infinite space. This piece is a powerful focal point, bringing the grandeur of the heavens indoors.",
      priceStatus: "Price upon request",
      imageSrc: images.hero, // Using hero as an example for large piece
      imageAlt: "Cloudscape Symphony large oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
    {
      id: "sunrise-over-wadi",
      title: "Sunrise Over Wadi",
      artist: "Jeanne Kassab",
      medium: "Oil on Linen",
      dimensions: "24 x 48 inches",
      year: "2023",
      description:
        "Witness the tranquil beauty of morning light breaking over a desert wadi. 'Sunrise Over Wadi' employs a soft, warm palette to create a serene and inspiring atmosphere. The brushwork hints at ancient rock formations and the gentle flow of water, a timeless landscape captured in oil.",
      priceStatus: "Available",
      imageSrc: images.card2, // Using card2 as an example for another artwork
      imageAlt: "Sunrise Over Wadi oil painting",
      whatsAppNumber: "+12345678900",
      status: "Available",
    },
  ],
  contacts: {
    whatsAppNumber: "+12345678900",
    email: "info@jeannekassab.art",
  },
  artistBio: {
    title: "The Artist's Journey",
    quote: "My art is a journey into the soul of the landscape, where color and texture converge to tell a story.",
    paragraph1:
      "Jeanne Kassab is a Lebanese-Canadian artist known for her deeply textured abstract landscapes and layered oil paintings. Her work explores the intricate connections between memory, emotion, and the natural world, transforming familiar vistas into realms of vibrant abstraction. Raised amidst the rich cultural tapestry of Beirut and later shaped by the expansive Canadian wilderness, Jeanne's art is a dialogue between urban complexity and natural serenity.",
    paragraph2:
      "With a background in architecture, Jeanne brings a unique understanding of space, light, and form to her canvases. This structural sensibility is intuitively woven with a passion for color and organic textures, resulting in artworks that are both emotionally resonant and visually compelling. Each piece in The Kassab Collection Canvas is an invitation to pause, reflect, and discover a new perspective.",
    paragraph3:
      "Jeanne’s work has been exhibited in various galleries and private collections across North America and Europe, establishing her as a distinctive voice in contemporary abstract art. She continues to draw inspiration from her travels and the ever-changing beauty of the natural world, bringing new stories and landscapes to life in her studio.",
    imageSrc: images.ambient,
    imageAlt: "Jeanne Kassab working in her studio",
  },
};

export const stats = {
  kpis: [
    {
      label: "New Inquiries",
      value: "3",
      delta: "+1",
      hint: "Last 24 hours",
    },
    {
      label: "Available Works",
      value: "10",
      delta: "",
      hint: "Ready for acquisition",
    },
    {
      label: "Sold This Month",
      value: "2",
      delta: "+1",
      hint: "Compared to last month",
    },
    {
      label: "Website Visits",
      value: "450",
      delta: "+15%",
      hint: "Last 30 days",
    },
  ],
  recentItems: [
    {
      id: "crimson-tide",
      title: "Crimson Tide",
      description: "Available · Inquired by: Sarah Chen",
      imageSrc: images.artwork1,
    },
    {
      id: "whispering-pines",
      title: "Whispering Pines",
      description: "Sold · Pending pickup by Eleanor V.",
      imageSrc: images.artwork3,
    },
    {
      id: "forests-embrace",
      title: "Forest's Embrace",
      description: "Available · Inquired by: David Lee",
      imageSrc: images.artwork8,
    },
    {
      id: "azure-dream",
      title: "Azure Dream",
      description: "Available · Featured on homepage",
      imageSrc: images.artwork4,
    },
    {
      id: "silent-peak",
      title: "Silent Peak",
      description: "Available · New upload (awaiting description)",
      imageSrc: images.artwork6,
    },
    {
      id: "golden-embers",
      title: "Golden Embers",
      description: "Available · Updated pricing",
      imageSrc: images.artwork5,
    },
    {
      id: "serene-waters",
      title: "Serene Waters",
      description: "Available · Uploaded today",
      imageSrc: images.artwork9,
    },
    {
      id: "urban-reflections",
      title: "Urban Reflections",
      description: "Available · AI description generated",
      imageSrc: images.artwork7,
    },
  ],
  activity: [
    {
      title: "New inquiry for 'Crimson Tide'",
      detail: "From WhatsApp, Sarah C. | 10:32 AM",
      when: "Just now",
    },
    {
      title: "Artwork 'Whispering Pines' marked as sold",
      detail: "Updated by Jeanne Kassab | 09:15 AM",
      when: "2 hours ago",
    },
    {
      title: "New artwork uploaded: 'Serene Waters'",
      detail: "Ready for publication | Yesterday",
      when: "Yesterday",
    },
    {
      title: "AI description generated for 'Urban Reflections'",
      detail: "Assisted content creation | Yesterday",
      when: "Yesterday",
    },
    {
      title: "Homepage feature updated for 'Azure Dream'",
      detail: "Curated display change | 2 days ago",
      when: "2 days ago",
    },
    {
      title: "Inquiry follow-up with David L. for 'Forest's Embrace'",
      detail: "Via Email thread | 3 days ago",
      when: "3 days ago",
    },
    {
      title: "Artwork 'Golden Embers' price updated",
      detail: "Price adjustment by Jeanne Kassab | 4 days ago",
      when: "4 days ago",
    },
    {
      title: "Scheduled social post drafted for 'Desert Bloom'",
      detail: "Using AI content assistant | 5 days ago",
      when: "5 days ago",
    },
  ],
  homepageSuggestions: [
    {
      artworkId: "azure-dream",
      title: "Azure Dream",
      reason: "High views last week, striking colors.",
      imageSrc: images.artwork4,
    },
    {
      artworkId: "forests-embrace",
      title: "Forest's Embrace",
      reason: "Recent inquiry, strong collector interest.",
      imageSrc: images.artwork8,
    },
    {
      artworkId: "cloudscape-symphony",
      title: "Cloudscape Symphony",
      reason: "Newest large-scale work, prime for visibility.",
      imageSrc: images.hero,
    },
  ],
};
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
