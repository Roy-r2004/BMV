export const RECIPE_ID = "editorial" as const;
