// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProductShowcase, BrandFooter } from '@/ui';

const SKELETON_ID = "public-catalog" as const;

export default function GalleryPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jane Art"} headline={"Gallery / Collection Page"} subcopy="Cinematic first impression — brand-forward, vivid, and ready for the next step." primaryCta={{ label: "Explore now", href: "#details" }} secondaryCta={{ label: "See how it works", href: "#process" }} imageSrc={images.hero} imageAlt="" />
    ),
    showcase: (
      <ProductShowcase heading="Featured experiences" items={[{ title: "Signature service", description: "A dependable starting point.", imageSrc: images.card1, imageAlt: "" }, { title: "Everyday essential", description: "Built for daily use.", imageSrc: images.card2, imageAlt: "" }]} />
    ),
    footer: (
      <BrandFooter brandName={"Jane Art"} description="Premium presence from first glance to booked revenue." />
    ),
  };

  return (
    <PublicShell brandName={"Jane Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
