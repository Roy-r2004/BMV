// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, DataTable, ActivityFeed } from '@/ui';

const SKELETON_ID = "ops-detail" as const;

export default function AdminArtworkEditPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={"Admin Artwork Edit"} description="A current view of the work that needs your attention." meta={<span className="text-sm text-muted">Today</span>} />
    ),
    table: (
      <DataTable columns={[{ key: "name", header: "Name" }, { key: "status", header: "Status" }, { key: "updated", header: "Updated" }]} rows={[{ name: "Primary record", status: "In progress", updated: "Today" }, { name: "Follow-up item", status: "On hold", updated: "Yesterday" }, { name: "Completed item", status: "Done", updated: "2 days ago" }]} />
    ),
    activity: (
      <ActivityFeed heading="Activity" items={[{ id: "activity-1", title: "Record updated", detail: "The latest details are ready.", time: "Just now" }, { id: "activity-2", title: "Owner assigned", detail: "Waiting on confirmation.", time: "12m ago" }, { id: "activity-3", title: "Note added", detail: "Customer asked for a callback.", time: "1h ago" }]} />
    ),
  };

  return (
    <OpsShell brandName={"Jane Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}
