// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;

export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={"Admin Dashboard"} description="A current view of the work that needs your attention." meta={<span className="text-sm text-muted">Today</span>} />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3"><StatCard label="Active today" value="24" delta="+8%" hint="Compared with last week" /><StatCard label="In progress" value="11" delta="+2" hint="Open work items" /><StatCard label="Resolved" value="93%" delta="-2%" hint="Rolling 7-day rate" /></div>
    ),
    chart: (
      <ChartCard title="Weekly performance" type="area" dataKey="value" xKey="day" data={[{ day: "Mon", value: 12 }, { day: "Tue", value: 18 }, { day: "Wed", value: 15 }, { day: "Thu", value: 22 }, { day: "Fri", value: 19 }]} />
    ),
    filters: (
      <FilterBar searchPlaceholder="Search records" filters={[{ id: "all", label: "All", active: true }, { id: "open", label: "Open", active: false }]} />
    ),
    table: (
      <DataTable columns={[{ key: "name", header: "Name" }, { key: "status", header: "Status" }, { key: "updated", header: "Updated" }]} rows={[{ name: "Primary record", status: "In progress", updated: "Today" }, { name: "Follow-up item", status: "On hold", updated: "Yesterday" }, { name: "Completed item", status: "Done", updated: "2 days ago" }]} />
    ),
    activity: (
      <ActivityFeed heading="Activity" items={[{ id: "activity-1", title: "Record updated", detail: "The latest details are ready.", time: "Just now" }, { id: "activity-2", title: "Owner assigned", detail: "Waiting on confirmation.", time: "12m ago" }, { id: "activity-3", title: "Note added", detail: "Customer asked for a callback.", time: "1h ago" }]} />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jane Art"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id}>{main}</div>
    </OpsShell>
  );
}
