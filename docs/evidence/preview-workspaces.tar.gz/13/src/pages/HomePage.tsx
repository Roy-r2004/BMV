// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, ProductShowcase, ProcessSection, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jane Art"} headline={"Home Page"} subcopy="Cinematic first impression — brand-forward, vivid, and ready for the next step." primaryCta={{ label: "Explore now", href: "#details" }} secondaryCta={{ label: "See how it works", href: "#process" }} imageSrc={images.hero} imageAlt="" />
    ),
    features: (
      <FeatureBento heading="Designed to feel alive" items={[{ title: "Immersive first view", description: "Atmosphere, motion, and brand color from the first scroll." }, { title: "Real product moments", description: "Concrete screens — bookings, tickets, KPIs — not placeholder cards." }, { title: "Guided next step", description: "Every section pushes toward a clear action." }]} />
    ),
    showcase: (
      <ProductShowcase heading="Featured experiences" items={[{ title: "Signature service", description: "A dependable starting point.", imageSrc: images.card1, imageAlt: "" }, { title: "Everyday essential", description: "Built for daily use.", imageSrc: images.card2, imageAlt: "" }]} />
    ),
    process: (
      <ProcessSection heading="How it works" steps={[{ title: "Choose", description: "Find the right option." }, { title: "Confirm", description: "Select a convenient time." }, { title: "Enjoy", description: "We take care of the details." }]} />
    ),
    testimonials: (
      <TestimonialRail heading="What clients say" items={[{ quote: "Clear, warm, and easy from start to finish.", author: "A returning client", role: "Verified guest" }]} />
    ),
    cta: (
      <CTABand heading="Make it unforgettable" description="Book the next chapter — polished, branded, never bland." primaryCta={{ label: "Get started", href: "#details" }} secondaryCta={{ label: "Talk to us", href: "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jane Art"} description="Premium presence from first glance to booked revenue." />
    ),
  };

  return (
    <PublicShell brandName={"Jane Art"} chrome="immersive" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
