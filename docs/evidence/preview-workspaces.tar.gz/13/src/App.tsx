import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutPage from './pages/AboutPage';
import AdminAboutEditPage from './pages/role-admin/AdminAboutEditPage';
import AdminArtworkEditPage from './pages/role-admin/AdminArtworkEditPage';
import AdminDashboardPage from './pages/role-admin/AdminDashboardPage';
import ContactPage from './pages/ContactPage';
import GalleryPage from './pages/GalleryPage';
import HomePage from './pages/HomePage';
import PaintingDetailPage from './pages/PaintingDetailPage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/contact');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/gallery/v2" element={<PaintingDetailPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/admin/artworks/edit" element={<AdminArtworkEditPage />} />
          <Route path="/admin/about/edit" element={<AdminAboutEditPage />} />
          <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}