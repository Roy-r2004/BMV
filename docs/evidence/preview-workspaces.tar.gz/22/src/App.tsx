import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutPage from './pages/AboutPage';
import AdminArtworkAddPage from './pages/role-artist/AdminArtworkAddPage';
import AdminArtworkListPage from './pages/role-artist/AdminArtworkListPage';
import AdminDashboardPage from './pages/role-artist/AdminDashboardPage';
import AdminLoginPage from './pages/role-artist/AdminLoginPage';
import ArtworkDetailPage from './pages/ArtworkDetailPage';
import GalleryPage from './pages/GalleryPage';
import HomePage from './pages/HomePage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/artwork" element={<ArtworkDetailPage />} />
          <Route path="/gallery/:id" element={<ArtworkDetailPage />} />
          <Route path="/gallery/:slug" element={<ArtworkDetailPage />} />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
          <Route path="/admin/artworks" element={<AdminArtworkListPage />} />
          <Route path="/admin/:id" element={<AdminArtworkListPage />} />
          <Route path="/admin/:slug" element={<AdminArtworkListPage />} />
          <Route path="/admin/artworks/add" element={<AdminArtworkAddPage />} />
          <Route path="/admin/artworks/:id" element={<AdminArtworkAddPage />} />
          <Route path="/admin/artworks/:slug" element={<AdminArtworkAddPage />} />
          <Route path="/about" element={<AboutPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}