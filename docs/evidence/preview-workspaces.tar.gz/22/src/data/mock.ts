export const brand = {
  name: "Jeanne Kassab Art",
  tagline: "Original abstract landscapes and atelier works for collectors.",
  accent: "#0f766e",
  accent_dark: "#0d635c",
  accent_light: "#e0f2f1",
  font: "Source Sans 3",
  owner_name: "Jeanne",
  testimonials: [
    {
      name: "Layla Mansour",
      initials: "LM",
      text: "Jeanne's art transformed my living space. The online gallery made browsing a joy, and the inquiry process was seamless.",
      service: "Original Abstract Painting",
    },
    {
      name: "Karim Semaan",
      initials: "KS",
      text: "As a collector, I appreciate the serene presentation of her work. Each piece tells a story, and the WhatsApp direct contact is excellent.",
      service: "Abstract Landscape Collection",
    },
    {
      name: "Nadia Haddad",
      initials: "NH",
      text: "Finding unique art for my home office was a challenge until I discovered Jeanne's online atelier. The quality and detail are stunning.",
      service: "Atelier Work",
    },
  ],
  social_proof: "Trusted by collectors across Lebanon and beyond.",
  design_system: {
    primary_color: "#0f766e",
    secondary_color: "#0369a1",
    background_color: "#f8fafc",
    surface_color: "#ffffff",
    text_color: "#042f2e",
    muted_text_color: "#5f7a78",
    font_family: "Source Sans 3",
    display_font_family: "Fraunces",
    font_import_url:
      "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
    font_display: '"Fraunces", Georgia, serif',
    brand_locked: true,
    brand_brief_version: "1.0",
    mood: "modern",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature: "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.",
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    recipe_id: "editorial",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    recipe_prompt:
      "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    style_keywords: "Editorial · Calm air",
    border_radius: "0.97rem",
    design_overlay_id: "calm_air",
    design_overlay_label: "Calm air",
    design_overlay_blurb: "Airy clinical calm — soft surfaces, quiet type, low density.",
    density: "airy",
    token_overrides: {
      radius_ui: "0.97rem",
      bg_mix: "3%",
      fg_mix: "38%",
      muted_mix: "28%",
      border_mix: "12%",
      shadow: "0 28px 56px -40px",
      shadow_alpha: "22%",
      glow: "4%",
      card: "#ffffff",
      atmosphere:
        "radial-gradient(90% 55% at 8% -5%, color-mix(in srgb, var(--color-brand) 9%, transparent), transparent 58%), linear-gradient(180deg, #fbfcfd 0%, color-mix(in srgb, var(--color-brand) 3%, #f5f7f9) 55%, #f8fafb 100%)",
    },
    font_import: "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;1,700",
    design_brief_version: "1.0",
    design_brief_sealed: true,
  },

  services: [{"name": "Jeanne Kassab Art", "title": "Jeanne Kassab Art", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
};

export const images = {
  "hero": "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1400&q=80&fit=crop&auto=format",
  "hero2": "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=700&q=80&fit=crop&auto=format",
  "card1": "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=700&q=80&fit=crop&auto=format",
  "card2": "https://images.unsplash.com/photo-1482160549825-59d1b23cb208?w=700&q=80&fit=crop&auto=format",
  "card3": "https://images.unsplash.com/photo-1549490349-8643362247b5?w=900&q=80&fit=crop&auto=format",
  "ambient": "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=1400&q=80&fit=crop&auto=format"
};

export const roles = [
  {
    "id": "ROLE-COLLECTOR",
    "label": "Art Collector",
    "defaultPath": "/",
    "icon": "image"
  },
  {
    "id": "ROLE-ARTIST",
    "label": "Jeanne Kassab (Artist)",
    "defaultPath": "/admin/dashboard",
    "icon": "artboard"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    },
    {
      "id": "artwork",
      "path": "/artwork",
      "href": "/artwork",
      "label": "Artwork"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    }
  ],
  "admin": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-artworks",
      "path": "/admin/artworks",
      "href": "/admin/artworks",
      "label": "Admin Artwork List"
    },
    {
      "id": "admin-artworks-add",
      "path": "/admin/artworks/add",
      "href": "/admin/artworks/add",
      "label": "Admin Artwork Add"
    }
  ],
  "ROLE-COLLECTOR": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    },
    {
      "id": "artwork",
      "path": "/artwork",
      "href": "/artwork",
      "label": "Artwork"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    }
  ],
  "ROLE-ARTIST": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-artworks",
      "path": "/admin/artworks",
      "href": "/admin/artworks",
      "label": "Admin Artwork List"
    },
    {
      "id": "admin-artworks-add",
      "path": "/admin/artworks/add",
      "href": "/admin/artworks/add",
      "label": "Admin Artwork Add"
    }
  ]
};

export const seed = {
  hero: {
    eyebrow: "Jeanne Kassab Art",
    headline: "Capturing the Essence of Landscape",
    subcopy: "Explore original oil paintings that evoke emotion and bring serene beauty to your space.",
    primaryCta: { label: "View Gallery", href: "/gallery" },
    secondaryCta: { label: "About the Artist", href: "/about" },
  },
  credentialsHeading: "Trusted by Collectors",
  credentials: [
    { title: "20+ Years", description: "Experience in oil painting and fine art." },
    { title: "Worldwide", description: "Collections shipped to international homes." },
    { title: "Unique", description: "Each piece is an original, one-of-a-kind creation." },
  ],
  featuresHeading: "Experience Jeanne Kassab's Art",
  features: [
    {
      name: "Browse Original Works",
      description: "Explore Jeanne Kassab's latest abstract landscapes and atelier pieces.",
      badge: "View Gallery",
      image: images.card1,
    },
    {
      name: "Artwork Details & Inspiration",
      description: "Understand the story, dimensions, and medium behind each unique painting.",
      badge: "Learn More",
      image: images.card2,
    },
    {
      name: "Direct Inquiries via WhatsApp",
      description: "Connect personally with Jeanne Kassab about artworks of interest.",
      badge: "Inquire Now",
      image: images.card3,
    },
  ],
  showcaseHeading: "Recently Featured Works",
  items: [
    {
      id: "desert-bloom",
      slug: "desert-bloom",
      title: "Desert Bloom",
      description: "A vibrant abstract capturing the ephemeral beauty of desert flora after rain.",
      medium: "Oil on canvas",
      dimensions: "120 x 90 cm (47 x 35 inches)",
      year: "2023",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=700&q=80&fit=crop&auto=format",
    },
    {
      id: "coastal-embrace",
      slug: "coastal-embrace",
      title: "Coastal Embrace",
      description: "An evocative landscape reflecting the serene meeting of land and sea.",
      medium: "Oil on linen",
      dimensions: "100 x 100 cm (39 x 39 inches)",
      year: "2022",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1482160549825-59d1b23cb208?w=700&q=80&fit=crop&auto=format",
    },
    {
      id: "morning-mist",
      slug: "morning-mist",
      title: "Morning Mist",
      description: "Soft hues and fluid forms depict the tranquility of a misty dawn.",
      medium: "Oil on wood panel",
      dimensions: "80 x 60 cm (31 x 24 inches)",
      year: "2023",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1549490349-8643362247b5?w=900&q=80&fit=crop&auto=format",
    },
    {
      id: "urban-reflections",
      slug: "urban-reflections",
      title: "Urban Reflections",
      description: "An abstract interplay of light and shadow in a city landscape.",
      medium: "Oil on canvas",
      dimensions: "70 x 70 cm (27 x 27 inches)",
      year: "2021",
      status: "Sold",
      imageSrc: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1400&q=80&fit=crop&auto=format",
    },
    {
      id: "whispering-woods",
      slug: "whispering-woods",
      title: "Whispering Woods",
      description: "Nature's quiet symphony, captured through dynamic brushstrokes.",
      medium: "Oil on canvas",
      dimensions: "110 x 80 cm (43 x 31 inches)",
      year: "2022",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=1400&q=80&fit=crop&auto=format",
    },
  ],
  testimonialsHeading: "What Collectors Say",
  cta: {
    heading: "Ready to acquire an original work?",
    description: "Connect directly with Jeanne Kassab to discuss commissions, availability, and collecting her unique pieces.",
    primaryLabel: "Inquire Now",
    primaryHref: "https://wa.me/15551234567?text=Hello%20Jeanne%2C%20I%20am%20interested%20in%20your%20artworks.", // Replace with actual WhatsApp link
    secondaryLabel: "Explore All Works",
    secondaryHref: "/gallery",
  },
  footer: {
    description: "Jeanne Kassab Art — bringing peace and beauty through abstract expression.",
  },
  otherMetrics: [
    {
      label: "Commissions in Progress",
      value: "3",
      delta: "+1 started this month",
      hint: "Custom artwork requests.",
    },
  ],
  artworks: [
    {
      id: "desert-bloom",
      title: "Desert Bloom",
      medium: "Oil on canvas",
      dimensions: "120 x 90 cm (47 x 35 inches)",
      year: "2023",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=700&q=80&fit=crop&auto=format",
      description: "A vibrant abstract capturing the ephemeral beauty of desert flora after rain. This piece explores the resilience and delicate beauty found in unexpected places, with layers of color building a sense of depth and hope.",
    },
    {
      id: "coastal-embrace",
      title: "Coastal Embrace",
      medium: "Oil on linen",
      dimensions: "100 x 100 cm (39 x 39 inches)",
      year: "2022",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1482160549825-59d1b23cb208?w=700&q=80&fit=crop&auto=format",
      description: "An evocative landscape reflecting the serene meeting of land and sea. The painting captures the gentle power of ocean currents meeting a rugged coastline, rendered in calming blues and earthy tones.",
    },
    {
      id: "morning-mist",
      title: "Morning Mist",
      medium: "Oil on wood panel",
      dimensions: "80 x 60 cm (31 x 24 inches)",
      year: "2023",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1549490349-8643362247b5?w=900&q=80&fit=crop&auto=format",
      description: "Soft hues and fluid forms depict the tranquility of a misty dawn. This piece is an ode to the quiet moments just before the world awakens, inviting contemplation and peace.",
    },
    {
      id: "urban-reflections",
      title: "Urban Reflections",
      medium: "Oil on canvas",
      dimensions: "70 x 70 cm (27 x 27 inches)",
      year: "2021",
      status: "Sold",
      imageSrc: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1400&q=80&fit=crop&auto=format",
      description: "An abstract interplay of light and shadow in a bustling city landscape, capturing the energy and fleeting beauty of urban life. This piece has found a new home.",
    },
    {
      id: "whispering-woods",
      title: "Whispering Woods",
      medium: "Oil on canvas",
      dimensions: "110 x 80 cm (43 x 31 inches)",
      year: "2022",
      status: "Sold",
      imageSrc: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=1400&q=80&fit=crop&auto=format",
      description: "Nature's quiet symphony, captured through dynamic brushstrokes that convey light filtering through dense canopies. This painting is now part of a private collection.",
    },
    {
      id: "serene-harbor",
      title: "Serene Harbor",
      medium: "Oil on canvas",
      dimensions: "90 x 90 cm (35 x 35 inches)",
      year: "2023",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=700&q=80&fit=crop&auto=format",
      description: "A peaceful depiction of a harbor at dusk, with gentle reflections on calming waters. This piece evokes a sense of tranquility and homecoming.",
    },
    {
      id: "mountain-solitude",
      title: "Mountain Solitude",
      medium: "Oil on wood panel",
      dimensions: "75 x 50 cm (30 x 20 inches)",
      year: "2023",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1482160549825-59d1b23cb208?w=700&q=80&fit=crop&auto=format",
      description: "The majesty and quietude of mountain peaks against a vast sky, painted with a blend of abstract forms and evocative colors. Ideal for a contemplative space.",
    },
    {
      id: "golden-hour-field",
      title: "Golden Hour Field",
      medium: "Oil on canvas",
      dimensions: "130 x 100 cm (51 x 39 inches)",
      year: "2022",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1549490349-8643362247b5?w=900&q=80&fit=crop&auto=format",
      description: "Capturing the warm, ethereal light of late afternoon over an expansive field, with abstract textures inviting a sense of peace and warmth.",
    },
    {
      id: "river-journey",
      title: "River Journey",
      medium: "Mixed media on canvas",
      dimensions: "110 x 140 cm (43 x 55 inches)",
      year: "2023",
      status: "Available",
      imageSrc: "https://images.unsplash.com/photo-1549490349-8643362247b5?q=80&w=2940&auto=format&fit=crop",
      description: "An abstract interpretation of a winding river's path, symbolizing life's continuous flow and discovery. Features layers of texture and an earthy palette.",
    },
    {
      id: "autumn-hues",
      title: "Autumn Hues",
      medium: "Oil on canvas",
      dimensions: "90 x 70 cm (35 x 27 inches)",
      year: "2021",
      status: "Sold",
      imageSrc: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1400&q=80&fit=crop&auto=format",
      description: "A vibrant explosion of fall colors, capturing the transient beauty of autumn. This energetic piece was sold to a private collector in Beirut.",
    },
  ]
};

export const stats = [
  { label: "Total Artworks", value: "28", change: "+2 new this month" },
  { label: "Available for Sale", value: "18", change: "" },
  { label: "WhatsApp Inquiries", value: "9", change: "+3 this week" },
  { label: "Website Visitors (30 days)", value: "734", change: "+15% from last month" },
];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
