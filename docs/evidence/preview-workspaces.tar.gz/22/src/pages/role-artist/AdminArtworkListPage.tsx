import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Select, Input } from '@/ui';

const SKELETON_ID = "ops-list" as const;

export default function AdminArtworkListPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const artworkData = [
    {
      id: "desert-horizon",
      image: "/images/admin-thumb-1.jpg",
      title: "Desert Horizon",
      medium: "Oil on Linen",
      dimensions: "48 x 36 in",
      year: "2023",
      status: "Available",
      date_added: "2023-11-01",
      edit_link: "/admin/artworks/edit/desert-horizon",
      delete_action: "delete-desert-horizon"
    },
    {
      id: "auburn-sands",
      image: "/images/admin-thumb-2.jpg",
      title: "Auburn Sands",
      medium: "Oil on Canvas",
      dimensions: "30 x 40 in",
      year: "2022",
      status: "Available",
      date_added: "2023-10-15",
      edit_link: "/admin/artworks/edit/auburn-sands",
      delete_action: "delete-auburn-sands"
    },
    {
      id: "coastal-embrace",
      image: "/images/admin-thumb-3.jpg",
      title: "Coastal Embrace",
      medium: "Oil on Board",
      dimensions: "24 x 24 in",
      year: "2021",
      status: "Sold",
      date_added: "2023-09-20",
      edit_link: "/admin/artworks/edit/coastal-embrace",
      delete_action: "delete-coastal-embrace"
    }
  ];

  const slots = {
    header: (
      <PageHeader
        title="Your Collection"
        description="Overview of all paintings in your gallery."
        actions={[
          <Button key="new-artwork" href="/admin/artworks/new" data-appspec-evidence="EVIDENCE-ADMIN-ADD-ARTWORK-BUTTON" data-appspec-action="ACTION-ADD-ARTWORK">
            New Artwork
          </Button>
        ]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search by title, medium..."
        actions={[
          <Select
            key="status-filter"
            options={[
              { value: "All", label: "All" },
              { value: "Available", label: "Available" },
              { value: "Sold", label: "Sold" },
              { value: "Draft", label: "Draft" },
            ]}
            placeholder="Status"
          />
        ]}
      />
    ),
    table: (
      <DataTable
        data-appspec-evidence="EVIDENCE-ADMIN-ARTWORK-TABLE"
        columns={[
          {
            key: "image",
            header: "Image",
            render: (row) => (
              <img src={row.image} alt={row.title} className="h-10 w-10 object-cover rounded-sm" />
            )
          },
          { key: "title", header: "Title" },
          { key: "medium", header: "Medium" },
          { key: "dimensions", header: "Dimensions" },
          { key: "year", header: "Year" },
          { key: "status", header: "Status" },
          { key: "date_added", header: "Date Added" },
          {
            key: "actions",
            header: "Actions",
            render: (row) => (
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" href={row.edit_link} data-appspec-action="ACTION-EDIT-ARTWORK">
                  Edit
                </Button>
                <Button variant="destructive" size="sm" onClick={() => console.log('Delete:', row.id)}>
                  Delete
                </Button>
              </div>
            )
          },
        ]}
        rows={artworkData}
        emptyMessage="No artworks found. Start by adding a new piece."
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ADMIN-ARTWORK-LIST">
        <span className="sr-only" data-appspec-action="ACTION-ADD-ARTWORK">ACTION-ADD-ARTWORK</span>
        <span className="sr-only" data-appspec-action="ACTION-EDIT-ARTWORK">ACTION-EDIT-ARTWORK</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ADMIN-ARTWORK-TABLE">EVIDENCE-ADMIN-ARTWORK-TABLE</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ADMIN-ADD-ARTWORK-BUTTON">EVIDENCE-ADMIN-ADD-ARTWORK-BUTTON</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}