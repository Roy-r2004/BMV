import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, Button } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Atelier Hub"}
        description={"Welcome, Jeanne."}
        meta={<span className="text-sm text-muted">{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</span>}
        actions={
          <Button
            href="/admin/artworks/new"
            data-appspec-action="ACTION-NAV-ADMIN-ADD-ARTWORK"
            data-appspec-evidence="EVIDENCE-ADMIN-DASHBOARD-MENU"
          >
            Add New Artwork
          </Button>
        }
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {/* Available Pieces */}
        <StatCard
          label="Available Pieces"
          value="18"
          delta="+2 new this month"
          hint="Paintings currently listed as 'Available'"
          variant="card"
        />
        {/* Website Visits */}
        <StatCard
          label="Website Visits"
          value="734"
          delta="+15% last 7 days"
          hint="Unique visitors to jeannekassab.art"
          variant="card"
        />
        {/* WhatsApp Inquiries (unread) */}
        <StatCard
          label="WhatsApp Inquiries"
          value="9"
          delta="0 unread"
          hint="Direct inquiries about artworks"
          variant="card"
        />
        {/* Optional: Recent Inquiries Snippet mapped to a KPI for display */}
        {seed.otherMetrics?.[0] && (
          <StatCard
            label={seed.otherMetrics[0].label}
            value={seed.otherMetrics[0].value}
            delta={seed.otherMetrics[0].delta}
            hint={seed.otherMetrics[0].hint}
            variant="card"
          />
        )}
      </div>
    ),
    chart: (
      <ChartCard
        title="Website Visits last 7 days"
        type="area"
        dataKey="value"
        xKey="day"
        data={[
          { day: "Sun", value: 80 },
          { day: "Mon", value: 120 },
          { day: "Tue", value: 150 },
          { day: "Wed", value: 130 },
          { day: "Thu", value: 170 },
          { day: "Fri", value: 100 },
          { day: "Sat", value: 90 },
        ]}
        description="Daily unique visitors"
        insight="Peaked mid-week with new collection announcement."
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Find artwork or activity..."
        filters={[
          { id: "all", label: "All Activity", active: true },
          { id: "artworks", label: "Artworks Modified", active: false },
          { id: "inquiries", label: "Inquiries", active: false },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "from", header: "From" },
          { key: "message_snippet", header: "Message Snippet" },
          { key: "time", header: "Time" },
          { key: "action", header: "Action" },
        ]}
        rows={[
          {
            from: "Layla K.",
            message_snippet: "Interested in 'Azure Depths'...",
            time: "15 min ago",
            action: <Button variant="ghost" size="sm" href="/admin/inbox/layla-k" data-appspec-action="ACTION-VIEW-INQUIRY">View</Button>,
          },
          {
            from: "Omar S.",
            message_snippet: "Is 'Coastal Embrace' still available?",
            time: "2h ago",
            action: <Button variant="ghost" size="sm" href="/admin/inbox/omar-s" data-appspec-action="ACTION-VIEW-INQUIRY">View</Button>,
          },
          {
            from: "Sarah T.",
            message_snippet: "Commission inquiry for a diptych.",
            time: "Yesterday",
            action: <Button variant="ghost" size="sm" href="/admin/inbox/sarah-t" data-appspec-action="ACTION-VIEW-INQUIRY">View</Button>,
          },
        ]}
        emptyMessage="No recent inquiries."
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Artwork Activity"
        items={[
          {
            id: "artwork-activity-1",
            title: "Morning Mist over Beirut",
            detail: "Status: Available",
            time: "Just now",
            actions: (
              <>
                <Button variant="ghost" size="sm" href="/admin/artworks/morning-mist">Edit</Button>
                <a href="/artwork/morning-mist" target="_blank" rel="noopener noreferrer" className="text-brand-primary hover:underline text-sm ml-2">View Public Page</a>
              </>
            )
          },
          {
            id: "artwork-activity-2",
            title: "Desert Bloom",
            detail: "Status: Available",
            time: "2 hours ago",
            actions: (
              <>
                <Button variant="ghost" size="sm" href="/admin/artworks/desert-bloom">Edit</Button>
                <a href="/artwork/desert-bloom" target="_blank" rel="noopener noreferrer" className="text-brand-primary hover:underline text-sm ml-2">View Public Page</a>
              </>
            )
          },
          {
            id: "artwork-activity-3",
            title: "Coastal Embrace",
            detail: "Status: Sold",
            time: "Yesterday",
            actions: (
              <>
                <Button variant="ghost" size="sm" href="/admin/artworks/coastal-embrace">Archive</Button>
                <a href="/artwork/coastal-embrace" target="_blank" rel="noopener noreferrer" className="text-brand-primary hover:underline text-sm ml-2">View Public Page</a>
              </>
            )
          },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems} rail={rail} data-appspec-page="PAGE-ADMIN-DASHBOARD">
      <div className="flex flex-col gap-8">
        <span className="sr-only" data-appspec-action="ACTION-NAV-ADMIN-ARTWORK-LIST">Navigate to Artwork List</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ADMIN-DASHBOARD-MENU">Admin Navigation Menu</span>
        {main}
      </div>
    </OpsShell>
  );
}