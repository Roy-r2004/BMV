// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProductShowcase, BrandFooter } from '@/ui';

const SKELETON_ID = "public-catalog" as const;
export default function GalleryPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jeanne Kassab Art"} headline={"Gallery Catalogue"} subcopy={"Gallery Catalogue — browse what’s here. This page is not the homepage story."} primaryCta={{ label: "View collection", href: "/gallery" }} secondaryCta={{ label: "Back home", href: "/" }} imageSrc={images.card1} imageAlt="" />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Jeanne Kassab Art"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.card1, images.card2, images.card3][index % 3], imageAlt: item.title, href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={seed.footer?.description ?? "Jeanne Kassab Art — clear choices and real bookings."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-GALLERY">

        <span className="sr-only" data-appspec-action="ACTION-VIEW-ARTWORK">ACTION-VIEW-ARTWORK</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-GALLERY-GRID">EVIDENCE-GALLERY-GRID</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-GALLERY-THUMBNAILS">EVIDENCE-GALLERY-THUMBNAILS</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-GALLERY-EMPTY-MESSAGE">EVIDENCE-GALLERY-EMPTY-MESSAGE</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
