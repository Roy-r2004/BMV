// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-service" as const;
const RECIPE_ORDER = ["hero", "features", "testimonials", "cta", "footer"] as const;

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jeanne Kassab Art"} headline={"About Jeanne"} subcopy={"About Jeanne — browse what’s here, the atelier. This page is not the homepage story."} primaryCta={{ label: "View Gallery", href: "/gallery" }} secondaryCta={{ label: "Back home", href: "/" }} imageSrc={images.card1} imageAlt="" />
    ),
    features: (
      <FeatureBento heading={seed.featuresHeading ?? "What Jeanne Kassab Art offers"} imagePool={[images.card1, images.card2, images.card3]} items={seed.features ?? []} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={seed.footer?.description ?? "Jeanne Kassab Art — clear choices and real bookings."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ABOUT">

        <span className="sr-only" data-appspec-evidence="EVIDENCE-ABOUT-CONTENT">EVIDENCE-ABOUT-CONTENT</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}
