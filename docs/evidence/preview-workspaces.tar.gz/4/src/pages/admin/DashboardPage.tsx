// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable } from '@/ui';

const SKELETON_ID = "ops-list" as const;

export default function DashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={"Admin Dashboard"} description="A current view of the work that needs your attention." meta={<span className="text-sm text-muted">Today</span>} />
    ),
    filters: (
      <FilterBar searchPlaceholder="Search records" filters={[{ id: "all", label: "All", active: true }, { id: "open", label: "Open", active: false }]} />
    ),
    table: (
      <DataTable columns={[{ key: "name", header: "Name" }, { key: "status", header: "Status" }, { key: "updated", header: "Updated" }]} rows={[{ name: "Primary record", status: "In progress", updated: "Today" }, { name: "Follow-up item", status: "On hold", updated: "Yesterday" }, { name: "Completed item", status: "Done", updated: "2 days ago" }]} />
    ),
  };

  return (
    <OpsShell brandName={"Jane Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}
