// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader } from '@/ui';

const SKELETON_ID = "ops-settings" as const;

export default function LoginPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={"Admin Login"} description="A current view of the work that needs your attention." meta={<span className="text-sm text-muted">Today</span>} />
    ),
  };

  return (
    <OpsShell brandName={"Jane Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}
