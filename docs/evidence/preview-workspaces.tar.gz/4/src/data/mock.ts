export const brand = {"name": "Jane Art", "tagline": "",
  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  services: [{"name": "Jane Art Signature", "title": "Jane Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jane Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jane Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jane", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jane Art clients.",

  name: "Jane Art",
  tagline: {},
};

export const images = {
  "hero": "https://images.unsplash.com/photo-1553877522-43269d4ea984?w=1400&q=80&fit=crop&auto=format",
  "hero2": "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=1400&q=80&fit=crop&auto=format",
  "card1": "https://images.unsplash.com/photo-1497366216548-37526070297c?w=700&q=80&fit=crop&auto=format",
  "card2": "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=700&q=80&fit=crop&auto=format",
  "card3": "https://images.unsplash.com/photo-1552664730-d307ca884978?w=700&q=80&fit=crop&auto=format",
  "ambient": "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=900&q=80&fit=crop&auto=format"
};

export const roles = [
  {
    "id": "customer",
    "label": "Collector",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "admin",
    "label": "Admin",
    "defaultPath": "/admin",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Jane Art - Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery - Jane Art"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Jane Art"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Jane Art"
    }
  ],
  "admin": [
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login"
    },
    {
      "id": "admin-paintings-new",
      "path": "/admin/paintings/new",
      "href": "/admin/paintings/new",
      "label": "Add New Painting"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Jane Art - Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery - Jane Art"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Jane Art"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Jane Art"
    }
  ]
};

// build-correctness guard: auto-added missing exports
export const stats = [{"id": "stats-1", "name": "stats 1", "title": "stats 1", "label": "stats 1", "status": "In progress", "detail": "Sample Jane Art record for demo lists", "amount": 52, "count": 4}, {"id": "stats-2", "name": "stats 2", "title": "stats 2", "label": "stats 2", "status": "Done", "detail": "Sample Jane Art record for demo lists", "amount": 64, "count": 5}, {"id": "stats-3", "name": "stats 3", "title": "stats 3", "label": "stats 3", "status": "Scheduled", "detail": "Sample Jane Art record for demo lists", "amount": 76, "count": 6}, {"id": "stats-4", "name": "stats 4", "title": "stats 4", "label": "stats 4", "status": "Open", "detail": "Sample Jane Art record for demo lists", "amount": 88, "count": 7}];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
