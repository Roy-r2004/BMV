// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProductShowcase, BrandFooter, Button, CredentialStrip, TestimonialRail, CTABand } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

const artworks = [
  {
    id: 'azure-depths',
    title: 'Azure Depths',
    medium: 'Oil on Canvas',
    dimensions: '36 x 48 inches',
    availability: 'Available',
    mainImage: images.artwork1_main,
    altImages: [
      images.artwork1_detail1,
      images.artwork1_detail2,
      images.artwork1_room,
    ],
    description: 'A captivating abstract landscape, "Azure Depths" invites the viewer into a realm of tranquil blues and greens. The painting explores the interplay of light and shadow on an imagined horizon, evoking the vastness and mystery of the ocean.',
  },
  {
    id: 'whispers-of-the-horizon',
    title: 'Whispers of the Horizon',
    medium: 'Layered Oils on Wood Panel',
    dimensions: '24 x 30 inches',
    availability: 'Inquire for Availability',
    mainImage: images.artwork2_main,
    altImages: [
      images.artwork2_detail1,
      images.artwork2_detail2,
      images.artwork2_room,
    ],
    description: 'This piece, "Whispers of the Horizon," captures the delicate transition between sky and earth. Layers of muted tones and subtle textures create a sense of ethereal calm, drawing the eye towards a distant, beckoning light.',
  },
  {
    id: 'coastal-mist',
    title: 'Coastal Mist',
    medium: 'Oil on Linen',
    dimensions: '30 x 40 inches',
    availability: 'Sold',
    mainImage: images.artwork3_main,
    altImages: [
      images.artwork3_detail1,
      images.artwork3_detail2,
      images.artwork3_room,
    ],
    description: 'Inspired by the quiet beauty of the morning coast, "Coastal Mist" renders the soft, atmospheric conditions where sky meets sea. The work experiments with translucent layers, creating a dreamlike quality and a feeling of serene solitude.',
  },
];

const currentArtwork = artworks[0];

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={currentArtwork.title}
        subcopy={""}
        primaryCta={undefined}
        secondaryCta={undefined}
        imageSrc={currentArtwork.mainImage}
        imageAlt={`Artwork: ${currentArtwork.title}`}
        className="h-[30vh] lg:h-[40vh] flex items-center justify-center bg-cover bg-center"
        eyebrow="Jeanne Kassab Art"
      />
    ),
    showcase: (
      <ProductShowcase heading={currentArtwork.title} className="py-16 lg:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-12 gap-y-8">
          <div className="lg:col-span-1">
            <img src={currentArtwork.mainImage} alt={currentArtwork.title} className="w-full h-auto object-cover mb-6 shadow-md" />
            <div className="grid grid-cols-3 gap-4">
              {currentArtwork.altImages.map((imgSrc, index) => (
                <img
                  key={index}
                  src={imgSrc}
                  alt={`${currentArtwork.title} - Detail ${index + 1}`}
                  className="w-full h-auto object-cover cursor-pointer hover:opacity-75 transition-opacity duration-200 shadow-sm"
                />
              ))}
            </div>
          </div>
          <div className="lg:col-span-1 flex flex-col justify-start space-y-6">
            <h1 className="font-display text-4xl lg:text-5xl text-text leading-tight">{currentArtwork.title}</h1>
            <p className="text-lg text-muted">{currentArtwork.medium}</p>
            <p className="text-lg text-muted">{currentArtwork.dimensions}</p>
            <p className="text-xl text-text font-semibold">{currentArtwork.availability}</p>
            {currentArtwork.availability !== 'Sold' && (
              <Button
                variant="default"
                size="lg"
                href={`https://wa.me/?text=Hello%20Jeanne%2C%20I'm%20interested%20in%20your%20artwork%20%22${encodeURIComponent(currentArtwork.title)}%22`}
                className="bg-brand text-white hover:bg-brand-dark transition-colors duration-200 max-w-xs"
                target="_blank"
                rel="noopener noreferrer"
              >
                Inquire on WhatsApp
              </Button>
            )}
          </div>
        </div>
      </ProductShowcase>
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={seed.footer?.description ?? "Jeanne Kassab Art — original works, shown plainly."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="artwork-detail">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}