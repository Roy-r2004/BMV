// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        eyebrow={"Original Paintings"}
        headline={"The Serene Canvas"}
        subcopy={"Discover a living gallery of original oil paintings, where abstract landscapes and layered oils evoke calm and contemplation."}
        primaryCta={{ label: "View the Collection", href: "/gallery" }}
        secondaryCta={{ label: "About the Artist", href: "/about" }}
        imageSrc={images.hero}
        imageAlt="An abstract landscape oil painting with soft, layered colors by Jeanne Kassab"
      />
    ),
    credentials: (
      <CredentialStrip
        heading={"Jeanne Kassab Art"}
        items={[
          { icon: "brush", title: "Original Works", description: "Each piece is a unique, hand-painted oil on canvas, ensuring an authentic experience." },
          { icon: "palette", title: "Rich Textures", description: "Layered oil techniques create depth and character in every brushstroke." },
          { icon: "mountains", title: "Abstract Landscapes", description: "Inspired by nature, evoking a sense of peace and expansive beauty." },
        ]}
      />
    ),
    features: (
      <FeatureBento
        heading={"Timeless Art for Contemporary Spaces"}
        description={"Art that speaks to the soul and transforms your environment."}
        imagePool={[images.card1, images.card2, images.card3]}
        items={[
          { title: "Curated Collection", description: "Explore a carefully selected portfolio of Jeanne Kassab's latest works." },
          { title: "Direct from Studio", description: "Acquire original paintings directly, ensuring a personal connection with the art." },
          { title: "Seamless Inquiry", description: "Connect with Jeanne Kassab directly for details, commissions, or acquisitions." },
          { title: "Thoughtful Presentation", description: "Experience artworks presented with generous whitespace and high-resolution detail." },
        ]}
      />
    ),
    showcase: (
      <ProductShowcase
        heading={"Latest Works"}
        description={"A refreshed selection of abstract landscapes and layered oils, always evolving."}
        items={[
          { title: "Whispering Sands I", description: "Layered oils on canvas, 24x36 inches", imageSrc: images.card1, imageAlt: "Abstract painting with warm desert tones", href: "/gallery/whispering-sands-i" },
          { title: "Azure Depths", description: "Oil on linen, 30x40 inches", imageSrc: images.card2, imageAlt: "Abstract painting with deep blue and green hues", href: "/gallery/azure-depths" },
          { title: "Mist Over the Ridge", description: "Textured oils, 18x24 inches", imageSrc: images.card3, imageAlt: "Abstract landscape painting with soft grays and greens", href: "/gallery/mist-over-the-ridge" },
          { title: "Golden Horizon", description: "Oil & cold wax, 36x36 inches", imageSrc: images.card4 ?? images.hero, imageAlt: "Abstract painting with luminous golden and ochre tones", href: "/gallery/golden-horizon" },
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading={"Voices from Collectors"}
        items={[
          { author: "E. Patel, Interior Designer", quote: "Jeanne's work brings such a profound sense of calm and sophistication to any space. Truly a centerpiece." },
          { author: "M. Chen, Collector", quote: "My gallery features her abstract landscapes prominently. They invite reflection and conversation." },
          { author: "A. Ramirez, Art Enthusiast", quote: "The texture and depth in her paintings are incredible. Far more captivating in person." },
        ]}
      />
    ),
    cta: (
      <CTABand
        heading={"Find Your Serene Canvas"}
        description={"Explore the collection or connect with Jeanne Kassab to discuss a piece, a commission, or upcoming exhibitions."}
        primaryCta={{ label: "Browse Paintings", href: "/gallery" }}
        secondaryCta={{ label: "Contact Jeanne", href: "/contact" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings by Jeanne Kassab. Abstract landscapes and layered oils for discerning collectors and inspired spaces."}
        links={[
          { title: "Gallery", href: "/gallery" },
          { title: "About", href: "/about" },
          { title: "Contact", href: "/contact" },
          { title: "Privacy Policy", href: "/privacy" },
        ]}
        meta={"© 2024 Jeanne Kassab Art. All rights reserved."}
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}