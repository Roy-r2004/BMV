import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProductShowcase, BrandFooter, Button, CredentialStrip, TestimonialRail, CTABand } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    hero: (
      <MarketingHero
        brandName="Jeanne Kassab Art"
        headline="Contact Jeanne Kassab"
        subcopy="A direct connection for inquiries and collaborations."
        primaryCta={undefined}
        secondaryCta={undefined}
        imageSrc={undefined} // No distracting imagery
        imageAlt=""
      />
    ),
    showcase: (
      <ProductShowcase heading="Connect with Jeanne" description={undefined}>
        <div className="flex flex-col items-center justify-center space-y-6 p-8 text-center bg-surface">
          <p className="text-lg text-text max-w-lg">
            For inquiries about original works, commissions, or collaborations, please connect directly.
          </p>
          <Button
            href="https://wa.me/MESSAGE_NUMBER" // Replace with Jeanne's WhatsApp number
            target="_blank"
            rel="noopener noreferrer"
            className="bg-brand text-white hover:bg-opacity-90 transition-colors py-3 px-6 rounded-lg text-lg font-semibold"
          >
            Connect on WhatsApp
          </Button>
          <div className="text-text text-md">
            <p className="mt-4">
              Email: <a href="mailto:jeanne.kassab.art@email.com" className="text-brand hover:underline">jeanne.kassab.art@email.com</a>
            </p>
            <p className="mt-2">
              Studio: {seed.location || 'Beirut, Lebanon'}
            </p>
          </div>
        </div>
      </ProductShowcase>
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={"Jeanne Kassab Art — original works, shown plainly."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="contact-page">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}