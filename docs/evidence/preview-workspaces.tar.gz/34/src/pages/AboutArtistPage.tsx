// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

export default function AboutArtistPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jeanne Kassab Art"} headline={"About Jeanne Kassab"} subcopy={"About Jeanne Kassab — browse what’s here. This page is not the homepage story."} primaryCta={{ label: "Inquire about this piece", href: "/about" }} secondaryCta={{ label: "Back home", href: "/" }} imageSrc={images.card1} imageAlt="" />
    ),
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Jeanne Kassab Art"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.card1, images.card2, images.card3][index % 3], imageAlt: item.title, href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={seed.footer?.description ?? "Jeanne Kassab Art — original works, shown plainly."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="about-artist">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}
