// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Button, DataTable, ActivityFeed } from '@/ui';

const SKELETON_ID = "ops-detail" as const;
export default function EditArtworkPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const tableColumns = [
    { key: 'field', label: 'Field' },
    { key: 'value', label: 'Value' }
  ];

  const tableRows = [
    { field: 'Title', value: 'Evening Hues' },
    { field: 'Medium', value: 'Oil on Canvas' },
    { field: 'Dimensions', value: '24x36 inches' },
    { field: 'Availability', value: 'Available' }
  ];

  const activityItems = [
    { id: '1', title: 'Artwork Created', description: 'Artwork was initially added to the catalogue.', timestamp: '2023-01-01T10:00:00Z' },
    { id: '2', title: 'Details Updated', description: 'Medium and dimensions updated.', timestamp: '2023-02-01T14:30:00Z' }
  ];

  const slots = {
    header: (
      <PageHeader
        title="Edit Artwork — The Serene Canvas"
        actions={
          <Button variant="ghost" href="/owner/dashboard">
            Back to Dashboard
          </Button>
        }
      />
    ),
    table: (
      <DataTable columns={tableColumns} rows={tableRows} emptyMessage="No artwork details found" />
    ),
    activity: (
      <ActivityFeed items={activityItems} heading="Artwork History" />
    ),
  };

  return (
    <OpsShell brandName="Jeanne Kassab Art" navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-edit-artwork" className="p-4 md:p-8 lg:p-12 space-y-8 max-w-4xl mx-auto">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />

        <div className="flex justify-end space-x-4">
          <Button variant="ghost" href="/owner/dashboard">Cancel</Button>
          <Button variant="default">Save Changes</Button>
        </div>
      </div>
    </OpsShell>
  );
}