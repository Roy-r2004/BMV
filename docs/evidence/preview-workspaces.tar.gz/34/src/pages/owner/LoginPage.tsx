// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function LoginPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Artist Portal"}
        description={"Access your gallery management tools."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Manage Artworks"}</h3>
            <p className="text-sm leading-6 text-muted">{"Add new paintings, update details, and mark pieces as sold."}</p>
            <Button href={"/owner/artworks"} className="mt-auto w-fit">
              {"Go to Artworks"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Edit About Page"}</h3>
            <p className="text-sm leading-6 text-muted">{"Update your artist statement and biography."}</p>
            <Button href={"/owner/about-edit"} className="mt-auto w-fit">
              {"Edit Profile"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Update Contact Info"}</h3>
            <p className="text-sm leading-6 text-muted">{"Review and revise your contact details."}</p>
            <Button href={"/owner/contact-edit"} className="mt-auto w-fit">
              {"Edit Contact"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"© 2024 Jeanne Kassab Art. All rights reserved."}
      />
    ),
  };

  return (
      <div className="contents" data-appspec-page="admin-login">
      </div>
    <PublicShell
      brandName={"Jeanne Kassab Art"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"account"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
