// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Button, Input } from '@/ui';

const SKELETON_ID = "ops-settings" as const;
export default function EditAboutPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title="Edit About Page — The Serene Canvas"
        actions={
          <Button variant="ghost" href="/owner/dashboard">
            Back to Dashboard
          </Button>
        }
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-edit-about" className="p-4 md:p-8 lg:p-12 space-y-8 max-w-4xl mx-auto">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />

        {/* Workspace: Artist Biography and Artist Statement */}
        <div className="bg-surface p-6 rounded-lg shadow-sm space-y-6">
          <h2 className="text-xl font-display text-text">Artist Biography</h2>
          <Input
            as="textarea"
            rows={10}
            label="Biography"
            placeholder="Introduce yourself, your journey, and your artistic vision."
            defaultValue="Jeanne Kassab is a contemporary artist renowned for her evocative abstract landscapes and intricate layered oil paintings. Her work explores the interplay of light, texture, and emotion, drawing viewers into serene yet dynamic worlds. Each piece is a meditation on nature's subtle beauty, translated through a meticulous process of layering and color blending. Jeanne's art seeks to offer a moment of calm contemplation, inviting collectors to connect deeply with the natural world through her unique visual language."
            className="font-sans"
          />

          <h2 className="text-xl font-display text-text pt-4">Artist Statement</h2>
          <Input
            as="textarea"
            rows={7}
            label="Statement"
            placeholder="Describe the overarching themes and philosophy behind your art."
            defaultValue="My practice is a continuous dialogue with the ephemeral. I am fascinated by the quiet power of nature and the emotional resonance of color. Through layering and texture, I seek to capture moments of stillness and movement, inviting the viewer into a shared space of reflection."
            className="font-sans"
          />
        </div>

        <div className="flex justify-end space-x-4">
          <Button variant="ghost" href="/owner/dashboard">Cancel</Button>
          <Button variant="default">Save Changes</Button>
        </div>
      </div>
    </OpsShell>
  );
}