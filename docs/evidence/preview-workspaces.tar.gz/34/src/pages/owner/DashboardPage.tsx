// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, Button } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function DashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const mainChartData = [
    { month: "Jan", listings: 3, sales: 1 },
    { month: "Feb", listings: 2, sales: 0 },
    { month: "Mar", listings: 4, sales: 2 },
    { month: "Apr", listings: 5, sales: 1 },
    { month: "May", listings: 3, sales: 0 },
    { month: "Jun", listings: 6, sales: 3 },
  ];

  const slots = {
    header: (
      <PageHeader
        title={"The Serene Canvas \u2014 Artist Dashboard"}
        actions={[
          <Button key="logout" variant="ghost" onClick={() => console.log("Logout clicked")}>
            Logout (Jeanne)
          </Button>
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          variant="card"
          label={"Paintings Listed"}
          value={"18"}
          delta={"+2"}
          hint={"Last 30 days"}
        />
        <StatCard
          variant="card"
          label={"Pending Inquiries"}
          value={"3"}
          delta={"0"}
          hint={"Via WhatsApp"}
        />
        <StatCard
          variant="card"
          label={"Recently Sold"}
          value={"1"}
          delta={"-1"}
          hint={"This month"}
        />
        <StatCard
          variant="card"
          label={"Drafts"}
          value={"5"}
          delta={"+1"}
          hint={"Unpublished works"}
        />
      </div>
    ),
    chart: (
      <ChartCard
        title={"New Listings & Sales Last 6 Months"}
        type="bar"
        dataKey="listings"
        xKey="month"
        data={mainChartData}
        description="Visualizing the ebb and flow of your gallery's activity."
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search artworks..."
        filters={[
          { id: "all", label: "All Time", active: true },
          { id: "30days", label: "Last 30 days", active: false },
          { id: "quarter", label: "This Quarter", active: false },
        ]}
        actions={[
          <Button key="add-artwork" variant="default">Add New Artwork</Button>
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "title", header: "Artwork Title" },
          { key: "status", header: "Status" },
          { key: "actions", header: "" },
        ]}
        rows={[
          {
            id: "painting-1",
            title: "Evening Hues",
            status: "Available",
            actions: <Button variant="ghost" size="sm">Edit</Button>,
          },
          {
            id: "painting-2",
            title: "Whispers of the Horizon",
            status: "Sold",
            actions: <Button variant="ghost" size="sm">View</Button>,
          },
          {
            id: "painting-3",
            title: "Coastal Mist",
            status: "Inquire for Availability",
            actions: <Button variant="ghost" size="sm">Edit</Button>,
          },
          {
            id: "painting-4",
            title: "Golden Hour Abstract",
            status: "Available",
            actions: <Button variant="ghost" size="sm">Edit</Button>,
          },
        ]}
        emptyMessage="No recent artwork activity."
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "act-1", title: "New artwork added:", detail: "'Golden Hour Abstract'", time: "Just now" },
          { id: "act-2", title: "Artwork marked Sold:", detail: "'Coastal Reflection'", time: "2 hours ago" },
          { id: "act-3", title: "Updated 'About the Artist' page content", detail: "Bio refreshed", time: "Yesterday" },
          { id: "act-4", title: "Inquiry received:", detail: "'Evening Hues' via WhatsApp", time: "2 days ago" },
        ]}
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}