// directory listing scaffold — distinct from home marketing clone
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { BRAND_MANIFEST, images } from '@/data/mock';
import { PublicShell, PublicNav, PageHeader, ProductShowcase, CTABand, BrandFooter } from '@/ui';

const services = Array.isArray(BRAND_MANIFEST?.services) ? BRAND_MANIFEST.services : [];
const LISTING_BASE = "/owner/artworks";

export default function ArtworkListPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const people = (services.length ? services : [
    { id: 'dr-1', name: 'Dr. Avery Chen', description: 'Family medicine · accepting new patients' },
    { id: 'dr-2', name: 'Dr. Jordan Miles', description: 'Pediatrics · same-week visits' },
    { id: 'dr-3', name: 'Dr. Sam Rivera', description: 'Internal medicine · telehealth available' },
  ]).map((s: any, i: number) => ({
    title: String(s.name || s.title || `Provider ${i + 1}`),
    description: String(s.description || s.specialty || s.role || 'Available for appointments'),
    imageSrc: [images.card1, images.card2, images.card3][i % 3],
    imageAlt: String(s.name || s.title || 'Provider'),
    href: `${LISTING_BASE}/${s.id || i + 1}`,
  }));

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} chrome="solid" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton="public-catalog" data-appspec-page="admin-artwork-list">

      <PageHeader
        title={"Manage Artworks \u2014 The Serene Canvas"}
        description="Browse pieces and details \u2014 then inquire about availability."
      />
      <ProductShowcase
        heading="From the collection"
        description="Each card opens a closer look. Inquire when you are ready."
        items={people}
      />
      <CTABand
        heading="Interested in a piece?"
        description="Ask about availability, commissions, or a studio visit."
        primaryCta={{ label: "Inquire", href: "/about" }}
        secondaryCta={{ label: "Back home", href: "/" }}
      />
      <BrandFooter brandName={"Jeanne Kassab Art"} description="Browse the collection. Inquire when a piece speaks to you." />
      </div>
    </PublicShell>
  );
}
