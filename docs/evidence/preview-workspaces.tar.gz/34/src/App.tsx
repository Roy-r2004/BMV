import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutArtistPage from './pages/AboutArtistPage';
import AddArtworkPage from './pages/owner/AddArtworkPage';
import AiFeaturesPage from './pages/AiFeaturesPage';
import ArtworkDetailPage from './pages/ArtworkDetailPage';
import ArtworkListPage from './pages/owner/ArtworkListPage';
import ContactPage from './pages/ContactPage';
import DashboardPage from './pages/owner/DashboardPage';
import EditAboutPage from './pages/owner/EditAboutPage';
import EditArtworkPage from './pages/owner/EditArtworkPage';
import GalleryHomePage from './pages/GalleryHomePage';
import HomePage from './pages/HomePage';
import LoginPage from './pages/owner/LoginPage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/gallery');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/gallery" element={<GalleryHomePage />} />
          <Route path="/artwork/:slug" element={<ArtworkDetailPage />} />
          <Route path="/about" element={<AboutArtistPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/owner/login" element={<LoginPage />} />
          <Route path="/owner/dashboard" element={<DashboardPage />} />
          <Route path="/owner/artworks" element={<ArtworkListPage />} />
          <Route path="/owner/:id" element={<ArtworkListPage />} />
          <Route path="/owner/:slug" element={<ArtworkListPage />} />
          <Route path="/owner/artworks/add" element={<AddArtworkPage />} />
          <Route path="/owner/artworks/:id" element={<AddArtworkPage />} />
          <Route path="/owner/artworks/:slug" element={<AddArtworkPage />} />
          <Route path="/owner/artworks/edit/:id" element={<EditArtworkPage />} />
          <Route path="/owner/about" element={<EditAboutPage />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/ai-features" element={<AiFeaturesPage />} />
          <Route path="/gallery/:id" element={<ArtworkDetailPage />} />
          <Route path="/gallery/:slug" element={<ArtworkDetailPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}