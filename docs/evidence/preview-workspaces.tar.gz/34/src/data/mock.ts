export const brand = {"name": "Jeanne Kassab Art", "tagline": "", "design_system": {"primary_color": "#0f766e", "secondary_color": "#134e4a", "background_color": "#f0fdfa", "surface_color": "#ffffff", "text_color": "#042f2e", "muted_text_color": "#5f7a78", "font_family": "Source Sans 3", "display_font_family": "Fraunces", "font_import_url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap", "font_sans": "\"Source Sans 3\", \"Segoe UI\", sans-serif", "font_display": "\"Fraunces\", Georgia, serif", "brand_locked": true, "brand_brief_version": "1.0", "mood": "modern", "voice": "Warm, grounded, unhurried. Speak like a trusted studio host.", "signature": "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.", "avoid": ["purple-on-white or purple-to-indigo default themes", "Inter / Roboto / Arial as the display face", "card grids in the hero", "generic SaaS marketing copy", "inventing a second palette per page"], "rules": ["Every page inherits this palette and type stack via CSS tokens only.", "Use bg-brand / text-brand / font-display — never hardcode hex colors.", "First viewport must feature the brand name as a hero-level signal."], "recipe_id": "editorial", "hub_variant": "marketing", "hero_variant": "editorial", "feature_variant": "alternating", "recipe_prompt": "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.", "style_keywords": "Editorial · Calm air", "border_radius": "0.81rem", "design_overlay_id": "calm_air", "design_overlay_label": "Calm air", "design_overlay_blurb": "Airy clinical calm — soft surfaces, quiet type, low density.", "density": "airy", "token_overrides": {"radius_ui": "0.81rem", "bg_mix": "3%", "fg_mix": "38%", "muted_mix": "28%", "border_mix": "12%", "shadow": "0 28px 56px -40px", "shadow_alpha": "22%", "glow": "6%", "card": "#ffffff", "atmosphere": "radial-gradient(90% 55% at 8% -5%, color-mix(in srgb, var(--color-brand) 9%, transparent), transparent 58%), linear-gradient(180deg, #fbfcfd 0%, color-mix(in srgb, var(--color-brand) 3%, #f5f7f9) 55%, #f8fafb 100%)"}, "font_import": "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700", "design_brief_version": "1.0", "design_brief_sealed": true},
  services: [{"name": "Jeanne Kassab Art Signature", "title": "Jeanne Kassab Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jeanne Kassab Art clients.",

  design_system: {"primary_color": "#0f766e", "secondary_color": "#134e4a", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  name: "Jeanne Kassab Art",
  tagline: {},
};

export const images = {
  "hero": "https://images.pexels.com/photos/6812572/pexels-photo-6812572.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/7788509/pexels-photo-7788509.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/6812478/pexels-photo-6812478.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/19976571/pexels-photo-19976571.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/12917343/pexels-photo-12917343.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/6627689/pexels-photo-6627689.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const roles = [
  {
    "id": "customer",
    "label": "Collector & Visitor",
    "defaultPath": "/gallery",
    "icon": "users"
  },
  {
    "id": "artist",
    "label": "Artist (Owner)",
    "defaultPath": "/owner/dashboard",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Jeanne Kassab"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Jeanne Kassab"
    },
    {
      "id": "owner-login",
      "path": "/owner/login",
      "href": "/owner/login",
      "label": "Artist Login"
    },
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-artworks",
      "path": "/owner/artworks",
      "href": "/owner/artworks",
      "label": "Artworks"
    },
    {
      "id": "owner-artworks-add",
      "path": "/owner/artworks/add",
      "href": "/owner/artworks/add",
      "label": "Add"
    },
    {
      "id": "owner-about",
      "path": "/owner/about",
      "href": "/owner/about",
      "label": "About"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Jeanne Kassab"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Jeanne Kassab"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    }
  ],
  "artist": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-login",
      "path": "/owner/login",
      "href": "/owner/login",
      "label": "Artist Login"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-artworks",
      "path": "/owner/artworks",
      "href": "/owner/artworks",
      "label": "Artworks"
    },
    {
      "id": "owner-artworks-add",
      "path": "/owner/artworks/add",
      "href": "/owner/artworks/add",
      "label": "Add"
    },
    {
      "id": "owner-about",
      "path": "/owner/about",
      "href": "/owner/about",
      "label": "About"
    }
  ]
};

export const seed = {
  hero: {
    eyebrow: 'Jeanne Kassab Art',
    headline: 'Jeanne Kassab Art',
    subcopy: 'A clear next step from Jeanne Kassab Art — warm, specific, and ready when you are.',
    primaryCta: { label: 'Get started', href: '#details' },
    secondaryCta: { label: 'See how it works', href: '#process' },
  },
  items: [
    { title: 'Jeanne Kassab Art signature', description: 'A dependable starting point at Jeanne Kassab Art.' },
    { title: 'Everyday essential', description: 'Built for daily use.' },
    { title: 'Guest favorite', description: 'The one people come back to Jeanne Kassab Art for.' },
  ],
  features: [
    { title: 'What Jeanne Kassab Art is known for', description: 'Concrete offerings guests can book without guessing.' },
    { title: 'Guided next step', description: 'Every section points toward a clear action.' },
    { title: 'Built for return visits', description: 'Details that make Jeanne Kassab Art easy to come back to.' },
  ],
  featuresHeading: 'What Jeanne Kassab Art offers',
  showcaseHeading: 'From Jeanne Kassab Art',
  credentialsHeading: 'Why Jeanne Kassab Art',
  credentials: [
    { title: 'Known locally', detail: 'Neighbors recommend Jeanne Kassab Art for consistent results.' },
    { title: 'Clear next steps', detail: 'Booking and follow-up stay simple from the start.' },
  ],
  trustLabels: [
    'Jeanne Kassab Art quality\', \'On schedule\', \'Repeat guests\', \'Local favorite',
  ],
  cta: {
    heading: 'Ready for Jeanne Kassab Art?',
    description: 'Tell Jeanne Kassab Art what you need — clear options, real next steps.',
    primaryLabel: 'Get started',
    primaryHref: '#details',
    secondaryLabel: 'Talk to us',
    secondaryHref: '#contact',
  },
  footer: {
    description: 'Jeanne Kassab Art — clear choices and real bookings.',
  },

  "tone": "reassuring",
  "hero": {
    "eyebrow": "Jeanne Kassab Art",
    "headline": "Original Oil Paintings by Jeanne Kassab",
    "subcopy": "Explore abstract landscapes and layered oils, each piece a unique expression of color and form.",
    "primaryCta": {
      "label": "View the Collection",
      "href": "/gallery"
    },
    "secondaryCta": {
      "label": "About the Artist",
      "href": "/about"
    }
  },
  "items": [
    {
      "title": "Preventive cleaning",
      "description": "Exam, polish, and a clear plan for the patient — no surprise upsells."
    },
    {
      "title": "Restorative care",
      "description": "Fillings, crowns, and repairs scheduled around your week."
    },
    {
      "title": "Orthodontics consult",
      "description": "Alignment options with digital previews and realistic timelines."
    },
    {
      "title": "Emergency slot",
      "description": "Same-day openings when pain cannot wait for next month."
    }
  ],
  "features": [
    {
      "title": "Digital intake before you arrive",
      "description": "Forms and insurance details finished at home — less clipboard time."
    },
    {
      "title": "Providers with public bios",
      "description": "Credentials, languages, and focus areas visible before you book."
    },
    {
      "title": "Reminders that actually help",
      "description": "SMS and email with prep notes, not just \"see you soon.\""
    }
  ],
  "process": [
    {
      "title": "Choose a visit type",
      "description": "Cleaning, consult, or urgent — with expected duration."
    },
    {
      "title": "Pick provider and time",
      "description": "Live openings across the week; filters by preference."
    },
    {
      "title": "Confirm and prepare",
      "description": "Intake link arrives immediately; arrive ready."
    }
  ],
  "credentials": [
    {
      "title": "Board-certified clinicians",
      "detail": "Every provider listed with license and specialty."
    },
    {
      "title": "Sterilization standards posted",
      "detail": "Protocols patients can read — not marketing fluff."
    },
    {
      "title": "Insurance desk on-site",
      "detail": "Benefits checked before treatment, not after."
    }
  ],
  "testimonials": [
    {
      "quote": "They explained the X-ray in normal words and booked the follow-up while I still had my calendar open.",
      "author": "Rita H.",
      "role": "Cleaning patient"
    },
    {
      "quote": "Same-day emergency slot saved me a weekend of guessing and Advil.",
      "author": "Omar F.",
      "role": "Urgent visit"
    }
  ],
  "treatments": [
    {
      "id": "offer-1",
      "name": "Preventive cleaning",
      "duration": "60 min"
    },
    {
      "id": "offer-2",
      "name": "Restorative care",
      "duration": "60 min"
    },
    {
      "id": "offer-3",
      "name": "Orthodontics consult",
      "duration": "60 min"
    },
    {
      "id": "offer-4",
      "name": "Emergency slot",
      "duration": "60 min"
    }
  ],
  "showcaseHeading": "Care we provide",
  "featuresHeading": "Designed around patients",
  "processHeading": "Book without the phone tree",
  "credentialsHeading": "Trust you can verify",
  "testimonialsHeading": "Patient notes",
  "cta": {
    "heading": "Openings this week",
    "description": "Book a cleaning or consult — insurance check included before you arrive.",
    "primaryLabel": "Book visit",
    "primaryHref": "/book",
    "secondaryLabel": "New patient forms",
    "secondaryHref": "/intake"
  },
  "footer": {
    "description": "A clinic for patients who want clear plans, on-time visits, and providers they chose on purpose."
  },
  "trustLabels": [
    "Board-certified",
    "Digital intake",
    "Insurance desk",
    "Same-day urgency"
  ],
  "kpis": [
    {
      "label": "Paintings Listed",
      "value": "18",
      "delta": "+2",
      "hint": "Last 30 days"
    },
    {
      "label": "Pending Inquiries",
      "value": "3",
      "delta": "0",
      "hint": "Via WhatsApp"
    },
    {
      "label": "Recently Sold",
      "value": "1",
      "delta": "-1",
      "hint": "This month"
    }
  ],
  "activity": [
    {
      "id": "activity-1",
      "title": "New painting added: 'Golden Hour Abstract'",
      "detail": "Updated gallery and status.",
      "time": "Just now"
    },
    {
      "id": "activity-2",
      "title": "Artwork 'Coastal Reflection' marked as Sold",
      "detail": "Availability updated.",
      "time": "2 hours ago"
    },
    {
      "id": "activity-3",
      "title": "Updated 'About the Artist' page content",
      "detail": "New artist statement added.",
      "time": "Yesterday"
    }
  ],
  "risk": [
    {
      "id": "risk-1",
      "title": "No-show risk",
      "detail": "2:15 cleaning still unconfirmed",
      "severity": "high"
    },
    {
      "id": "risk-2",
      "title": "Provider running late",
      "detail": "Dr. Miles +12m · Room 3",
      "severity": "medium"
    }
  ],
  "tableRows": [
    {
      "id": "row-1",
      "name": "Preventive cleaning",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-2",
      "name": "Restorative care",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-3",
      "name": "Orthodontics consult",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-4",
      "name": "Emergency slot",
      "status": "Open",
      "owner": "Team"
    }
  ]
};

export const aiFeatures = [
  {
    "id": "automated-image-optimization",
    "name": "Automated Image Optimization",
    "description": "Automatically resizes and compresses uploaded artwork images for fast loading times while maintaining visual quality.",
    "category": "automation",
    "surface": "automation",
    "demo_hint": "Trigger the automation Jeanne Kassab Art actually needs",
    "demo_prompts": [
      "Notify the next person waiting for intake",
      "Chase what's missing for booking",
      "Run tonight's follow-ups for Jeanne Kassab Art"
    ],
    "placement_label": "Automation",
    "demo_results": {
      "Notify the next person waiting for intake": "Automation for “Notify the next person waiting for intake”: message drafted, spot held for 30 minutes, next guest in line ready if they decline.",
      "Chase what's missing for booking": "Chase sequence for “Chase what's missing for booking”: reminder #1 sent about booking, escalates tomorrow if still open.",
      "Run tonight's follow-ups for Jeanne Kassab Art": "Tonight's follow-ups for Jeanne Kassab Art are queued — review → approve → run. Covers intake and booking."
    },
    "placement_path": "/owner/login",
    "placement_component": "src/pages/owner/LoginPage.tsx",
    "placement_title": "Artist Login"
  },
  {
    "id": "smart-artwork-tagging-future",
    "name": "Smart Artwork Tagging (Future)",
    "description": "Suggests descriptive tags or categories for paintings based on visual analysis, potentially aiding in future search and discoverability.",
    "category": "ops",
    "surface": "ops",
    "demo_hint": "Route ops work the way Jeanne Kassab Art runs",
    "demo_prompts": [
      "Triage new requests about intake",
      "Assign an owner for this booking issue",
      "What should the Jeanne Kassab Art team do next?"
    ],
    "placement_label": "Ops AI",
    "demo_results": {
      "Triage new requests about intake": "Routed “Triage new requests about intake” → queue + owner + checklist for intake. Status: In progress.",
      "Assign an owner for this booking issue": "Assigned “Assign an owner for this booking issue” to the best available owner with a booking checklist and due time today.",
      "What should the Jeanne Kassab Art team do next?": "Next for Jeanne Kassab Art: clear the intake backlog, confirm booking, then review tonight's handoff."
    },
    "placement_path": "/owner/dashboard",
    "placement_component": "src/pages/owner/DashboardPage.tsx",
    "placement_title": "Dashboard — The Serene Canvas"
  },
  {
    "id": "personalized-you-might-also-like-recommendations",
    "name": "Personalized \"You Might Also Like\" Recommendations (Future)",
    "description": "Based on user browsing behavior and artwork attributes, suggests other pieces from Jeanne's portfolio that a collector might find appealing.",
    "category": "ops",
    "surface": "automation",
    "demo_hint": "Route ops work the way Jeanne Kassab Art runs",
    "demo_prompts": [
      "Triage new requests about intake",
      "Assign an owner for this booking issue",
      "What should the Jeanne Kassab Art team do next?"
    ],
    "placement_label": "Ops AI",
    "demo_results": {
      "Triage new requests about intake": "Routed “Triage new requests about intake” → queue + owner + checklist for intake. Status: In progress.",
      "Assign an owner for this booking issue": "Assigned “Assign an owner for this booking issue” to the best available owner with a booking checklist and due time today.",
      "What should the Jeanne Kassab Art team do next?": "Next for Jeanne Kassab Art: clear the intake backlog, confirm booking, then review tonight's handoff."
    },
    "placement_path": "/owner/dashboard",
    "placement_component": "src/pages/owner/DashboardPage.tsx",
    "placement_title": "Dashboard — The Serene Canvas"
  }
] as const;
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;

// build-correctness guard: auto-added missing exports
export const BRAND_MANIFEST = {"brand_name": "Jeanne Kassab Art", "name": "Jeanne Kassab Art", "tagline": "", "accent": "#6366f1", "design_system": {"primary_color": "#6366f1", "secondary_color": "#0d9488", "accent": "#6366f1", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "inter", "font_import_url": "https://fonts.googleapis.com/css2?family=inter:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"}, "services": [{"id": "intro-session", "name": "Jeanne Kassab Art intro session", "description": "A welcoming first session for new guests.", "duration": "90 min", "level": "Beginner Friendly", "day": "Thursday", "status": "Open"}, {"id": "signature-workshop", "name": "Signature workshop", "description": "The core experience guests book most often.", "duration": "2 hours", "level": "All Levels", "day": "Saturday", "status": "Open"}, {"id": "advanced-studio", "name": "Advanced studio time", "description": "Deeper practice with guided feedback.", "duration": "3 hours", "level": "Intermediate", "day": "Wednesday", "status": "Full"}], "products": [{"title": "Jeanne Kassab Art essential", "description": "A dependable pick from the shop floor.", "name": "Jeanne Kassab Art essential"}, {"title": "Studio favorite", "description": "The piece guests ask about first.", "name": "Studio favorite"}]};
export const stats = [{"id": "stats-1", "name": "stats 1", "title": "stats 1", "label": "stats 1", "status": "In progress", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 1", "amount": 52, "count": 4, "date": "2026-07-28", "time": "10:00", "startDate": "2026-07-28", "endDate": "2026-07-28", "dropOffDate": "2026-07-28", "dropOffTime": "10:00", "pickupDate": "2026-07-30", "scheduledAt": "2026-07-28T10:00:00", "createdAt": "2026-07-28T10:00:00", "timestamp": "2026-07-28T10:00:00", "instructor": "Maya R.", "memberName": "Member 1", "loadType": "Bisque", "registered": 5, "capacity": 12, "isFull": false}, {"id": "stats-2", "name": "stats 2", "title": "stats 2", "label": "stats 2", "status": "Done", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 2", "amount": 64, "count": 5, "date": "2026-07-29", "time": "11:30", "startDate": "2026-07-29", "endDate": "2026-07-29", "dropOffDate": "2026-07-29", "dropOffTime": "11:30", "pickupDate": "2026-07-31", "scheduledAt": "2026-07-29T11:30:00", "createdAt": "2026-07-29T11:30:00", "timestamp": "2026-07-29T11:30:00", "instructor": "Jordan K.", "memberName": "Member 2", "loadType": "Glaze", "registered": 6, "capacity": 12, "isFull": false}, {"id": "stats-3", "name": "stats 3", "title": "stats 3", "label": "stats 3", "status": "Scheduled", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 3", "amount": 76, "count": 6, "date": "2026-07-30", "time": "12:00", "startDate": "2026-07-30", "endDate": "2026-07-30", "dropOffDate": "2026-07-30", "dropOffTime": "12:00", "pickupDate": "2026-08-01", "scheduledAt": "2026-07-30T12:00:00", "createdAt": "2026-07-30T12:00:00", "timestamp": "2026-07-30T12:00:00", "instructor": "Sam T.", "memberName": "Member 3", "loadType": "Cone 6", "registered": 7, "capacity": 12, "isFull": false}, {"id": "stats-4", "name": "stats 4", "title": "stats 4", "label": "stats 4", "status": "Open", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 4", "amount": 88, "count": 7, "date": "2026-07-31", "time": "13:30", "startDate": "2026-07-31", "endDate": "2026-07-31", "dropOffDate": "2026-07-31", "dropOffTime": "13:30", "pickupDate": "2026-08-02", "scheduledAt": "2026-07-31T13:30:00", "createdAt": "2026-07-31T13:30:00", "timestamp": "2026-07-31T13:30:00", "instructor": "Noa B.", "memberName": "Member 4", "loadType": "Raku", "registered": 8, "capacity": 12, "isFull": false}];