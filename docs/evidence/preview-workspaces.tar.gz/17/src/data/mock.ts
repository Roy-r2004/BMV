export const brand = {
  name: "Jane Art",
  tagline: "Curated expressions, timeless elegance.",
  accent: "#a87b4f", // Soft gold/brass accent
  accent_dark: "#8f673e",
  accent_light: "#f7f0e7",
  font: '"Source Sans 3", "Segoe UI", sans-serif',
  owner_name: "Jane Doe",

  design_system: {"primary_color": "#0f766e", "secondary_color": "#134e4a", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  services: [{"name": "Jane Art Signature", "title": "Jane Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jane Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jane Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": ""}]
,
  client_names: ["Maya Jane", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jane Art clients.",
};

export const images = {
  hero: 'https://images.unsplash.com/photo-1549887552-cb1071d3e37c?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  hero2: 'https://images.unsplash.com/photo-1579783901586-cf7ebdc704f6?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  ambient: 'https://images.unsplash.com/photo-1578926372074-ce46700c242a?q=80&w=2674&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  card1: 'https://images.unsplash.com/photo-1618005182384-ce65297321e0?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  card2: 'https://images.unsplash.com/photo-1618005182384-ce65297321e0?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  card3: 'https://images.unsplash.com/photo-1618005182384-ce65297321e0?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  avatar1: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=2574&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  avatar2: 'https://images.unsplash.com/photo-1498059534927-ef349ad15bd6?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  avatar3: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=2564&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  galleryHero: 'https://images.unsplash.com/photo-1517487881594-2787fdb1edcd?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
};

export const roles = [
  {
    "id": "PublicUser",
    "label": "Public User",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "Admin",
    "label": "Admin",
    "defaultPath": "/admin",
    "icon": "users"
  }
];

// build-correctness guard: auto-added missing exports
export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home Page"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery/Collection Page"
    },
    {
      "id": "gallery-painting-slug",
      "path": "/gallery/painting/slug",
      "href": "/gallery/painting/slug",
      "label": "Painting Detail Page"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Page"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    }
  ],
  "admin": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login Page"
    },
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin Dashboard Page"
    },
    {
      "id": "admin-paintings-add",
      "path": "/admin/paintings/add",
      "href": "/admin/paintings/add",
      "label": "Add/Edit Painting Page"
    }
  ],
  "PublicUser": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home Page"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery/Collection Page"
    },
    {
      "id": "gallery-painting-slug",
      "path": "/gallery/painting/slug",
      "href": "/gallery/painting/slug",
      "label": "Painting Detail Page"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Page"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    }
  ],
  "Admin": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login Page"
    },
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin Dashboard Page"
    },
    {
      "id": "admin-paintings-add",
      "path": "/admin/paintings/add",
      "href": "/admin/paintings/add",
      "label": "Add/Edit Painting Page"
    }
  ]
};
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
