import { PublicShell, MarketingHero, FeatureBento, CTABand, BrandFooter, Button, SkeletonComposer, getSkeleton, PublicNav } from '@/ui';

import { images, brand } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';

const SKELETON_ID = 'public-service' as const;

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const { brandName } = brand;

  const skeleton = getSkeleton(SKELETON_ID);

  const heroSlot = (
    <MarketingHero
      brandName={brandName}
      headline="About Jane Art"
      subcopy="The Story Behind the Canvas and the Curator."
      primaryCta={{ label: 'Explore the Collection', href: '/gallery' }}
      imageSrc={images.hero2}
      imageAlt="Jane Art studio with paint and canvases"
    />
  );

  const featuresSlot = (
    <FeatureBento
      heading=""
      className="pb-16 lg:pb-24"
      items={[
        {
          title: 'The Artist',
          description: '',
          content: (
            <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8 lg:gap-12">
              <div
                data-appspec-evidence="E12_ArtistBioDisplay"
                className="relative group bg-brand-surface p-4 rounded-lg shadow-md max-w-sm mx-auto"
              >
                <img
                  src={images.ambient}
                  alt="Portrait of Jane, the artist and curator"
                  className="rounded-md object-cover object-center w-full h-auto shadow-sm"
                />
              </div>
              <div data-appspec-evidence="E12_ArtistBioDisplay" className="flex-1 text-center lg:text-left">
                <h3 className="font-display text-2xl lg:text-3xl text-brand-text mb-4">Jane Doe</h3>
                <p className="font-sans text-muted-text leading-relaxed mb-4">
                  Jane Doe is a contemporary artist based in Provence, France, known for her evocative
                  use of color and texture to capture the transient beauty of landscapes and the human form.
                  Her journey began with classical training at the Académie Julian in Paris, evolving into a
                  distinctive abstract style that blends impressionistic influences with modern minimalism.
                </p>
                <p className="font-sans text-muted-text leading-relaxed">
                  Her work is a meditative exploration of light and shadow, often drawing inspiration from
                  the serene Provençal countryside and the emotional depth of human experience.
                  Jane's dedication to her craft is palpable in each brushstroke, inviting viewers into a
                  world of profound beauty and introspection.
                </p>
              </div>
            </div>
          ),
        },
        {
          title: 'Our Story',
          description: '',
          content: (
            <div data-appspec-evidence="E13_GalleryStoryDisplay" className="text-center lg:text-left">
              <h3 className="font-display text-2xl lg:text-3xl text-brand-text mb-4">The Canvas Curator</h3>
              <div className="lg:grid lg:grid-cols-2 gap-8 font-sans text-muted-text leading-relaxed">
                <p className="mb-4 lg:mb-0">
                  Jane Art was founded in 2023 as an online extension of Jane Doe's private studio,
                  aiming to make original, high-quality art accessible to collectors worldwide.
                  Each piece is personally curated and often created by Jane herself, ensuring a unique
                  and intimate connection between artist and patron.
                </p>
                <p>
                  We believe art is more than just decoration; it is a passion project born from a deep love
                  for fine art and a desire to connect people with pieces that resonate with their soul.
                  The Canvas Curator experience is designed to be warm, personal, and profoundly elegant.
                </p>
              </div>
            </div>
          ),
        },
      ]}
    />
  );

  const ctaSlot = (
    <CTABand
      heading="Connect with Jane"
      description="Have a question or looking for a custom commission? Jane would love to hear from you."
      primaryCta={{ label: 'Contact Jane', href: '/contact', variant: 'default' }}
      className="pb-16 lg:pb-24"
    />
  );

  const footerSlot = (
    <BrandFooter
      brandName={brandName}
      meta={[
        { label: 'Privacy Policy', href: '#' },
        { label: 'Terms of Service', href: '#' },
      ]}
      className="bg-brand/[3%] py-8 text-sm text-brand-muted"
    />
  );

  const slots = {
    hero: heroSlot,
    features: featuresSlot,
    cta: ctaSlot,
    footer: footerSlot,
  };

  return (
    <PublicShell 
      brandName={brandName} 
      nav={<PublicNav items={navItems} cta={navCta} />}
      footer={footerSlot}
      chrome="solid"
      data-appspec-page="AboutPage"
    >
      {skeleton && <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />}
    </PublicShell>
  );
}