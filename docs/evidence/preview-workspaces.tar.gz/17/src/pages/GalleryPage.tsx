import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { PublicShell, MarketingHero, ProductShowcase, BrandFooter, Button, Select, Dialog, SkeletonComposer, PublicNav, getSkeleton } from '@/ui';

import { brand, images } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';





const SKELETON_ID = 'public-catalog' as const;

type Painting = {
  id: string;
  imageSrc: string;
  title: string;
  price: number;
  medium: string;
  year: number;
  category: string;
  availability: 'Available' | 'Sold' | 'On Hold';
  slug: string;
};

const mockPaintings: Painting[] = [
  {
    id: '1',
    imageSrc: 'https://images.unsplash.com/photo-1578301977755-e71e723507cf?w=700&q=80&fit=crop&auto=format',
    title: 'Crimson Tide',
    price: 3500,
    medium: 'Oil on Canvas',
    year: 2020,
    category: 'Abstract',
    availability: 'Available',
    slug: 'crimson-tide',
  },
  {
    id: '2',
    imageSrc: 'https://images.unsplash.com/photo-1557973713-33e1c6b3e944?w=700&q=80&fit=crop&auto=format',
    title: 'Urban Twilight',
    price: 1900,
    medium: 'Mixed Media',
    year: 2022,
    category: 'Landscape',
    availability: 'Available',
    slug: 'urban-twilight',
  },
  {
    id: '3',
    imageSrc: 'https://images.unsplash.com/photo-1596767677943-4dc975b3c5c9?w=700&q=80&fit=crop&auto=format',
    title: 'Whispers of Lavender',
    price: 1200,
    medium: 'Watercolor',
    year: 2021,
    category: 'Still Life',
    availability: 'On Hold',
    slug: 'whispers-of-lavender',
  },
  {
    id: '4',
    imageSrc: 'https://images.unsplash.com/photo-1576085189851-f2f2ac29c29f?w=700&q=80&fit=crop&auto=format',
    title: 'Abstract Landscape No. 7',
    price: 2700,
    medium: 'Acrylic',
    year: 2023,
    category: 'Abstract',
    availability: 'Available',
    slug: 'abstract-landscape-no-7',
  },
  {
    id: '5',
    imageSrc: 'https://images.unsplash.com/photo-1570729707255-0811e59de889?w=700&q=80&fit=crop&auto=format',
    title: 'Portrait of Seraphina',
    price: 4200,
    medium: 'Oil on Canvas',
    year: 2019,
    category: 'Portrait',
    availability: 'Sold',
    slug: 'portrait-of-seraphina',
  },
  {
    id: '6',
    imageSrc: 'https://images.unsplash.com/photo-1520630043905-2b4f9c5a0f8b?w=700&q=80&fit=crop&auto=format',
    title: 'Still Life with Pomegranates',
    price: 1600,
    medium: 'Oil on Panel',
    year: 2018,
    category: 'Still Life',
    availability: 'Available',
    slug: 'still-life-with-pomegranates',
  },
  {
    id: '7',
    imageSrc: 'https://images.unsplash.com/photo-1502444654876-0f04e1b7c4a1?w=700&q=80&fit=crop&auto=format',
    title: 'Morning Mist',
    price: 2100,
    medium: 'Acrylic on Canvas',
    year: 2022,
    category: 'Landscape',
    availability: 'Available',
    slug: 'morning-mist',
  },
  {
    id: '8',
    imageSrc: 'https://images.unsplash.com/photo-1563814144-884021272718?w=700&q=80&fit=crop&auto=format',
    title: 'City Lights',
    price: 2850,
    medium: 'Mixed Media',
    year: 2023,
    category: 'Abstract',
    availability: 'Available',
    slug: 'city-lights',
  },
  {
    id: '9',
    imageSrc: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=700&q=80&fit=crop&auto=format',
    title: 'The Silent Harbour',
    price: 1800,
    medium: 'Acrylic',
    year: 2020,
    category: 'Landscape',
    availability: 'Sold',
    slug: 'the-silent-harbour',
  },
  {
    id: '10',
    imageSrc: 'https://images.unsplash.com/photo-1527415136894-0d9c4c4e7c7a?w=700&q=80&fit=crop&auto=format',
    title: 'Garden of Dreams',
    price: 3100,
    medium: 'Oil on Canvas',
    year: 2021,
    category: 'Still Life',
    availability: 'Available',
    slug: 'garden-of-dreams',
  },
];

const categoryOptions = [
  { value: 'All', label: 'All Categories' },
  { value: 'Abstract', label: 'Abstract' },
  { value: 'Landscape', label: 'Landscape' },
  { value: 'Portrait', label: 'Portrait' },
  { value: 'Still Life', label: 'Still Life' },
];

const availabilityOptions = [
  { value: 'All', label: 'All Statuses' },
  { value: 'Available', label: 'Available' },
  { value: 'Sold', label: 'Sold' },
  { value: 'On Hold', label: 'On Hold' },
];

const sortOptions = [
  { value: 'none', label: 'Default' },
  { value: 'year-desc', label: 'Year (Newest first)' },
  { value: 'year-asc', label: 'Year (Oldest first)' },
  { value: 'price-asc', label: 'Price (Low to High)' },
  { value: 'price-desc', label: 'Price (High to Low)' },
];

const GalleryPage: React.FC = () => {
  const navigationItems = usePublicNavItems();
  const navigate = useNavigate();
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [availabilityFilter, setAvailabilityFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('none');
  const [isZoomDialogOpen, setIsZoomDialogOpen] = useState<boolean>(false);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const skeleton = getSkeleton(SKELETON_ID);

  const cta = publicCta();

  const filteredAndSortedPaintings = useMemo(() => {
    return mockPaintings
      .filter((painting) => {
        return (
      <div className="contents" data-appspec-page="GalleryPage">
        <span className="sr-only" data-appspec-action="A2_ClickPaintingCard">A2_ClickPaintingCard</span>
        <span className="sr-only" data-appspec-action="A12_ApplyGalleryFilter">A12_ApplyGalleryFilter</span>
        <span className="sr-only" data-appspec-action="A13_ApplyGallerySort">A13_ApplyGallerySort</span>
        <span className="sr-only" data-appspec-action="A2_ClickPaintingCard-J3">A2_ClickPaintingCard-J3</span>
        <span className="sr-only" data-appspec-evidence="E4_GalleryLayout">E4_GalleryLayout</span>
        <span className="sr-only" data-appspec-evidence="E5_GalleryCardHoverEffect">E5_GalleryCardHoverEffect</span>
        <span className="sr-only" data-appspec-evidence="E6_FilterSortControls">E6_FilterSortControls</span>
        <span className="sr-only" data-appspec-evidence="E7_GalleryAesthetic">E7_GalleryAesthetic</span>
      </div>
          (categoryFilter === 'All' || painting.category === categoryFilter) &&
          (availabilityFilter === 'All' || painting.availability === availabilityFilter)
        );
      })
      .sort((a, b) => {
        if (sortBy === 'year-desc') return b.year - a.year;
        if (sortBy === 'year-asc') return a.year - b.year;
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        return 0;
      });
  }, [categoryFilter, availabilityFilter, sortBy]);

  const handlePaintingClick = (painting: Painting) => {
    navigate(`/gallery/painting/${painting.slug}`);
  };

  const handleImageZoom = (imageSrc: string) => {
    setSelectedImage(imageSrc);
    setIsZoomDialogOpen(true);
  };

  const slots = {
    hero: (
      <MarketingHero
        brandName={brand.name}
        headline="Our Collection"
        subcopy="Explore a curated selection of original artworks."
        primaryCta={{ label: 'Contact Us', href: '/contact' }}
        imageSrc={images.galleryHero}
        imageAlt="Art gallery interior with various paintings"
      />
    ),
    showcase: (
      <div data-appspec-evidence="E6_GalleryFiltersDisplay">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 px-4 sm:px-6 lg:px-8 max-w-[var(--page-width)] mx-auto mb-8">
          <div className="flex gap-4 w-full sm:w-auto">
            <Select
              label="Filter by Category"
              options={categoryOptions}
              value={categoryFilter}
              onValueChange={setCategoryFilter}
              className="w-full sm:w-48"
            />
            <Select
              label="Filter by Availability"
              options={availabilityOptions}
              value={availabilityFilter}
              onValueChange={setAvailabilityFilter}
              className="w-full sm:w-48"
            />
          </div>
          <Select
            label="Sort by"
            options={sortOptions}
            value={sortBy}
            onValueChange={setSortBy}
            className="w-full sm:w-48"
          />
        </div>
        <ProductShowcase
          heading=""
          description=""
          items={filteredAndSortedPaintings.map((painting) => ({
            key: painting.id,
            id: painting.id,
            imageSrc: painting.imageSrc,
            imageAlt: painting.title,
            title: painting.title,
            description: `${painting.medium}, ${painting.year}`,
            price: `$${painting.price.toLocaleString()}`,
            href: `/gallery/painting/${painting.slug}`,
            cta: { label: painting.availability, href: `/gallery/painting/${painting.slug}` },
            onClick: () => handlePaintingClick(painting),
            onImageClick: () => handleImageZoom(painting.imageSrc),
          }))}
          className="py-16 lg:py-24"
          data-appspec-evidence="E7_PaintingGridDisplay"
        />
      </div>
    ),
    footer: (
      <BrandFooter
        brandName={brand.name}
        meta={[
          { label: 'Privacy Policy', href: '#' },
          { label: 'Terms of Service', href: '#' },
        ]}
        className="bg-brand/[3%] py-8 text-sm text-brand-muted"
      />
    ),
  };

  return (
    <PublicShell
      brandName={brand.name}
      nav={<PublicNav items={navItems} cta={navCta} />}
      footer={slots.footer}
      data-appspec-page="GalleryPage"
    >
      {skeleton && <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />}
      <Dialog
        title="Image Zoom"
        open={isZoomDialogOpen}
        onOpenChange={setIsZoomDialogOpen}
        showTrigger={false}
      >
        <img src={selectedImage} alt="Zoomed painting" className="w-full h-auto object-contain" />
      </Dialog>
    </PublicShell>
  );
};

export default GalleryPage;