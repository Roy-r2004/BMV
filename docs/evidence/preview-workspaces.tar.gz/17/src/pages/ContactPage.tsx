import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, PageHeader, Card, CTABand, BrandFooter } from '@/ui';
import { brand } from '@/data/mock';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={"Contact Page"} description="A current view of the work that needs your attention." meta={<span className="text-sm text-muted">Today</span>} />
    ),
    workspace: (
      <Card title="Your details" description="Everything for this step in one place."><div className="space-y-4"><div className="grid gap-3 sm:grid-cols-2"><div className="rounded-[calc(var(--radius-ui)+0.15rem)] border border-border-subtle bg-[color-mix(in_srgb,var(--color-brand)_5%,var(--color-background))] p-3"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted">Line items</p><p className="mt-1 text-sm font-medium text-foreground">Signature package · Qty 1</p></div><div className="rounded-[calc(var(--radius-ui)+0.15rem)] border border-border-subtle bg-[color-mix(in_srgb,var(--color-brand)_5%,var(--color-background))] p-3"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted">Status</p><p className="mt-1 text-sm font-medium text-brand">Ready to confirm</p></div></div><p className="text-sm leading-6 text-muted">Totals and confirmation details update as you make changes.</p></div></Card>
    ),
    cta: (
      <CTABand heading="Make it unforgettable" description="Book the next chapter — polished, branded, never bland." primaryCta={{ label: "Get started", href: "#details" }} secondaryCta={{ label: "Talk to us", href: "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={brand.name} description="Premium presence from first glance to booked revenue." />
    ),
  };

  return (
    <PublicShell brandName={brand.name} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="ContactPage">

        <span className="sr-only" data-appspec-action="A5_SubmitContactForm">A5_SubmitContactForm</span>
        <span className="sr-only" data-appspec-action="A5_SubmitContactForm-J5">A5_SubmitContactForm-J5</span>
        <span className="sr-only" data-appspec-evidence="E14_ContactFormDisplay">E14_ContactFormDisplay</span>
        <span className="sr-only" data-appspec-evidence="E15_MessagePreFill">E15_MessagePreFill</span>
        {skeleton && <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />}
      </div>
    </PublicShell>
  );
}