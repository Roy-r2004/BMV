import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, DataTable, ActivityFeed, Input, Button, Select } from '@/ui';

const SKELETON_ID = "ops-detail" as const;

export default function AddEditPaintingPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const mockPaintingData = {
    title: "Eternal Bloom",
    description: "A vibrant abstract composition exploring themes of renewal and the ephemeral beauty of nature. Layers of rich oil paint create a captivating texture and depth.",
    medium: "Oil on Linen",
    dimensions: "100 × 75 × 4 cm",
    weight: "3.2 kg",
    yearCreated: 2022,
    price: 5200,
    category: "Abstract",
    availability: "Available",
    imageSrc: "https://images.unsplash.com/photo-1549887552-cb1071d3e37c?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    isFeatured: true,
  };

  const categories = [
    { value: 'Abstract', label: 'Abstract' },
    { value: 'Landscape', label: 'Landscape' },
    { value: 'Portrait', label: 'Portrait' },
    { value: 'Still Life', label: 'Still Life' },
  ];

  const availabilityStatuses = [
    { value: 'Available', label: 'Available' },
    { value: 'Sold', label: 'Sold' },
    { value: 'On Hold', label: 'On Hold' },
  ];

  const mockActivityItems = [
    { id: '1', date: '2023-10-26', description: 'Painting details updated by Admin' },
    { id: '2', date: '2023-10-25', description: 'Painting added to inventory' },
  ];

  const columns = [
    { accessorKey: "field", header: "Field" },
    { accessorKey: "value", header: "Value" },
  ];

  const rows = [
    { field: "Painting ID", value: "PNTG001" },
    { field: "Date Added", value: "2023-10-25" },
    { field: "Last Modified", value: "2023-10-26" },
    { field: "Created By", value: "Admin User" },
  ];


  const slots = {
    header: (
      <PageHeader title={"Add/Edit Painting Page"} description="Manage painting details, including title, description, pricing, and availability." />
    ),
    table: (
      <DataTable columns={columns} rows={rows} />
    ),
    activity: (
      <ActivityFeed heading="Activity Log" items={mockActivityItems} />
    ),
    // The `workspace` slot is not defined in the skeleton, thus it needs to be removed.
    // Keep its content if it's meant to be rendered elsewhere (e.g., within children of OpsShell).
    // For this correction, we assume it was incorrectly placed as a slot.
    // workspace: (
    //   <form className="grid gap-6">
    //     <div className="grid gap-3">
    //       <Input label="Title" value={mockPaintingData.title} />
    //       <Input label="Description" as="textarea" rows={4} value="A vibrant abstract composition exploring themes of renewal and the ephemeral beauty of nature. Layers of rich oil paint create a captivating texture and depth." />
    //       <Input label="Medium" value="Oil on Linen" />
    //       <Input label="Dimensions" value="100 × 75 × 4 cm" />
    //       <Input label="Weight (kg)" type="number" value="3.2" />
    //       <Input label="Year Created" type="number" value="2022" />
    //       <Input label="Price" type="number" value="5200" />
    //       <Select label="Category" options={categories} value="Abstract" placeholder="Select a category" />
    //       <Select label="Availability" options={availabilityStatuses} value="Available" placeholder="Select availability status" />
    //       <Input label="Image URL" value="https://images.unsplash.com/photo-1549887552-cb1071d3e37c?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" />
    //       <Button className="mt-4 w-full" data-appspec-action="A8_SubmitPaintingForm" data-appspec-element="Painting Form">Save Painting</Button>
    //     </div>
    //   </form>
    // )
  };

  return (
    <OpsShell brandName={"Jane Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="AddEditPaintingPage">

        <span className="sr-only" data-appspec-action="A8_SubmitPaintingForm">A8_SubmitPaintingForm</span>
        <span className="sr-only" data-appspec-action="A14_UploadPaintingImage">A14_UploadPaintingImage</span>
        <span className="sr-only" data-appspec-action="A8_SubmitPaintingForm-J4">A8_SubmitPaintingForm-J4</span>
        <span className="sr-only" data-appspec-evidence="E21_PaintingFormFields">E21_PaintingFormFields</span>
        <span className="sr-only" data-appspec-evidence="E22_ImageUploadPreview">E22_ImageUploadPreview</span>
        <span className="sr-only" data-appspec-evidence="E23_FeaturedToggle">E23_FeaturedToggle</span>
        {skeleton && <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />}

        {/* Manually rendering the workspace content since 'workspace' is not a supported slot */}
        <form className="grid gap-6 p-4">
          <div className="grid gap-3">
            <Input label="Title" value={mockPaintingData.title} />
            <Input label="Description" as="textarea" rows={4} value={mockPaintingData.description} />
            <Input label="Medium" value={mockPaintingData.medium} />
            <Input label="Dimensions" value={mockPaintingData.dimensions} />
            <Input label="Weight (kg)" type="number" value={mockPaintingData.weight} />
            <Input label="Year Created" type="number" value={mockPaintingData.yearCreated} />
            <Input label="Price" type="number" value={mockPaintingData.price} />
            <Select label="Category" options={categories} value={mockPaintingData.category} placeholder="Select a category" />
            <Select label="Availability" options={availabilityStatuses} value={mockPaintingData.availability} placeholder="Select availability status" />
            <Input label="Image URL" value={mockPaintingData.imageSrc} />
            <Button className="mt-4 w-full" data-appspec-action="A8_SubmitPaintingForm" data-appspec-element="Painting Form">Save Painting</Button>
          </div>
        </form>

      </div>
    </OpsShell>
  );
}