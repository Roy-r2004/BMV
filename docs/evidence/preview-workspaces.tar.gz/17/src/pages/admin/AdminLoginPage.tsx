import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { OpsShell, Input, Button, SkeletonComposer, getSkeleton } from '@/ui';

import { brand } from '@/data/mock';
import { useAdminNavItems } from '@/lib/app-nav';

const SKELETON_ID = 'ops-dashboard' as const;
const skeleton = getSkeleton(SKELETON_ID);

export default function AdminLoginPage() {
  const adminNavItems = useAdminNavItems();
  const navigate = useNavigate();
  const navItems = useAdminNavItems();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Hardcoded credentials for the single admin account
    if (email === 'jane@janeart.com' && password === 'adminpassword') {
      // Simulate successful login and redirect to admin dashboard
      console.log('Login successful');
      navigate('/admin');
    } else {
      setError('Invalid email or password.');
    }
  };

  // For a login page, we center a card within the OpsShell's content.
  // The required skeleton slots are not directly applicable for a login form,
  // so we pass them as empty fragments or null to fulfill the contract,
  // but the visual content will be the centered login card itself.
  const slots = {
    header: <></>,
    kpis: <></>,
    chart: <></>,
    filters: <></>,
    table: <></>,
    activity: <></>,
  };

  return (
    <OpsShell brandName={brand.name} navItems={adminNavItems}>
      <div
        className="flex min-h-screen items-center justify-center bg-brand-background px-4 py-12"
        data-appspec-page="AdminLoginPage"
      >
        <div className="card w-full max-w-md p-8 shadow-lg text-foreground bg-card animate-fade-in rounded-[calc(var(--radius-ui)+0.25rem)] border border-border-subtle">
          <div className="flex flex-col items-center gap-6">
            <h1
              className="font-display text-4xl text-brand text-center tracking-tight"
              data-appspec-evidence="E16_LoginFormDisplay"
            >
              Jane Art
            </h1>
            <h2 className="font-display text-2xl text-foreground text-center font-semibold">
              Curator Login
            </h2>
          </div>
          <form onSubmit={handleLogin} className="mt-8 space-y-6">
            <div>
              <Input
                label="Email"
                id="email"
                type="email"
                placeholder="jane@janeart.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-base border-border-subtle bg-background"
                data-appspec-evidence="E16_LoginFormDisplay"
              />
            </div>
            <div>
              <Input
                label="Password"
                id="password"
                type="password"
                placeholder="**********"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-base border-border-subtle bg-background"
                data-appspec-evidence="E16_LoginFormDisplay"
              />
            </div>
            {error && <p className="text-destructive text-sm text-center">{error}</p>}
            <Button
              type="submit"
              className="w-full bg-brand hover:bg-brand-dark rounded-full py-2.5 text-white shadow-md shadow-brand/25 transition"
              data-appspec-action="A6_AdminLoginAttempt"
            >
              Sign In
            </Button>
            <p
              className="mt-6 text-center text-muted text-sm font-sans"
              data-appspec-evidence="E17_NoSignupOption"
            >
              Access restricted to authorized curators only.
            </p>
          </form>
        </div>
      </div>
      {/* SkeletonComposer is required by contract, but its content is empty for this specific page layout */}
      <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
    </OpsShell>
  );
}