import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getSkeleton, SkeletonComposer, PublicShell, Button, PublicNav, MarketingHero, ProductShowcase, CTABand, BrandFooter } from '@/ui';

import { images, brand } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';

// Re-using a controlled, headless "modal" element to demonstrate zoom without depending on UiHeadless or other external libs.
// This is an inline definition purely for this page's functionality.
interface ZoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageSrc: string;
  imageAlt: string;
}

const ZoomModal: React.FC<ZoomModalProps> = ({ isOpen, onClose, imageSrc, imageAlt }) => {
  if (!isOpen) return null;

  return (
      <div className="contents" data-appspec-page="PaintingDetailPage">
        <span className="sr-only" data-appspec-action="A3_ClickImageToZoom">A3_ClickImageToZoom</span>
        <span className="sr-only" data-appspec-action="A4_ClickInquireButton">A4_ClickInquireButton</span>
        <span className="sr-only" data-appspec-evidence="E8_PaintingImageDisplay">E8_PaintingImageDisplay</span>
        <span className="sr-only" data-appspec-evidence="E9_PaintingSpecsDisplay">E9_PaintingSpecsDisplay</span>
        <span className="sr-only" data-appspec-evidence="E10_InquiryCTA">E10_InquiryCTA</span>
        <span className="sr-only" data-appspec-evidence="E11_PaintingDetailAesthetic">E11_PaintingDetailAesthetic</span>
      </div>
    <div
      data-appspec-evidence="E8_PaintingImageDisplay"
      className="fixed inset-0 z-[999] flex items-center justify-center bg-black bg-opacity-75 backdrop-blur-sm"
      onClick={onClose}
    >
      <div className="relative max-w-[90vw] max-h-[90vh] overflow-auto">
        <img src={imageSrc} alt={imageAlt} className="w-full h-full object-contain" />
        <Button
          onClick={onClose}
          variant="ghost"
          className="absolute top-4 right-4 text-white text-lg"
          aria-label="Close"
        >
          &times;
        </Button>
      </div>
    </div>
  );
};


const SKELETON_ID = 'public-detail' as const;

// Mock data for a single painting and related works
const paintingData = {
  slug: 'eternal-bloom',
  title: 'Eternal Bloom',
  imageSrc: images.hero2,
  description: 'A vibrant abstract composition exploring themes of renewal and the ephemeral beauty of nature. Layers of rich oil paint create a captivating texture and depth.',
  medium: 'Oil on Linen',
  dimensions: '100 × 75 × 4 cm',
  weight: '3.2 kg',
  yearCreated: 2022,
  price: 5200,
  availability: 'Available', // Can be 'Available', 'Sold', 'On Hold'
};

const getAvailabilityTag = (status: string) => {
  switch (status) {
    case 'Available':
      return <span className="inline-flex items-center rounded-md bg-green-50 px-2 py-1 text-xs font-medium text-green-700 ring-1 ring-inset ring-green-600/20">Available</span>;
    case 'Sold':
      return <span className="inline-flex items-center rounded-md bg-red-50 px-2 py-1 text-xs font-medium text-red-700 ring-1 ring-inset ring-red-600/20">Sold</span>;
    case 'On Hold':
      return <span className="inline-flex items-center rounded-md bg-orange-50 px-2 py-1 text-xs font-medium text-orange-700 ring-1 ring-inset ring-orange-600/20">On Hold</span>;
    default:
      return null;
  }
};


export default function PaintingDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);
  const skeleton = getSkeleton(SKELETON_ID);

  // In a real app, 'slug' would be used to fetch painting data from an API
  // For this preview, we'll use static data.
  const currentPainting = paintingData; // Assuming 'eternal-bloom' for the demo

  const slots = {
    hero: (
      <MarketingHero
        brandName={brand.name}
        eyebrow="The Canvas Curator"
        headline={currentPainting.title}
        subcopy="A piece designed to inspire contemplation and evoke emotion."
        primaryCta={{ label: 'Explore the Collection', href: '/gallery' }}
        imageSrc={currentPainting.imageSrc}
        imageAlt={`Art piece titled ${currentPainting.title}`}
        className="text-brand-text"
      />
    ),
    showcase: (
      <ProductShowcase heading="" className="py-16 lg:py-24" data-appspec-evidence="E9_PaintingSpecsDisplay">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-7xl mx-auto px-6">
          {/* Painting Image */}
          <div className="relative group overflow-hidden rounded-md shadow-lg border border-border-subtle"
            data-appspec-action="A3_ClickImageToZoom">
            <img
              src={currentPainting.imageSrc}
              alt={currentPainting.title}
              className="w-full h-auto object-cover transition-transform duration-500 hover:scale-105 cursor-zoom-in"
              onClick={() => setIsZoomModalOpen(true)}
            />
            {/* Magnifying glass icon on hover */}
            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-opacity duration-300 pointer-events-none">
              <svg className="h-12 w-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>

          {/* Painting Details */}
          <div className="flex flex-col justify-start">
            <div className="mb-6">
              <h2 className="font-display text-4xl text-brand-text mb-4">{currentPainting.title}</h2>
              <p className="font-sans text-lg text-muted-text leading-relaxed mb-4">{currentPainting.description}</p>
              <div className="flex items-center gap-4 text-lg font-semibold text-brand-text mb-4">
                <span>${currentPainting.price.toLocaleString()} USD</span>
                {getAvailabilityTag(currentPainting.availability)}
              </div>

              <div className="grid grid-cols-2 gap-4 text-muted-text text-sm mb-6">
                <div>
                  <p><span className="font-semibold">Medium:</span> {currentPainting.medium}</p>
                  <p><span className="font-semibold">Dimensions:</span> {currentPainting.dimensions}</p>
                </div>
                <div>
                  <p><span className="font-semibold">Year Created:</span> {currentPainting.yearCreated}</p>
                  <p><span className="font-semibold">Weight:</span> {currentPainting.weight}</p>
                </div>
              </div>

              <Button
                variant="default"
                size="lg"
                onClick={() => navigate('/contact')}
                disabled={currentPainting.availability === 'Sold'}
                className="w-full md:w-auto mt-4"
                data-appspec-action="A4_InquireAboutPainting"
              >
                {currentPainting.availability === 'Sold' ? 'Sold' : 'Inquire About This Piece'}
              </Button>
            </div>
          </div>
        </div>
      </ProductShowcase>
    ),
    cta: (
      <CTABand
        heading="Interested in a similar piece?"
        description="Reach out to discuss commissions or art advisory services."
        primaryCta={{ label: 'Contact Jane Art', href: '/contact' }}
        className="py-16 lg:py-24"
      />
    ),
    footer: (
      <BrandFooter
        brandName={brand.name}
        meta={[
          { label: 'Privacy Policy', href: '#' },
          { label: 'Terms of Service', href: '#' },
        ]}
        className="bg-brand/[3%] py-8 text-sm text-brand-muted"
      />
    ),
  };

  return (
    <PublicShell
      brandName={brand.name}
      nav={<PublicNav items={navItems} cta={navCta} />}
      footer={slots.footer}
      data-appspec-page="PaintingDetailPage"
    >
      {skeleton && <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />}

      <ZoomModal
        isOpen={isZoomModalOpen}
        onClose={() => setIsZoomModalOpen(false)}
        imageSrc={currentPainting.imageSrc}
        imageAlt={currentPainting.title}
      />
    </PublicShell>
  );
}