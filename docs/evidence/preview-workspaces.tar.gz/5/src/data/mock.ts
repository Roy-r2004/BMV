export const brand = {"name": "Jane Art", "tagline": "", "design_system": {"primary_color": "#0f766e", "secondary_color": "#0369a1", "background_color": "#f8fafc", "surface_color": "#ffffff", "text_color": "#042f2e", "muted_text_color": "#5f7a78", "font_family": "Source Sans 3", "display_font_family": "Fraunces", "font_import_url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap", "font_sans": "\"Source Sans 3\", \"Segoe UI\", sans-serif", "font_display": "\"Fraunces\", Georgia, serif", "brand_locked": true, "brand_brief_version": "1.0", "mood": "modern", "voice": "Warm, grounded, unhurried. Speak like a trusted studio host.", "signature": "A calm full-bleed atmosphere with Jane Art as the hero signal, not a card grid.", "avoid": ["purple-on-white or purple-to-indigo default themes", "Inter / Roboto / Arial as the display face", "card grids in the hero", "generic SaaS marketing copy", "inventing a second palette per page"], "rules": ["Every page inherits this palette and type stack via CSS tokens only.", "Use bg-brand / text-brand / font-display — never hardcode hex colors.", "First viewport must feature the brand name as a hero-level signal."], "recipe_id": "editorial", "hub_variant": "marketing", "hero_variant": "cinematic", "feature_variant": "alternating", "recipe_prompt": "RECIPE editorial: generous whitespace, serif/display headlines via font-display, fewer cards, longer subcopy, cinematic imagery, avoid dense tables on public pages.", "style_keywords": "Editorial", "border_radius": "0.35rem"},
  services: [{"name": "Jane Art Signature", "title": "Jane Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jane Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jane Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jane", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jane Art clients.",

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  name: "Jane Art",
  tagline: {},
};

export const images = {
  "hero": "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=1400&q=80&fit=crop&auto=format",
  "hero2": "https://images.unsplash.com/photo-1497366216548-37526070297c?w=700&q=80&fit=crop&auto=format",
  "card1": "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=700&q=80&fit=crop&auto=format",
  "card2": "https://images.unsplash.com/photo-1552664730-d307ca884978?w=700&q=80&fit=crop&auto=format",
  "card3": "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=900&q=80&fit=crop&auto=format",
  "ambient": "https://images.unsplash.com/photo-1553877522-43269d4ea984?w=1400&q=80&fit=crop&auto=format"
};

export const roles = [
  {
    "id": "customer",
    "label": "Collector",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "owner",
    "label": "Curator",
    "defaultPath": "/admin",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Jane Art"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Jane Art"
    }
  ],
  "admin": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login - Jane Art"
    },
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin"
    },
    {
      "id": "admin-paintings-add",
      "path": "/admin/paintings/add",
      "href": "/admin/paintings/add",
      "label": "Add"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Jane Art"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Jane Art"
    }
  ],
  "owner": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login - Jane Art"
    },
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin"
    },
    {
      "id": "admin-paintings-add",
      "path": "/admin/paintings/add",
      "href": "/admin/paintings/add",
      "label": "Add"
    }
  ]
};

// build-correctness guard: auto-added missing exports
export const stats = [{"id": "stats-1", "name": "stats 1", "title": "stats 1", "label": "stats 1", "status": "In progress", "detail": "Sample Jane Art record for demo lists", "message": "stats update 1", "amount": 52, "count": 4, "date": "2026-07-16", "time": "10:00", "startDate": "2026-07-16", "endDate": "2026-07-16", "dropOffDate": "2026-07-16", "dropOffTime": "10:00", "pickupDate": "2026-07-18", "scheduledAt": "2026-07-16T10:00:00", "createdAt": "2026-07-16T10:00:00", "timestamp": "2026-07-16T10:00:00", "instructor": "Maya R.", "memberName": "Member 1", "loadType": "Bisque", "registered": 5, "capacity": 12, "isFull": false}, {"id": "stats-2", "name": "stats 2", "title": "stats 2", "label": "stats 2", "status": "Done", "detail": "Sample Jane Art record for demo lists", "message": "stats update 2", "amount": 64, "count": 5, "date": "2026-07-17", "time": "11:30", "startDate": "2026-07-17", "endDate": "2026-07-17", "dropOffDate": "2026-07-17", "dropOffTime": "11:30", "pickupDate": "2026-07-19", "scheduledAt": "2026-07-17T11:30:00", "createdAt": "2026-07-17T11:30:00", "timestamp": "2026-07-17T11:30:00", "instructor": "Jordan K.", "memberName": "Member 2", "loadType": "Glaze", "registered": 6, "capacity": 12, "isFull": false}, {"id": "stats-3", "name": "stats 3", "title": "stats 3", "label": "stats 3", "status": "Scheduled", "detail": "Sample Jane Art record for demo lists", "message": "stats update 3", "amount": 76, "count": 6, "date": "2026-07-18", "time": "12:00", "startDate": "2026-07-18", "endDate": "2026-07-18", "dropOffDate": "2026-07-18", "dropOffTime": "12:00", "pickupDate": "2026-07-20", "scheduledAt": "2026-07-18T12:00:00", "createdAt": "2026-07-18T12:00:00", "timestamp": "2026-07-18T12:00:00", "instructor": "Sam T.", "memberName": "Member 3", "loadType": "Cone 6", "registered": 7, "capacity": 12, "isFull": false}, {"id": "stats-4", "name": "stats 4", "title": "stats 4", "label": "stats 4", "status": "Open", "detail": "Sample Jane Art record for demo lists", "message": "stats update 4", "amount": 88, "count": 7, "date": "2026-07-19", "time": "13:30", "startDate": "2026-07-19", "endDate": "2026-07-19", "dropOffDate": "2026-07-19", "dropOffTime": "13:30", "pickupDate": "2026-07-21", "scheduledAt": "2026-07-19T13:30:00", "createdAt": "2026-07-19T13:30:00", "timestamp": "2026-07-19T13:30:00", "instructor": "Noa B.", "memberName": "Member 4", "loadType": "Raku", "registered": 8, "capacity": 12, "isFull": false}];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
