// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, ProductShowcase, ProcessSection, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jane Art"} headline={"Jane Art - Curating Moments of Beauty"} subcopy="A clear, considered experience built around your next step." primaryCta={{ label: "Get started", href: "#details" }} imageSrc={images.hero} imageAlt="" />
    ),
    features: (
      <FeatureBento heading="What you can expect" items={[{ title: "Simple planning", description: "Everything needed to make a confident choice." }, { title: "Thoughtful service", description: "A consistent experience from first visit to follow-up." }]} />
    ),
    showcase: (
      <ProductShowcase heading="Featured experiences" items={[{ title: "Signature service", description: "A dependable starting point.", imageSrc: images.card1, imageAlt: "" }, { title: "Everyday essential", description: "Built for daily use.", imageSrc: images.card2, imageAlt: "" }]} />
    ),
    process: (
      <ProcessSection heading="How it works" steps={[{ title: "Choose", description: "Find the right option." }, { title: "Confirm", description: "Select a convenient time." }, { title: "Enjoy", description: "We take care of the details." }]} />
    ),
    testimonials: (
      <TestimonialRail heading="What clients say" items={[{ quote: "Clear, warm, and easy from start to finish.", author: "A returning client", role: "Verified guest" }]} />
    ),
    cta: (
      <CTABand heading="Ready for the next step?" primaryCta={{ label: "Get started", href: "#details" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jane Art"} description="Thoughtful service, clearly delivered." />
    ),
  };

  return (
    <PublicShell brandName={"Jane Art"} chrome="immersive" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
