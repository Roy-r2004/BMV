export const brand = {
  name: "Jeanne Kassab Art",
  tagline: "Original oil paintings for collectors, curated with intention.",
  accent: "#0f766e",
  accent_dark: "#0b5c56",
  accent_light: "#e0f2f1",

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  services: [{"name": "Jeanne Kassab Art Signature", "title": "Jeanne Kassab Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jeanne Kassab Art clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/6607759/pexels-photo-6607759.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/36764950/pexels-photo-36764950.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/6109043/pexels-photo-6109043.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/16960921/pexels-photo-16960921.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/36764944/pexels-photo-36764944.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/3704263/pexels-photo-3704263.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item1": "https://images.pexels.com/photos/7718455/pexels-photo-7718455.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item2": "https://images.pexels.com/photos/16397831/pexels-photo-16397831.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item3": "https://images.pexels.com/photos/4823073/pexels-photo-4823073.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item4": "https://images.pexels.com/photos/16397772/pexels-photo-16397772.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item5": "https://images.pexels.com/photos/16397793/pexels-photo-16397793.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item6": "https://images.pexels.com/photos/1701227/pexels-photo-1701227.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item7": "https://images.pexels.com/photos/16397760/pexels-photo-16397760.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item8": "https://images.pexels.com/photos/4780946/pexels-photo-4780946.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Jeanne Kassab Art"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    },
    {
      "id": "order-confirmation",
      "path": "/order-confirmation",
      "href": "/order-confirmation",
      "label": "Order Confirmation"
    }
  ],
  "admin": [
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin"
    },
    {
      "id": "admin-paintings-new",
      "path": "/admin/paintings/new",
      "href": "/admin/paintings/new",
      "label": "New"
    },
    {
      "id": "admin-orders",
      "path": "/admin/orders",
      "href": "/admin/orders",
      "label": "Orders | Canvas Curator"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Jeanne Kassab Art"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    },
    {
      "id": "order-confirmation",
      "path": "/order-confirmation",
      "href": "/order-confirmation",
      "label": "Order Confirmation"
    }
  ],
  "operator": [
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin"
    },
    {
      "id": "admin-paintings-new",
      "path": "/admin/paintings/new",
      "href": "/admin/paintings/new",
      "label": "New"
    },
    {
      "id": "admin-orders",
      "path": "/admin/orders",
      "href": "/admin/orders",
      "label": "Orders | Canvas Curator"
    }
  ]
};

export const paintings = [
  {
    id: "whispers-of-dusk",
    title: "Whispers of Dusk",
    medium: "Oil on canvas",
    dimensions: "36 x 48 inches",
    year: 2023,
    price: "$2,800",
    description:
      "An abstract landscape echoing the quiet transition from day to night, rendered in layered oils. This piece explores the subtle shifts of light and shadow as day gives way to twilight, inviting contemplation.",
    image: images.item1,
    isSold: false,
  },
  {
    id: "oceanic-depths",
    title: "Oceanic Depths",
    medium: "Oil on linen",
    dimensions: "40 x 30 inches",
    year: 2022,
    price: "$3,500",
    description:
      "A deep dive into cool blues and greens, capturing the vastness of the sea in impasto textures. 'Oceanic Depths' evokes the mysterious beauty of the ocean's silent world, where light dances through water.",
    image: images.item2,
    isSold: false,
  },
  {
    id: "earth-embrace",
    title: "Earth's Embrace",
    medium: "Oil on panel",
    dimensions: "24 x 24 inches",
    year: 2023,
    price: "$2,200",
    description:
      "Warm earth tones and organic forms intertwine, celebrating the grounding presence of nature. This painting is a tribute to the unseen connections within our natural environment.",
    image: images.item3,
    isSold: true,
  },
  {
    id: "crimson-horizon",
    title: "Crimson Horizon",
    medium: "Oil on canvas",
    dimensions: "48 x 36 inches",
    year: 2023,
    price: "$3,100",
    description:
      "A vibrant abstract, where bold strokes of crimson meet a serene, expansive sky. 'Crimson Horizon' captures the dramatic beauty of a sunset over an imagined landscape, full of passion and peace.",
    image: images.item4,
    isSold: false,
  },
  {
    id: "silver-lining",
    title: "Silver Lining",
    medium: "Oil on board",
    dimensions: "18 x 24 inches",
    year: 2022,
    price: "$1,900",
    description:
      "Delicate layers of silver and grey evoke a sense of hope and ethereal beauty. This piece explores the subtle interplay of light on cloudy days, finding beauty in overcast skies.",
    image: images.item5,
    isSold: false,
  },
  {
    id: "golden-fields",
    title: "Golden Fields",
    medium: "Oil on linen",
    dimensions: "30 x 40 inches",
    year: 2021,
    price: "$2,750",
    description:
      "Radiant yellows and rich ochres narrate the story of sun-drenched landscapes and bountiful harvests. A celebration of warmth and abundance, bringing the vibrancy of nature indoors.",
    image: images.item6,
    isSold: true,
  },
  {
    id: "indigo-dream",
    title: "Indigo Dream",
    medium: "Oil on canvas",
    dimensions: "36 x 36 inches",
    year: 2023,
    price: "$2,950",
    description:
      "A tranquil composition in deep indigo and sapphire, inviting introspection and calm. 'Indigo Dream' is a journey into the subconscious, a painted reverie.",
    image: images.item7,
    isSold: false,
  },
  {
    id: "verdant-memory",
    title: "Verdant Memory",
    medium: "Oil on panel",
    dimensions: "20 x 20 inches",
    year: 2022,
    price: "$2,600",
    description:
      "Lush greens and hidden textures recall the verdant beauty of forgotten places in nature. This painting is a nostalgic echo of wild growth and serene hidden groves.",
    image: images.item8,
    isSold: false,
  },
  {
    id: "mountain-mist",
    title: "Mountain Mist",
    medium: "Oil on canvas",
    dimensions: "30 x 60 inches",
    year: 2024,
    price: "$4,200",
    description:
      "A large-scale atmospheric piece capturing the ethereal dance of mist through mountain peaks. Delicate washes and strong impasto strokes convey both grandeur and fleeting beauty.",
    image: images.card1, // Reusing images for more variety
    isSold: false,
  },
  {
    id: "desert-bloom",
    title: "Desert Bloom",
    medium: "Oil on linen",
    dimensions: "24 x 30 inches",
    year: 2024,
    price: "$2,100",
    description:
      "Vibrant bursts of color against a muted, sandy backdrop, reflecting the surprising beauty of desert flora after rain. A celebration of resilience and unexpected life.",
    image: images.card2, // Reusing images for more variety
    isSold: false,
  },
];


export const roles = [
  {
    "id": "customer",
    "label": "Collector & Visitor",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "operator",
    "label": "Gallery Owner",
    "defaultPath": "/admin",
    "icon": "chart"
  }
];

export const seed = {
  trustLabels: [
    'Jeanne Kassab Art quality\', \'On schedule\', \'Repeat guests\', \'Local favorite',
  ],
  hero: {
    headline: "Original Oil Paintings by Jeanne Kassab",
    subcopy: "Discover evocative abstract landscapes and layered oils for your collection.",
    primaryCta: { label: "View Available Works", href: "/gallery" },
    secondaryCta: { label: "About the Artist", href: "/about" },
    eyebrow: "Jeanne Kassab Art"
  },
  credentialsHeading: "Why Jeanne Kassab Art",
  credentials: [
    { title: "Unique Originals", detail: "Each painting is a one-of-a-kind creation, signed by the artist." },
    { title: "Museum-Quality Materials", detail: "Crafted with professional-grade oil paints and archival surfaces." },
    { title: "Direct from Studio", detail: "Acquire pieces directly from Jeanne's studio, ensuring authenticity." },
  ],
  featuresHeading: "What Jeanne Kassab Art offers",
  features: [
    { title: "Original works", description: "Signed pieces, each one photographed as it hangs." },
    { title: "Commissions", description: "A piece scaled to your room, your light, your palette." },
    { title: "Collector support", description: "Framing, shipping, and placement handled end to end." },
  ],
  showcaseHeading: "From Jeanne Kassab Art",
  items: paintings.map(p => ({
    title: p.title,
    description: p.description,
    imageSrc: p.image,
    imageAlt: p.title,
    badge: p.isSold ? "Sold" : "Available",
    id: p.id,
    href: `/gallery/${p.id}`,
  })), // Using actual paintings for showcase
  testimonialsHeading: "Words from Collectors",
  testimonials: [
    {
      name: "Sophia Chen",
      initials: "SC",
      text: "The painting brings such calm and depth to my living room. Jeanne's online gallery made the entire process so personal and effortless.",
      service: "Original Painting"
    },
    {
      name: "Marcus Sterling",
      initials: "MS",
      text: "I was looking for a statement piece, and Jeanne's work exceeded all expectations. The detail page let me truly appreciate every brushstroke before inquiring.",
      service: "Original Painting"
    },
    {
      name: "Eleanor Vance",
      initials: "EV",
      text: "The online experience was elegant and straightforward. It felt like walking through a private gallery, even from my home office.",
      service: "Original Painting"
    },
    {
      name: "David Miller",
      initials: "DM",
      text: "A truly captivating piece that enhances my entire study. The process from selection to delivery was handled with exceptional care.",
      service: "Original Painting"
    },
    {
      name: "Isabelle Dubois",
      initials: "ID",
      text: "Jeanne's art has a unique way of speaking to the soul. My commissioned piece perfectly captures the essence I desired for my space.",
      service: "Art Commission"
    },
  ],
  cta: {
    headline: "Discover Your Next Masterpiece",
    subcopy: "Explore the full collection of original oil paintings and bring home a unique work of art.",
    primaryCta: { label: "View Gallery", href: "/gallery" },
    secondaryCta: { label: "Inquire about Commissions", href: "/contact" },
  },
  opsHero: {
    headline: "Canvas Curator Dashboard",
    subcopy: "Manage your gallery operations and sales.",
  },
  kpis: [
    { label: "Available Paintings", value: "8", delta: "-2", hint: "Last month" },
    { label: "Pending Orders", value: "2", delta: "+1", hint: "Last 24 hours" },
    { label: "Total Sales (MoM)", value: "$9.5K", delta: "+10%", hint: "Compared to last month" },
  ],
  tableRows: [
    { id: "CC-2023-005", customer: "Sarah Chen", items: "'Ocean Deep'", total: "$2,800", status: "Processing", date: "2024-03-20" },
    { id: "CC-2023-004", customer: "Liam Smith", items: "'Forest Edge'", total: "$3,200", status: "Shipped", date: "2024-03-18" },
    { id: "CC-2023-003", customer: "Olivia Brown", items: "'Desert Horizon'", total: "$2,500", status: "Completed", date: "2024-03-15" },
    { id: "CC-2023-002", customer: "Noah Johnson", items: "'Azure Peaks'", total: "$4,100", status: "Completed", date: "2024-03-12" },
    { id: "CC-2023-001", customer: "Emma Davis", items: "'Golden Fields'", total: "$2,750", status: "Completed", date: "2024-03-10" },
  ],
  activity: [
    { title: "Order #CC-2023-005 received", detail: "Collector: Sarah Chen, 'Ocean Deep' purchased.", when: "Just now" },
    { title: "New painting uploaded", detail: "'Mountain Mist' added to gallery.", when: "2 hours ago" },
    { title: "Inventory update for 'Earth's Embrace'", detail: "Painting status changed to 'Sold'.", when: "Yesterday" },
    { title: "New inquiry from Maya Patel", detail: "Commission request for large-scale triptych.", when: "2 days ago" },
    { title: "Order #CC-2023-004 shipped", detail: "Collector: Liam Smith, Tracking #XYZ123.", when: "3 days ago" },
  ],
  footer: {
    
  }
,
  ctaDescription: "Cta description — Jeanne Kassab Art",
  ctaHeading: "Cta heading — Jeanne Kassab Art",
  showcase: [{ title: "Showcase — Jeanne Kassab Art", description: "Prepared by Jeanne Kassab Art." }],
};

export const stats = {
  chartData: [
    { label: "Jan", value: 4 },
    { label: "Feb", value: 6 },
    { label: "Mar", value: 5 },
    { label: "Apr", value: 8 },
    { label: "May", value: 7 },
    { label: "Jun", value: 9 },
    { label: "Jul", value: 11 },
    { label: "Aug", value: 10 },
    { label: "Sep", value: 12 },
    { label: "Oct", value: 14 },
    { label: "Nov", value: 13 },
    { label: "Dec", value: 15 },
  ],
  recentOrders: [
    {
      id: paintings[0].id,
      title: paintings[0].title,
      price: paintings[0].price,
      customer: "Eleanor Vance",
      status: "Processing",
      date: "2024-03-25",
    },
    {
      id: paintings[1].id,
      title: paintings[1].title,
      price: paintings[1].price,
      customer: "Marcus Sterling",
      status: "Pending Shipment",
      date: "2024-03-24",
    },
    {
      id: paintings[7].id,
      title: paintings[7].title,
      price: paintings[7].price,
      customer: "Sophia Chen",
      status: "Shipped",
      date: "2024-03-22",
    },
    {
      id: paintings[3].id,
      title: paintings[3].title,
      price: paintings[3].price,
      customer: "David Miller",
      status: "Completed",
      date: "2024-03-20",
    },
    {
      id: paintings[5].id,
      title: paintings[5].title,
      price: paintings[5].price,
      customer: "Isabelle Dubois",
      status: "Completed",
      date: "2024-03-18",
    },
  ],
};
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;