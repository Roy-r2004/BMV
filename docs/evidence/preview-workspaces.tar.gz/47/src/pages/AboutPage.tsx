// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const; // Updated order based on page brief needs

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    features: (
      <FeatureBento heading={seed.featuresHeading ?? "What Jeanne Kassab Art offers"} imagePool={[images.card1, images.card2, images.card3]} items={seed.features?.length ? seed.features : [{"title": "Original works", "description": "Signed pieces, each one photographed as it hangs."}, {"title": "Commissions", "description": "A piece scaled to your room, your light, your palette."}, {"title": "Collector support", "description": "Framing, shipping, and placement handled end to end."}]} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Jeanne Kassab Art"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.card1, images.card2, images.card3][index % 3], imageAlt: item.title, badge: String((item as any).badge || (item as any).category || "Featured work"), href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        eyebrow={"Meet the Artist"}
        headline={"About Jeanne Kassab"}
        subcopy={"Journey into the inspirations and artistic philosophy behind Jeanne Kassab Art."}
        primaryCta={{ label: "Explore My Paintings", href: "/gallery" }}
        imageSrc={images.hero2} // Using hero2 for Jeanne's photograph
        imageAlt="Jeanne Kassab, artist"
        variant="atelier" // Adjusting variant for a more personal, artistic feel
        className="pb-24 pt-32" // Generous padding for whitespace
      />
    ),
    credentials: (
      <div className="max-w-4xl mx-auto py-24 px-4 sm:px-6 lg:px-8 bg-surface rounded-lg shadow-soft-glass mt-12 mb-12">
        {/* Manually crafted content for artist bio and statement within a div, ensuring ample whitespace and direct styling */}
        <h2 className="font-display text-4xl text-text-brand mb-8 text-center">My Artistic Path</h2>
        <div className="font-sans text-muted text-lg leading-relaxed space-y-6">
          <p>
            From the serene landscapes of my childhood to the vibrant cityscapes of my adult life, my artistic journey has always been guided by a profound connection to the natural world. My work explores the interplay of light, emotion, and memory, transforming raw pigment into evocative abstract landscapes. Each brushstroke is a meditation, a layer added to a story told not in words, but in color and texture.
          </p>
          <p>
            My fascination with layered oils allows me to build depth and complexity, creating surfaces that invite closer inspection and reveal new details with every glance. This process, often slow and deliberate, mirrors the organic evolution of the landscapes themselves, capturing moments of shifting light and transient beauty.
          </p>
          <p>
            I believe art has the power to transform spaces and souls. My hope is that each painting offers a quiet sanctuary, a moment of reflection, and a deep sense of connection to the enduring beauty of our world.
          </p>
          <h3 className="font-display text-3xl text-text-brand mt-16 mb-6 text-center">Artist Statement</h3>
          <p>
            "My art is an invitation to pause and discover the subtle narratives held within nature. Through abstract forms and a fervent use of color, I strive to capture the fleeting essence of landscapes — not as they are seen, but as they are felt. My work is a dialogue between memory and imagination, where light is a character and shadow, a silent confidante. Each canvas is a journey into the heart of perception, offering a new perspective on the unseen beauty that surrounds us."
          </p>
        </div>
      </div>
    ),
    testimonials: (
      <TestimonialRail
        heading={"Collector Reflections"}
        items={[
          {
            quote: "Jeanne's painting transformed my living space. It brings a profound sense of calm and beauty every single day. The layers are captivating.",
            author: "Eleanor V.",
            role: "Art Collector"
          },
          {
            quote: "Working with Jeanne to select a piece for a client's project was seamless. Her art adds such a sophisticated, earthy elegance.",
            author: "Marcus P.",
            role: "Interior Designer"
          },
          {
            quote: "Her abstract landscapes have a unique ability to evoke both memory and wonder. Truly exceptional work.",
            author: "Dr. Anya Sharma",
            role: "Gallery Visitor"
          },
        ]}
        className="py-24" 
      />
    ),
    cta: (
      <CTABand
        heading={"Discover the Collection"}
        description={"Explore Jeanne Kassab's original oil paintings and find a piece that speaks to you."}
        primaryCta={{ label: "View Available Paintings", href: "/gallery" }}
        secondaryCta={{ label: "Inquire About Commissions", href: "/contact" }}
        className="py-24" 
      />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={"Jeanne Kassab Art — original works, shown plainly."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="about">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}