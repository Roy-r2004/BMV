// composed confirmation page (ConfirmStage)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, BrandFooter, ConfirmStage } from '@/ui';

export default function OrderConfirmationPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();

  return (
    <>
      <div className="contents" data-appspec-page="order-confirmation">
      </div>
      <PublicShell
      brandName={"Jeanne Kassab Art"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <ConfirmStage
        eyebrow={"Confirmed"}
        title={"Order Confirmed"}
        detail={"Confirmation on file"}
        description={"Thank you for your purchase from Jeanne Kassab Art."}
        primaryCta={{"label": "Back to home", "href": "/"}}
        nextSteps={[{"title": "Order #JK2024-0317A", "description": "Your order for 'Crimson Horizon' has been successfully placed. A confirmation email with details and an estimated delivery timeframe has been sent to your inbox. We will contact you shortly regarding shipping arrangements.", "ctaLabel": "View Your Artworks", "href": "/account/orders/JK2024-0317A"}, {"title": "Need Assistance?", "description": "If you have any questions about your order or shipping, please don't hesitate to reach out.", "ctaLabel": "Contact Us", "href": "/contact"}, {"title": "Explore More Art", "description": "Discover new arrivals and other unique original oil paintings.", "ctaLabel": "Continue Browsing", "href": "/gallery"}]}
      />
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"© 2024 Jeanne Kassab Art. All rights reserved."}
      />
    </PublicShell>
    </>
  );
}
