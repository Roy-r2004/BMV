// composed public-utility page (content JSON → kit)
import { PublicShell, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, Input, CTABand } from '@/ui';
import { PageHeader } from '@/ui/PageHeader';
import { seed } from '@/data/mock'; // Import seed from mock data

const SKELETON_ID = "public-utility" as const;

export default function CheckoutPage() {

  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    header: (
      <PageHeader title="Complete Your Order" description="Secure Checkout" compact />
    ),
    workspace: (
      <Card className="space-y-4 p-6">
          <div className="grid gap-4 md:grid-cols-2">
          <Input
            label={"Email"}
            placeholder={"your@email.com"}
            type={"email"}
          />
          <Input
            label={"Full Name"}
            placeholder={"First Last"}
            type={"text"}
          />
          <Input
            label={"Shipping Address"}
            placeholder={"123 Gallery Lane"}
            type={"text"}
          />
          <Input
            label={"City"}
            placeholder={"Artville"}
            type={"text"}
          />
          <Input
            label={"State / Province"}
            placeholder={"CA"}
            type={"text"}
          />
          <Input
            label={"Zip / Postal Code"}
            placeholder={"90210"}
            type={"text"}
          />
          </div>
          <p className="text-sm text-muted">{"A final shipping cost will be calculated at the next step."}</p>
        </Card>
    ),
    summary: (
      <Card className="space-y-4 p-6">
          <h3 className="font-display text-2xl text-foreground">{"Order Summary"}</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-3 text-sm">
              <span className="text-muted">{"Deep Horizon (2023)"}</span>
              <span className="font-semibold tabular-nums text-foreground">$2,800</span>
            </div>
            <div className="flex items-center justify-between gap-3 text-sm">
              <span className="text-muted">{"Shipping (estimated)"}</span>
              <span className="font-semibold tabular-nums text-foreground">{"Calculated Next"}</span>
            </div>
            <div className="flex items-center justify-between gap-3 text-sm">
              <span className="text-muted">{"Total"}</span>
              <span className="font-semibold tabular-nums text-foreground">$2,800</span>
            </div>
          </div>
          <Button href={"/order-confirmation"} className="w-full sm:w-auto">
            {"Continue to Shipping"}
          </Button>
        </Card>
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"All transactions are secure and encrypted. Your privacy is paramount."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="checkout">
      </div>
      <PublicShell
      brandName={"Jeanne Kassab Art"}
      chrome="solid"
      nav={null}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"checkout"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}