// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jeanne Kassab Art"} eyebrow={seed.hero?.eyebrow ?? "Brand"} headline={seed.hero?.headline || "Contact | Jeanne Kassab Art"} subcopy={seed.hero?.subcopy} primaryCta={seed.hero?.primaryCta} secondaryCta={seed.hero?.secondaryCta} imageSrc={images.hero} imageAlt="" />
    ),
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Brand"} items={seed.credentials ?? []} />
    ),
    features: (
      <FeatureBento heading={seed.featuresHeading ?? "What Brand offers"} imagePool={[images.card1, images.card2, images.card3]} items={seed.features?.length ? seed.features : [{"title": "Original works", "description": "Signed pieces, each one photographed as it hangs."}, {"title": "Commissions", "description": "A piece scaled to your room, your light, your palette."}, {"title": "Collector support", "description": "Framing, shipping, and placement handled end to end."}]} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Brand"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.card1, images.card2, images.card3][index % 3], imageAlt: item.title, badge: String((item as any).badge || (item as any).category || "Featured work"), href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Brand"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Brand?"} description={seed.cta?.description ?? "Tell Brand what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={seed.footer?.description ?? "Brand — original works, shown plainly."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="contact">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}
