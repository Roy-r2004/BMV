// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CatalogGrid, BrandFooter, Input, Select, Button, LogoMarquee } from '@/ui';
import { useState } from 'react';

const SKELETON_ID = "public-catalog" as const;
const RECIPE_ORDER = ["hero", "showcase", "features", "cta", "footer"] as const;

// Define a type for artwork items conforming to CatalogGrid's item shape
interface ArtworkItem {
  id: string;
  title: string;
  description: string;
  meta: string; // Price
  category?: string;
  status: 'available' | 'sold';
  imageSrc: string;
  imageAlt: string;
  badge?: string;
}

const mockArtworks: ArtworkItem[] = [
  {
    id: 'painting-1',
    title: 'Whispers of Dusk',
    description: 'An abstract landscape echoing the quiet transition from day to night, rendered in layered oils.',
    meta: '$2,800',
    status: 'available',
    imageSrc: images.item1,
    imageAlt: 'Whispers of Dusk - Original Oil Painting',
  },
  {
    id: 'painting-2',
    title: 'Oceanic Depths',
    description: 'A deep dive into cool blues and greens, capturing the vastness of the sea in impasto textures.',
    meta: '$3,500',
    status: 'available',
    imageSrc: images.item2,
    imageAlt: 'Oceanic Depths - Original Oil Painting',
  },
  {
    id: 'painting-3',
    title: 'Earth\'s Embrace',
    description: 'Warm earth tones and organic forms intertwine, celebrating the grounding presence of nature.',
    meta: '$2,200',
    status: 'sold',
    imageSrc: images.item3,
    imageAlt: 'Earth\'s Embrace - Original Oil Painting',
    badge: 'Sold',
  },
  {
    id: 'painting-4',
    title: 'Crimson Horizon',
    description: 'A vibrant abstract, where bold strokes of crimson meet a serene, expansive sky.',
    meta: '$3,100',
    status: 'available',
    imageSrc: images.item4,
    imageAlt: 'Crimson Horizon - Original Oil Painting',
  },
  {
    id: 'painting-5',
    title: 'Silver Lining',
    description: 'Delicate layers of silver and grey evoke a sense of hope and ethereal beauty.',
    meta: '$1,900',
    status: 'available',
    imageSrc: images.item5,
    imageAlt: 'Silver Lining - Original Oil Painting',
  },
  {
    id: 'painting-6',
    title: 'Golden Fields',
    description: 'Radiant yellows and rich ochres narrate the story of sun-drenched landscapes and bountiful harvests.',
    meta: '$2,750',
    status: 'sold',
    imageSrc: images.item6,
    imageAlt: 'Golden Fields - Original Oil Painting',
    badge: 'Sold',
  },
  {
    id: 'painting-7',
    title: 'Indigo Dream',
    description: 'A tranquil composition in deep indigo and sapphire, inviting introspection and calm.',
    meta: '$2,950',
    status: 'available',
    imageSrc: images.item7,
    imageAlt: 'Indigo Dream - Original Oil Painting',
  },
  {
    id: 'painting-8',
    title: 'Verdant Memory',
    description: 'Lush greens and hidden textures recall the verdant beauty of forgotten places in nature.',
    meta: '$2,600',
    status: 'available',
    imageSrc: images.item8,
    imageAlt: 'Verdant Memory - Original Oil Painting',
  },
];


export default function GalleryPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterAvailability, setFilterAvailability] = useState('all');

  const filteredArtworks = mockArtworks.filter(artwork => {
    const matchesSearch = artwork.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      artwork.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAvailability = filterAvailability === 'all' || artwork.status === filterAvailability;
    return matchesSearch && matchesAvailability;
  });

  const slots = {
    trust: (
      <LogoMarquee size="display" items={(seed.trustLabels ?? []).map((entry: any) => ({ label: String(entry?.label ?? entry ?? '') })).filter((entry: { label: string }) => entry.label)} />
    ),
    hero: (
      <MarketingHero brandName={"Jeanne Kassab Art"} headline={"Gallery"} subcopy={"Explore a living collection of original oil paintings."} primaryCta={{ label: "View available works", href: "#current-collection" }} imageSrc={images.hero} imageAlt="An abstract oil painting by Jeanne Kassab" />
    ),
    showcase: (
      <CatalogGrid
        heading="Current Collection"
        description="Discover original oil paintings, available to collect."
        detailBase="/gallery"
        itemNoun="paintings"
        items={filteredArtworks.map(painting => ({
          id: painting.id,
          title: painting.title,
          description: painting.description,
          meta: painting.meta,
          status: painting.status,
          imageSrc: painting.imageSrc,
          imageAlt: painting.imageAlt,
          badge: painting.badge,
          action: painting.status === 'available' ? { label: 'Add to Cart', href: `/cart?add=${painting.id}` } : undefined, // Example: 'Add to Cart' if available
        }))}
        className="pt-16 pb-16"
      />
    ),
    features: (
      <div id="search-filter" className="flex flex-col md:flex-row gap-4 justify-between p-4 md:p-8 max-w-7xl mx-auto bg-surface rounded-lg shadow-sm -mt-24 relative z-10 transition-all duration-300 ease-in-out md:sticky md:top-24 dark:bg-gray-800">
        <Input
          type="text"
          placeholder="Search paintings..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-grow w-full md:w-auto soft-glass-input"
          label="Search"
        />
        <div className="flex items-center gap-4 w-full md:w-auto">
          <Select
            label="Availability"
            options={[
              { label: 'All', value: 'all' },
              { label: 'Available', value: 'available' },
              { label: 'Sold', value: 'sold' },
            ]}
            value={filterAvailability}
            onValueChange={setFilterAvailability}
            className="w-full md:w-auto soft-glass-select"
          />
          {/* Add a placeholder for more filters if needed. Keep it simple for MVP. */}
          {/* <Button variant="ghost" size="sm" className="bg-brand/10 text-brand">More filters</Button> */}
        </div>
      </div>
    ),
    cta: (
      // CTABand is a required slot if features is used, providing a natural follow-up action.
      // Based on the given requirements, the CTA brief is generic, so we'll adapt it.
      // The hero has a primary CTA to 'View collection', so this CTA can focus on 'Contact'.
      <></>
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={"Original oil paintings for collectors and designers. A living gallery of abstract landscapes and layered oils."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="gallery">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}