import { Link, useParams } from 'react-router-dom';
import { Fragment, useState } from 'react';
import { paintings as mockPaintings } from '../data/mock'; // Assuming mock paintings for now
import { UiIcon } from '../components/UiIcon'; // Assuming a UiIcon component for icons

export default function ArtworkDetailPage() {
  const { paintingId } = useParams();
  const painting = mockPaintings.find((p) => p.id === paintingId);
  const [isInquiryModalOpen, setIsInquiryModalOpen] = useState(false); // For modal if needed, but for now direct cart

  if (!painting) {
    return (
      <div className="container mx-auto px-6 py-16 text-center text-text lg:py-24">
        <h1 className="mb-4 font-display text-4xl font-semibold lg:text-6xl">Painting Not Found</h1>
        <p className="text-xl text-muted">The artwork you are looking for may have moved or been sold.</p>
        <Link
          to="/gallery"
          className="mt-8 inline-flex items-center justify-center rounded-[var(--radius-ui)] border border-brand bg-transparent px-8 py-3 text-lg font-medium text-brand shadow-sm transition-all ease-in-out hover:scale-[1.02] hover:bg-brand hover:text-white focus:outline-none focus:ring-2 focus:ring-brand focus:ring-offset-2"
        >
          Explore the Gallery
        </Link>
      </div>
    );
  }

  // Determine availability status for display
  const availabilityStatus = painting.isSold ? 'Sold' : 'Available for Purchase';
  const availabilityColor = painting.isSold ? 'text-muted_text' : 'text-brand';

  // Subtle hover effect
  const imageHoverClass = "transition-transform duration-300 ease-in-out group-hover:scale-[1.01]";

  return (
    <Fragment>
      <section className="relative overflow-hidden py-10 lg:py-16 bg-atmosphere">
        <div className="container mx-auto max-w-7xl px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:gap-16">
            {/* Image Section */}
            <div className="lg:w-2/3 group relative">
              <div className="relative overflow-hidden rounded-[var(--radius-ui)] shadow-[var(--shadow)] bg-surface">
                <img
                  src={painting.image}
                  alt={`Artwork: ${painting.title}`}
                  className={`w-full object-cover object-center ${imageHoverClass}`}
                />
              </div>
            </div>

            {/* Details Section */}
            <div className="mt-8 lg:mt-0 lg:w-1/3 p-4 lg:p-0">
              <h1 className="font-display text-4xl font-semibold leading-tight text-text lg:text-5xl">
                {painting.title}
              </h1>
              <p className="mt-4 font-normal text-xl text-muted font-sans">{painting.medium}</p>

              <div className="mt-6 border-t border-b border-border-subtle py-6">
                <dl className="space-y-3 text-text font-sans">
                  <div className="flex justify-between items-center">
                    <dt className="font-medium text-muted">Dimensions:</dt>
                    <dd className="text-right">{painting.dimensions}</dd>
                  </div>
                  <div className="flex justify-between items-center">
                    <dt className="font-medium text-muted">Year Created:</dt>
                    <dd className="text-right">{painting.year}</dd>
                  </div>
                  <div className="flex justify-between items-center">
                    <dt className="font-medium text-muted">Price:</dt>
                    <dd className="text-right font-semibold text-text">{painting.price}</dd>
                  </div>
                  <div className="flex justify-between items-center pt-2">
                    <dt className="font-medium text-muted">Availability:</dt>
                    <dd className={`font-semibold text-right ${availabilityColor}`}>
                      {availabilityStatus}
                    </dd>
                  </div>
                </dl>
              </div>

              <div className="mt-6 text-lg leading-relaxed text-muted font-sans">
                {painting.description}
              </div>

              <div className="mt-10">
                {painting.isSold ? (
                  <button
                    disabled
                    className="inline-flex w-full items-center justify-center rounded-[var(--radius-ui)] bg-muted_text px-8 py-3 text-lg font-medium text-white opacity-70 cursor-not-allowed shadow-md"
                  >
                    Sold
                  </button>
                ) : (
                  <button
                    onClick={() => console.log(`Adding ${painting.title} to cart`)} // Placeholder for add to cart logic
                    className="inline-flex w-full items-center justify-center rounded-[var(--radius-ui)] bg-brand px-8 py-3 text-lg font-medium text-white shadow-lg transition-all ease-in-out hover:scale-[1.01] hover:bg-brand-dark focus:outline-none focus:ring-2 focus:ring-brand focus:ring-offset-2"
                  >
                    <UiIcon name="PlusCircle" className="mr-2 h-5 w-5" />
                    Add to Cart
                  </button>
                )}
                {!painting.isSold && (
                  <Link
                    to="/contact" // Assuming contact for general inquiries
                    className="mt-4 inline-flex w-full items-center justify-center rounded-[var(--radius-ui)] border border-brand bg-transparent px-8 py-3 text-lg font-medium text-brand shadow-sm transition-all ease-in-out hover:scale-[1.01] hover:bg-brand hover:text-white focus:outline-none focus:ring-2 focus:ring-brand focus:ring-offset-2"
                  >
                    <UiIcon name="Mail" className="mr-2 h-5 w-5" />
                    Inquire about this Piece
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Related Works Section */}
      <section className="py-16