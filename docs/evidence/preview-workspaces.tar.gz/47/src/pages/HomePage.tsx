// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter, Button } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    features: (
      <FeatureBento
        heading={seed.featuresHeading ?? "What Jeanne Kassab Art offers"}
        imagePool={[images.card1, images.card2, images.card3]}
        items={seed.features?.length ? seed.features : [
          { "title": "Original works", "description": "Signed pieces, each one photographed as it hangs." },
          { "title": "Commissions", "description": "A piece scaled to your room, your light, your palette." },
          { "title": "Collector support", "description": "Framing, shipping, and placement handled end to end." }
        ]}
      />
    ),
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"Original Oil Paintings by Jeanne Kassab"}
        subcopy={"Discover evocative abstract landscapes and layered oils for your collection."}
        primaryCta={{
          label: "View Gallery",
          href: "/gallery"
        }}
        secondaryCta={{
          label: "Request Commission",
          href: "/contact"
        }}
        imageSrc={images.hero}
        imageAlt={"Abstract oil painting by Jeanne Kassab"}
      />
    ),
    showcase: (
      <ProductShowcase
        heading={seed.showcaseHeading ?? "Featured Works"}
        items={seed.showcase?.length ? seed.showcase : [
          { "title": "Golden Hour", "description": "Oil on canvas, 24x36 inches", "imageSrc": images.product1, "href": "/gallery/golden-hour" },
          { "title": "Forest Serenade", "description": "Oil on wood panel, 18x24 inches", "imageSrc": images.product2, "href": "/gallery/forest-serenade" },
          { "title": "Crimson Tide", "description": "Oil on linen, 30x40 inches", "imageSrc": images.product3, "href": "/gallery/crimson-tide" },
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading={seed.testimonialsHeading ?? "What Collectors Say"}
        items={seed.testimonials?.length ? seed.testimonials : [
          { "quote": "Jeanne's art brings a profound sense of calm and beauty to my home.", "author": "A. Smith", "role": "Collector" },
          { "quote": "The depth and texture in her work are simply mesmerizing.", "author": "B. Jones", "role": "Interior Designer" },
        ]}
      />
    ),
    cta: (
      <CTABand
        heading={seed.ctaHeading ?? "Ready to Adorn Your Space?"}
        description={seed.ctaDescription ?? "Explore the full collection or inquire about a custom piece today."}
        primaryCta={{
          label: "Browse Artworks",
          href: "/gallery"
        }}
        secondaryCta={{
          label: "Contact Jeanne",
          href: "/contact"
        }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings for modern spaces. Discover evocative abstract landscapes and layered oils."
        }
        links={[
          { label: "Gallery", href: "/gallery" },
          { label: "Commissions", href: "/contact" },
          { label: "Contact", href: "/contact" },
          { label: "Privacy Policy", href: "#" },
        ]}
        meta={[
          { label: "&copy; 2024 Jeanne Kassab Art" },
          { label: "All rights reserved" }
        ]}

      >
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="default" aria-label="Instagram" href="https://instagram.com/jeannekassabart">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-text-muted">
              <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
              <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
              <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
            </svg>
          </Button>
          <Button variant="ghost" size="default" aria-label="Pinterest" href="https://pinterest.com/jeannekassabart" >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-text-muted">
              <path d="M12 2C6.5 2 2 6.5 2 12c0 3.3 1.6 6.3 4.2 8C5.2 19 4 17.5 4 16c0-3 2.7-5.5 6-5.5s6 2.5 6 5.5c0 2.3-1.6 4.3-4 5.2V22l-1-1v-2H11c-2.3 0-4.5-.8-6-2.2v-2.3c.6.2 1.3.4 2 .4s1.4-.1 2-.4v-1.1c-1.3-.2-2.5-.9-3.4-2.1l-1.6-2.1c-.2-.6-.4-1.2-.4-1.8 0-2.8 2.2-5 5-5s5 2.2 5 5c0 1.2-.4 2.2-1 3v.8c.2.2.4.4.6.6l1.7 1.7c.9.9 1.4 2 1.4 3.2 0 2.8-2.2 5-5 5C6.5 22 2 17.5 2 12c0-5.5 4.5-9.6 10-9.6z" />
            </svg>
          </Button>
        </div>
      </BrandFooter>
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}