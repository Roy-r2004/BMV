// composed public-utility page (content JSON → kit)
import { PublicShell, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, Table, CTABand } from '@/ui';
import { PageHeader } from '@/ui/PageHeader';
import { QuantityAdjuster } from '@/ui/QuantityAdjuster';
import { seed } from '@/data/mock'; // Import seed from mock data

const SKELETON_ID = "public-utility" as const;

export default function CartPage() {

  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    header: (
      <PageHeader title="Your Cart" description="Review your selected artworks before proceeding to checkout." compact />
    ),
    workspace: (
      <Card className="space-y-4 p-6">
        <h3 className="sr-only">Cart Items</h3>
        <div className="grid gap-4">
          <div className="flex items-center space-x-4">
            <img src="https://images.pexels.com/photos/7718455/pexels-photo-7718455.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Crimson Horizon" className="h-20 w-20 object-cover rounded-md" />
            <div className="flex-1">
              <h4 className="font-semibold">Crimson Horizon</h4>
              <p className="text-sm text-muted">Original Oil Painting, 30" x 40"</p>
              <div className="flex items-center mt-2">
                <QuantityAdjuster quantity={1} onUpdate={() => {}} />
                <Button variant="ghost" size="sm" className="ml-2 text-sm text-red-600">Remove</Button>
              </div>
            </div>
            <span className="font-semibold tabular-nums text-foreground">$3,200</span>
          </div>
          <div className="flex items-center space-x-4">
            <img src="https://images.pexels.com/photos/16397831/pexels-photo-16397831.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Whispers of the Tundra" className="h-20 w-20 object-cover rounded-md" />
            <div className="flex-1">
              <h4 className="font-semibold">Whispers of the Tundra</h4>
              <p className="text-sm text-muted">Original Oil Painting, 24" x 36"</p>
              <div className="flex items-center mt-2">
                <QuantityAdjuster quantity={1} onUpdate={() => {}} />
                <Button variant="ghost" size="sm" className="ml-2 text-sm text-red-600">Remove</Button>
              </div>
            </div>
            <span className="font-semibold tabular-nums text-foreground">$2,800</span>
          </div>
        </div>
      </Card>
    ),
    summary: (
      <Card className="space-y-4 p-6">
          <h3 className="font-display text-2xl text-foreground">{"Order Summary"}</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-3 text-sm">
              <span className="text-muted">{"Subtotal"}</span>
              <span className="font-semibold tabular-nums text-foreground">$6,000</span>
            </div>
            <div className="flex items-center justify-between gap-3 text-sm">
              <span className="text-muted">{"Shipping"}</span>
              <span className="font-semibold tabular-nums text-foreground">{"Calculated at Checkout"}</span>
            </div>
            <div className="flex items-center justify-between gap-3 text-sm">
              <span className="text-muted">{"Total"}</span>
              <span className="font-semibold tabular-nums text-foreground">$6,000</span>
            </div>
          </div>
          <Button href={"/checkout"} className="w-full sm:w-auto">
            {"Proceed to Checkout"}
          </Button>
        </Card>
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"By continuing, you agree to our Terms of Service and Privacy Policy."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="cart">
      </div>
      <PublicShell
      brandName={"Jeanne Kassab Art"}
      chrome="solid"
      nav={null}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"cart"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}