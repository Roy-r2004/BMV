// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, DataTable, ActivityFeed, Input, Select, Button, AiFeaturePanel, Dialog, UiIcon } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-detail" as const;

export default function EditPaintingPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // Sample painting data (replace with actual fetched data for a real painting)
  const [paintingData, setPaintingData] = useState({
    title: "Echoes of the High Desert",
    description: "A large-scale abstract landscape, rich with layered oils capturing the stark beauty and expansive skies of the high desert. Textural forms evoke ancient earth, while subtle blues hint at distant mountain ranges. This piece resonates with a quiet power, inviting contemplation.",
    dimensions: "48\" x 60\"",
    medium: "Oil on canvas",
    year: "2023",
    price: "8,500.00",
    availability: "Available", // or 'Sold', 'Reserved'
    imageUrl: "https://images.pexels.com/photos/6109043/pexels-photo-6109043.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPaintingData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setPaintingData(prev => ({ ...prev, [name]: value }));
  };

  const handleGenerateDescription = () => {
    // Simulate AI generation
    setPaintingData(prev => ({
      ...prev,
      description: "A newly AI-generated description based on visual cues and existing details. It highlights the dynamic interplay of light and shadow, and the emotional resonance of color. Perfect for a collector seeking a contemplative piece."
    }));
  };

  const slots = {
    header: (
      <PageHeader
        title={`Edit Painting: ${paintingData.title}`}
        actions={[
          { label: "Save Changes", onClick: () => console.log("Save Changes", paintingData), variant: "default" },
          { label: "Delete Painting", onClick: () => console.log("Delete Painting"), variant: "destructive" },
          { label: "Cancel", href: "/admin/paintings", variant: "ghost" },
        ]}
      />
    ),
    table: (
      <div className="space-y-6 p-4">
        <form onSubmit={(e) => { e.preventDefault(); console.log("Form submitted", paintingData); }} className="space-y-6">
          <Input
            label="Title"
            name="title"
            value={paintingData.title}
            onChange={handleInputChange}
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label="Dimensions"
              name="dimensions"
              value={paintingData.dimensions}
              onChange={handleInputChange}
            />
            <Input
              label="Medium"
              name="medium"
              value={paintingData.medium}
              onChange={handleInputChange}
            />
            <Input
              label="Year"
              name="year"
              value={paintingData.year}
              onChange={handleInputChange}
              type="number"
            />
            <Input
              label="Price"
              name="price"
              value={paintingData.price}
              onChange={handleInputChange}
              type="number"
            />
            <Select
              label="Availability Status"
              name="availability"
              value={paintingData.availability}
              onValueChange={(value) => handleSelectChange('availability', value)}
              options={[
                { value: 'Available', label: 'Available' },
                { value: 'Sold', label: 'Sold' },
                { value: 'Reserved', label: 'Reserved' },
              ]}
            />
          </div>

          <div className="relative">
            <Input
              as="textarea"
              label="Description"
              name="description"
              value={paintingData.description}
              onChange={handleInputChange}
              rows={6}
            />
            <Button
              className="absolute bottom-2 right-2"
              variant="secondary"
              onClick={handleGenerateDescription}
            >
              Generate Description (AI)
            </Button>
            <AiFeaturePanel feature="Artful Description Assistant" className="mt-2" compact />
          </div>


          <div>
            <label className="block text-sm font-medium text-text-brand mb-2">Painting Image</label>
            <div className="flex items-center space-x-4">
              {paintingData.imageUrl && (
                <img src={paintingData.imageUrl} alt="Current Painting" className="w-32 h-32 object-cover rounded-md border border-muted" />
              )}
              <div className="flex-grow">
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-muted border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <UiIcon name="Upload" className="mx-auto h-12 w-12 text-muted" />
                    <div className="flex text-sm text-muted">
                      <label htmlFor="file-upload" className="relative cursor-pointer rounded-md bg-surface font-medium text-primary hover:text-secondary focus-within:outline-none focus-within:ring-2 focus-within:ring-primary focus-within:ring-offset-2">
                        <span>Upload a file</span>
                        <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setPaintingData(prev => ({ ...prev, imageUrl: URL.createObjectURL(e.target.files![0]) }));
                          }
                        }} />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-muted">PNG, JPG, GIF up to 10MB</p>
                  </div>
                </div>
                <AiFeaturePanel feature="Smart Image Cropping/Resizing for Display" className="mt-2" compact />
              </div>
            </div>
          </div>
        </form>
      </div>
    ),
    activity: (
      <ActivityFeed
        heading="Activity Log"
        items={[
          {
            id: "activity-1",
            title: "Painting updated",
            detail: "Title, description, and price adjusted.",
            time: "Just now",
            icon: <UiIcon name="Edit" className="h-5 w-5 text-text-brand" />,
          },
          {
            id: "activity-2",
            title: "Availability changed to 'Sold'",
            detail: "Marked sold by Jeanne Kassab.",
            time: "2 days ago",
            icon: <UiIcon name="CheckCircle" className="h-5 w-5 text-primary" />,
          },
          {
            id: "activity-3",
            title: "Image uploaded",
            detail: "Main artwork image updated.",
            time: "1 week ago",
            icon: <UiIcon name="Upload" className="h-5 w-5 text-text-brand" />,
          },
        ]}
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-edit-painting">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}