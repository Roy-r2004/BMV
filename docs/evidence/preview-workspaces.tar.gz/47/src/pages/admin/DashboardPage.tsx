import React from 'react';
import { useAdminNavItems } from '@/lib/app-nav';
import { getSkeleton, composeSkeletonLayout, OpsShell, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, AiFeaturePanel, UiIcon } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;

export default function DashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // Business-specific operational data
  const availablePaintings = 17;
  const pendingOrders = 3;
  const totalSalesMoM = 15200; // Example value, $15,200
  const salesDelta = "+5%";

  const recentOrdersData = [
    { id: "order-001", orderId: "#ART-2024-001", customer: "Sophia Chen", date: "2024-07-28", status: "Processing", total: "$1,800" },
    { id: "order-002", orderId: "#ART-2024-002", customer: "Marcus Sterling", date: "2024-07-27", status: "Shipped", total: "$3,200" },
    { id: "order-003", orderId: "#ART-2024-003", customer: "Eleanor Vance", date: "2024-07-27", status: "New", total: "$950" },
  ];

  const salesChartData = [
    { month: "Jan", sales: 8000 },
    { month: "Feb", sales: 10000 },
    { month: "Mar", sales: 9500 },
    { month: "Apr", sales: 11000 },
    { month: "May", sales: 13000 },
    { month: "Jun", sales: 14500 },
    { month: "Jul", sales: 15200 },
  ];

  const activityFeedItems = [
    { id: "act-1", title: "New order received", detail: "#ART-2024-003 placed by Eleanor Vance", time: "Just now", icon: <UiIcon name="ShoppingCart" className="text-brand" /> },
    { id: "act-2", title: "Painting uploaded", detail: "'Whispers of the Horizon' added to gallery.", time: "15m ago", icon: <UiIcon name="Image" className="text-brand" /> },
    { id: "act-3", title: "Inventory update", detail: "'Ocean Depths, III' status changed to 'Sold'.", time: "1h ago", icon: <UiIcon name="Package" className="text-brand" /> },
    { id: "act-4", title: "Customer inquiry", detail: "New message from David R. about 'Dreamscapes'.", time: "2h ago", icon: <UiIcon name="MessageSquare" className="text-brand" /> },
    { id: "act-5", title: "Order shipped", detail: "#ART-2024-002 for Marcus Sterling is on its way.", time: "Yesterday", icon: <UiIcon name="Truck" className="text-brand" /> },
  ];

  const slots = {
    header: (
      <PageHeader
        title={"Welcome, Jeanne"}
        description={"Overview of your gallery operations."}
        actions={[
          { label: "New Painting", href: "/admin/paintings/new" },
          { label: "View Profile", href: "/admin/profile", variant: "secondary" },
          { label: "Logout", onClick: () => console.log("Logout action"), variant: "ghost" },
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard variant="card" label="Available Paintings" value={availablePaintings.toString()} hint="Currently in your living gallery" />
        <StatCard variant="card" label="Pending Orders" value={pendingOrders.toString()} hint="Awaiting your expert touch" />
        <StatCard variant="card" label="Total Sales (MoM)" value={`$${totalSalesMoM.toLocaleString()}`} delta={salesDelta} hint="Compared to previous month" />
      </div>
    ),
    filters: ( // Mapped conceptual 'Collections' card into the 'filters' slot, as it's a filtering/grouping mechanism.
      <div className="flex flex-col gap-4">
        <FilterBar
          searchPlaceholder="Search orders, paintings..."
          filters={[
            { id: "all", label: "All", active: true },
            { id: "pending", label: "Pending", active: false },
            { id: "shipped", label: "Shipped", active: false }
          ]}
        />
        {/* 'Collections' card suggesting groups of current paintings based on AI features */}
        <AiFeaturePanel
          feature={{
            id: "curated-collections",
            name: "Collection Suggestions",
            description: "Canvas Curator AI recommends potential groupings of paintings based on visual or thematic elements. Explore these to create compelling narratives for your collectors.",
            // The following properties are added to satisfy the AiFeatureItem contract
            category: "Merchandising",
            demo_hint: "Click to view suggestions",
            demo_prompts: ["suggest groupings for new arrivals", "create a collection for abstract landscapes"],
            demo_results: {
              collection1: "Coastal Reflections Series: 3 new paintings",
              collection2: "Layered Abstracts: New additions to your signature style",
            },
            placement_label: "AI Collection Curator",
            placement_path: "/admin/collections",
            placement_title: "AI Collection Curator",
            placement_component: "AiFeaturePanel"
          }}
          className="p-4 bg-surface rounded-lg shadow-sm"
        />
      </div>
    ),
    chart: (
      <ChartCard
        title="Sales Trends"
        description="Monthly gallery performance"
        type="area"
        dataKey="sales"
        xKey="month"
        data={salesChartData}
        valueFormat="currency"
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "orderId", header: "Order ID" },
          { key: "customer", header: "Customer" },
          { key: "date", header: "Date" },
          { key: "status", header: "Status" },
          { key: "total", header: "Total" },
        ]}
        rows={recentOrdersData}
        emptyMessage="No recent orders to show."
      />
    ),
    activity: (
      <ActivityFeed heading="Recent Gallery Activity" items={activityFeedItems} />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
    </OpsShell>
  );
}