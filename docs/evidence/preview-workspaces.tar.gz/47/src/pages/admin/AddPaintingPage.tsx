// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, DataTable, ActivityFeed, Input, Select, Button, AiFeaturePanel, UiIcon } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-detail" as const;

export default function AddPaintingPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dimensions, setDimensions] = useState('');
  const [medium, setMedium] = useState('');
  const [year, setYear] = useState('');
  const [price, setPrice] = useState('');
  const [availability, setAvailability] = useState('Available');
  const [primaryImage, setPrimaryImage] = useState<File | null>(null);
  const [additionalImages, setAdditionalImages] = useState<File[]>([]);
  const [aiGeneratedDescription, setAiGeneratedDescription] = useState<string | null>(null);

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>, setImage: React.Dispatch<React.SetStateAction<File | null>>) => {
    event.preventDefault();
    if (event.dataTransfer.files && event.dataTransfer.files[0]) {
      setImage(event.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>, setImage: React.Dispatch<React.SetStateAction<File | null>>) => {
    if (event.target.files && event.target.files[0]) {
      setImage(event.target.files[0]);
    }
  };

  const handleAdditionalImagesChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      setAdditionalImages(prev => [...prev, ...Array.from(event.target.files)]);
    }
  };

  const generateDescription = () => {
    // Simulate AI generation based on existing input
    const generated = `A captivating ${medium} piece, '${title}' (${year}), measuring ${dimensions}. Its layered brushwork evokes a sense of ${Math.random() > 0.5 ? 'calm depth' : 'vibrant energy'}, inviting contemplation. This original work explores themes of ${Math.random() > 0.5 ? 'abstract landscapes' : 'emotional resonance'}.`;
    setAiGeneratedDescription(generated);
    setDescription(generated); // Auto-populate the description field
  };

  const cropImage = (image: File) => {
    // This is a placeholder for actual image cropping/resizing logic.
    // In a real application, this would involve client-side image manipulation libraries or server-side processing.
    return URL.createObjectURL(image); // Return a blob URL for preview
  };

  const AvailabilityOptions = [
    { label: 'Available', value: 'Available' },
    { label: 'Reserved', value: 'Reserved' },
    { label: 'Sold', value: 'Sold' },
  ];

  const slots = {
    header: (
      <PageHeader title={"Add New Painting"} description={"Capture the essence of your latest creation by adding its details here, from title to availability. " } actions={[
        { label: "Save Painting", onClick: () => alert('Painting saved!'), variant: "default" }
      ]} />
    ),
    table: (
      <div className="bg-surface p-6 rounded-lg shadow-sm space-y-6 max-w-4xl mx-auto">
        <h2 className="font-display text-text-brand text-2xl mb-4">Painting Details</h2>
        <Input label="Title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., 'Whispering Pines'" />
        
        <div className="relative">
          <Input 
            as="textarea" 
            label="Description" 
            value={description} 
            onChange={(e) => setDescription(e.target.value)} 
            placeholder="A poetic narrative describing the artwork..." 
            rows={5} 
            className="pr-36" // Add padding for the button
          />
          <div className="absolute right-2 bottom-2">
            <Button onClick={generateDescription} variant="secondary" size="sm">
              <UiIcon name="ai" className="mr-2" /> Generate Description
            </Button>
          </div>
          {aiGeneratedDescription && (
            <p className="text-muted text-sm mt-2">AI suggested: "{aiGeneratedDescription}"</p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Input label="Dimensions" value={dimensions} onChange={(e) => setDimensions(e.target.value)} placeholder="e.g., '24x36 inches'" />
          <Input label="Medium" value={medium} onChange={(e) => setMedium(e.target.value)} placeholder="e.g., 'Oil on canvas'" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Input label="Year" value={year} onChange={(e) => setYear(e.target.value)} placeholder="e.g., '2023'" type="number" />
          <Input label="Price" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="e.g., '3500.00'" type="number" />
        </div>
        
        <Select 
          label="Availability status" 
          options={AvailabilityOptions} 
          value={availability} 
          onValueChange={setAvailability} 
          placeholder="Select availability" 
        />

        <div className="space-y-4">
          <h3 className="font-display text-text-muted text-xl">Image Upload</h3>

          {/* Primary Image */}
          <div className="border border-muted/30 rounded-lg p-4 bg-background/50">
            <label className="block text-sm font-medium text-text-brand mb-2">Primary Image (Hero Display)</label>
            <div 
              className="relative border-2 border-dashed border-muted/50 rounded-lg p-6 text-center cursor-pointer hover:border-text-brand transition-all flex flex-col items-center justify-center min-h-[150px]"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, setPrimaryImage)}
              onClick={() => document.getElementById('primary-image-upload')?.click()}
            >
              <UiIcon name="upload" className="h-8 w-8 text-muted mb-2" />
              <p className="text-sm text-muted">Drag & drop your primary image here, or click to upload.</p>
              <input 
                id="primary-image-upload" 
                type="file" 
                className="hidden" 
                onChange={(e) => handleFileChange(e, setPrimaryImage)} 
                accept="image/*" 
              />
              {primaryImage && <p className="text-sm text-brand mt-2">Selected: {primaryImage.name}</p>}
            </div>
            {primaryImage && (
              <div className="mt-4 p-4 border border-muted/20 rounded-lg bg-surface flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <img src={cropImage(primaryImage)} alt="Primary artwork preview" className="w-20 h-20 object-cover rounded-md shadow-sm" />
                  <div>
                    <p className="font-medium text-text-brand">{primaryImage.name}</p>
                    <p className="text-sm text-muted">Optimized for display (gallery, detail, zoom)</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setPrimaryImage(null)}>Remove</Button>
              </div>
            )}
            <AiFeaturePanel className="mt-4" feature={{name: "Smart Image Cropping/Resizing", description: "Automatically optimizes uploaded artwork images for various display formats (gallery thumbnail, detail page, zoom view) while preserving artistic integrity and focus."}} />
          </div>

          {/* Additional Images */}
          <div className="border border-muted/30 rounded-lg p-4 bg-background/50">
            <label className="block text-sm font-medium text-text-brand mb-2">Additional Images (Gallery Views)</label>
            <div 
              className="relative border-2 border-dashed border-muted/50 rounded-lg p-6 text-center cursor-pointer hover:border-text-brand transition-all flex flex-col items-center justify-center min-h-[100px]"
              onDragOver={handleDragOver}
              onDrop={(e) => setAdditionalImages(prev => [...prev, ...(Array.from(e.dataTransfer.files))])}
              onClick={() => document.getElementById('additional-images-upload')?.click()}
            >
              <UiIcon name="upload" className="h-6 w-6 text-muted mb-2" />
              <p className="text-sm text-muted">Click or drag additional images here.</p>
              <input 
                id="additional-images-upload" 
                type="file" 
                multiple 
                className="hidden" 
                onChange={handleAdditionalImagesChange} 
                accept="image/*" 
              />
            </div>
            {additionalImages.length > 0 && (
              <div className="mt-4 space-y-2">
                {additionalImages.map((image, index) => (
                  <div key={index} className="p-3 border border-muted/20 rounded-lg bg-surface flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <img src={cropImage(image)} alt={`Additional artwork preview ${index + 1}`} className="w-16 h-16 object-cover rounded-md shadow-sm" />
                      <div>
                        <p className="font-medium text-text-brand">{image.name}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => setAdditionalImages(prev => prev.filter((_, i) => i !== index))}>Remove</Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    ),
    activity: (
      <ActivityFeed 
        heading="Recent Additions" 
        items={[
          { id: "painting-1", title: "Sunrise Serenity", detail: "Added 2 days ago", time: "2d ago", icon: <UiIcon name="image" /> },
          { id: "painting-2", title: "Urban Rhythms", detail: "Added 1 week ago", time: "1w ago", icon: <UiIcon name="image" /> },
          { id: "painting-3", title: "Forest Whispers", detail: "Added 3 weeks ago", time: "3w ago", icon: <UiIcon name="image" /> }
        ]} 
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-add-painting">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}