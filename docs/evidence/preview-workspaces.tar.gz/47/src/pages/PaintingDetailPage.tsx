// deterministic catalogue contract scaffold
import { useParams } from 'react-router-dom';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, Button, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, InquiryPanel, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "inquire", "cta", "footer"] as const;

export default function PaintingDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const params = useParams();
  const catalogItems = (seed.items ?? []) as any[];
  const itemKey = String(params.id ?? params.slug ?? '').trim();
  const itemToken = (value: any) =>
    String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  const wantedToken = itemToken(itemKey);
  const itemIndex = catalogItems.findIndex(
    (entry: any, index: number) =>
      wantedToken !== '' &&
      (itemToken(entry?.id) === wantedToken ||
        itemToken(entry?.slug) === wantedToken ||
        itemToken(entry?.title) === wantedToken ||
        String(index + 1) === itemKey),
  );
  const item: any = itemIndex >= 0 ? catalogItems[itemIndex] : undefined;
  const notFound = itemKey !== '' && itemIndex < 0;
  const itemTitle = String(item?.title ?? 'This piece');
  const itemImage = String(
    item?.image ??
      [images.item1, images.item2, images.item3, images.item4,
       images.item5, images.item6, images.item7, images.item8][
        (itemIndex >= 0 ? itemIndex : 0) % 8
      ],
  );
  const itemSpecs = [
    item?.dimensions ? { title: 'Dimensions', detail: String(item.dimensions) } : null,
    item?.medium ? { title: 'Medium', detail: String(item.medium) } : null,
    item?.year ? { title: 'Year', detail: String(item.year) } : null, // Assuming a 'year' property might exist
    item?.status ? { title: 'Availability', detail: String(item.status) } : 'Available', // Default to available
    item?.price ? { title: 'Price', detail: String(item.price) } : null,
  ].filter(Boolean) as { title: string; detail: string }[];

  const skeleton = getSkeleton(SKELETON_ID);

  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    hero: (
      // MarketingHero is used to display the prominent artwork image
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={itemTitle}
        subcopy={""} // Subcopy is not needed for this hero as details are in showcase
        imageSrc={itemImage}
        imageAlt={itemTitle} // "product" variant is suitable for a single item display
        primaryCta={item?.status !== 'Sold' ? { label: "Add to Cart", href: "#" } : undefined}
        secondaryCta={item?.status !== 'Sold' ? { label: "Inquire about this piece", href: "#inquire" } : { label: "Explore other works", href: "/gallery" }}
        className="pb-0" // Adjust padding to maintain whitespace
      />
    ),
    showcase: (
      <div className="mx-auto max-w-6xl px-6 py-12 lg:py-16">
        <div className="lg:grid lg:grid-cols-2 lg:gap-x-12">
          {/* Left column for image and zoom overlay placeholder */}
          <div className="relative group overflow-hidden rounded-lg shadow-lg">
            <img
              src={itemImage}
              alt={itemTitle}
              className="w-full h-full object-cover object-center transition-transform duration-300 group-hover:scale-105"
            />
            {/* Interactive zoom placeholder */}
            <div className="absolute inset-0 bg-transparent flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
              <span className="text-white text-lg px-4 py-2 bg-black bg-opacity-50 rounded-full font-sans">
                Hover to zoom
              </span>
            </div>
          </div>
          {/* Right column for Artwork Details */}
          <div className="mt-8 lg:mt-0 lg:pl-8">
            <h1 className="font-display text-4xl leading-tight text-text-brand">{itemTitle}</h1>
            <p className="mt-4 text-xl text-muted">A captivating piece from Jeanne Kassab Art collection.</p>

            <div className="mt-6 space-y-4">
              {itemSpecs.map((spec, idx) => (
                <div key={idx} className="flex justify-between items-center pb-2 border-b border-muted/20 last:border-b-0">
                  <span className="text-muted text-lg">{spec.title}:</span>
                  <span className="text-text-brand text-lg font-medium">{spec.detail}</span>
                </div>
              ))}
            </div>

            <p className="mt-8 text-base leading-relaxed text-text-brand">
              This compelling oil painting, "{itemTitle}", is a testament to the depth of abstract landscapes. Jeanne Kassab’s signature layered oils create a rich texture and vibrant energy, inviting viewers to explore its nuances. It captures a moment of serene contemplation, perfect for adding an enduring artistic presence to any space.
            </p>

            {item?.status !== 'Sold' ? (
              <Button className="mt-10 w-full lg:w-auto" size="lg">
                Add to Cart
              </Button>
            ) : (
              <Button className="mt-10 w-full lg:w-auto" size="lg" variant="ghost" disabled>
                Sold
              </Button>
            )}
          </div>
        </div>
      </div>
    ),
    testimonials: (
      <TestimonialRail
        heading="Collectors' Impressions"
        items={[
          { quote: "Jeanne's painting transformed my living space. The colors are even more vibrant in person, and the texture truly tells a story. A truly cherished acquisition.", author: "Eleanor V." },
          { quote: "Every detail reflects a deep passion. Her work brings a unique tranquility and depth to my collection. I look forward to adding more of her art.", author: "Marcus L., Interior Designer" },
          { quote: "The online images are beautiful, but holding the actual canvas revealed another layer of artistic mastery. A seamless and delightful experience from discovery to delivery.", author: "Sophia P." },
        ]}
      />
    ),
    inquire: (
      <InquiryPanel
        heading={`Deepen your connection with "${itemTitle}"`}
        description="Have a question about this piece, its story, or commission a similar work? Jeanne welcomes your inquiries."
        itemId={itemKey}
        itemTitle={itemTitle}
        messagePlaceholder="Tell us more about your interest in this painting or any specific questions you may have."
        ctaLabel="Send Inquiry"
        confirmationHeading="Thank you for your inquiry!"
        confirmationBody="Jeanne will personally review your message and be in touch shortly."
      />
    ),
    cta: (
      <CTABand
        heading="Discover more of Jeanne's world"
        description="Explore the full collection and find the perfect piece to resonate with your space."
        primaryCta={{ label: "View All Paintings", href: "/gallery" }}
        secondaryCta={{ label: "Meet the Artist", href: "/about" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description="Jeanne Kassab Art — original oils, abstract landscapes. A living gallery of authentic connection and expressive form."
        links={[
          { label: "Gallery", href: "/gallery" },
          { label: "About", href: "/about" },
          { label: "Contact", href: "/contact" },
          { label: "Privacy Policy", href: "#" },
        ]}
      />
    ),
  };

  if (notFound) {
    return (
      <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
        <div data-skeleton={skeleton.id} data-detail-not-found="" data-appspec-page="painting-detail">
          <div className="mx-auto w-full max-w-3xl px-6 pt-32 pb-24 lg:pt-40">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-brand">
              Not found
            </p>
            <h1 className="mt-4 font-display text-[clamp(2rem,4vw,3rem)] leading-tight tracking-tight text-foreground">
              We could not find that one
            </h1>
            <p className="mt-4 text-base leading-7 text-muted">
              It may have sold or moved. Browse what is available now.
            </p>
            <Button href={"/gallery"} className="mt-8">Back to the collection</Button>
          </div>
        </div>
      </PublicShell>
    );
  }

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="painting-detail">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}