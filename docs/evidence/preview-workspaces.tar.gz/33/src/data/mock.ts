export const brand = {"name": "Jeanne Kassab Art", "tagline": "", "design_system": {"primary_color": "#0f766e", "secondary_color": "#0369a1", "background_color": "#f8fafc", "surface_color": "#ffffff", "text_color": "#042f2e", "muted_text_color": "#5f7a78", "font_family": "Source Sans 3", "display_font_family": "Fraunces", "font_import_url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap", "font_sans": "\"Source Sans 3\", \"Segoe UI\", sans-serif", "font_display": "\"Fraunces\", Georgia, serif", "brand_locked": true, "brand_brief_version": "1.0", "mood": "modern", "voice": "Warm, grounded, unhurried. Speak like a trusted studio host.", "signature": "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.", "avoid": ["purple-on-white or purple-to-indigo default themes", "Inter / Roboto / Arial as the display face", "card grids in the hero", "generic SaaS marketing copy", "inventing a second palette per page"], "rules": ["Every page inherits this palette and type stack via CSS tokens only.", "Use bg-brand / text-brand / font-display — never hardcode hex colors.", "First viewport must feature the brand name as a hero-level signal."], "recipe_id": "editorial", "hub_variant": "marketing", "hero_variant": "editorial", "feature_variant": "alternating", "recipe_prompt": "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.", "style_keywords": "Editorial · Calm air", "border_radius": "0.77rem", "design_overlay_id": "calm_air", "design_overlay_label": "Calm air", "design_overlay_blurb": "Airy clinical calm — soft surfaces, quiet type, low density.", "density": "airy", "token_overrides": {"radius_ui": "0.77rem", "bg_mix": "3%", "fg_mix": "38%", "muted_mix": "28%", "border_mix": "12%", "shadow": "0 28px 56px -40px", "shadow_alpha": "22%", "glow": "7%", "card": "#ffffff", "atmosphere": "radial-gradient(90% 55% at 8% -5%, color-mix(in srgb, var(--color-brand) 9%, transparent), transparent 58%), linear-gradient(180deg, #fbfcfd 0%, color-mix(in srgb, var(--color-brand) 3%, #f5f7f9) 55%, #f8fafb 100%)"}, "font_import": "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700", "design_brief_version": "1.0", "design_brief_sealed": true}};

export const images = {
  "hero": "https://images.pexels.com/photos/3845983/pexels-photo-3845983.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/6627349/pexels-photo-6627349.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/6627329/pexels-photo-6627329.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/6627350/pexels-photo-6627350.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/4269936/pexels-photo-4269936.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/6627724/pexels-photo-6627724.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const roles = [
  {
    "id": "collector",
    "label": "Collector & Visitor",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "admin",
    "label": "Artist & Admin",
    "defaultPath": "/admin/login",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "path": "/collection",
      "href": "/collection",
      "label": "The Collection — All Paintings"
    },
    {
      "path": "/collection/:id",
      "href": "/collection/:id",
      "label": "Artwork Detail — [Painting Title]"
    },
    {
      "path": "/about",
      "href": "/about",
      "label": "About Jeanne Kassab — Artist & Studio"
    },
    {
      "path": "/contact",
      "href": "/contact",
      "label": "Contact & Inquiries"
    },
    {
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "path": "/gallery/:id",
      "href": "/gallery/:id",
      "label": "Artwork"
    }
  ],
  "admin": [
    {
      "path": "/",
      "href": "/",
      "label": "Books overview"
    },
    {
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login"
    },
    {
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Dashboard — Manage The Canvas Collection"
    },
    {
      "path": "/admin/artworks",
      "href": "/admin/artworks",
      "label": "Manage Artworks"
    },
    {
      "path": "/admin/artworks/new",
      "href": "/admin/artworks/new",
      "label": "Add New Artwork"
    },
    {
      "path": "/admin/artworks/:id/edit",
      "href": "/admin/artworks/:id/edit",
      "label": "Edit Artwork"
    },
    {
      "path": "/admin/inquiries",
      "href": "/admin/inquiries",
      "label": "Inquiries & Messages"
    },
    {
      "path": "/admin/settings",
      "href": "/admin/settings",
      "label": "Settings & Profile"
    },
    {
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    }
  ]
};

export const seed = {
  "tone": "reassuring",
  "hero": {
    "eyebrow": "Jeanne Kassab Art",
    "headline": "Original Oil Paintings by Jeanne Kassab",
    "subcopy": "Discover abstract landscapes and layered compositions, each a unique expression of light and emotion.",
    "primaryCta": {
      "label": "View The Collection",
      "href": "/collection"
    },
    "secondaryCta": {
      "label": "About the Artist",
      "href": "/about"
    }
  },
  "items": [
    {
      "title": "Preventive cleaning",
      "description": "Exam, polish, and a clear plan for the patient — no surprise upsells."
    },
    {
      "title": "Restorative care",
      "description": "Fillings, crowns, and repairs scheduled around your week."
    },
    {
      "title": "Orthodontics consult",
      "description": "Alignment options with digital previews and realistic timelines."
    },
    {
      "title": "Emergency slot",
      "description": "Same-day openings when pain cannot wait for next month."
    }
  ],
  "features": [
    {
      "title": "Abstract Landscapes",
      "description": "Immerse yourself in paintings that evoke dynamic and serene natural environments."
    },
    {
      "title": "Layered Oils",
      "description": "Experience the depth and texture achieved through rich, translucent oil layers."
    },
    {
      "title": "Unique Originals",
      "description": "Each piece is a one-of-a-kind creation, infused with artistic intention and crafted by hand."
    }
  ],
  "process": [
    {
      "title": "Browse the Gallery",
      "description": "Explore new and featured works in The Canvas Collection."
    },
    {
      "title": "Discover Your Piece",
      "description": "View detailed images and descriptions for each unique painting."
    },
    {
      "title": "Inquire Directly",
      "description": "Connect with Jeanne Kassab to discuss acquisition or arrange a viewing."
    }
  ],
  "credentials": [
    {
      "title": "Featured Artist",
      "detail": "Local Gallery Showcase 2023"
    },
    {
      "title": "Private Collections",
      "detail": "Works held in esteemed collections globally"
    }
  ],
  "testimonials": [
    {
      "quote": "Jeanne's work brings such a profound sense of calm and beauty into a space. Simply stunning.",
      "author": "Priya S.",
      "role": "Art Collector"
    },
    {
      "quote": "The texture and depth in these oil paintings are truly captivating. A joy to behold.",
      "author": "Marcus L.",
      "role": "Interior Designer"
    }
  ],
  "treatments": [
    {
      "id": "offer-1",
      "name": "Preventive cleaning",
      "duration": "60 min"
    },
    {
      "id": "offer-2",
      "name": "Restorative care",
      "duration": "60 min"
    },
    {
      "id": "offer-3",
      "name": "Orthodontics consult",
      "duration": "60 min"
    },
    {
      "id": "offer-4",
      "name": "Emergency slot",
      "duration": "60 min"
    }
  ],
  "showcaseHeading": "Care we provide",
  "featuresHeading": "Designed around patients",
  "processHeading": "Book without the phone tree",
  "credentialsHeading": "Trust you can verify",
  "testimonialsHeading": "Patient notes",
  "cta": {
    "heading": "Openings this week",
    "description": "Book a cleaning or consult — insurance check included before you arrive.",
    "primaryLabel": "Book visit",
    "primaryHref": "/book",
    "secondaryLabel": "New patient forms",
    "secondaryHref": "/intake"
  },
  "footer": {
    "description": "A clinic for patients who want clear plans, on-time visits, and providers they chose on purpose."
  },
  "trustLabels": [
    "Board-certified",
    "Digital intake",
    "Insurance desk",
    "Same-day urgency"
  ],
  "kpis": [
    {
      "label": "Available Works",
      "value": "18",
      "delta": "+2",
      "hint": "New paintings this month"
    },
    {
      "label": "Open Inquiries",
      "value": "3",
      "delta": "0",
      "hint": "Pending collector messages"
    },
    {
      "label": "Featured on Homepage",
      "value": "6",
      "delta": "—",
      "hint": "Curated selection"
    }
  ],
  "activity": [
    {
      "id": "activity-1",
      "title": "New artwork uploaded: 'Azure Depths'",
      "detail": "Added to Collection",
      "time": "Just now"
    },
    {
      "id": "activity-2",
      "title": "Inquiry for 'Golden Hour'",
      "detail": "From Sarah Jenkins (website)",
      "time": "15 minutes ago"
    },
    {
      "id": "activity-3",
      "title": "Artwork 'Echo Point' marked as Sold",
      "detail": "Updated status",
      "time": "2 hours ago"
    }
  ],
  "risk": [
    {
      "id": "risk-1",
      "title": "No-show risk",
      "detail": "2:15 cleaning still unconfirmed",
      "severity": "high"
    },
    {
      "id": "risk-2",
      "title": "Provider running late",
      "detail": "Dr. Miles +12m · Room 3",
      "severity": "medium"
    }
  ],
  "tableRows": [
    {
      "id": "row-1",
      "name": "Preventive cleaning",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-2",
      "name": "Restorative care",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-3",
      "name": "Orthodontics consult",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-4",
      "name": "Emergency slot",
      "status": "Open",
      "owner": "Team"
    }
  ]
};

export const aiFeatures = [
  {
    "id": "ai-image-optimizer",
    "name": "AI Image Optimizer",
    "description": "Automatically adjusts uploaded artwork images for optimal web display and fast loading without compromising visual quality.",
    "category": "automation",
    "surface": "automation",
    "demo_hint": "Trigger the automation Jeanne Kassab Art actually needs",
    "demo_prompts": [
      "Notify the next person waiting for intake",
      "Chase what's missing for booking",
      "Run tonight's follow-ups for Jeanne Kassab Art"
    ],
    "placement_label": "Automation",
    "demo_results": {
      "Notify the next person waiting for intake": "Automation for “Notify the next person waiting for intake”: message drafted, spot held for 30 minutes, next guest in line ready if they decline.",
      "Chase what's missing for booking": "Chase sequence for “Chase what's missing for booking”: reminder #1 sent about booking, escalates tomorrow if still open.",
      "Run tonight's follow-ups for Jeanne Kassab Art": "Tonight's follow-ups for Jeanne Kassab Art are queued — review → approve → run. Covers intake and booking."
    },
    "placement_path": "/admin/artworks",
    "placement_component": "src/pages/admin/ArtworkListPage.tsx",
    "placement_title": "Manage Artworks"
  },
  {
    "id": "descriptive-tag-generation",
    "name": "Descriptive Tag Generation",
    "description": "Suggests relevant keywords and tags for each artwork based on its title and description, improving discoverability.",
    "category": "ops",
    "surface": "automation",
    "demo_hint": "Route ops work the way Jeanne Kassab Art runs",
    "demo_prompts": [
      "Triage new requests about intake",
      "Assign an owner for this booking issue",
      "What should the Jeanne Kassab Art team do next?"
    ],
    "placement_label": "Ops AI",
    "demo_results": {
      "Triage new requests about intake": "Routed “Triage new requests about intake” → queue + owner + checklist for intake. Status: In progress.",
      "Assign an owner for this booking issue": "Assigned “Assign an owner for this booking issue” to the best available owner with a booking checklist and due time today.",
      "What should the Jeanne Kassab Art team do next?": "Next for Jeanne Kassab Art: clear the intake backlog, confirm booking, then review tonight's handoff."
    },
    "placement_path": "/admin/dashboard",
    "placement_component": "src/pages/admin/DashboardPage.tsx",
    "placement_title": "Dashboard — Manage The Canvas Collection"
  },
  {
    "id": "basic-search-enhancement",
    "name": "Basic Search Enhancement",
    "description": "Improves the relevance of internal search results by understanding natural language queries related to art.",
    "category": "ops",
    "surface": "automation",
    "demo_hint": "Route ops work the way Jeanne Kassab Art runs",
    "demo_prompts": [
      "Triage new requests about intake",
      "Assign an owner for this booking issue",
      "What should the Jeanne Kassab Art team do next?"
    ],
    "placement_label": "Ops AI",
    "demo_results": {
      "Triage new requests about intake": "Routed “Triage new requests about intake” → queue + owner + checklist for intake. Status: In progress.",
      "Assign an owner for this booking issue": "Assigned “Assign an owner for this booking issue” to the best available owner with a booking checklist and due time today.",
      "What should the Jeanne Kassab Art team do next?": "Next for Jeanne Kassab Art: clear the intake backlog, confirm booking, then review tonight's handoff."
    },
    "placement_path": "/admin/dashboard",
    "placement_component": "src/pages/admin/DashboardPage.tsx",
    "placement_title": "Dashboard — Manage The Canvas Collection"
  }
] as const;
