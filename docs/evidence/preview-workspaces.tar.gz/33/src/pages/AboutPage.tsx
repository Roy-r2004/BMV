import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, CTABand, BrandFooter, FeatureBento, ProcessSection } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  
  const slots = {
    hero: (
      <MarketingHero 
        brandName="Jeanne Kassab Art" 
        headline="About Jeanne Kassab — Artist & Studio"
        subcopy="A glimpse into the artist behind the canvas — her journey, her process, and the quiet spaces that inspire her work."
        variant="editorial"
        primaryCta={{ label: "Get in Touch", href: "/contact" }}
        secondaryCta={{ label: "View Collection", href: "/gallery" }}
        imageSrc={images.hero2}
        imageAlt="Jeanne Kassab in her studio"
      />
    ),
    credentials: (
      <CredentialStrip 
        heading="Credentials & Recognition"
        items={[
          "Featured Artist – Local Gallery Showcase 2023",
          "Works held in private collections worldwide",
          "Solo Exhibition – Contemporary Art Fair 2022",
          "Studio represented by Art Consultants Group"
        ]}
      />
    ),
    showcase: (
      <ProductShowcase heading="Artist Statement">
        <p className="max-w-prose text-lg leading-relaxed font-light text-muted-foreground">
          My work explores the interplay of light and shadow in nature, translating fleeting moments into tangible, layered compositions. Each piece is an invitation to pause and connect with the quiet beauty of the abstract landscape. Through oil on canvas, I build depth with translucent glazes, letting the history of each layer remain visible — much like the strata of memory in a familiar horizon.
        </p>
      </ProductShowcase>
    ),
    features: (
      <FeatureBento 
        heading="Jeanne’s Journey"
        variant="alternating"
        items={[
          {
            title: "A Lifetime of Observation",
            description: "Jeanne Kassab has been painting for over two decades, drawing inspiration from coastal dawns and inland silences. Her abstract landscapes are born from early‑morning walks and the shifting light across Mediterranean hills."
          },
          {
            title: "International Presence",
            description: "Her work has been exhibited in group and solo shows across Europe and the Middle East, finding homes in private collections from Paris to Dubai."
          },
          {
            title: "Studio Craft",
            description: "Every canvas begins with raw linen, hand‑stretched in her studio. The slow, deliberate process of layering oils — sometimes over months — ensures each work holds a sense of time within its surface."
          },
          {
            title: "Collectors & Relationships",
            description: "Jeanne values direct, unhurried conversations with collectors. Many patrons return to commission companion pieces, building narratives across entire walls."
          }
        ]}
      />
    ),
    process: (
      <ProcessSection 
        heading="The Creative Process"
        steps={[
          {
            title: "Conception",
            description: "A mood, a colour memory, or a photograph from a recent walk becomes the seed. Sketches and small studies map out composition and palette."
          },
          {
            title: "Underpainting",
            description: "Thin, transparent layers of pigment are applied to build luminosity. The canvas breathes; the first gestures set the emotional tone."
          },
          {
            title: "Layering & Texture",
            description: "Using palette knives and soft brushes, Jeanne adds thicker oil, scraping back to reveal earlier colours. This push‑and‑pull creates a rich, living surface."
          },
          {
            title: "Quiet Reflection",
            description: "The finished piece rests in the studio for weeks. Natural light reveals its final voice — only then is it considered complete."
          }
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail 
        heading="What Collectors Say"
        items={[
          {
            quote: "Jeanne’s paintings bring a quiet elegance to our living room — every day, I notice something new.",
            author: "Sarah L., Private Collector"
          },
          {
            quote: "A master of light and texture; her work transforms a space entirely. I recommend her to every client looking for a true statement piece.",
            author: "Michael D., Interior Designer"
          },
          {
            quote: "Collecting Jeanne’s pieces has been a joy — her studio felt like a home for art, not a transaction.",
            author: "Elena R., Art Enthusiast"
          }
        ]}
      />
    ),
    cta: (
      <CTABand 
        heading="Let’s Talk About Your Space"
        description="Whether you’re looking for a statement piece, want to discuss a commission, or simply say hello — I’d love to hear from you."
        primaryCta={{ label: "Get in Touch", href: "/contact" }}
        secondaryCta={{ label: "Explore Works", href: "/gallery" }}
      />
    ),
    footer: (
      <BrandFooter 
        brandName="Jeanne Kassab Art" 
        description="Original oil paintings — abstract landscapes and layered compositions." 
      />
    ),
  };

  return (
    <PublicShell brandName="Jeanne Kassab Art" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="public-about">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}