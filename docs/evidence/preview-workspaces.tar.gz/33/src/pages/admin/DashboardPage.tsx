import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import {
  OpsShell,
  getSkeleton,
  composeSkeletonLayout,
  PageHeader,
  StatCard,
  RiskQueue,
  ChartCard,
  FilterBar,
  DataTable,
  ActivityFeed,
  Badge,
  Button,
} from '@/ui';

const SKELETON_ID = 'ops-dashboard' as const;

export default function DashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const slots = {
    header: (
      <PageHeader
        title="Manage The Canvas Collection"
        description="Artwork inventory and inquiries overview for Jeanne Kassab Art."
        meta={<span className="text-sm text-muted">Live</span>}
        actions={[
          {
            label: 'Logout',
            href: '/admin/logout',
            variant: 'outline',
          },
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <StatCard
          label="Available Works"
          value="18"
          delta="+2"
          hint="New paintings this month"
          variant="card"
        />
        <StatCard
          label="Open Inquiries"
          value="3"
          delta="0"
          hint="Pending collector messages"
          variant="card"
        />
        <StatCard
          label="Featured on Homepage"
          value="6"
          hint="Curated selection"
          variant="card"
        />
      </div>
    ),
    risk: (
      <RiskQueue
        heading="Needs Attention"
        items={[
          {
            id: 'risk-1',
            title: 'Coastal Hues status needs review',
            detail: 'Marked as Sold — confirm or revert to Available.',
            severity: 'medium',
          },
          {
            id: 'risk-2',
            title: 'Morning Mist missing dimensions',
            detail: 'Update artwork record with medium and size.',
            severity: 'low',
          },
        ]}
      />
    ),
    chart: (
      <ChartCard
        title="Artwork Status Breakdown"
        description="Current inventory by availability"
        type="bar"
        dataKey="count"
        xKey="label"
        data={[
          { label: 'Available', count: 18 },
          { label: 'Sold', count: 7 },
          { label: 'Reserved', count: 2 },
        ]}
        insight="18 of 27 works are currently available for inquiry."
        density="comfortable"
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search artworks..."
        filters={[
          { id: 'all', label: 'All', active: true },
          { id: 'available', label: 'Available', active: false },
          { id: 'sold', label: 'Sold', active: false },
          { id: 'featured', label: 'Featured', active: false },
        ]}
        actions={[
          {
            label: 'Add New Artwork',
            href: '/admin/artworks/new',
            variant: 'default',
          },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: 'title', header: 'Title' },
          { key: 'status', header: 'Status' },
          { key: 'medium', header: 'Medium' },
          { key: 'price', header: 'Price' },
          { key: 'featured', header: 'Featured' },
          { key: 'added', header: 'Date Added' },
          { key: 'actions', header: 'Actions' },
        ]}
        rows={[
          {
            id: 'art-1',
            title: 'Whispering Pines',
            status: (
              <Badge variant="default">Available</Badge>
            ),
            medium: 'Oil on Canvas',
            price: '$2,400',
            featured: 'Yes',
            added: '3 days ago',
            actions: (
              <span className="inline-flex items-center gap-2">
                <Button variant="ghost" size="sm" aria-label="View Whispering Pines">
                  View
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  aria-label="Edit Whispering Pines"
                >
                  Edit
                </Button>
              </span>
            ),
          },
          {
            id: 'art-2',
            title: 'Coastal Hues',
            status: (
              <Badge variant="default">Available</Badge>
            ),
            medium: 'Oil on Linen',
            price: '$3,100',
            featured: 'Yes',
            added: '5 days ago',
            actions: (
              <span className="inline-flex items-center gap-2">
                <Button variant="ghost" size="sm" aria-label="View Coastal Hues">
                  View
                </Button>
                <Button variant="ghost" size="sm" aria-label="Edit Coastal Hues">
                  Edit
                </Button>
              </span>
            ),
          },
          {
            id: 'art-3',
            title: 'Morning Mist',
            status: (
              <Badge variant="outline">Sold</Badge>
            ),
            medium: 'Oil on Canvas',
            price: '$1,800',
            featured: 'No',
            added: '1 week ago',
            actions: (
              <span className="inline-flex items-center gap-2">
                <Button variant="ghost" size="sm" aria-label="View Morning Mist">
                  View
                </Button>
                <Button variant="ghost" size="sm" aria-label="Edit Morning Mist">
                  Edit
                </Button>
              </span>
            ),
          },
          {
            id: 'art-4',
            title: 'Azure Depths',
            status: (
              <Badge variant="default">Available</Badge>
            ),
            medium: 'Oil on Canvas',
            price: '$2,800',
            featured: 'Yes',
            added: 'Just now',
            actions: (
              <span className="inline-flex items-center gap-2">
                <Button variant="ghost" size="sm" aria-label="View Azure Depths">
                  View
                </Button>
                <Button variant="ghost" size="sm" aria-label="Edit Azure Depths">
                  Edit
                </Button>
              </span>
            ),
          },
          {
            id: 'art-5',
            title: 'Echo Point',
            status: (
              <Badge variant="outline">Sold</Badge>
            ),
            medium: 'Oil on Linen',
            price: '$3,400',
            featured: 'No',
            added: '2 weeks ago',
            actions: (
              <span className="inline-flex items-center gap-2">
                <Button variant="ghost" size="sm" aria-label="View Echo Point">
                  View
                </Button>
                <Button variant="ghost" size="sm" aria-label="Edit Echo Point">
                  Edit
                </Button>
              </span>
            ),
          },
        ]}
        emptyMessage="No artworks match the current filters."
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          {
            id: 'act-1',
            title: 'New artwork uploaded',
            detail: 'Azure Depths',
            time: 'Just now',
          },
          {
            id: 'act-2',
            title: 'Inquiry received',
            detail: 'Golden Hour — Sarah Jenkins',
            time: '15 min ago',
          },
          {
            id: 'act-3',
            title: 'Artwork marked as Sold',
            detail: 'Echo Point',
            time: '2 hours ago',
          },
          {
            id: 'act-4',
            title: 'Featured list updated',
            detail: 'Whispering Pines added to homepage',
            time: 'Yesterday',
          },
          {
            id: 'act-5',
            title: 'Status changed',
            detail: 'Morning Mist → Sold',
            time: '1 week ago',
          },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell
      brandName="Jeanne Kassab Art"
      navItems={adminNavItems}
      rail={rail}
      appearance="soft"
      defaultSidebarCollapsed={false}
    >
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
    </OpsShell>
  );
}