import { useState } from 'react';
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import {
  OpsShell,
  getSkeleton,
  SkeletonComposer,
  PageHeader,
  DataTable,
  ActivityFeed,
  Button,
  Input,
  Select,
  Badge,
  Dialog,
} from '@/ui';

const SKELETON_ID = 'ops-detail' as const;

// Mock artwork data for the edit form
const mockArtwork = {
  id: '1',
  title: 'Morning Light on Canvas',
  description:
    'A layered oil landscape capturing the soft glow of dawn over the Provençal countryside.',
  dimensions: '60 x 80 cm',
  medium: 'Oil on linen',
  price: '$4,200',
  status: 'Available',
  featured: true,
  images: [
    {
      id: 'img1',
      url: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=300&h=200&fit=crop',
      filename: 'morning-light-main.jpg',
    },
    {
      id: 'img2',
      url: 'https://images.unsplash.com/photo-1518519279871-5b38e75e3ba2?w=300&h=200&fit=crop',
      filename: 'morning-light-detail.jpg',
    },
  ],
  editHistory: [
    {
      id: 'eh1',
      title: 'Price updated',
      detail: 'From $4,000 to $4,200',
      time: '2 hours ago',
    },
    {
      id: 'eh2',
      title: 'Description updated',
      detail: 'Revised artist notes for clarity',
      time: '1 day ago',
    },
  ],
  inquiries: [
    {
      id: 'inq1',
      title: 'Inquiry from Collector',
      detail: 'Interested in Morning Light, asking about availability.',
      time: '3 days ago',
    },
  ],
};

export default function ArtworkEditPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const [artwork, setArtwork] = useState(mockArtwork);
  const [pendingStatus, setPendingStatus] = useState<string | null>(null);
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>,
    field: string
  ) => {
    setArtwork((prev) => ({ ...prev, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const handleStatusChange = (newStatus: string) => {
    setPendingStatus(newStatus);
    setShowStatusDialog(true);
  };

  const confirmStatusChange = () => {
    if (pendingStatus) {
      setArtwork((prev) => ({ ...prev, status: pendingStatus }));
      setPendingStatus(null);
    }
    setShowStatusDialog(false);
  };

  const cancelStatusChange = () => {
    setPendingStatus(null);
    setShowStatusDialog(false);
  };

  const handleFeaturedToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
    setArtwork((prev) => ({ ...prev, featured: e.target.checked }));
  };

  const handleDelete = () => {
    // In a real app, call API then redirect
    setShowDeleteDialog(false);
    setTimeout(() => window.location.assign('/admin/artworks'), 200);
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!artwork.title.trim()) newErrors.title = 'Title is required.';
    if (!artwork.price.trim()) newErrors.price = 'Price is required.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validateForm()) return;
    setSuccessMessage('Artwork updated successfully.');
    setTimeout(() => window.location.assign('/admin/artworks'), 1500);
  };

  const handleCancel = () => {
    window.location.assign('/admin/artworks');
  };

  // Image action columns for DataTable
  const imageColumns = [
    {
      key: 'thumbnail',
      header: 'Image',
      render: (row: any) => (
        <img
          src={row.url}
          alt="artwork"
          className="h-12 w-16 object-cover rounded-md border border-muted/20"
        />
      ),
    },
    { key: 'filename', header: 'File name' },
    {
      key: 'actions',
      header: '',
      render: (row: any) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm">
            Replace
          </Button>
          <Button variant="ghost" size="sm" className="text-destructive">
            Delete
          </Button>
          <Button variant="ghost" size="sm">
            Reorder
          </Button>
        </div>
      ),
    },
  ];

  // Mix edit history and inquiries for activity feed
  const activityItems = [
    ...artwork.inquiries.map((i) => ({
      id: i.id,
      title: i.title,
      detail: i.detail,
      time: i.time,
    })),
    ...artwork.editHistory.map((h) => ({
      id: h.id,
      title: h.title,
      detail: h.detail,
      time: h.time,
    })),
  ];

  const slots = {
    header: (
      <PageHeader
        title="Edit Artwork"
        description={
          <span className="text-muted inline-flex items-center gap-2 text-sm">
            Artworks / {artwork.title} / Edit
          </span>
        }
        actions={[
          {
            label: 'Cancel',
            onClick: handleCancel,
            variant: 'ghost',
          },
        ]}
      />
    ),

    table: (
      <div className="space-y-8">
        {successMessage && (
          <div className="bg-brand/10 text-brand rounded-lg px-4 py-3 text-sm font-medium">
            {successMessage}
          </div>
        )}
        {/* Editable form & image gallery */}
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-6">
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-text mb-1">
                  Title
                </label>
                <Input
                  value={artwork.title}
                  onChange={(e: any) => handleInputChange(e, 'title')}
                  placeholder="Painting title"
                  error={errors.title}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-text mb-1">
                  Description
                </label>
                <Input
                  as="textarea"
                  rows={4}
                  value={artwork.description}
                  onChange={(e: any) => handleInputChange(e, 'description')}
                  placeholder="Artist notes, inspiration, technique..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text mb-1">
                    Dimensions
                  </label>
                  <Input
                    value={artwork.dimensions}
                    onChange={(e: any) => handleInputChange(e, 'dimensions')}
                    placeholder="e.g., 60 x 80 cm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text mb-1">
                    Medium
                  </label>
                  <Input
                    value={artwork.medium}
                    onChange={(e: any) => handleInputChange(e, 'medium')}
                    placeholder="Oil on linen"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-text mb-1">
                  Price
                </label>
                <Input
                  value={artwork.price}
                  onChange={(e: any) => handleInputChange(e, 'price')}
                  placeholder="e.g., $4,200"
                  error={errors.price}
                />
              </div>
              <div className="flex items-center gap-6 pt-2">
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium text-text">Status</span>
                  <Select
                    options={[
                      { value: 'Available', label: 'Available' },
                      { value: 'Sold', label: 'Sold' },
                    ]}
                    value={artwork.status}
                    onValueChange={(value) => handleStatusChange(value)}
                    className="min-w-[140px]"
                  />
                  <Badge
                    variant={artwork.status === 'Available' ? 'default' : 'secondary'}
                    className="ml-2"
                  >
                    {artwork.status}
                  </Badge>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={artwork.featured}
                    onChange={handleFeaturedToggle}
                    className="rounded border-muted text-brand focus:ring-brand"
                  />
                  <span className="text-sm font-medium text-text">
                    Featured on homepage
                  </span>
                </label>
              </div>
            </div>
          </div>

          {/* Image gallery card */}
          <div className="bg-surface border border-muted/10 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-text text-sm">Images</h3>
              <Button variant="outline" size="sm">
                + Add
              </Button>
            </div>
            <DataTable
              columns={imageColumns}
              rows={artwork.images.map((img) => ({
                id: img.id,
                url: img.url,
                filename: img.filename,
              }))}
              emptyMessage="No images uploaded yet."
            />
          </div>
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between border-t border-muted/10 pt-6">
          <div className="flex gap-3">
            <Button onClick={handleSave}>Save changes</Button>
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
          </div>
          <Button
            variant="destructive"
            onClick={() => setShowDeleteDialog(true)}
          >
            Delete artwork
          </Button>
        </div>

        {/* Status change confirmation dialog */}
        <Dialog
          open={showStatusDialog}
          onOpenChange={setShowStatusDialog}
          title={`Change status to ${pendingStatus}?`}
          description="This will update the artwork’s public visibility and may affect inquiries."
          footer={
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={cancelStatusChange}>
                Keep {artwork.status}
              </Button>
              <Button onClick={confirmStatusChange}>Confirm</Button>
            </div>
          }
        >
          <p className="text-muted text-sm">
            The status change will be reflected immediately on the public gallery.
          </p>
        </Dialog>

        {/* Delete confirmation dialog */}
        <Dialog
          open={showDeleteDialog}
          onOpenChange={setShowDeleteDialog}
          title="Delete artwork?"
          description="This action cannot be undone. All images and data will be permanently removed."
          footer={
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => setShowDeleteDialog(false)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleDelete}>
                Yes, delete
              </Button>
            </div>
          }
        >
          <p className="text-muted text-sm">
            Deleting this artwork will also remove it from the public gallery and any active inquiries.
          </p>
        </Dialog>
      </div>
    ),

    activity: (
      <ActivityFeed
        heading="Activity"
        items={activityItems.length > 0 ? activityItems : seed.activity || []}
      />
    ),
  };

  return (
    <OpsShell brandName={'Jeanne Kassab Art'} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-artwork-edit">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}