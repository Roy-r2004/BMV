// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function LoginPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Admin Login"}
        description={"Orders, saved items, and preferences."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Recent orders"}</h3>
            <p className="text-sm leading-6 text-muted">{"2 open · 1 delivered this month"}</p>
            <Button href={"/admin/login"} className="mt-auto w-fit">
              {"Track orders"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Saved items"}</h3>
            <p className="text-sm leading-6 text-muted">{"3 products waiting in your list"}</p>
            <Button href={"/"} className="mt-auto w-fit">
              {"Continue shopping"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Business"}
        description={"Signed-in experience for Business customers."}
      />
    ),
  };

  return (
      <div className="contents" data-appspec-page="admin-login">
      </div>
    <PublicShell
      brandName={"Business"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"account"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
