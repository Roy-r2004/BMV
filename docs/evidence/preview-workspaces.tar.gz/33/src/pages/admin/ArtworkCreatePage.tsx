import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Button, Input, Select, Badge, ActivityFeed } from '@/ui';

const SKELETON_ID = 'ops-detail' as const;

interface FormState {
  title: string;
  height: string;
  width: string;
  depth: string;
  medium: string;
  price: string;
  description: string;
  tags: string;
  status: 'Available' | 'Sold';
  featured: boolean;
}

export default function ArtworkCreatePage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const navigate = useNavigate();

  const [form, setForm] = useState<FormState>({
    title: '',
    height: '',
    width: '',
    depth: '',
    medium: 'Oil on Canvas',
    price: '',
    description: '',
    tags: '',
    status: 'Available',
    featured: false,
  });

  const [primaryPreview, setPrimaryPreview] = useState<string | null>(null);
  const [galleryPreviews, setGalleryPreviews] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handlePrimaryImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPrimaryPreview(URL.createObjectURL(file));
    }
  };

  const handleGalleryImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const urls = files.map((file) => URL.createObjectURL(file));
    setGalleryPreviews((prev) => [...prev, ...urls]);
  };

  const removeGalleryImage = (index: number) => {
    setGalleryPreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleChange = (field: keyof FormState, value: string | boolean) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!form.title.trim()) newErrors.title = 'Title is required.';
    if (!form.height.trim() || isNaN(Number(form.height))) newErrors.height = 'Valid height required.';
    if (!form.width.trim() || isNaN(Number(form.width))) newErrors.width = 'Valid width required.';
    if (form.depth.trim() && isNaN(Number(form.depth))) newErrors.depth = 'Depth must be a number.';
    if (!form.medium) newErrors.medium = 'Medium is required.';
    if (!form.price.trim() || isNaN(Number(form.price))) newErrors.price = 'Valid price required.';
    if (!primaryPreview && !form.title) newErrors.primaryImage = 'Primary image is required.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    // Simulate save
    setSubmitted(true);
    setTimeout(() => {
      navigate('/admin/artworks');
    }, 1500);
  };

  const handleSaveAndAddAnother = () => {
    if (!validate()) return;
    // Simulate save & reset
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setForm({
        title: '',
        height: '',
        width: '',
        depth: '',
        medium: 'Oil on Canvas',
        price: '',
        description: '',
        tags: '',
        status: 'Available',
        featured: false,
      });
      setPrimaryPreview(null);
      setGalleryPreviews([]);
      window.scrollTo(0, 0);
    }, 500);
  };

  const dimensionUnit = 'cm'; // could be dynamic

  const activityItems = [
    {
      id: 'hint1',
      title: 'Image upload',
      detail: 'Use high-resolution photos (3000px+ wide). Primary image is required.',
      time: '',
    },
    {
      id: 'hint2',
      title: 'Dimensions',
      detail: `Enter in ${dimensionUnit} — height, width, depth. Depth is optional.`,
      time: '',
    },
    {
      id: 'hint3',
      title: 'Tags',
      detail: 'Comma-separated keywords like "abstract, landscape, oils".',
      time: '',
    },
    {
      id: 'hint4',
      title: 'Status & featured',
      detail: 'Mark as Available for live gallery. Featured works appear on homepage.',
      time: '',
    },
  ];

  const slots = {
    header: (
      <PageHeader
        title="Add New Artwork"
        description="Upload a new painting to the collection."
        meta={<span className="text-sm text-muted">Artworks &gt; New</span>}
        actions={[
          { label: 'Cancel', href: '/admin/artworks', variant: 'ghost' },
        ]}
      />
    ),
    table: (
      <div className="max-w-3xl mx-auto px-4 py-8">
        {submitted ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Badge variant="secondary" className="text-lg px-4 py-2">Artwork saved successfully!</Badge>
            <p className="text-muted">Redirecting…</p>
          </div>
        ) : (
          <form id="artwork-form" onSubmit={handleSubmit} className="space-y-8">
            {/* Image Upload Section */}
            <fieldset className="border border-gray-200 rounded-lg p-6 space-y-5">
              <legend className="text-xl font-display text-brand">Images</legend>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-text mb-1">
                    Primary Image <span className="text-destructive">*</span>
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-brand/50 transition-colors">
                    {primaryPreview ? (
                      <div className="relative">
                        <img src={primaryPreview} alt="Primary preview" className="max-h-48 mx-auto object-contain rounded" />
                        <button
                          type="button"
                          onClick={() => setPrimaryPreview(null)}
                          className="absolute top-1 right-1 text-xs text-muted hover:text-destructive"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <>
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={handlePrimaryImage}
                          id="primary-image"
                          className="hidden"
                          aria-label="Upload primary image"
                        />
                        <label htmlFor="primary-image" className="cursor-pointer block py-3 text-muted">
                          Drag & drop or click to upload
                        </label>
                      </>
                    )}
                  </div>
                  {errors.primaryImage && <p className="text-destructive text-xs mt-1">{errors.primaryImage}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-text mb-1">
                    Gallery Images
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-brand/50 transition-colors">
                    <Input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleGalleryImages}
                      id="gallery-images"
                      className="hidden"
                      aria-label="Upload gallery images"
                    />
                    <label htmlFor="gallery-images" className="cursor-pointer block py-3 text-muted">
                      Upload additional views
                    </label>
                  </div>
                  {galleryPreviews.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {galleryPreviews.map((url, idx) => (
                        <div key={idx} className="relative w-16 h-16">
                          <img src={url} alt={`Gallery ${idx + 1}`} className="w-full h-full object-cover rounded" />
                          <button
                            type="button"
                            onClick={() => removeGalleryImage(idx)}
                            className="absolute -top-1 -right-1 bg-white rounded-full p-0.5 shadow text-xs text-muted hover:text-destructive"
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </fieldset>

            {/* Details Section */}
            <fieldset className="space-y-5">
              <legend className="text-xl font-display text-brand">Details</legend>
              <Input
                label="Title"
                required
                value={form.title}
                onChange={(e) => handleChange('title', (e.target as HTMLInputElement).value)}
                error={errors.title}
                placeholder="Enter painting title"
              />
              <div className="grid grid-cols-3 gap-4">
                <Input
                  label={`Height (${dimensionUnit})`}
                  required
                  value={form.height}
                  onChange={(e) => handleChange('height', (e.target as HTMLInputElement).value)}
                  error={errors.height}
                  placeholder="100"
                  type="number"
                />
                <Input
                  label={`Width (${dimensionUnit})`}
                  required
                  value={form.width}
                  onChange={(e) => handleChange('width', (e.target as HTMLInputElement).value)}
                  error={errors.width}
                  placeholder="80"
                  type="number"
                />
                <Input
                  label={`Depth (${dimensionUnit})`}
                  value={form.depth}
                  onChange={(e) => handleChange('depth', (e.target as HTMLInputElement).value)}
                  error={errors.depth}
                  placeholder="2.5"
                  type="number"
                />
              </div>
              <Select
                label="Medium"
                required
                options={['Oil on Canvas', 'Oil on Panel', 'Oil on Linen', 'Acrylic on Canvas', 'Mixed Media']}
                value={form.medium}
                onValueChange={(value) => handleChange('medium', value)}
                error={errors.medium}
              />
              <Input
                label="Price (USD)"
                required
                value={form.price}
                onChange={(e) => handleChange('price', (e.target as HTMLInputElement).value)}
                error={errors.price}
                placeholder="1200"
                type="number"
                min="0"
                step="0.01"
              />
              <Input
                as="textarea"
                label="Description"
                value={form.description}
                onChange={(e) => handleChange('description', (e.target as HTMLTextAreaElement).value)}
                rows={4}
                placeholder="Artwork description, inspiration, notes..."
              />
              <Input
                label="Tags / Themes"
                value={form.tags}
                onChange={(e) => handleChange('tags', (e.target as HTMLInputElement).value)}
                placeholder="abstract, landscape, layered..."
              />
              <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
                <Select
                  label="Status"
                  required
                  options={['Available', 'Sold']}
                  value={form.status}
                  onValueChange={(value) => handleChange('status', value)}
                />
                <label className="flex items-center gap-2 cursor-pointer pt-5">
                  <input
                    type="checkbox"
                    checked={form.featured}
                    onChange={(e) => handleChange('featured', e.target.checked)}
                    className="rounded border-gray-300 text-brand focus:ring-brand"
                  />
                  <span className="text-sm font-medium text-text">Featured on homepage</span>
                </label>
              </div>
            </fieldset>

            {/* Form Actions */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-100">
              <Button type="submit" variant="default" size="lg">
                Save Artwork
              </Button>
              <Button type="button" variant="secondary" size="lg" onClick={handleSaveAndAddAnother}>
                Save & Add Another
              </Button>
              <Button type="button" variant="ghost" size="lg" href="/admin/artworks">
                Cancel
              </Button>
            </div>
          </form>
        )}
      </div>
    ),
    activity: (
      <ActivityFeed heading="Field Hints" items={activityItems} />
    ),
  };

  return (
    <OpsShell brandName="Jeanne Kassab Art" navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-artwork-create">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}