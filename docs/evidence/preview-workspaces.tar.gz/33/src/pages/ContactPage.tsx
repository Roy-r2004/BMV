// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, CTABand } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Business?"} description={seed.cta?.description ?? "Tell Business what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    header: (
      <PageHeader
        title={"Get in Touch"}
        description={"Have a question or interested in a specific piece? We'd love to hear from you."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Send an Email"}</h3>
            <p className="text-sm leading-6 text-muted">{"Reach out directly to Jeanne for any inquiries about the collection, commissions, or gallery visits."}</p>
            <Button href={"mailto:jeanne@jeannekassabart.com"} className="mt-auto w-fit">
              {"Send Email"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Chat on WhatsApp"}</h3>
            <p className="text-sm leading-6 text-muted">{"Prefer instant messaging? Start a conversation for quick questions or to discuss a painting."}</p>
            <Button href={"https://wa.me/96171234567"} className="mt-auto w-fit">
              {"Start a Chat"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Follow on Instagram"}</h3>
            <p className="text-sm leading-6 text-muted">{"See studio moments, new works, and behind-the-scenes of the creative process."}</p>
            <Button href={"https://instagram.com/jeannekassabart"} className="mt-auto w-fit">
              {"View Instagram"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Business"}
        description={"© 2025 Jeanne Kassab Art — Original Oil Paintings. All inquiries welcome."}
      />
    ),
  };

  return (
      <div className="contents" data-appspec-page="public-contact">
      </div>
    <PublicShell
      brandName={"Business"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"generic"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
