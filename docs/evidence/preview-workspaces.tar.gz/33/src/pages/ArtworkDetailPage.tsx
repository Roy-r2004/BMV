// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import {
  PublicShell,
  getSkeleton,
  SkeletonComposer,
  PublicNav,
  MarketingHero,
  CredentialStrip,
  ProductShowcase,
  TestimonialRail,
  CTABand,
  BrandFooter,
  Badge,
  Button,
  UiIcon,
} from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  // Artwork data — "Coastal Hues"
  const artwork = {
    title: "Coastal Hues",
    medium: "Oil on Canvas",
    dimensions: '48" × 36"',
    price: "$4,500",
    status: "Available",
    year: "2024",
    image: images.card1,
    description:
      "Coastal Hues explores the interplay of turquoise and amber tones, evoking the transition between sea and sky at golden hour. Layered translucent oils create depth and movement, inviting the viewer to pause and reflect.",
  };

  const slots = {
    hero: (
      <div className="relative w-full h-[70vh] max-h-[700px] overflow-hidden">
        <img
          src={artwork.image}
          alt={`${artwork.title} — ${artwork.medium}`}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
        {/* Brand signal */}
        <div className="absolute top-6 left-8 md:left-16 text-white/70 text-sm tracking-[0.2em] uppercase font-sans">
          Jeanne Kassab Art
        </div>
        {/* Hero content */}
        <div className="absolute bottom-8 left-8 md:left-16 text-white space-y-4 max-w-2xl">
          <Badge variant="secondary" className="mb-2">
            {artwork.status}
          </Badge>
          <h1 className="font-display text-4xl md:text-6xl font-light leading-tight">
            {artwork.title}
          </h1>
          <p className="text-lg font-sans text-white/80">
            {artwork.medium} · {artwork.dimensions} · {artwork.price}
          </p>
        </div>
      </div>
    ),

    credentials: (
      <CredentialStrip
        heading="Why Collect from Jeanne Kassab Art"
        items={[
          "Original Oil Paintings",
          "Studio-Direct Purchase",
          "Worldwide Shipping",
          "Certificates of Authenticity",
        ]}
      />
    ),

    showcase: (
      <section className="py-16 px-6 md:px-12 mx-auto max-w-7xl">
        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Large image with zoom */}
          <div className="relative group overflow-hidden rounded-lg shadow-lg">
            <img
              src={artwork.image}
              alt={artwork.title}
              className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <a
              href={artwork.image}
              target="_blank"
              rel="noopener noreferrer"
              className="absolute bottom-4 right-4 bg-white/80 text-brand p-2 rounded-full shadow hover:bg-white transition focus:outline-none focus:ring-2 focus:ring-brand"
              aria-label="View full size image"
            >
              <UiIcon name="search" />
            </a>
          </div>

          {/* Metadata & description */}
          <div className="space-y-8">
            <div>
              <Badge variant="secondary">{artwork.status}</Badge>
            </div>
            <h2 className="font-display text-4xl font-light text-brand">
              {artwork.title}
            </h2>

            <div className="grid grid-cols-2 gap-4 text-base text-muted">
              <div>
                <span className="block font-semibold text-text">Medium</span>
                <span>{artwork.medium}</span>
              </div>
              <div>
                <span className="block font-semibold text-text">Dimensions</span>
                <span>{artwork.dimensions}</span>
              </div>
              <div>
                <span className="block font-semibold text-text">Price</span>
                <span>{artwork.price} USD</span>
              </div>
              <div>
                <span className="block font-semibold text-text">Created</span>
                <span>{artwork.year}</span>
              </div>
            </div>

            <div className="prose prose-slate max-w-none text-muted">
              <p className="text-lg leading-relaxed">{artwork.description}</p>
            </div>

            <Button
              variant="default"
              size="lg"
              href={`https://wa.me/1234567890?text=I'm%20interested%20in%20${encodeURIComponent(artwork.title)}`}
              className="w-full md:w-auto"
            >
              Inquire About This Piece
            </Button>
            <p className="text-sm text-muted">
              Or <a href="/contact" className="underline">send a message</a>
            </p>
          </div>
        </div>

        {/* Related works */}
        <ProductShowcase
          heading="Related Works"
          description="Continue exploring the collection"
          items={[
            {
              title: "Sunset Drift",
              description: "Oil on Canvas",
              imageSrc: images.card2,
              imageAlt: "Sunset Drift",
              href: "/collection/sunset-drift",
            },
            {
              title: "Azure Layers",
              description: "Oil on Canvas",
              imageSrc: images.card3,
              imageAlt: "Azure Layers",
              href: "/collection/azure-layers",
            },
            {
              title: "Golden Veil",
              description: "Oil on Canvas",
              imageSrc: images.card1,
              imageAlt: "Golden Veil",
              href: "/collection/golden-veil",
            },
          ]}
          className="mt-16"
        />
      </section>
    ),

    testimonials: (
      <TestimonialRail
        heading="What Collectors Say"
        items={[
          {
            quote:
              "Coastal Hues brought a serene energy to our home. The layering and light are extraordinary.",
            author: "— Sarah L., Interior Designer",
          },
          {
            quote:
              "Jeanne's originals are breathtaking. The depth of color cannot be captured in photos — they need to be seen in person.",
            author: "— Michael T., Collector",
          },
          {
            quote:
              "We commissioned a piece after seeing Coastal Hues online. The process was seamless and the result even better than expected.",
            author: "— Daniel & Claire, New York",
          },
        ]}
      />
    ),

    cta: (
      <CTABand
        heading="Bring a Piece Home"
        description="Original oils that speak to the soul. Explore the full collection or inquire about a specific work."
        primaryCta={{ label: "View Collection", href: "/collection" }}
        secondaryCta={{ label: "Contact Studio", href: "/contact" }}
      />
    ),

    footer: (
      <BrandFooter
        brandName="Jeanne Kassab Art"
        description="Original oil paintings — abstract landscapes and layered compositions. Direct from the artist's studio."
        links={[
          { label: "Collection", href: "/collection" },
          { label: "About", href: "/about" },
          { label: "Contact", href: "/contact" },
          { label: "WhatsApp", href: "https://wa.me/1234567890" },
        ]}
        meta="© 2024 Jeanne Kassab Art. All rights reserved."
      />
    ),
  };

  return (
    <PublicShell brandName="Jeanne Kassab Art" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="public-artwork-detail">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}