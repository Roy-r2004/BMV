import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import Aboutpage from './pages/Aboutpage';
import AdmindashboardPage from './pages/admin/AdmindashboardPage';
import Adminloginpage from './pages/admin/Adminloginpage';
import Adminpaintingformpage from './pages/admin/Adminpaintingformpage';
import Contactpage from './pages/Contactpage';
import Gallerypage from './pages/Gallerypage';
import Homepage from './pages/Homepage';
import Paintingdetailpage from './pages/Paintingdetailpage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/admin/login');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/admin/login" element={<Adminloginpage />} />
          <Route path="/admin" element={<AdmindashboardPage />} />
          <Route path="/admin/painting/form" element={<Adminpaintingformpage />} />
          <Route path="/gallery" element={<Gallerypage />} />
          <Route path="/gallery/v2" element={<Paintingdetailpage />} />
          <Route path="/contact" element={<Contactpage />} />
          <Route path="/" element={<Homepage />} />
          <Route path="/about" element={<Aboutpage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}