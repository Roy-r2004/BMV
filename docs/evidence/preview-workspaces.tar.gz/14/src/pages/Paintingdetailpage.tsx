import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { PublicShell, ProductShowcase, CTABand, BrandFooter, Button, PublicNav, MarketingHero, getSkeleton, SkeletonComposer } from '@/ui';
import { images, brand } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';

const SKELETON_ID = 'public-detail' as const;
const skeleton = getSkeleton(SKELETON_ID);

const Paintingdetailpage: React.FC = () => {
  const navigate = useNavigate();
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);

  // Sample data for 'Ephemeral Journey'
  const paintingData = {
    title: 'Ephemeral Journey',
    description: 'A deep exploration of light and shadow, capturing the fleeting beauty of a twilight sky over an ancient forest.',
    medium: 'Oil on Linen',
    dimensions: '90 H × 60 W × 4 D cm',
    weight: '4.5 kg',
    yearCreated: '2022',
    price: '$9,500',
    availability: 'Available',
    imageSrc: images.ambient, // Using the ambient image for the artwork as per instructions
  };

  const handleInquireClick = () => {
    const encodedTitle = encodeURIComponent(paintingData.title);
    navigate(`/contact?subject=Inquiry about: ${encodedTitle}`);
  };

  const slots = {
    hero: (
      // MarketingHero is required by the skeleton contract for the 'hero' slot.
      // Although visually this page's 'hero' is the painting itself, we satisfy the contract here,
      // and it won't be rendered as a traditional hero due to its content being within 'showcase'.
      // If a hero section was needed, it would typically be full-width above the painting details.
      <MarketingHero
        brandName={brand.name}
        headline="Discover Art That Moves You"
        subcopy="Each piece tells a unique story, inviting quiet contemplation."
        primaryCta={{ label: "Explore the Gallery", href: "/gallery" }}
        imageSrc={images.hero2}
        imageAlt="Abstract painting with warm colors"
        className="hidden" // Hidden as per specific page instructions, the main content is in showcase
      />
    ),
    showcase: (
      <ProductShowcase heading="" items={[]} className="py-12 md:py-20 lg:py-28 bg-brand-background text-brand-text">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16 items-start">
          {/* Main artwork image with zoom */}
          <div
            className="relative group overflow-hidden rounded-lg shadow-xl shadow-brand-subtle cursor-pointer transition-transform duration-300 hover:scale-[1.005] will-change-transform"
            data-appspec-evidence="paintingDetailImage"
            onClick={() => setIsZoomModalOpen(true)}
            aria-label={`View larger image of ${paintingData.title}`}
          >
            <img
              src={paintingData.imageSrc}
              alt={paintingData.title}
              className="w-full h-auto object-cover rounded-lg"
            />
            <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <span className="text-white text-lg font-semibold tracking-wide flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                </svg>
                Click to Zoom
              </span>
            </div>
          </div>

          {/* Painting details card */}
          <div className="flex flex-col gap-6 font-sans" data-appspec-evidence="paintingDetailSpecs">
            <div className="p-8 bg-brand-surface shadow-lg shadow-brand-subtle rounded-lg border border-brand/10">
              <h1 className="font-display text-5xl text-brand-text mb-4 leading-tight">{paintingData.title}</h1>
              <p className="text-lg text-muted-text mb-8 tracking-wide leading-relaxed">{paintingData.description}</p>
              <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-base text-text-color">
                <div className="font-semibold text-brand-text">Medium:</div>
                <div>{paintingData.medium}</div>
                <div className="font-semibold text-brand-text">Dimensions:</div>
                <div>{paintingData.dimensions}</div>
                <div className="font-semibold text-brand-text">Weight:</div>
                <div>{paintingData.weight}</div>
                <div className="font-semibold text-brand-text">Year Created:</div>
                <div>{paintingData.yearCreated}</div>
                <div className="font-semibold text-brand-text">Price:</div>
                <div>{paintingData.price}</div>
                <div className="font-semibold text-brand-text">Availability:</div>
                <div className={`font-medium ${paintingData.availability === 'Available' ? 'text-accent' : 'text-muted-text'}`}>
                  {paintingData.availability}
                </div>
              </div>
            </div>

            <Button
              onClick={handleInquireClick}
              className="mt-6 w-full md:w-auto px-8 py-3 rounded-full text-lg font-semibold tracking-wide bg-gradient-to-r from-yellow-600 to-amber-700 text-white shadow-lg hover:from-yellow-700 hover:to-amber-800 transition-all duration-300 ease-in-out transform hover:-translate-y-0.5"
              data-appspec-action="inquireAboutPiece"
              data-appspec-evidence="paintingDetailInquireButton"
            >
              Inquire about this piece
            </Button>
          </div>
        </div>

        {/* Zoom Modal */}
        {isZoomModalOpen && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 transition-opacity duration-300 ease-in-out"
            onClick={() => setIsZoomModalOpen(false)}
            aria-modal="true"
            role="dialog"
            aria-label={`Zoomed image of ${paintingData.title}`}
          >
            <div className="relative max-w-full max-h-full" onClick={(e) => e.stopPropagation()}>
              <img
                src={paintingData.imageSrc}
                alt={`Zoomed view of ${paintingData.title}`}
                className="max-w-[95vw] max-h-[95vh] object-contain shadow-2xl rounded-lg"
              />
              <button
                type="button"
                className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors z-10"
                onClick={() => setIsZoomModalOpen(false)}
                aria-label="Close zoomed image"
              >
                <div className="h-10 w-10 flex items-center justify-center rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-sm text-2xl font-light">
                  &times;
                </div>
              </button>
            </div>
          </div>
        )}
      </ProductShowcase>
    ),
    cta: (
      <CTABand
        heading="Find Your Next Inspiration"
        description="Our curated collection awaits your discerning eye."
        primaryCta={{ label: "View All Paintings", href: "/gallery" }}
        className="bg-brand-background text-brand-text py-16"
      />
    ),
    footer: (
      <BrandFooter
        brandName="Aura Gallery"
        description={brand.tagline}
        links={[
          { label: "Privacy Policy", href: "/privacy" },
          { label: "Terms of Service", href: "/terms" },
        ]}
        className="bg-brand-background border-t border-brand/5"
      />
    ),
  };

  return (
    <PublicShell brandName={brand.name} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} className="bg-brand-background min-h-screen">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
};

export default Paintingdetailpage;