import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PublicShell,
  MarketingHero,
  ProductShowcase,
  CTABand,
  BrandFooter,
  SkeletonComposer,
  Button, ProcessSection, TestimonialRail, PublicNav, getSkeleton } from '@/ui';
import { images, brand } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';


const SKELETON_ID = 'public-home' as const;

// Mock painting data for Recent Works and Hero
const mockPaintings = [
  {
    id: 'golden-horizon',
    title: 'Golden Horizon',
    imageSrc: images.hero,
    price: 6500,
    medium: 'Acrylic on Canvas',
    year: 2023,
    featured: true,
  },
  {
    id: 'silent-blooms',
    title: 'Silent Blooms',
    imageSrc: images.hero2,
    price: 4800,
    medium: 'Oil on Linen',
    year: 2022,
    featured: true,
  },
  {
    id: 'coastal-dream',
    title: 'Coastal Dream',
    imageSrc: images.card3,
    price: 3200,
    medium: 'Watercolor',
    year: 2023,
    featured: false,
  },
  {
    id: 'city-hues',
    title: 'City Hues',
    imageSrc: images.card2,
    price: 5800,
    medium: 'Mixed Media',
    year: 2023,
    featured: false,
  },
  {
    id: 'forests-embrace',
    title: "Forest's Embrace",
    imageSrc: images.card1,
    price: 2900,
    medium: 'Oil on Wood',
    year: 2022,
    featured: false,
  },
  {
    id: 'desert-song',
    title: 'Desert Song',
    imageSrc: images.ambient,
    price: 4100,
    medium: 'Pastel',
    year: 2023,
    featured: false,
  },
  {
    id: 'morning-mist',
    title: 'Morning Mist',
    imageSrc: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=900&q=80&fit=crop&auto=format', // Using hero image for more variety
    price: 2500,
    medium: 'Ink Wash',
    year: 2024,
    featured: false,
  },
  {
    id: 'abstract-flow',
    title: 'Abstract Flow',
    imageSrc: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?w=1400&q=80&fit=crop&auto=format', // Using hero2 image here
    price: 6500,
    medium: 'Acrylic Pour',
    year: 2024,
    featured: false,
  },
].sort((a, b) => b.year - a.year); // Sort by year for "Recent Works"

const featuredPaintings = mockPaintings.filter((p) => p.featured);
const recentWorks = mockPaintings.slice(0, 6);

export default function Homepage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const navigate = useNavigate();
  const [currentHeroIndex, setCurrentHeroIndex] = useState(0);
  const skeleton = getSkeleton(SKELETON_ID);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentHeroIndex((prevIndex) => (prevIndex + 1) % featuredPaintings.length);
    }, 5000); // Change image every 5 seconds
    return () => clearInterval(interval);
  }, [featuredPaintings.length]);

  const currentHeroPainting = featuredPaintings[currentHeroIndex];

  const slots = {
    showcase: (
      <ProductShowcase heading="Featured experiences" items={[{ title: "Signature service", description: "A dependable starting point.", imageSrc: images.card1, imageAlt: "" }, { title: "Everyday essential", description: "Built for daily use.", imageSrc: images.card2, imageAlt: "" }]} />
    ),
    process: (
      <ProcessSection heading="How it works" steps={[{ title: "Choose", description: "Find the right option." }, { title: "Confirm", description: "Select a convenient time." }, { title: "Enjoy", description: "We take care of the details." }]} />
    ),
    testimonials: (
      <TestimonialRail heading="What clients say" items={[{ quote: "Clear, warm, and easy from start to finish.", author: "A returning client", role: "Verified guest" }]} />
    ),
    hero: (
      <MarketingHero
        brandName="Jane Art"
        headline="Aura Gallery: Curated Canvas"
        subcopy={brand.tagline || 'A serene sanctuary for art enthusiasts to discover and connect with unique paintings.'}
        primaryCta={{ label: 'View Gallery', onClick: () => navigate('/gallery'), href: '/gallery' }}
        imageSrc={currentHeroPainting?.imageSrc || images.hero}
        imageAlt={currentHeroPainting?.title || 'Featured Artwork'}
        eyebrow="Discover Timeless Beauty"
        className="text-white relative z-0 h-screen overflow-hidden flex items-center justify-center p-6 lg:p-12"
        data-appspec-evidence="homePageHeroSection"
      />
    ),
    features: (
      // Using ProductShowcase for "Recent Works" as FeatureBento doesn't directly support product cards
      <ProductShowcase
        heading="Recent Works"
        items={recentWorks.map((painting) => ({
          title: painting.title,
          description: `Price: ${painting.price}`,
          imageSrc: painting.imageSrc,
          meta: [painting.medium, painting.year.toString()],
          href: `/gallery/${painting.id}`,
        }))}
        description="The latest additions to our collection. Each piece tells a story, waiting to find its home."
        className="py-16 lg:py-24 bg-brand-background shadow-brand-subtle"
        headingClassName="text-center font-display text-4xl lg:text-5xl text-brand mb-12"
        data-appspec-evidence="homePageRecentWorksSection"
      >
        {(item) => (
          <div className="group relative overflow-hidden rounded-[calc(var(--radius-ui)+0.25rem)] border border-border-subtle bg-card shadow-[var(--shadow-ui)] hover:shadow-lg transition-all duration-300 ease-in-out transform hover:-translate-y-1">
            <img
              src={item.imageSrc}
              alt={item.title}
              className="w-full h-80 object-cover object-center transition-transform duration-500 ease-in-out group-hover:scale-105"
            />
            <div className="p-6">
              <h3 className="font-display text-2xl text-brand mb-2 transition-colors duration-300 group-hover:text-brand-primary">
                {item.title}
              </h3>
              <p className="text-muted-foreground text-lg">{item.description}</p>
              <div className="absolute inset-0 flex items-center justify-center bg-brand-primary/80 opa"></div>
            </div>
          </div>
        )}
      </ProductShowcase>
    ),
    cta: (
      <CTABand
        heading="Connect with Art"
        description="Ready to find that perfect piece? Explore our gallery or get in touch for custom inquiries."
        primaryCta={{ label: "View All Artworks", href: "/gallery" }}
        secondaryCta={{ label: "Contact Us", href: "/contact" }}
      />
    ),
    footer: (
      <BrandFooter brandName={brand.name} />
    ),
  };

  return (
    <PublicShell brandName={brand.name} chrome="immersive" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}