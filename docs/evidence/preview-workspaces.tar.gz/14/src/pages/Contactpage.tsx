import React, { useState, useEffect, FormEvent } from 'react';
import { useLocation } from 'react-router-dom';
import { PublicShell, MarketingHero, CTABand, BrandFooter, PublicNav, Button, getSkeleton, SkeletonComposer } from '@/ui';
import { brand, images } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';


const SKELETON_ID = 'public-service' as const;

export default function Contactpage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const location = useLocation();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const subject = queryParams.get('subject');
    if (subject) {
      setMessage(subject);
    }
  }, [location.search]);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // In a real application, you would send this data to a backend.
    console.log({ name, email, message });
    alert('Thank you for your inquiry! We will get back to you shortly.');
    setName('');
    setEmail('');
    setMessage('');
  };

  const skeleton = getSkeleton(SKELETON_ID);

  const slots = {
    hero: (
      <MarketingHero
        brandName={brand.name}
        headline="Connect with Jane Art"
        subcopy="Please use the form below for any questions regarding artworks, commissions, or collaborations. We look forward to hearing from you."
        primaryCta={{ label: 'Explore Gallery', href: '/gallery' }}
        imageSrc={images.ambient}
        imageAlt="Warm and inviting art gallery interior"
        className="text-center"
      />
    ),
    features: (
      <div className="relative isolate overflow-hidden bg-brand-background px-6 py-16 text-brand-text sm:py-24 lg:px-8">
        <div className="mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8 lg:py-16 rounded-[calc(var(--radius-ui)+0.25rem)] border border-border-subtle bg-card shadow-[var(--shadow-ui)]"
          data-appspec-evidence="contactForm">
          <h2 className="text-center font-display text-4xl leading-tight tracking-tight text-brand-primary sm:text-5xl mb-8">
            Inquire About an Artwork
          </h2>
          <form onSubmit={handleSubmit} className="mx-auto max-w-xl space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-brand-muted">
                Your Name
              </label>
              <div className="mt-1">
                <input
                  type="text"
                  name="name"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                  className="block w-full rounded-md border-brand-accent bg-brand-surface py-3 px-4 text-brand-primary placeholder:text-brand-muted focus:border-brand-primary focus:ring-brand-primary shadow-sm ring-inset ring-brand-muted/20 sm:text-sm sm:leading-6 transition-all duration-300 ease-in-out hover:border-brand-primary/70 focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-surface"
                  placeholder="Jane Doe"
                  required
                />
              </div>
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-brand-muted">
                Your Email
              </label>
              <div className="mt-1">
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  className="block w-full rounded-md border-brand-accent bg-brand-surface py-3 px-4 text-brand-primary placeholder:text-brand-muted focus:border-brand-primary focus:ring-brand-primary shadow-sm ring-inset ring-brand-muted/20 sm:text-sm sm:leading-6 transition-all duration-300 ease-in-out hover:border-brand-primary/70 focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-surface"
                  placeholder="you@example.com"
                  required
                />
              </div>
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-brand-muted">
                Your Message
              </label>
              <div className="mt-1">
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="block w-full rounded-md border-brand-accent bg-brand-surface py-3 px-4 text-brand-primary placeholder:text-brand-muted focus:border-brand-primary focus:ring-brand-primary shadow-sm ring-inset ring-brand-muted/20 sm:text-sm sm:leading-6 transition-all duration-300 ease-in-out hover:border-brand-primary/70 focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-surface"
                  placeholder="I'm interested in..."
                  required
                />
              </div>
            </div>
            <div className="pt-4">
              <Button
                type="submit"
                className="w-full bg-[color-mix(in_srgb,gold_80%,bronze)] hover:bg-[color-mix(in_srgb,gold_90%,bronze)] text-white font-medium py-3 px-6 rounded-md shadow-md hover:shadow-lg transition-all duration-300 ease-in-out"
                data-appspec-action="submitContactForm"
              >
                Send Message
              </Button>
            </div>
          </form>
        </div>
      </div>
    ),
    cta: (
      <CTABand
        heading="Discover Your Next Piece"
        description="Explore our curated collection and find the perfect artwork for your space."
        primaryCta={{ label: "View Gallery", href: "/gallery" }}
      />
    ),
    footer: (
      <BrandFooter brandName={brand.name} />
    ),
  };

  return (
    <PublicShell brandName={brand.name} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}