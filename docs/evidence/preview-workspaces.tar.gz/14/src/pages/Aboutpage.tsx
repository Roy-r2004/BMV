import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-service" as const;

export default function Aboutpage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jane Art"} headline={"About Page"} subcopy="Cinematic first impression — brand-forward, vivid, and ready for the next step." primaryCta={{ label: "Explore now", href: "#details" }} secondaryCta={{ label: "See how it works", href: "#process" }} imageSrc={images.hero} imageAlt="" />
    ),
    features: (
      <FeatureBento heading="Designed to feel alive" items={[{ title: "Immersive first view", description: "Atmosphere, motion, and brand color from the first scroll." }, { title: "Real product moments", description: "Concrete screens — bookings, tickets, KPIs — not placeholder cards." }, { title: "Guided next step", description: "Every section pushes toward a clear action." }]} />
    ),
    cta: (
      <CTABand heading="Make it unforgettable" description="Book the next chapter — polished, branded, never bland." primaryCta={{ label: "Get started", href: "#details" }} secondaryCta={{ label: "Talk to us", href: "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jane Art"} description="Premium presence from first glance to booked revenue." />
    ),
  };

  return (
    <PublicShell brandName={"Jane Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}