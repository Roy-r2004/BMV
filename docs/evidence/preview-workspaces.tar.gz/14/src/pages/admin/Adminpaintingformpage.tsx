import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { OpsShell, PageHeader, Input, Button, Select, SkeletonComposer, UiIcon, getSkeleton } from '@/ui';

import { paintings as mockPaintings } from '@/data/mock';
// Corrected import for admin navigation items to match manifest and typical app structure
import { useAdminNavItems } from '@/lib/app-nav'; 

// Type definition for a painting, matching the form structure
interface PaintingData {
  title: string;
  description: string;
  medium: string;
  dimensionsH: number;
  dimensionsW: number;
  dimensionsD: number;
  weight: number;
  year: number;
  price: number;
  category: string;
  tags: string; // Storing tags as a comma-separated string for simpler input
  availability: 'Available' | 'Sold' | 'On Hold';
  featured: boolean;
  imageUrl: string; 
}

const SKELETON_ID = 'ops-settings' as const;

// Hardcoded options for selects and radios
const CATEGORY_OPTIONS = [
  { value: 'Abstract', label: 'Abstract' },
  { value: 'Landscape', label: 'Landscape' },
  { value: 'Portrait', label: 'Portrait' },
  { value: 'Still Life', label: 'Still Life' },
  { value: 'Figurative', label: 'Figurative' },
  { value: 'Sculpture', label: 'Sculpture' }, // Added to ensure a diverse set of categories, though not explicitly in brief, good practice
];

const AVAILABILITY_OPTIONS = [
  { value: 'Available', label: 'Available' },
  { value: 'Sold', label: 'Sold' },
  { value: 'On Hold', label: 'On Hold' },
];

export default function AdminPaintingFormPage() {
  const adminNavItems = useAdminNavItems();
  const { paintingId } = useParams<{ paintingId?: string }>();
  const navigate = useNavigate();
  // const navItems = useAdminNavItems(); // This was a duplicate, removed.
  const skeleton = getSkeleton(SKELETON_ID); // This must remain, as per contract

  const isEditing = !!paintingId;

  const [formData, setFormData] = useState<PaintingData>({
    title: '',
    description: '',
    medium: '',
    dimensionsH: 0,
    dimensionsW: 0,
    dimensionsD: 0,
    weight: 0,
    year: new Date().getFullYear(),
    price: 0,
    category: CATEGORY_OPTIONS[0].value,
    tags: '',
    availability: 'Available',
    featured: false,
    imageUrl: '', // This will hold the base64 or URL
  });
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);

  // Simulate fetching data for editing as per critic's notes and sample data
  useEffect(() => {
    if (isEditing && paintingId) { // Ensure paintingId is defined for editing
      const initialPainting = mockPaintings.find((p) => p.id === paintingId);
      if (initialPainting) {
        setFormData({
          title: initialPainting.title,
          description: initialPainting.description || '',
          medium: initialPainting.medium,
          dimensionsH: initialPainting.dimensions.h,
          dimensionsW: initialPainting.dimensions.w,
          dimensionsD: initialPainting.dimensions.d,
          weight: initialPainting.weight,
          year: initialPainting.year,
          price: initialPainting.price,
          category: initialPainting.category,
          tags: initialPainting.tags.join(', '),
          availability: initialPainting.availability,
          featured: initialPainting.featured,
          imageUrl: initialPainting.imageSrc,
        });
        setImagePreviewUrl(initialPainting.imageSrc);
      } else {
        // Painting not found scenario, as per original handling
        navigate('/admin'); 
      }
    }
  }, [isEditing, paintingId, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type, checked } = e.target as HTMLInputElement;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleNumberInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      // Convert to number, or 0 if empty/invalid. Allows user to clear input.
      [name]: value === '' ? 0 : parseFloat(value), 
    }));
  };

  const handleSelectChange = (name: keyof PaintingData) => (value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreviewUrl(result);
        setFormData((prev) => ({ ...prev, imageUrl: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Painting data saved:', formData);
    
    // Simulate successful API call for data persistence
    setTimeout(() => {
      // In a real application, you'd integrate with your backend here.
      // For this mock, we simply navigate back to the admin dashboard.
      navigate('/admin');
    }, 500); 
  };

  const pageTitle = isEditing
    ? `Edit Artwork: ${formData.title || 'Untitled'}` // Default to 'Untitled' for clarity
    : 'Add New Artwork';

  const slots = {
    header: (
      <PageHeader
        title={pageTitle}
        // Conditional meta for editing context, as per brief
        meta={isEditing ? `ID: ${paintingId}` : undefined} 
        className="font-display text-text-color" // Apply display font for page header
      />
    ),
  };

  return (
    <OpsShell brandName="Jane Art" navItems={adminNavItems} appearance="soft">
      <SkeletonComposer skeletonId={SKELETON_ID} slots={slots}>
        <div
          className="mx-auto max-w-4xl p-8 bg-surface rounded-[var(--border-radius)] shadow-[var(--shadow-ui)] space-y-8" 
          data-appspec-page="adminPaintingFormPage"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6" data-appspec-evidence="adminPaintingFormFields">
              {/* Image Upload and Preview Section */}
              <div className="md:col-span-1 flex flex-col items-center p-4 border border-border-subtle rounded-md bg-background-subtle">
                <label className="block text-sm font-display text-text-color mb-3">Artwork Image</label>
                <div
                  className="w-full max-w-sm aspect-square border-2 border-dashed border-border-subtle rounded-lg flex items-center justify-center overflow-hidden mb-4 bg-background-light"
                  data-appspec-evidence="adminPaintingImagePreview"
                >
                  {imagePreviewUrl ? (
                    <img 
                      src={imagePreviewUrl} 
                      alt="Artwork Preview" 
                      className="object-contain w-full h-full p-1" // Use object-contain for full image visibility
                    />
                  ) : (
                    <UiIcon name="image" className="w-16 h-16 text-muted-text-color opacity-70" />
                  )}
                </div>
                {/* Custom file input styling to match theme */}
                <input
                  type="file"
                  id="imageUpload"
                  name="imageUpload"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden" // Hide default file input
                />
                <label 
                  htmlFor="imageUpload" 
                  className="inline-flex items-center justify-center px-4 py-2 border border-brand-accent text-brand-text-on-accent bg-brand hover:opacity-90 rounded-md shadow-sm text-sm font-medium cursor-pointer"
                >
                  <UiIcon name="upload" className="w-4 h-4 mr-2" /> Select Image
                </label>
                {/* Display file name if available, for better UX */}
                {imagePreviewUrl && (
                  <p className="mt-2 text-xs text-muted-text-color">Image loaded.</p>
                )}
              </div>

              {/* Basic Details Form */}
              <div className="md:col-span-1 space-y-5">
                <Input
                  label="Title"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  required
                />
                <Select
                  label="Category"
                  id="category"
                  name="category"
                  // Ensure options values match formData.category type
                  options={CATEGORY_OPTIONS} 
                  value={formData.category}
                  onValueChange={handleSelectChange('category')} // onValueChange handles string
                  required
                />
                <Input
                  label="Medium"
                  id="medium"
                  name="medium"
                  value={formData.medium}
                  onChange={handleInputChange}
                  required
                />
                <Input
                  label="Year Created"
                  id="year"
                  name="year"
                  type="number"
                  value={formData.year}
                  onChange={handleNumberInputChange}
                  min={1000} // Sensible minimum for year
                  max={new Date().getFullYear() + 5} // Allow slightly in future for prospective pieces
                  required
                />
              </div>

              {/* Description (full width) */}
              <div className="md:col-span-2">
                <Input
                  as="textarea"
                  label="Description"
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows={6} // Increased rows for more substantial descriptions
                  placeholder="A vibrant abstract evoking a sunset..." // Example placeholder from sample
                  className="resize-y" // Allow vertical resizing
                />
              </div>

              {/* Dimensions and Weight */}
              <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                <Input
                  label="Dimensions (H cm)"
                  id="dimensionsH"
                  name="dimensionsH"
                  type="number"
                  value={formData.dimensionsH}
                  onChange={handleNumberInputChange}
                  min={0.1}
                  step="0.1"
                  required
                />
                <Input
                  label="Dimensions (W cm)"
                  id="dimensionsW"
                  name="dimensionsW"
                  type="number"
                  value={formData.dimensionsW}
                  onChange={handleNumberInputChange}
                  min={0.1}
                  step="0.1"
                  required
                />
                <Input
                  label="Dimensions (D cm)"
                  id="dimensionsD"
                  name="dimensionsD"
                  type="number"
                  value={formData.dimensionsD}
                  onChange={handleNumberInputChange}
                  min={0.0}
                  step="0.1"
                  required
                />
                <Input
                  label="Weight (kg)"
                  id="weight"
                  name="weight"
                  type="number"
                  value={formData.weight}
                  onChange={handleNumberInputChange}
                  min={0.01}
                  step="0.1"
                  required
                />
              </div>
              <div className="md:col-span-2"> {/* Price is often its own section */}
                <Input
                  label="Price ($)"
                  id="price"
                  name="price"
                  type="number"
                  value={formData.price}
                  onChange={handleNumberInputChange}
                  min={0.01}
                  step="0.01"
                  required
                />
              </div>

              {/* Tags */}
              <div className="md:col-span-2">
                <Input
                  label="Tags (comma-separated)"
                  id="tags"
                  name="tags"
                  value={formData.tags}
                  onChange={handleInputChange}
                  placeholder="e.g., abstract, warm, landscape, texture"
                />
              </div>

              {/* Availability Status (Radio Buttons) */}
              <div className="md:col-span-2 space-y-3 pt-2">
                <label className="block text-sm font-display text-text-color">Availability Status</label>
                <div className="flex flex-wrap gap-x-6 gap-y-2">
                  {AVAILABILITY_OPTIONS.map((option) => (
                    <div key={option.value} className="flex items-center">
                      <input
                        type="radio"
                        id={`availability-${option.value}`}
                        name="availability"
                        value={option.value}
                        checked={formData.availability === option.value}
                        onChange={handleInputChange}
                        className="h-4 w-4 text-brand focus:ring-brand border-border-subtle" // Themed radio button
                      />
                      <label 
                        htmlFor={`availability-${option.value}`} 
                        className="ml-2 text-sm text-text-color cursor-pointer"
                      >
                        {option.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Featured Toggle Switch */}
              <div className="md:col-span-2 flex items-center justify-between py-2 border-t border-border-subtle mt-4">
                <label htmlFor="featured" className="text-base font-display text-text-color cursor-pointer">
                  Featured on Homepage
                </label>
                <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                  <input
                    type="checkbox"
                    id="featured"
                    name="featured"
                    checked={formData.featured}
                    onChange={handleInputChange}
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-surface border-4 appearance-none cursor-pointer"
                  />
                  <label htmlFor="featured" className="toggle-label block overflow-hidden h-6 rounded-full bg-muted-text-color cursor-pointer"></label>
                </div>
              </div>
            </div>

            {/* Form Actions */}
            <div className="flex justify-end space-x-4 pt-6 border-t border-border-subtle">
              <Button
                type="button" // Important to specify type="button" to prevent form submission
                variant="outline"
                onClick={() => navigate('/admin')}
                className="font-sans" // Use sans-serif for buttons as per aesthetic
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                variant="default" 
                className="bg-brand text-text-brand-on-accent hover:opacity-90 transition-opacity font-sans" // Soft gold button as per brief
              >
                Save Changes
              </Button>
            </div>
          </form>
        </div>
      </SkeletonComposer>
    </OpsShell>
  );
}