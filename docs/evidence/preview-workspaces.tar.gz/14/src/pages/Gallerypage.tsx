import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { PublicShell, Button, Select, ProductShowcase, BrandFooter, MarketingHero, SkeletonComposer, getSkeleton, PublicNav } from '@/ui';
import { images, brand } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav'; // Assuming these are valid imports


const SKELETON_ID = 'public-catalog' as const;
const skeleton = getSkeleton(SKELETON_ID);

// Type definitions for paintings based on business context
interface Painting {
  id: string;
  title: string;
  category: string;
  availability: 'Available' | 'Sold' | 'On Hold';
  medium: string;
  year: number;
  price: number;
  imageSrc: string;
}

// Sample data as per business context and critic notes
const allPaintings: Painting[] = [
  {
    id: '1',
    title: 'Crimson Tide',
    category: 'Abstract',
    availability: 'Available',
    medium: 'Oil on Wood Panel',
    year: 2021,
    price: 7500,
    imageSrc: images.card1,
  },
  {
    id: '2',
    title: 'Urban Glow',
    category: 'Figurative',
    availability: 'Available',
    medium: 'Acrylic on Canvas',
    year: 2023,
    price: 4200,
    imageSrc: images.card2,
  },
  {
    id: '3',
    title: 'Serene Vista',
    category: 'Landscape',
    availability: 'Sold',
    medium: 'Watercolor on Paper',
    year: 2020,
    price: 3800,
    imageSrc: images.ambient,
  },
  {
    id: '4',
    title: 'Midnight Bloom',
    category: 'Portrait',
    availability: 'On Hold',
    medium: 'Mixed Media on Board',
    year: 2022,
    price: 5100,
    imageSrc: images.card3,
  },
  {
    id: '5',
    title: 'Whispering Willows',
    category: 'Landscape',
    availability: 'Available',
    medium: 'Oil on Canvas',
    year: 2022,
    price: 6300,
    imageSrc: images.hero, // Using provided Unsplash images
  },
  {
    id: '6',
    title: 'Azure Dream',
    category: 'Abstract',
    availability: 'Available',
    medium: 'Acrylic on Linen',
    year: 2023,
    price: 3900,
    imageSrc: images.hero2, // Using provided Unsplash images
  },
  {
    id: '7',
    title: 'Golden Hour',
    category: 'Figurative',
    availability: 'Sold',
    medium: 'Pastel on Paper',
    year: 2019,
    price: 2700,
    imageSrc: images.card1,
  },
  {
    id: '8',
    title: 'Echoes of Time',
    category: 'Portrait',
    availability: 'Available',
    medium: 'Charcoal on Paper',
    year: 2021,
    price: 3100,
    imageSrc: images.card3,
  },
];

// Options for filter and sort controls
const categoryOptions = [
  { value: 'All', label: 'All Categories' },
  { value: 'Abstract', label: 'Abstract' },
  { value: 'Figurative', label: 'Figurative' },
  { value: 'Landscape', label: 'Landscape' },
  { value: 'Portrait', label: 'Portrait' },
];

const availabilityOptions = [
  { value: 'All', label: 'All Statuses' },
  { value: 'Available', label: 'Available' },
  { value: 'Sold', label: 'Sold' },
  { value: 'On Hold', label: 'On Hold' },
];

const sortOptions = [
  { value: 'year-desc', label: 'Year (Newest)' },
  { value: 'year-asc', label: 'Year (Oldest)' },
  { value: 'price-asc', label: 'Price (Low to High)' },
  { value: 'price-desc', label: 'Price (High to Low)' },
];

// ArtworkCard component, restyled and animated as per critic notes
function ArtworkCard({ painting }: { painting: Painting }) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/gallery/v2?id=${painting.id}`); // Correct navigation path
  };

  return (
    <div
      className="group relative cursor-pointer overflow-hidden rounded-lg shadow-sm transition-all duration-300 ease-in-out hover:shadow-md border border-brand-accent/20 hover:border-brand-accent focus:outline-none focus:ring-2 focus:ring-brand-accent focus:ring-offset-2"
      onClick={handleClick}
    >
      <img
        src={painting.imageSrc}
        alt={painting.title}
        className="h-full w-full object-cover object-center max-h-96"
      />
      {/* Default display */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-brand-surface/90 to-transparent p-4 text-brand-text transition-opacity duration-300 ease-in-out group-hover:opacity-0">
        <h3 className="font-display text-lg font-semibold">{painting.title}</h3>
        <p className="font-sans text-sm text-brand-muted mt-1">{painting.price.toLocaleString('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 })}</p>
      </div>
      {/* Hover overlay with gold accent */}
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-brand-accent/80 p-4 text-white opacity-0 transition-opacity duration-300 ease-in-out group-hover:opacity-100">
        <h3 className="font-display text-xl font-semibold mb-2">{painting.title}</h3>
        <p className="font-sans text-md">{painting.medium}</p>
        <p className="font-sans text-md">{painting.year}</p>
      </div>
    </div>
  );
}

export default function GalleryPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const location = useLocation();

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedAvailability, setSelectedAvailability] = useState('All');
  const [selectedSort, setSelectedSort] = useState('year-desc');

  // Highlight active nav item
  useEffect(() => {
    // This is a placeholder for actual active state logic if PublicNav supports it.
    // In a real app, PublicNav would likely handle active state internally based on current path.
    // For this exercise, we assume `usePublicNavItems` provides items that can be matched.
  }, [location.pathname]);

  const filteredAndSortedPaintings = useMemo(() => {
    let filtered = allPaintings.filter((p) => {
      const categoryMatch = selectedCategory === 'All' || p.category === selectedCategory;
      const availabilityMatch = selectedAvailability === 'All' || p.availability === selectedAvailability;
      return categoryMatch && availabilityMatch;
    });

    switch (selectedSort) {
      case 'year-asc':
        filtered.sort((a, b) => a.year - b.year);
        break;
      case 'year-desc':
        filtered.sort((a, b) => b.year - a.year);
        break;
      case 'price-asc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      default:
        break;
    }
    return filtered;
  }, [selectedCategory, selectedAvailability, selectedSort]);

  // Map into skeleton slots as per requirements and critic notes
  const slots = {
    hero: (
      // Compact hero for Gallery page with elegant serif typography
      <MarketingHero
        brandName={brand.name}
        headline="Our Collection"
        subcopy="A curated selection of unique original paintings, each with its own story and charm, awaiting discovery."
        primaryCta={{ href: '#collection-grid', label: 'Explore Artworks' }}
        imageSrc={images.hero2} // Using an appropriate image from provided URLs
        imageAlt="An elegantly lit art gallery featuring a captivating painting."
        className="py-24 lg:py-32 bg-brand-background text-brand-text" // Use compact variant for a page-specific hero
      />
    ),
    showcase: (
      <ProductShowcase
        heading="Curated Canvas"
        description="Refine your search with the filter and sort options below."
        className="py-16 lg:py-24 bg-brand-background text-brand-text " // Applying beige/cream base
      >
        <div className="mx-auto max-w-7xl px-6 lg:px-8 space-y-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            {/* Category Filter */}
            <div className="flex items-center gap-2">
              <label htmlFor="category-select" className="font-sans text-sm text-brand-text/80">Category:</label>
              <Select
                id="category-select"
                options={categoryOptions}
                value={selectedCategory}
                onValueChange={setSelectedCategory}
                className="w-48 [&>trigger]:bg-brand-surface [&>trigger]:border-brand-accent/50 [&>trigger]:text-brand-text [&>trigger]:hover:bg-brand-accent/10 [&>trigger]:data-[state=open]:bg-brand-accent/10"
              />
            </div>

            {/* Availability Filter */}
            <div className="flex items-center gap-2">
              <label htmlFor="availability-select" className="font-sans text-sm text-brand-text/80">Status:</label>
              <Select
                id="availability-select"
                options={availabilityOptions}
                value={selectedAvailability}
                onValueChange={setSelectedAvailability}
                className="w-48 [&>trigger]:bg-brand-surface [&>trigger]:border-brand-accent/50 [&>trigger]:text-brand-text [&>trigger]:hover:bg-brand-accent/10 [&>trigger]:data-[state=open]:bg-brand-accent/10"
              />
            </div>

            {/* Sort Control */}
            <div className="flex items-center gap-2 ml-auto">
              <label htmlFor="sort-select" className="font-sans text-sm text-brand-text/80">Sort By:</label>
              <Select
                id="sort-select"
                options={sortOptions}
                value={selectedSort}
                onValueChange={setSelectedSort}
                className="w-48 [&>trigger]:bg-brand-surface [&>trigger]:border-brand-accent/50 [&>trigger]:text-brand-text [&>trigger]:hover:bg-brand-accent/10 [&>trigger]:data-[state=open]:bg-brand-accent/10"
              />
            </div>
          </div>
          {filteredAndSortedPaintings.length === 0 ? (
            <div className="py-16 text-center text-xl font-display text-brand-muted">
              No artworks match your selected criteria.
            </div>
          ) : (
            <ul
              id="collection-grid"
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 scroll-mt-24"
            >
              {filteredAndSortedPaintings.map((painting) => (
                <ArtworkCard key={painting.id} painting={painting} />
              ))}
            </ul>
          )}
        </div>
      </ProductShowcase>
    ),
    footer: (
      // Updated footer as per critic notes
      <BrandFooter
        brandName={brand.name}
        description={`© ${new Date().getFullYear()} Aura Gallery. All rights reserved.`}
        links={[
          { href: '/privacy', label: 'Privacy Policy' },
          { href: '/terms', label: 'Terms of Service' },
        ]}
        className="bg-brand-surface text-brand-muted_text"
      />
    ),
  };

  return (
    <PublicShell 
      brandName={brand.name} 
      nav={<PublicNav items={navItems} cta={navCta} />}
      className="bg-brand-background" // Apply general textured background to the shell
    >
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}