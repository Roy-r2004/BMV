import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutPage from './pages/AboutPage';
import AdminAddEditPaintingPage from './pages/admin/AdminAddEditPaintingPage';
import AdminEditPaintingPage from './pages/admin/AdminEditPaintingPage';
import AdminLoginPage from './pages/admin/AdminLoginPage';
import AdminPaintingsPage from './pages/admin/AdminPaintingsPage';
import ContactPage from './pages/ContactPage';
import GalleryPage from './pages/GalleryPage';
import HomePage from './pages/HomePage';
import PaintingDetailPage from './pages/PaintingDetailPage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/painting/:slug" element={<PaintingDetailPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/admin" element={<AdminPaintingsPage />} />
          <Route path="/admin/painting/add" element={<AdminAddEditPaintingPage />} />
          <Route path="/admin/painting/edit/:id" element={<AdminEditPaintingPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}