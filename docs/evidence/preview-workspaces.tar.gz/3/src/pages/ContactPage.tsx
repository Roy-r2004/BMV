// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-service" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"JaneArt"} headline={"JaneArt Gallery - Contact"} subcopy="A clear, considered experience built around your next step." primaryCta={{ label: "Get started", href: "#details" }} imageSrc={images.hero} imageAlt="" />
    ),
    features: (
      <FeatureBento heading="What you can expect" items={[{ title: "Simple planning", description: "Everything needed to make a confident choice." }, { title: "Thoughtful service", description: "A consistent experience from first visit to follow-up." }]} />
    ),
    cta: (
      <CTABand heading="Ready for the next step?" primaryCta={{ label: "Get started", href: "#details" }} />
    ),
    footer: (
      <BrandFooter brandName={"JaneArt"} description="Thoughtful service, clearly delivered." />
    ),
  };

  return (
    <PublicShell brandName={"JaneArt"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
