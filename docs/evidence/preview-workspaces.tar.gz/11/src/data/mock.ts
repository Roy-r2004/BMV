export const brand = {"name": "Jane Art", "tagline": "", "design_system": {"primary_color": "#0f766e", "secondary_color": "#0369a1", "background_color": "#f8fafc", "surface_color": "#ffffff", "text_color": "#042f2e", "muted_text_color": "#5f7a78", "font_family": "Source Sans 3", "display_font_family": "Fraunces", "font_import_url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap", "font_sans": "\"Source Sans 3\", \"Segoe UI\", sans-serif", "font_display": "\"Fraunces\", Georgia, serif", "brand_locked": true, "brand_brief_version": "1.0", "mood": "modern", "voice": "Warm, grounded, unhurried. Speak like a trusted studio host.", "signature": "A calm full-bleed atmosphere with Jane Art as the hero signal, not a card grid.", "avoid": ["purple-on-white or purple-to-indigo default themes", "Inter / Roboto / Arial as the display face", "card grids in the hero", "generic SaaS marketing copy", "inventing a second palette per page"], "rules": ["Every page inherits this palette and type stack via CSS tokens only.", "Use bg-brand / text-brand / font-display — never hardcode hex colors.", "First viewport must feature the brand name as a hero-level signal."], "recipe_id": "editorial", "hub_variant": "marketing", "hero_variant": "cinematic", "feature_variant": "alternating", "recipe_prompt": "RECIPE editorial: generous whitespace, serif/display headlines via font-display, fewer cards, longer subcopy, cinematic imagery, avoid dense tables on public pages.", "style_keywords": "Editorial", "border_radius": "0.35rem"}};

export const images = {
  "hero": "https://images.unsplash.com/photo-1553877522-43269d4ea984?w=1400&q=80&fit=crop&auto=format",
  "hero2": "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=1400&q=80&fit=crop&auto=format",
  "card1": "https://images.unsplash.com/photo-1497366216548-37526070297c?w=700&q=80&fit=crop&auto=format",
  "card2": "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=700&q=80&fit=crop&auto=format",
  "card3": "https://images.unsplash.com/photo-1552664730-d307ca884978?w=700&q=80&fit=crop&auto=format",
  "ambient": "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=900&q=80&fit=crop&auto=format"
};

export const roles = [
  {
    "id": "ROLE-PUBLIC-VISITOR",
    "label": "Public Visitor",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "ROLE-GALLERY-OWNER",
    "label": "Gallery Owner",
    "defaultPath": "/admin",
    "icon": "users"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home Page"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery Page"
    },
    {
      "id": "gallery-v2",
      "path": "/gallery/v2",
      "href": "/gallery/v2",
      "label": "Painting Detail Page"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Page"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    }
  ],
  "admin": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login Page"
    },
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-painting",
      "path": "/admin/painting",
      "href": "/admin/painting",
      "label": "Painting"
    }
  ],
  "ROLE-PUBLIC-VISITOR": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home Page"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery Page"
    },
    {
      "id": "gallery-v2",
      "path": "/gallery/v2",
      "href": "/gallery/v2",
      "label": "Painting Detail Page"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Page"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    }
  ],
  "ROLE-GALLERY-OWNER": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login Page"
    },
    {
      "id": "admin",
      "path": "/admin",
      "href": "/admin",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-painting",
      "path": "/admin/painting",
      "href": "/admin/painting",
      "label": "Painting"
    }
  ]
};
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
