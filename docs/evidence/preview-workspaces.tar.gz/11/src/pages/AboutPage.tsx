// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProductShowcase, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-detail" as const;

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jane Art"} headline={"About Page"} subcopy="A clear, considered experience built around your next step." primaryCta={{ label: "Get started", href: "#details" }} imageSrc={images.hero} imageAlt="" />
    ),
    showcase: (
      <ProductShowcase heading="Featured experiences" items={[{ title: "Signature service", description: "A dependable starting point.", imageSrc: images.card1, imageAlt: "" }, { title: "Everyday essential", description: "Built for daily use.", imageSrc: images.card2, imageAlt: "" }]} />
    ),
    cta: (
      <CTABand heading="Ready for the next step?" primaryCta={{ label: "Get started", href: "#details" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jane Art"} description="Thoughtful service, clearly delivered." />
    ),
  };

  return (
    <PublicShell brandName={"Jane Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
