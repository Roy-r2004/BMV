export const BRAND_MANIFEST = {
  design_system: {
    primary_color: '#0f172a',
    secondary_color: '#0369a1',
    background_color: '#f8fafc',
    surface_color: '#ffffff',
    text_color: '#042f2e',
    muted_text_color: '#5f7a78',
    font_family: 'Source Sans 3',
    display_font_family: 'Fraunces',
    font_import_url:
      'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap',
    font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
    font_display: '"Fraunces", Georgia, serif',
    brand_locked: true,
    brand_brief_version: '1.0',
    mood: 'modern',
    voice: 'Warm, grounded, unhurried. Speak like a trusted studio host.',
    signature: 'A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.',
    avoid: [
      'purple-on-white or purple-to-indigo default themes',
      'Inter / Roboto / Arial as the display face',
      'card grids in the hero',
      'generic SaaS marketing copy',
      'inventing a second palette per page',
    ],
    rules: [
      'Every page inherits this palette and type stack via CSS tokens only.',
      'Use bg-brand / text-brand / font-display — never hardcode hex colors.',
      'First viewport must feature the brand name as a hero-level signal.',
    ],
    recipe_id: 'editorial',
    hub_variant: 'marketing',
    hero_variant: 'editorial',
    feature_variant: 'alternating',
    recipe_prompt:
      'RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.',
    style_keywords: 'Editorial · Soft glass',
    border_radius: '0.63rem',
    design_overlay_id: 'soft_glass',
    design_overlay_label: 'Soft glass',
    design_overlay_blurb: 'Modern product glass — translucent cards, medium radius, brand wash.',
    density: 'comfortable',
    token_overrides: {
      radius_ui: '0.63rem',
      bg_mix: '7%',
      fg_mix: '40%',
      muted_mix: '32%',
      border_mix: '16%',
      shadow: '0 22px 48px -32px',
      shadow_alpha: '34%',
      glow: '13%',
      card: '#ffffff',
      atmosphere:
        'radial-gradient(90% 60% at 0% 0%, color-mix(in srgb, var(--color-brand) 16%, transparent), transparent 55%), radial-gradient(55% 45% at 100% 0%, color-mix(in srgb, var(--color-accent) 12%, transparent), transparent 50%), linear-gradient(165deg, color-mix(in srgb, var(--color-brand) 8%, #f4f6f8), #f7f8fa 55%, #eef1f5)',
    },
    font_import:
      'Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700',
    design_brief_version: '1.0',
    design_brief_sealed: true,
  },
  design_direction:
    'A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid. · Editorial: Gallery pacing, large display type, airy whitespace, soft surfaces. · Soft glass: Modern product glass — translucent cards, medium radius, brand wash. · Product kind storefront/storefront: Storefront — public marketing home is the product surface.',
  public_direction:
    "The public-facing experience will be art-first, with a focus on high-resolution imagery, ample whitespace, and elegant typography. Interactions will be subtle and intuitive, guiding collectors towards discovering art and making inquiries without visual clutter or distraction.",
  ops_direction:
    "The operator experience will be straightforward and efficient, designed to simplify the management of artwork and artist information. The visual design will be clean and functional, prioritizing clarity and ease of use over complex dashboards for the non-transactional nature of the business.",
  consistency_rules: [
    'All imagery must be high-resolution and consistently styled.',
    "Whitespace ratio should be consciously maintained across all pages to ensure artwork 'breathes'.",
    'Typography (primarily Montserrat, with Fraunces for select display elements) must be used consistently for hierarchy and readability.',
    'Interactive elements should respond subtly without jarring animations.',
    "Brand name 'Jeanne Kassab Art' or monogram should always be present but understated.",
    'WhatsApp icon and associated interaction should be identical wherever it appears.',
    'Every page inherits this palette and type stack via CSS tokens only.',
    'Use bg-brand / text-brand / font-display — never hardcode hex colors.',
    'First viewport must feature the brand name as a hero-level signal.',
  ],
  public_seed: {
    hero: {
      headline: 'Capturing Light and Landscape on Canvas',
      subcopy: "Explore Jeanne Kassab's collection of original abstract landscapes and layered oil paintings.",
      primaryCta: {
        label: 'View the Collection',
        href: '/gallery',
      },
      secondaryCta: {
        label: 'About the Artist',
        href: '/about',
      },
    },
    services: [
      {
        title: 'Abstract Landscapes',
        description: 'Discover evocative oil paintings that reinterpret natural vistas with sweeping color and texture.',
      },
      {
        title: 'Layered Oils',
        description: 'Delve into canvases built with rich, multi-dimensional oil applications, creating depth and intrigue.',
      },
      {
        title: 'Original Commissions',
        description: 'Connect with Jeanne to discuss a unique piece tailored to your vision and space.',
      },
    ],
    features: [],
    process: [
      {
        title: 'Browse the Gallery',
        description: 'Explore available original oil paintings, each with its unique story.',
      },
      {
        title: 'Inquire Directly',
        description: 'Found a piece you love? Reach out via WhatsApp for details and acquisition.',
      },
      {
        title: 'Welcome it Home',
        description: 'Secure your unique artwork and bring a piece of original art into your space.',
      },
    ],
    testimonials: [
      {
        quote: "Jeanne's work transformed our living space. The colors are even more vibrant in person.",
        author: 'Elara V.',
        role: 'Collector',
      },
      {
        quote: 'Working with Jeanne to select a piece for a client was seamless. The website clearly presented her beautiful art.',
        author: 'Marcus G.',
        role: 'Interior Designer',
      },
    ],
    credentials: [
      {
        title: "Solo Exhibition: 'Horizons Unseen'",
        detail: 'The Gallery, Spring 2023',
      },
      {
        title: "Selected for 'Emerging Artists Showcase'",
        detail: 'Art Collective, Autumn 2022',
      },
    ],
    trustLabels: [],
  },
  ops_seed: {
    hero: {
      headline: 'Your Canvas Curator Studio',
      subcopy: 'Manage your online gallery and connect with collectors effortlessly.',
    },
    kpis: [
      {
        label: 'New Inquiries (Today)',
        value: '2',
        delta: '+1',
        hint: 'Via WhatsApp',
      },
      {
        label: 'Active Listings',
        value: '18',
        delta: '-1',
        hint: 'Published paintings',
      },
      {
        label: 'Draft Paintings',
        value: '3',
        delta: '+1',
        hint: 'Unpublished works',
      },
    ],
    items: [
      {
        title: "Painting: 'Coastal Dreams'",
        description: 'Ready for publication',
      },
      {
        title: "Inquiry: 'Whispering Winds'",
        description: 'New WhatsApp message',
      },
    ],
    activity: [
      {
        title: "Published 'Crimson Sunset'",
        detail: 'Available in Gallery',
        when: '2 min ago',
      },
      {
        title: "New inquiry for 'Echoes of Dawn'",
        detail: 'Via WhatsApp',
        when: '15 min ago',
      },
      {
        title: "Updated 'About' page content",
        detail: 'Bio revised',
        when: '1 hour ago',
      },
    ],
    risk: [],
  },
  feature_coverage: [
    {
      feature: 'Homepage Gallery',
      role_id: 'customer',
      page_id: 'gallery-home',
      ui_element: 'Responsive grid of high-resolution painting thumbnails',
    },
    {
      feature: 'Individual Artwork Pages',
      role_id: 'customer',
      page_id: 'artwork-detail',
      ui_element: 'Dedicated page with large image, details, and inquiry CTA',
    },
    {
      feature: 'WhatsApp Direct Link',
      role_id: 'customer',
      page_id: 'artwork-detail',
      ui_element: "Floating 'Inquire via WhatsApp' button pre-populating with painting title",
    },
    {
      feature: 'Artist Bio Page',
      role_id: 'customer',
      page_id: 'about-jeanne',
      ui_element: "Dedicated 'About Jeanne Kassab' page with biography and philosophy",
    },
    {
      feature: 'Simple Navigation',
      role_id: 'customer',
      page_id: 'gallery-home',
      ui_element: 'Clean top-level navigation: Gallery, About, Contact',
    },
    {
      feature: 'Content Management System (CMS)',
      role_id: 'artist',
      page_id: 'admin-painting-list',
      ui_element: "Admin panel to 'Add New Painting' or 'Edit' existing ones",
    },
    {
      feature: 'Content Management System (CMS)',
      role_id: 'artist',
      page_id: 'admin-edit-painting',
      ui_element: 'Form fields for painting title, description, medium, dimensions, image upload',
    },
    {
      feature: 'Content Management System (CMS)',
      role_id: 'artist',
      page_id: 'admin-about',
      ui_element: "Text editor for updating Jeanne Kassab's biography",
    },
    {
      feature: 'Mobile Responsiveness',
      role_id: 'customer',
      page_id: 'gallery-home',
      ui_element: 'Gallery grid and artwork details adapt to mobile screen sizes (Mobile View Demo)',
    },
    {
      feature: 'Mobile Responsiveness',
      role_id: 'customer',
      page_id: 'artwork-detail',
      ui_element: 'Image and text reflow on mobile device (Mobile View Demo)',
    },
    {
      feature: 'Live Gallery Demo',
      role_id: 'customer',
      page_id: 'gallery-home',
      ui_element: 'Simulated responsive grid populated with example artworks (Preview Feature)',
    },
    {
      feature: 'Interactive Artwork Page',
      role_id: 'customer',
      page_id: 'artwork-detail',
      ui_element: 'Clickable artwork thumbnail leading to a detailed product page with large image (Preview Feature)',
    },
    {
      feature: 'WhatsApp Inquiry Simulation',
      role_id: 'customer',
      page_id: 'artwork-detail',
      ui_element: 'Functioning \'Inquire via WhatsApp\' button that simulates message pre-population (Preview Feature)',
    },
    {
      feature: 'Admin Panel Walkthrough',
      role_id: 'artist',
      page_id: 'admin-dashboard',
      ui_element: 'Dashboard overview with KPI cards and recent activity (Preview Feature)',
    },
    {
      feature: 'Admin Panel Walkthrough',
      role_id: 'artist',
      page_id: 'admin-painting-list',
      ui_element: "List of paintings with 'Add New' and 'Edit' options (Preview Feature)",
    },
    {
      feature: 'Admin Panel Walkthrough',
      role_id: 'artist',
      page_id: 'admin-edit-painting',
      ui_element: 'Form fields for editing a painting with image upload (Preview Feature)',
    },
  ],
  roles: [
    {
      id: 'customer',
      label: 'Collector & Visitor',
      tagline: 'Discovering original art and connecting with the artist.',
      icon: 'users',
      navigation: {
        type: 'top_nav',
        links: [],
      },
    },
  ],
};

export const brand = {
  name: 'Jeanne Kassab Art',
  tagline: 'Discover original oil paintings that evoke abstract landscapes and layered beauty.',
  accent: '#0f172a',
  accent_dark: '#0c121e',
  accent_light: '#e6e7ea',
  font: 'Source Sans 3',
  services: [
    {
      name: 'Original Oil Paintings',
      description: 'Explore and acquire unique abstract landscapes and layered oil paintings.',
      duration: 'Evergreen collection',
      badge: 'Available to Collect',
    },
    {
      name: 'Art Commissions',
      description: 'Collaborate on a custom original piece tailored to your vision.',
      duration: 'Project-based',
      badge: 'By Inquiry',
    },
    {
      name: 'Gallery Viewing',
      description: 'Experience the vibrant details of each painting in a curated online environment.',
      duration: 'Online Access',
      badge: 'Always Open',
    },
  ],
  owner_name: 'Jeanne',
  client_names: ['Sarah Chen', 'Michael Davis', 'Eleanor Vance', 'Thomas Rivington', 'Anya Sharma', 'David Geller'],
  testimonials: [
    {
      name: 'Sarah Chen',
      initials: 'SC',
      text: "Jeanne's artwork truly transforms a space. The abstract landscapes are breathtaking and bring such calm.",
      service: 'Original Oil Painting',
    },
    {
      name: 'Michael Davis',
      initials: 'MD',
      text: 'The online gallery beautifully showcases the texture and depth of the layered oils. It felt like I was in a physical gallery.',
      service: 'Gallery Browsing',
    },
    {
      name: 'Eleanor Vance',
      initials: 'EV',
      text: 'Acquiring a piece was seamless. The communication through WhatsApp ensured a personal and direct experience with Jeanne.',
      service: 'Artwork Inquiry',
    },
  ],
  social_proof: 'Collected in homes and curated spaces across 3 continents.',
  design_system: BRAND_MANIFEST.design_system,
  design_brief: {
    version: '1.0',
    sealed: true,
    brand_name: 'Jeanne Kassab Art',
    brand_locked: true,
    recipe_id: 'editorial',
    recipe_label: 'Editorial',
    recipe_blurb: 'Gallery pacing, large display type, airy whitespace, soft surfaces.',
    recipe_prompt:
      'RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.',
    hub_variant: 'marketing',
    hero_variant: 'editorial',
    feature_variant: 'alternating',
    product_kind: 'storefront',
    product_subtype: 'storefront',
    product_kind_note: 'Storefront — public marketing home is the product surface.',
    industry_template_id: 'art-gallery-portfolio-home',
    ops_template_id: null,
    template_prompt: null,
    ops_template_prompt: null,
    overlay_id: 'soft_glass',
    overlay_label: 'Soft glass',
    overlay_blurb: 'Modern product glass — translucent cards, medium radius, brand wash.',
    density: 'comfortable',
    mood: 'modern',
    voice: 'Warm, grounded, unhurried. Speak like a trusted studio host.',
    signature: 'A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.',
    palette: {
      primary: '#0f172a',
      secondary: '#0369a1',
      background: '#f8fafc',
      surface: '#ffffff',
      text: '#042f2e',
      muted: '#5f7a78',
    },
    typography: {
      font_family: 'Source Sans 3',
      display_font_family: 'Fraunces',
      font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
      font_display: '"Fraunces", Georgia, serif',
      font_import:
        'Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700',
      font_import_url:
        'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap',
    },
    token_overrides: {
      radius_ui: '0.63rem',
      bg_mix: '7%',
      fg_mix: '40%',
      muted_mix: '32%',
      border_mix: '16%',
      shadow: '0 22px 48px -32px',
      shadow_alpha: '34%',
      glow: '13%',
      card: '#ffffff',
      atmosphere:
        'radial-gradient(90% 60% at 0% 0%, color-mix(in srgb, var(--color-brand) 16%, transparent), transparent 55%), radial-gradient(55% 45% at 100% 0%, color-mix(in srgb, var(--color-accent) 12%, transparent), transparent 50%), linear-gradient(165deg, color-mix(in srgb, var(--color-brand) 8%, #f4f6f8), #f7f8fa 55%, #eef1f5)',
    },
    border_radius: '0.63rem',
    section_order: ['hero', 'showcase', 'features', 'process', 'credentials', 'testimonials', 'cta', 'footer'],
    avoid: [
      'purple-on-white or purple-to-indigo default themes',
      'Inter / Roboto / Arial as the display face',
      'card grids in the hero',
      'generic SaaS marketing copy',
      'inventing a second palette per page',
    ],
    rules: [
      'Every page inherits this palette and type stack via CSS tokens only.',
      'Use bg-brand / text-brand / font-display — never hardcode hex colors.',
      'First viewport must feature the brand name as a hero-level signal.',
    ],
    style_keywords: 'Editorial · Soft glass',
    direction:
      'A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid. · Editorial: Gallery pacing, large display type, airy whitespace, soft surfaces. · Soft glass: Modern product glass — translucent cards, medium radius, brand wash. · Product kind storefront/storefront: Storefront — public marketing home is the product surface.',
  },

  design_system: {"primary_color": "#0f172a", "secondary_color": "#0369a1", "accent": "#0f172a", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
};

export const images = {
  "hero": "https://images.pexels.com/photos/36733374/pexels-photo-36733374.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/32350937/pexels-photo-32350937.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/6109089/pexels-photo-6109089.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/16037029/pexels-photo-16037029.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/36715330/pexels-photo-36715330.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/7037476/pexels-photo-7037476.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const roles = [
  {
    "id": "customer",
    "label": "Collector & Visitor",
    "defaultPath": "/gallery",
    "icon": "users"
  },
  {
    "id": "artist",
    "label": "Artist (Jeanne Kassab)",
    "defaultPath": "/owner/dashboard",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    }
  ],
  "admin": [
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-paintings",
      "path": "/owner/paintings",
      "href": "/owner/paintings",
      "label": "Paintings"
    },
    {
      "id": "owner-paintings-add",
      "path": "/owner/paintings/add",
      "href": "/owner/paintings/add",
      "label": "Add"
    },
    {
      "id": "owner-about",
      "path": "/owner/about",
      "href": "/owner/about",
      "label": "About"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    }
  ],
  "artist": [
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-paintings",
      "path": "/owner/paintings",
      "href": "/owner/paintings",
      "label": "Paintings"
    },
    {
      "id": "owner-paintings-add",
      "path": "/owner/paintings/add",
      "href": "/owner/paintings/add",
      "label": "Add"
    },
    {
      "id": "owner-about",
      "path": "/owner/about",
      "href": "/owner/about",
      "label": "About"
    }
  ]
};

export const seed = {
  hero: {
    headline: 'Capturing Light and Landscape on Canvas',
    subcopy: "Explore Jeanne Kassab's collection of original abstract landscapes and layered oil paintings.",
    primaryCta: {
      label: 'View the Collection',
      href: '/gallery',
    },
    secondaryCta: {
      label: 'About the Artist',
      href: '/about',
    },
  },
  services: [
    {
      title: 'Abstract Landscapes',
      description: 'Discover evocative oil paintings that reinterpret natural vistas with sweeping color and texture.',
    },
    {
      title: 'Layered Oils',
      description: 'Delve into canvases built with rich, multi-dimensional oil applications, creating depth and intrigue.',
    },
    {
      title: 'Original Commissions',
      description: 'Connect with Jeanne to discuss a unique piece tailored to your vision and space.',
    },
  ],
  features: [
    {
      title: 'Curated Collections',
      description: 'Browse distinctive series, each telling its own visual story through paint.',
    },
    {
      title: 'Personalized Inquiries',
      description: 'Connect directly for details, commissions, or to arrange a viewing.',
    },
    {
      title: 'Secure Acquisition',
      description: 'A seamless process for collecting original art, from inquiry to installation.',
    },
  ],
  process: [
    {
      title: 'Browse the Gallery',
      description: 'Explore available original oil paintings, each with its unique story.',
    },
    {
      title: 'Inquire Directly',
      description: 'Found a piece you love? Reach out via WhatsApp for details and acquisition.',
    },
    {
      title: 'Welcome it Home',
      description: 'Secure your unique artwork and bring a piece of original art into your space.',
    },
  ],
  testimonials: [
    {
      quote: "Jeanne's work transformed our living space. The colors are even more vibrant in person.",
      author: 'Elara V.',
      role: 'Collector',
    },
    {
      quote: 'Working with Jeanne to select a piece for a client was seamless. The website clearly presented her beautiful art.',
      author: 'Marcus G.',
      role: 'Interior Designer',
    },
    {
      quote: "Jeanne's art brings a profound tranquility and vibrant energy to my home. Each piece is a conversation starter.",
      author: 'Anya Sharma',
      role: 'Collector',
    },
  ],
  testimonialsHeading: `From Collectors and Visitors`,
  credentials: [
    {
      title: "Solo Exhibition: 'Horizons Unseen'",
      detail: 'The Gallery, Spring 2023',
    },
    {
      title: "Selected for 'Emerging Artists Showcase'",
      detail: 'Art Collective, Autumn 2022',
    },
  ],
  trustLabels: [
    { label: 'Featured in Art Monthly' },
    { label: 'Collected by Private Galleries' },
    { label: 'Award for Abstract Landscape' },
  ],
  showcaseHeading: 'Featured Works in the Gallery',
  items: [
    {
      id: 'whispering-winds',
      slug: 'whispering-winds',
      title: 'Whispering Winds',
      description: 'Dynamic abstract landscape capturing the movement of air and light.',
      medium: 'Oil on Canvas',
      dimensions: '36 x 48 inches',
      price: '$2,800',
      status: 'Available',
      category: 'Abstract Landscapes',
      badge: 'New Arrival',
    },
    {
      id: 'coastal-echoes',
      slug: 'coastal-echoes',
      title: 'Coastal Echoes',
      description: 'Layers of oil bring to life the tranquil memory of the sea and sky.',
      medium: 'Oil on Panel',
      dimensions: '30 x 40 inches',
      price: '$2,500',
      status: 'Available',
      category: 'Layered Oils',
      badge: 'Available',
    },
    {
      id: 'crimson-sunset',
      slug: 'crimson-sunset',
      title: 'Crimson Sunset',
      description: 'Vibrant impasto textures evoking a warm evening sky over a distant horizon.',
      medium: 'Oil on Linen',
      dimensions: '24 x 36 inches',
      price: '$2,200',
      status: 'Available',
      category: 'Abstract Landscapes',
      badge: 'Collection Piece',
    },
    {
      id: 'urban-geometry',
      slug: 'urban-geometry',
      title: 'Urban Geometry',
      description: 'Bold lines and structured forms in a cityscape abstraction, exploring modern environments.',
      medium: 'Oil on Canvas',
      dimensions: '40 x 30 inches',
      price: '$3,100',
      status: 'Sold',
      category: 'Abstract Landscapes',
      badge: 'Sold',
    },
    {
      id: 'forest-depths',
      slug: 'forest-depths',
      title: 'Forest Depths',
      description: 'Dark, rich hues exploring the mystery and quietude of deep woods.',
      medium: 'Oil on Panel',
      dimensions: '20 x 20 inches',
      price: '$1,800',
      status: 'Available',
      category: 'Layered Oils',
      badge: '',
    },
    {
      id: 'desert-bloom',
      slug: 'desert-bloom',
      title: 'Desert Bloom',
      description: 'Subtle colors hinting at the resilient life in arid landscapes.',
      medium: 'Oil on Linen',
      dimensions: '18 x 24 inches',
      price: '$1,600',
      status: 'Available',
      category: 'Abstract Landscapes',
      badge: 'New Arrival',
    },
    {
      id: 'horizon-dream',
      slug: 'horizon-dream',
      title: 'Horizon Dream',
      description: 'A contemplative piece exploring the infinite space where sky meets land.',
      medium: 'Oil on Canvas',
      dimensions: '48 x 72 inches',
      price: '$4,500',
      status: 'Available',
      category: 'Abstract Landscapes',
      badge: 'Featured Work',
    },
    {
      id: 'emerald-glen',
      slug: 'emerald-glen',
      title: 'Emerald Glen',
      description: 'Textural layers create a lush, verdant scene of an imaginary forest glen.',
      medium: 'Oil on Board',
      dimensions: '24 x 24 inches',
      price: '$1,900',
      status: 'Available',
      category: 'Layered Oils',
      badge: '',
    },
  ],
  cta: {
    heading: 'Ready to bring original art into your space?',
    description: 'Connect directly with Jeanne Kassab to inquire about a painting or discuss a custom commission.',
    primaryLabel: 'View the Collection',
    primaryHref: '/gallery',
    secondaryLabel: 'Contact Jeanne',
    secondaryHref: '/contact',
  },
  footer: {
    description: 'Jeanne Kassab Art — original works, shown plainly.',
  },
  opsHero: {
    headline: 'Your Canvas Curator Studio',
    subcopy: 'Effortlessly manage your gallery and connect with collectors.',
  },
  kpis: [
    {
      label: 'New Inquiries (Today)',
      value: '2',
      delta: '+1',
      hint: 'via WhatsApp',
    },
    {
      label: 'Active Listings',
      value: '18',
      delta: '-1',
      hint: 'Published paintings',
    },
    {
      label: 'Draft Paintings',
      value: '3',
      delta: '+1',
      hint: 'Currently being finalized',
    },
    {
      label: 'Followers Growth (Last 30 days)',
      value: '+15%',
      delta: '+2%',
      hint: 'Social Media & Newsletter',
    },
  ],
  tableRows: [
    {
      id: '1',
      title: 'Whispering Winds',
      status: 'Available',
      medium: 'Oil on Canvas',
      dimensions: '36x48"',
      last_updated: '2023-10-26',
      inquiries: 5,
    },
    {
      id: '2',
      title: 'Coastal Echoes',
      status: 'Available',
      medium: 'Oil on Panel',
      dimensions: '30x40"',
      last_updated: '2023-10-25',
      inquiries: 3,
    },
    {
      id: '3',
      title: 'Crimson Sunset',
      status: 'Available',
      medium: 'Oil on Linen',
      dimensions: '24x36"',
      last_updated: '2023-10-24',
      inquiries: 8,
    },
    {
      id: '4',
      title: 'Urban Geometry',
      status: 'Sold',
      medium: 'Oil on Canvas',
      dimensions: '40x30"',
      last_updated: '2023-10-20',
      inquiries: 2,
    },
    {
      id: '5',
      title: 'Forest Depths',
      status: 'Available',
      medium: 'Oil on Panel',
      dimensions: '20x20"',
      last_updated: '2023-10-18',
      inquiries: 1,
    },
    {
      id: '6',
      title: 'Desert Bloom',
      status: 'Draft',
      medium: 'Oil on Linen',
      dimensions: '18x24"',
      last_updated: '2023-10-15',
      inquiries: 0,
    },
    {
      id: '7',
      title: 'Horizon Dream',
      status: 'Available',
      medium: 'Oil on Canvas',
      dimensions: '48x72"',
      last_updated: '2023-10-12',
      inquiries: 4,
    },
    {
      id: '8',
      title: 'Emerald Glen',
      status: 'Available',
      medium: 'Oil on Board',
      dimensions: '24x24"',
      last_updated: '2023-10-10',
      inquiries: 2,
    },
    {
      id: '9',
      title: 'River Bend',
      status: 'Sold',
      medium: 'Oil on Canvas',
      dimensions: '36x60"',
      last_updated: '2023-10-05',
      inquiries: 7,
    },
    {
      id: '10',
      title: 'Mountain Ascent',
      status: 'Available',
      medium: 'Oil on Linen',
      dimensions: '30x40"',
      last_updated: '2023-10-01',
      inquiries: 6,
    },
  ],
  activity: [
    {
      title: "Published 'Crimson Sunset'",
      detail: 'Now available in the gallery.',
      when: '2 minutes ago',
    },
    {
      title: "New inquiry for 'Echoes of Dawn'",
      detail: 'Received via WhatsApp from Anya Sharma.',
      when: '15 minutes ago',
    },
    {
      title: "Updated 'About' page content",
      detail: 'Biography revised and new exhibition added.',
      when: '1 hour ago',
    },
    {
      title: "Added 'Desert Bloom' to drafts",
      detail: 'Started drafting details for a new piece.',
      when: '2 hours ago',
    },
    {
      title: "Marked 'Urban Geometry' as sold",
      detail: 'Acquired by David Geller.',
      when: 'Yesterday',
    },
    {
      title: "Responded to inquiry for 'Coastal Echoes'",
      detail: 'Sent detailed photos and dimensions to Michael Davis.',
      when: '2 days ago',
    },
  ],
  aboutPage: {
    headline: 'About Jeanne Kassab',
    subcopy: `Jeanne Kassab is a contemporary oil painter known for her evocative abstract landscapes and richly layered oils. Her work explores the interplay of light, texture, and emotion, drawing inspiration from natural forms and atmospheric shifts.`,
    bio: [
      `Born in Beirut and now residing in the tranquil landscapes of the Pacific Northwest, Jeanne’s artistic journey is deeply influenced by the stark beauty of diverse environments. Her early studies in fine art focused on traditional techniques, providing a strong foundation for her later exploration into abstraction.`,
      `With a preference for working with oils, Jeanne meticulously builds her canvases with multiple layers, creating a sense of depth and luminosity that invites viewers to look beyond the surface. Her abstract landscapes are not merely representations of places but rather emotional responses, echoing the viewer's own experiences and interpretations.`,
      `Jeanne’s pieces are held in private collections across North America, Europe, and Asia. She believes that art should be an intimate part of daily life, transforming spaces and fostering a deeper connection to the aesthetic world.`,
    ],
    exhibitions: [
      {
        title: "Solo Exhibition: 'Horizons Unseen'",
        detail: 'The Gallery, Seattle, WA — Spring 2023',
      },
      {
        title: "Group Show: 'Emerging Voices'",
        detail: 'Art Collective, Portland, OR — Autumn 2022',
      },
      {
        title: "Feature Artist: 'Landscape Redefined'",
        detail: 'Modern Art Space, Vancouver, BC — Summer 2021',
      },
    ],
    artistStatement: `My art is an ongoing dialogue with the landscape, both external and internal. I'm fascinated by the ephemeral quality of light and the profound narratives hidden within geological forms. Through abstract expression, I invite the viewer to embark on their own journey of discovery, connecting with the painting not just visually, but emotionally and intuitively. It's about finding calm in the chaos, and beauty in the layered complexity of our world.`,
  },
};

export const stats = [
  {
    label: 'Total Paintings',
    value: 25,
    change: '+3 since last month',
  },
  {
    label: 'Available Pieces',
    value: 18,
    change: '-2 since last month',
  },
  {
    label: 'New Inquiries',
    value: 7,
    change: '+1 from last week',
  },
  {
    label: 'Website Visitors',
    value: '3,124',
    change: '+12% since last month',
  },
];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
