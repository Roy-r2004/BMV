// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CatalogGrid, FeatureBento, CTABand, BrandFooter, ProcessSection, TestimonialRail, LogoMarquee } from '@/ui';

const SKELETON_ID = "public-catalog" as const;
const RECIPE_ORDER = ["hero", "showcase", "features", "testimonials", "cta", "footer"] as const;

export default function GalleryHomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    trust: (
      <LogoMarquee size="display" items={(seed.trustLabels ?? []).map((label) => ({ label }))} />
    ),
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"Capturing Light and Landscape on Canvas"}
        subcopy={"Explore Jeanne Kassab's collection of original abstract landscapes and layered oil paintings."}
        primaryCta={{ label: "View the Collection", href: "/gallery" }}
        secondaryCta={{ label: "About the Artist", href: "/about" }}
        imageSrc={images.hero} // Changed to hero image as per brief
        imageAlt="An abstract oil painting with warm, earthy tones and dynamic brushstrokes"
        className="max-w-[var(--page-width)] mx-auto" // Added for spacing control
      />
    ),
    // Removed trust slot as it was not part of the brief or required sections
    // trust: (
    //   <LogoMarquee size="display" items={(seed.trustLabels ?? []).map((label) => ({ label }))} />
    // ),
    showcase: (
      <CatalogGrid
        heading={"Latest Works"}
        description={"Journey through recent expressions from the studio."}
        detailBase="/artwork" // Link to individual artwork pages
        itemNoun="paintings"
        items={[
          {
            id: '1', title: 'Whispering Winds', description: 'Dynamic abstract landscape capturing the movement of air.', imageSrc: images.card1, imageAlt: 'Abstract painting with soft blues and greens', meta: 'Oil on Canvas', status: 'Available'
          },
          {
            id: '2', title: 'Coastal Echoes', description: 'Layers of oil bring to life the memory of the sea.', imageSrc: images.card2, imageAlt: 'Layered oil painting with ocean tones', meta: 'Oil on Panel', status: 'Available'
          },
          {
            id: '3', title: 'Crimson Sunset', description: 'Vibrant impasto textures evoking a warm evening sky.', imageSrc: images.card3, imageAlt: 'Warm-toned abstract painting', meta: 'Oil on Linen', status: 'Available'
          },
          {
            id: '4', title: 'Urban Geometry', description: 'Bold lines and structured forms in a cityscape abstraction.', imageSrc: images.ambient, imageAlt: 'Abstract urban landscape painting', meta: 'Oil on Canvas', status: 'Sold', badge: 'Sold'
          },
          {
            id: '5', title: 'Forest Depths', description: 'Dark, rich hues exploring the mystery of deep woods.', imageSrc: images.hero2, imageAlt: 'Deep green and brown abstract forest scene', meta: 'Oil on Panel', status: 'Available'
          },
          {
            id: '6', title: 'Desert Bloom', description: 'Subtle colors hinting at life in arid landscapes.', imageSrc: images.card1, imageAlt: 'Soft, sandy colored abstract painting', meta: 'Oil on Linen', status: 'Available'
          },
        ]}
        className="mt-20 max-w-[var(--page-width)] mx-auto px-4 sm:px-6 lg:px-8" // Added for spacing and full bleed on smaller screens
      />
    ),
    features: (
      <ProcessSection
        heading="The Value of Original Art"
        description="Owning an original painting is an investment in beauty and a personal connection to artistry. Here’s how simple it is to bring one home."
        steps={[
          { title: "Browse the Collection", description: "Discover unique abstract landscapes and layered oils, each telling its own story." },
          { title: "Inquire Directly", description: "Connect with Jeanne Kassab to discuss any piece, including details or commission possibilities." },
          { title: "Welcome Home", description: "Experience the lasting joy and distinctive presence of an original painting in your space." },
        ]}
        className="mt-20 py-16 max-w-[var(--page-width)] mx-auto px-4 sm:px-6 lg:px-8 text-text-brand" // Added for spacing and full bleed on smaller screens
      />
    ),
    // Added testimonials slot as per brief's "two testimonials"
    testimonials: (
      <TestimonialRail
        heading="Voices from Collectors"
        items={[
          { quote: "Having a Jeanne Kassab original in my home brings such a calm and inspiring presence. It truly transforms the space.", author: "A discerning collector" },
          { quote: "Jeanne's ability to capture emotion through color and texture is extraordinary. Each painting is a journey.", author: "An interior designer" },
        ]}
        className="mt-20 py-16 max-w-[var(--page-width)] mx-auto px-4 sm:px-6 lg:px-8" // Added for spacing and full bleed on smaller screens
      />
    ),
    cta: (
      <CTABand
        heading={"Ready to Find Your Piece?"}
        description={"Connect with Jeanne Kassab about a painting that speaks to you, or to discuss a custom commission."}
        primaryCta={{ label: "View All Paintings", href: "/gallery" }}
        secondaryCta={{ label: "Contact Jeanne", href: "/contact" }} // Assuming a contact page route or direct WhatsApp link in future
        className="mt-20 py-20 max-w-[var(--page-width)] mx-auto px-4 sm:px-6 lg:px-8" // Added for spacing and full bleed on smaller screens
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings for collectors and designers. © 2024 Jeanne Kassab Art. All rights reserved."}
        links={[
          { href: "/about", label: "About the Artist" },
          { href: "/contact", label: "Contact Jeanne" },
        ]}
        className="max-w-[var(--page-width)] mx-auto px-4 sm:px-6 lg:px-8" // Added for spacing and full bleed on smaller screens
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="gallery-home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}