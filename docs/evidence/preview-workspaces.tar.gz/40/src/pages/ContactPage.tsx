// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Connect with Jeanne Kassab Art"}
        description={"For inquiries about available paintings, commissions, or collaborations, please reach out directly."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Inquire via WhatsApp"}</h3>
            <p className="text-sm leading-6 text-muted">{"The quickest way to ask about a painting or discuss a new project."}</p>
            <Button href={"https://wa.me/15551234567?text=Hello%20Jeanne%2C%20I%27d%20like%20to%20inquire%20about%20a%20painting."} className="mt-auto w-fit">
              {"Chat on WhatsApp"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Send an Email"}</h3>
            <p className="text-sm leading-6 text-muted">{"For detailed inquiries or formal correspondence."}</p>
            <Button href={"mailto:jeanne@jeannekassabart.com"} className="mt-auto w-fit">
              {"Email Jeanne"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Visit the Online Gallery"}</h3>
            <p className="text-sm leading-6 text-muted">{"Browse the latest collection of original oil paintings."}</p>
            <Button href={"/paintings"} className="mt-auto w-fit">
              {"View Gallery"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Learn About the Artist"}</h3>
            <p className="text-sm leading-6 text-muted">{"Discover Jeanne Kassab's artistic philosophy and journey."}</p>
            <Button href={"/about"} className="mt-auto w-fit">
              {"About Jeanne"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Jeanne Kassab Art · Original Oil Paintings & Abstract Landscapes"}
      />
    ),
  };

  return (
    <PublicShell
      brandName={"Jeanne Kassab Art"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"generic"} data-appspec-page="contact-page">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}