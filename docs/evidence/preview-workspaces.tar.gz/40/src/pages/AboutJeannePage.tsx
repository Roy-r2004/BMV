// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function AboutJeannePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"About Jeanne Kassab"}
        description={"Discover the artist behind the abstract landscapes and layered oil paintings."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Artist Biography"}</h3>
            <p className="text-sm leading-6 text-muted">{"Jeanne Kassab is an acclaimed artist renowned for her captivating abstract landscapes and deeply layered oil paintings. Born with a passion for art, she developed a unique style that blends natural forms with emotive color palettes, inviting viewers into contemplative worlds. Her work explores the interplay of light, texture, and memory, often drawing inspiration from raw, unbridled nature and fleeting moments. Each piece is a journey, meticulously crafted to evoke a sense of calm, introspection, and connection to the vastness of the natural world. Jeanne's dedication to her craft is evident in the depth and complexity of her compositions, making her a significant voice in contemporary fine art."}</p>
            <Button href={"/paintings"} className="mt-auto w-fit">
              {"View Recent Works"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Artistic Philosophy"}</h3>
            <p className="text-sm leading-6 text-muted">{"My philosophy centers on the transformative power of art to transport and inspire. I believe paintings should not merely depict, but rather resonate on a profound emotional level, offering a sanctuary of beauty and contemplation. Through layered oils, I aim to create a visual dialogue between the viewer and the canvas, where each brushstroke contributes to a unfolding narrative of abstraction and natural wonder. My work is a meditation on balance, contrast, and the subtle energies that shape our perceptions."}</p>
            <Button href={"/paintings"} className="mt-auto w-fit">
              {"Explore Collections"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Exhibitions & Features"}</h3>
            <p className="text-sm leading-6 text-muted">{"Jeanne Kassab's art has been showcased in numerous galleries and private collections worldwide. Recent exhibitions include 'Echoes of the Land' at The River Gallery (2023), 'Layered Horizons' at the Contemporary Art Space (2022), and 'Abstract Forms in Nature' at the Art District Collective (2021). Her work has been featured in 'Art & Soul Magazine' and 'Contemporary Painter's Digest'."}</p>
            <Button href={"/contact"} className="mt-auto w-fit">
              {"Inquire About Works"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"© 2024 Jeanne Kassab Art. All rights reserved."}
      />
    ),
  };

  return (
    <PublicShell
      brandName={"Jeanne Kassab Art"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"generic"} data-appspec-page="about-jeanne">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}