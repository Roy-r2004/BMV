// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        eyebrow={'Online Gallery'}
        headline={"Abstract Landscapes & Layered Oils"}
        subcopy={"Discover a living gallery of original oil paintings, each a unique expression from the studio of Jeanne Kassab."}
        primaryCta={{ label: "View the Collection", href: "/collection" }}
        secondaryCta={{ label: "About the Artist", href: "/about" }}
        imageSrc={images.hero}
        imageAlt="An abstract landscape oil painting, rich with texture and color."
      />
    ),
    credentials: (
      <CredentialStrip
        className="mt-20 mb-20"
        heading={"Dedicated to the Craft"}
        items={[
          { title: "Original Works", detail: "Each painting is a unique, hand-crafted oil on canvas from Jeanne Kassab's studio." },
          { title: "Art-First Presentation", detail: "We believe in showcasing art with generous whitespace and high-resolution detail." },
          { title: "Direct Connection", detail: "Inquire directly with Jeanne Kassab via WhatsApp for a personal touch." },
        ]}
      />
    ),
    features: (
      <FeatureBento
        heading={"Bringing Art to Your Space"}
        description={"Explore how Jeanne Kassab's paintings can transform your environment, from tranquil landscapes to dynamic abstracts."}
        imagePool={[images.card1, images.card2, images.card3]}
        items={[
          { "title": "Curated Collections", "description": "Browse distinctive series, each telling its own visual story through paint." },
          { "title": "Personalized Inquiries", "description": "Connect directly for details, commissions, or to arrange a viewing." },
          { "title": "Secure Acquisition", "description": "A seamless process for collecting original art, from inquiry to installation." }
        ]}
      />
    ),
    showcase: (
      <ProductShowcase
        heading={"Featured Works in the Gallery"}
        description={"A selection of original oil paintings currently available, ready to inspire and adorn."}
        items={[
          { title: "Whispers of the Horizon", description: "An immersive abstract landscape capturing the essence of dawn.", imageSrc: images.card1, imageAlt: "Abstract landscape painting titled 'Whispers of the Horizon'", href: "/gallery/whispers-of-the-horizon", badge: "New Arrival" },
          { title: "Beneath the Surface", description: "Layers of oil reveal a hidden narrative of depth and discovery.", imageSrc: images.card2, imageAlt: "Layered oil painting titled 'Beneath the Surface'", href: "/gallery/beneath-the-surface", badge: "Available" },
          { title: "Echoes in Blue", description: "A serene abstract with calming hues and intricate textures.", imageSrc: images.card3, imageAlt: "Abstract painting titled 'Echoes in Blue'", href: "/gallery/echoes-in-blue", badge: "Collection Piece" },
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading={"From Collectors and Visitors"}
        items={[
          {
            quote: "Jeanne's art brings a profound tranquility and vibrant energy to my home. Each piece is a conversation starter.",
            author: "Anya Sharma",
            role: "Collector"
          },
          {
            quote: "The online gallery is exquisitely designed, allowing the art to truly shine. It's a joy to browse.",
            author: "Marcus Chen",
            role: "Interior Designer"
          },
          {
            quote: "The direct inquiry via WhatsApp made acquiring a piece effortless and personal. A wonderful experience.",
            author: "Emily White",
            role: "First-time Buyer"
          }
        ]}
      />
    ),
    cta: (
      <CTABand
        heading={"Find Your Next Piece"}
        description={"Connect with Jeanne Kassab to discuss a painting, inquire about a commission, or simply share your thoughts."}
        primaryCta={{ label: "View Available Paintings", href: "/collection" }}
        secondaryCta={{ label: "Contact Jeanne", href: "/contact" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings for collectors and designers. Showcasing abstract landscapes and layered oils."}
        links={[
          { label: "Collection", href: "/collection" },
          { label: "About", href: "/about" },
          { label: "Inquire", href: "/contact" },
          { label: "Privacy Policy", href: "/privacy" }
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}