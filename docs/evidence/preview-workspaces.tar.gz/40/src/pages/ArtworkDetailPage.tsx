// deterministic catalogue contract scaffold
import { useParams } from 'react-router-dom';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, Button, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, InquiryPanel, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "inquire", "cta", "footer"] as const;

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const params = useParams();
  const catalogItems = (seed.items ?? []) as any[];
  const itemKey = String(params.id ?? params.slug ?? '').trim();
  const itemIndex = catalogItems.findIndex(
    (entry: any, index: number) =>
      String(entry?.id ?? entry?.slug ?? index + 1) === itemKey,
  );
  const item: any = itemIndex >= 0 ? catalogItems[itemIndex] : undefined;
  const notFound = itemKey !== '' && itemIndex < 0;
  const itemTitle = String(item?.title ?? 'This piece');
  const itemImage = [images.card1, images.card2, images.card3][
    (itemIndex >= 0 ? itemIndex : 0) % 3
  ];
  const itemSpecs = [
    { title: 'Reference', detail: itemKey || String(itemIndex + 1) },
    item?.medium ? { title: 'Medium', detail: String(item.medium) } : null,
    item?.dimensions ? { title: 'Dimensions', detail: String(item.dimensions) } : null,
    item?.price ? { title: 'Price', detail: String(item.price) } : null,
    item?.status ? { title: 'Availability', detail: String(item.status) } : null,
    item?.category ? { title: 'Collection', detail: String(item.category) } : null,
  ].filter(Boolean) as { title: string; detail: string }[];
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jeanne Kassab Art"} eyebrow={"Jeanne Kassab Art"} headline={itemTitle} subcopy={String(item?.description ?? "")} primaryCta={{ label: "Inquire about this piece", href: "#inquire" }} secondaryCta={{ label: "Back to the collection", href: "/gallery" }} imageSrc={itemImage} imageAlt={itemTitle} />
    ),
    credentials: (
      <CredentialStrip heading="Details" items={itemSpecs} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Jeanne Kassab Art"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.card1, images.card2, images.card3][index % 3], imageAlt: item.title, badge: String((item as any).badge || (item as any).category || "Featured work"), href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    inquire: (
      <InquiryPanel heading="Inquire about this piece" itemId={itemKey} itemTitle={itemTitle} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={seed.footer?.description ?? "Jeanne Kassab Art — original works, shown plainly."} />
    ),
  };

  if (notFound) {
    return (
      <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
        <div data-skeleton={skeleton.id} data-detail-not-found="" data-appspec-page="artwork-detail">
          <div className="mx-auto w-full max-w-3xl px-6 pt-32 pb-24 lg:pt-40">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-brand">
              Not found
            </p>
            <h1 className="mt-4 font-display text-[clamp(2rem,4vw,3rem)] leading-tight tracking-tight text-foreground">
              We could not find that one
            </h1>
            <p className="mt-4 text-base leading-7 text-muted">
              It may have sold or moved. Browse what is available now.
            </p>
            <Button href={"/gallery"} className="mt-8">Back to the collection</Button>
          </div>
        </div>
      </PublicShell>
    );
  }

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="artwork-detail">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}
