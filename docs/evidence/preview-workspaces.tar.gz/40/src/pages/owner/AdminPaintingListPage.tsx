// directory listing scaffold — distinct from home marketing clone
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { BRAND_MANIFEST, images } from '@/data/mock';
import { PublicShell, PublicNav, PageHeader, CatalogGrid, CTABand, BrandFooter } from '@/ui';

const services = Array.isArray(BRAND_MANIFEST?.services) ? BRAND_MANIFEST.services : [];
const LISTING_BASE = "/owner/paintings";

export default function AdminPaintingListPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  // CatalogGrid renders every entry and links each into LISTING_BASE/:id.
  // ProductShowcase used to fill this slot and silently showed only three.
  const people = (services.length ? services : [
    { id: 'dr-1', name: 'Dr. Avery Chen', description: 'Family medicine · accepting new patients' },
    { id: 'dr-2', name: 'Dr. Jordan Miles', description: 'Pediatrics · same-week visits' },
    { id: 'dr-3', name: 'Dr. Sam Rivera', description: 'Internal medicine · telehealth available' },
  ]).map((s: any, i: number) => ({
    id: String(s.id || s.slug || i + 1),
    title: String(s.name || s.title || `Provider ${i + 1}`),
    description: String(s.description || s.specialty || s.role || 'Available for appointments'),
    imageSrc: [images.card1, images.card2, images.card3][i % 3],
    imageAlt: String(s.name || s.title || 'Provider'),
    category: s.category ? String(s.category) : undefined,
    badge: s.badge ? String(s.badge) : undefined,
  }));

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} chrome="solid" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton="public-catalog" data-appspec-page="admin-painting-list">

      <div className="mx-auto w-full max-w-[92rem] px-6 pt-28 pb-10 lg:px-12 lg:pt-32 lg:pb-14">
        <PageHeader
          title={"Manage Paintings – Canvas Curator"}
          description="Browse providers, specialties, and availability — then book the right visit."
        />
      </div>
      <CatalogGrid
        heading="Meet the team"
        description="Each card opens a provider profile. Book when you are ready."
        detailBase={LISTING_BASE}
        itemNoun="providers"
        items={people}
      />
      <CTABand
        heading="Ready to schedule?"
        description="Pick a time online — same team you just reviewed."
        primaryCta={{ label: "Book a visit", href: "/book" }}
        secondaryCta={{ label: "Ask AI assistant", href: "/ai-features" }}
      />
      <BrandFooter brandName={"Jeanne Kassab Art"} description="Real providers. Clear booking. Not another homepage clone." />
      </div>
    </PublicShell>
  );
}
