// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Input, Button } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-settings" as const;
export default function AdminEditAboutPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // Sample data for pre-filling, replace with actual data fetching logic
  const [biography, setBiography] = useState<string>(
    "Jeanne Kassab is a Lebanese visual artist based in Beirut, known for her captivating abstract landscapes and expressive layered oil paintings. Her work explores the interplay of light, shadow, and texture, inviting viewers into a dialogue with nature's profound beauty. With a deep connection to her surroundings, Jeanne translates emotional landscapes onto canvas, using rich pigments and bold brushstrokes to convey a sense of depth and movement. Her art resonates with collectors and designers alike, seeking pieces that evoke tranquility and introspection."
  );
  const [artistStatement, setArtistStatement] = useState<string>(
    "My artistic practice is a continuous exploration of the natural world and the emotional resonance it carries. I aim to create pieces that are not merely representations but rather an interpretation of the inherent energy and poetry found in landscapes. Through the layering of oil paints, I build depth and complexity, seeking to capture the fleeting moments and profound quietude of the environment. Each painting is a journey, an invitation to pause, observe, and connect with the subtle narratives that unfold within the work."
  );
  const [credentials, setCredentials] = useState<string>(
    "Selected Exhibitions: \n- 'Echoes of Light', Solo Exhibition, Beirut Art Space, 2023\n- Group Show, 'Contemporary Expressions', Gallery S, 2022\n\nAwards & Recognition: \n- Emerging Artist Award, National Art Fair, 2021"
  );

  const handleSaveChanges = () => {
    // In a real application, this would send data to an API
    console.log("Saving changes...", { biography, artistStatement, credentials });
    alert("Changes saved successfully!");
  };

  const handleCancel = () => {
    // In a real application, this would revert changes or navigate away
    console.log("Cancelling changes.");
    // Optionally reset state to original fetched values
  };

  const slots = {
    header: (
      <PageHeader title={"Edit About Page – Canvas Curator"} description={"Update your biography, artistic philosophy, and credentials for your public profile."} />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-about" className="p-6 space-y-8 max-w-4xl mx-auto">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />

        <div className="bg-surface p-6 rounded-lg shadow-sm space-y-6">
          <h2 className="text-xl font-display text-text-brand leading-relaxed">Biography</h2>
          <Input
            as="textarea"
            rows={10}
            value={biography}
            onChange={(e) => setBiography(e.target.value)}
            className="w-full"
            aria-label="Artist Biography"
          />

          <h2 className="text-xl font-display text-text-brand leading-relaxed mt-8">Artist Statement</h2>
          <Input
            as="textarea"
            rows={10}
            value={artistStatement}
            onChange={(e) => setArtistStatement(e.target.value)}
            className="w-full"
            aria-label="Artist Statement"
          />

          <h2 className="text-xl font-display text-text-brand leading-relaxed mt-8">Credentials (Optional)</h2>
          <Input
            as="textarea"
            rows={5}
            value={credentials}
            onChange={(e) => setCredentials(e.target.value)}
            placeholder="e.g., Selected Exhibitions: 'Echoes of Light', Solo Exhibition, Beirut Art Space, 2023"
            className="w-full"
            aria-label="Artist Credentials"
          />

          <div className="flex justify-end space-x-4 mt-8">
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button onClick={handleSaveChanges}>
              Save Changes
            </Button>
          </div>
        </div>
      </div>
    </OpsShell>
  );
}