// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, DataTable, ActivityFeed, Input, Select, Button } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-detail" as const;

export default function AdminEditPaintingPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // Sample painting data (replace with actual data fetching in a real app)
  const [painting, setPainting] = useState({
    id: "painting-123",
    title: "Whispers of the Horizon",
    medium: "Oil on Canvas",
    dimensions: "24 x 36 inches",
    artistStatement: "A journey through abstract landscapes, where light and shadow dance across layered textures, evoking the quiet majesty of nature's embrace.",
    status: "Published",
    imageUrl: "https://images.pexels.com/photos/36733374/pexels-photo-36733374.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", // Mock image URL
    year: 2023,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPainting(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value: string) => {
    setPainting(prev => ({ ...prev, status: value }));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setPainting(prev => ({ ...prev, imageUrl: event.target?.result as string }));
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const statusOptions = [
    { value: "Draft", label: "Draft" },
    { value: "Published", label: "Published" },
    { value: "Sold", label: "Sold" },
  ];

  const slots = {
    header: (
      <PageHeader title={`Edit Painting: ${painting.title}`} actions={[
        { label: "AI tools", onClick: () => alert("Integrating AI tools..."), variant: "secondary" },
        { label: "Delete Painting", onClick: () => alert("Confirm delete?"), variant: "destructive" },
      ]} />
    ),
    table: (
      <div className="p-base bg-surface font-sans radius_ui">
        <div className="flex flex-col space-y-md">
          <Input 
            label="Title" 
            name="title" 
            value={painting.title} 
            onChange={handleInputChange} 
            required 
            className="w-full" 
          />
          <Input 
            label="Medium" 
            name="medium" 
            value={painting.medium} 
            onChange={handleInputChange} 
            required 
            className="w-full" 
          />
          <Input 
            label="Dimensions" 
            name="dimensions" 
            value={painting.dimensions} 
            onChange={handleInputChange} 
            className="w-full" 
          />
           <Input 
            label="Year" 
            name="year" 
            value={painting.year.toString()} 
            onChange={handleInputChange} 
            type="number"
            className="w-full" 
          />
          <Input 
            label="Artist Statement / Description" 
            name="artistStatement" 
            value={painting.artistStatement} 
            onChange={handleInputChange} 
            as="textarea" 
            rows={5} 
            className="w-full"
          />
          <Select 
            label="Status" 
            name="status" 
            options={statusOptions} 
            value={painting.status} 
            onValueChange={handleSelectChange} 
            className="w-full"
          />
          <div>
            <label htmlFor="image-upload" className="block text-sm font-medium text-text-brand mb-xs">Painting Image</label>
            {painting.imageUrl && (
              <div className="mb-sm">
                <img src={painting.imageUrl} alt={painting.title} className="max-w-xs h-auto rounded_ui" />
              </div>
            )}
            <Input 
              id="image-upload" 
              name="image" 
              type="file" 
              onChange={handleImageChange} 
              className="w-full" 
            />
          </div>
          <div className="flex justify-end space-x-sm pt-base">
            <Button variant="secondary" onClick={() => alert("Changes discarded.")}>Cancel</Button>
            <Button variant="default" onClick={() => alert("Painting saved!")}>Save Changes</Button>
          </div>
        </div>
      </div>
    ),
    activity: (
      <ActivityFeed 
        heading="Painting History" 
        items={[
          { id: "activity-1", title: "Painting 'Whispers of the Horizon' updated", detail: "Title, Medium, and Statement adjusted.", time: "Just now" }, 
          { id: "activity-2", title: "Status changed to 'Published'", detail: "Visible on public gallery.", time: "30m ago" }, 
          { id: "activity-3", title: "Painting created", detail: "Initial upload and details captured.", time: "2 days ago" }
        ]} 
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-edit-painting">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}