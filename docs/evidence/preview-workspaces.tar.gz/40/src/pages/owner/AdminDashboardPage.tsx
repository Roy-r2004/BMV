// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title="Welcome, Jeanne!"
        description="Manage your online gallery and connect with collectors effortlessly."
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
        <StatCard
          label="New Inquiries (Today)"
          value={seed.kpis?.[0]?.value ?? "5"}
          delta={seed.kpis?.[0]?.delta ?? "+2"}
          hint="Compared to yesterday"
        />
        <StatCard
          label="Active Paintings"
          value={seed.kpis?.[1]?.value ?? "28"}
          delta={seed.kpis?.[1]?.delta ?? "+1"}
          hint="Total live pieces"
        />
        <StatCard
          label="Draft Paintings"
          value={seed.kpis?.[2]?.value ?? "3"}
          delta={seed.kpis?.[2]?.delta ?? "0"}
          hint="Ready to publish"
        />
      </div>
    ),
    chart: (
      <ChartCard
        title="Monthly Inquiries"
        type="area"
        dataKey="value"
        xKey="month"
        data={[
          { month: "Jan", value: 12 },
          { month: "Feb", value: 18 },
          { month: "Mar", value: 15 },
          { month: "Apr", value: 22 },
          { month: "May", value: 19 },
          { month: "Jun", value: 25 },
        ]}
        description="Overview of direct inquiries for your art."
      />
    ),
    filters: (
      <FilterBar searchPlaceholder="Search inquiries" filters={[]} />
    ),
    table: (
      <DataTable
        columns={[
          { key: "painting", header: "Painting" },
          { key: "sender", header: "Sender" },
          { key: "status", header: "Status" },
          {
            key: "date",
            header: "Date",
            render: ({ row }) => (
              <span className="text-muted">{row.date}</span>
            ),
          },
        ]}
        rows={[
          { id: "inq-1", painting: "Crimson Sunset", sender: "Art Collector", status: "New", date: "2h ago" },
          { id: "inq-2", painting: "Echoes of Dawn", sender: "Interior Designer", status: "Replied", date: "1 day ago" },
          { id: "inq-3", painting: "Whispers of the Forest", sender: "Gallery Curator", status: "Follow-up", date: "3 days ago" },
          { id: "inq-4", painting: "Midnight Bloom", sender: "Private Buyer", status: "New", date: "5 days ago" },
        ]}
        emptyMessage="No recent inquiries."
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "act-1", title: "Published 'Crimson Sunset'", time: "Just now" },
          { id: "act-2", title: "New inquiry for 'Echoes of Dawn'", time: "2 hours ago" },
          { id: "act-3", title: "Updated 'About' page content", time: "1 day ago" },
          { id: "act-4", title: "Edited 'Whispers of the Forest' details", time: "3 days ago" },
          { id: "act-5", title: "Unpublished 'Lost in Thought' (Sold)", time: "1 week ago" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
    </OpsShell>
  );
}