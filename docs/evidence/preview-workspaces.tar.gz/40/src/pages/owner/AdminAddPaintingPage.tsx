// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, DataTable, ActivityFeed, Input, Button, Select } from '@/ui';

const SKELETON_ID = "ops-detail" as const;
export default function AdminAddPaintingPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title="Add New Painting"
        description="Carefully log the details of your latest creation to share with collectors."
      />
    ),
    table: (
      <div className="flex flex-col gap-6 p-6 rounded-lg bg-surface text-brand">
        <label htmlFor="painting-title" className="font-sans text-brand text-sm font-medium">Title</label>
        <Input id="painting-title" placeholder="e.g., Whispering Pines at Dusk" required />

        <label htmlFor="painting-medium" className="font-sans text-brand text-sm font-medium">Medium</label>
        <Input id="painting-medium" placeholder="e.g., Oil on canvas" required />

        <label htmlFor="painting-dimensions" className="font-sans text-brand text-sm font-medium">Dimensions</label>
        <Input id="painting-dimensions" placeholder="e.g., 24 x 36 inches" required />

        <label htmlFor="painting-description" className="font-sans text-brand text-sm font-medium">Artist Statement/Description</label>
        <Input id="painting-description" as="textarea" rows={5} placeholder="Share the inspiration, techniques, and narrative behind this piece." />

        <label htmlFor="painting-status" className="font-sans text-brand text-sm font-medium">Status</label>
        <Select
          id="painting-status"
          options={[
            { value: 'available', label: 'Available' },
            { value: 'draft', label: 'Draft' },
            { value: 'sold', label: 'Sold' },
          ]}
          defaultValue="available"
          required
        />

        <div className="flex flex-col gap-2">
          <label htmlFor="painting-image" className="font-sans text-brand text-sm font-medium">Image Upload</label>
          <Input id="painting-image" type="file" />
          <p className="text-muted text-xs">Upload a high-resolution image of your painting.</p>
        </div>

        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline">Cancel</Button>
          <Button type="submit">Save Painting</Button>
        </div>
      </div>
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "activity-1", title: "Painting Drafted", detail: "Started 'Whispering Pines at Dusk'.", time: "Just now" },
          { id: "activity-2", title: "Artwork Image Added", detail: "High-resolution photo uploaded.", time: "5m ago" },
          { id: "activity-3", title: "Status Changed", detail: "Marked 'Golden Hour' as Sold.", time: "2 days ago" }
        ]}
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-add-painting">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}