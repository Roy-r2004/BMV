import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutJeannePage from './pages/AboutJeannePage';
import AdminAddPaintingPage from './pages/owner/AdminAddPaintingPage';
import AdminDashboardPage from './pages/owner/AdminDashboardPage';
import AdminEditAboutPage from './pages/owner/AdminEditAboutPage';
import AdminEditPaintingPage from './pages/owner/AdminEditPaintingPage';
import AdminPaintingListPage from './pages/owner/AdminPaintingListPage';
import ArtworkDetailPage from './pages/ArtworkDetailPage';
import ContactPage from './pages/ContactPage';
import GalleryHomePage from './pages/GalleryHomePage';
import HomePage from './pages/HomePage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/gallery');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/gallery" element={<GalleryHomePage />} />
          <Route path="/about" element={<AboutJeannePage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/owner/dashboard" element={<AdminDashboardPage />} />
          <Route path="/owner/paintings" element={<AdminPaintingListPage />} />
          <Route path="/owner/paintings/add" element={<AdminAddPaintingPage />} />
          <Route path="/owner/paintings/:id" element={<AdminAddPaintingPage />} />
          <Route path="/owner/paintings/:slug" element={<AdminAddPaintingPage />} />
          <Route path="/owner/about" element={<AdminEditAboutPage />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/artwork/:slug" element={<ArtworkDetailPage />} />
          <Route path="/owner/paintings/edit/:id" element={<AdminEditPaintingPage />} />
          <Route path="/gallery/:id" element={<ArtworkDetailPage />} />
          <Route path="/gallery/:slug" element={<ArtworkDetailPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}