import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Galerie Aubert"} eyebrow={seed.hero?.eyebrow || "Curated Collection"} headline={seed.hero?.headline || "Galerie Aubert: Original Oil Paintings"} subcopy={seed.hero?.subcopy} primaryCta={seed.hero?.primaryCta} secondaryCta={seed.hero?.secondaryCta} imageSrc={images.hero} imageAlt="" />
    ),
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Galerie Aubert"} items={seed.credentials ?? []} />
    ),
    features: (
      <FeatureBento heading={seed.featuresHeading ?? "What Galerie Aubert offers"} imagePool={[images.card1, images.card2, images.card3]} items={seed.features?.length ? seed.features : [{"title": "Original works", "description": "Signed pieces, each one photographed as it hangs."}, {"title": "Commissions", "description": "A piece scaled to your room, your light, your palette."}, {"title": "Collector support", "description": "Framing, shipping, and placement handled end to end."}]} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Galerie Aubert"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.item1, images.item2, images.item3, images.item4, images.item5, images.item6, images.item7, images.item8][index % 8], imageAlt: item.title, badge: String((item as any).badge || (item as any).category || "Featured work"), href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Galerie Aubert"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Galerie Aubert?"} description={seed.cta?.description ?? "Tell Galerie Aubert what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "/contact#inquire" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "/contact#inquire" }} />
    ),
    footer: (
      <BrandFooter brandName={"Galerie Aubert"} description={seed.footer?.description ?? "Galerie Aubert — original works, shown plainly."} />
    ),
  };

  return (
    <PublicShell brandName={"Galerie Aubert"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}