// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable } from '@/ui';

const SKELETON_ID = "ops-list" as const;
export default function ArtworksPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={seed.opsHero?.headline || "Artwork Management · Aubert Atelier Digital"} description={seed.opsHero?.subcopy || "Appointments, check-ins, and the work that needs attention now."} meta={<span className="text-sm text-muted">Live</span>} actions={[{ label: "AI features", href: "/ai-features", variant: "secondary" }, { label: "Check in", href: "#queue" }]} />
    ),
    filters: (
      <FilterBar searchPlaceholder="Search records" filters={[{ id: "all", label: "All", active: true }, { id: "open", label: "Open", active: false }]} />
    ),
    table: (
      <DataTable columns={[{ key: "name", header: "Name" }, { key: "status", header: "Status" }, { key: "owner", header: "Owner" }]} rows={(seed.tableRows ?? [{ id: "t1", name: "Primary record", status: "In progress", owner: "Ops" }, { id: "t2", name: "Follow-up item", status: "On hold", owner: "Ops" }, { id: "t3", name: "Completed item", status: "Done", owner: "Ops" }]).map((row: any) => ({ name: String(row?.name ?? row?.title ?? row?.label ?? row?.id ?? ""), status: String(row?.status ?? row?.state ?? ""), owner: String(row?.owner ?? row?.collector ?? row?.assignee ?? row?.client ?? "—") }))} />
    ),
  };

  return (
    <OpsShell brandName={"Galerie Aubert"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-artworks">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}
