// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Button, Input, Select, Dialog } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-settings" as const;

export default function SettingsPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const [galleryName, setGalleryName] = useState('Galerie Aubert');
  const [artistName, setArtistName] = useState('Anya Aubert');
  const [contactEmail, setContactEmail] = useState('info@galerieaubert.com');
  const [phoneNumber, setPhoneNumber] = useState('+1 (555) 123-4567');
  const [physicalAddress, setPhysicalAddress] = useState('123 Atelier Street, Art City, AC 90210');
  const [displayPricesPublicly, setDisplayPricesPublicly] = useState('yes');
  const [defaultAvailability, setDefaultAvailability] = useState('available');
  const [inquiryResponseTime, setInquiryResponseTime] = useState('24 hours');
  const [instagramUrl, setInstagramUrl] = useState('https://instagram.com/galerieaubert');
  const [facebookUrl, setFacebookUrl] = useState('https://facebook.com/galerieaubert');
  const [ownerNotificationEmail, setOwnerNotificationEmail] = useState('owner@galerieaubert.com');

  const handleSaveChanges = () => {
    // In a real application, this would send data to a backend API
    console.log("Saving changes...");
    console.log({
      galleryName,
      artistName,
      contactEmail,
      phoneNumber,
      physicalAddress,
      displayPricesPublicly,
      defaultAvailability,
      inquiryResponseTime,
      instagramUrl,
      facebookUrl,
      ownerNotificationEmail,
    });
    // Add toast or notification for success/failure
  };

  const slots = {
    header: (
      <PageHeader
        title={"Gallery Settings"}
        actions={[
          { label: "Save Changes", onClick: handleSaveChanges, variant: "default" }
        ]}
      />
    ),
    // The main content of the settings page is not explicitly a 'slot' in ops-settings skeleton
    // but typically falls within the children of OpsShell
  };

  return (
    <OpsShell brandName={"Galerie Aubert"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-settings" className="p-8 space-y-8">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />

        <div className="grid gap-8 max-w-4xl mx-auto">
          {/* General Information */}
          <div className="bg-surface p-6 rounded-radius_ui shadow">
            <h2 className="font-display text-lg text-text mb-6">General Information</h2>
            <div className="space-y-4">
              <Input
                label="Gallery Name"
                type="text"
                value={galleryName}
                onChange={(e) => setGalleryName(e.target.value)}
                className="rounded-radius_ui"
              />
              <Input
                label="Artist Name"
                type="text"
                value={artistName}
                onChange={(e) => setArtistName(e.target.value)}
                className="rounded-radius_ui"
              />
              <Input
                label="Contact Email"
                type="email"
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                className="rounded-radius_ui"
              />
              <Input
                label="Phone Number"
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="rounded-radius_ui"
              />
              <Input
                label="Physical Address"
                as="textarea"
                rows={3}
                value={physicalAddress}
                onChange={(e) => setPhysicalAddress(e.target.value)}
                className="rounded-radius_ui"
              />
            </div>
          </div>

          {/* Website Preferences */}
          <div className="bg-surface p-6 rounded-radius_ui shadow">
            <h2 className="font-display text-lg text-text mb-6">Website Preferences</h2>
            <div className="space-y-4">
              <Select
                label="Display Artwork Prices Publicly?"
                options={[
                  { value: 'yes', label: 'Yes, display prices publicly' },
                  { value: 'no', label: 'No, require inquiry for prices' },
                ]}
                value={displayPricesPublicly}
                onValueChange={setDisplayPricesPublicly}
                className="rounded-radius_ui"
              />
              <Select
                label="Default Artwork Availability Status"
                options={[
                  { value: 'available', label: 'Available' },
                  { value: 'on_hold', label: 'On Hold' },
                  { value: 'sold', label: 'Sold' },
                ]}
                value={defaultAvailability}
                onValueChange={setDefaultAvailability}
                className="rounded-radius_ui"
              />
              <Input
                label="Inquiry Response Time Promise"
                type="text"
                value={inquiryResponseTime}
                onChange={(e) => setInquiryResponseTime(e.target.value)}
                placeholder="e.g., '24 hours' or '1-2 business days'"
                className="rounded-radius_ui"
              />
            </div>
          </div>

          {/* Social Media Links */}
          <div className="bg-surface p-6 rounded-radius_ui shadow">
            <h2 className="font-display text-lg text-text mb-6">Social Media Links</h2>
            <div className="space-y-4">
              <Input
                label="Instagram URL"
                type="url"
                value={instagramUrl}
                onChange={(e) => setInstagramUrl(e.target.value)}
                className="rounded-radius_ui"
              />
              <Input
                label="Facebook URL"
                type="url"
                value={facebookUrl}
                onChange={(e) => setFacebookUrl(e.target.value)}
                className="rounded-radius_ui"
              />
              {/* Add more social media inputs as needed */}
            </div>
          </div>

          {/* Admin Account Settings */}
          <div className="bg-surface p-6 rounded-radius_ui shadow">
            <h2 className="font-display text-lg text-text mb-6">Admin Account Settings</h2>
            <div className="space-y-4">
              <Dialog triggerLabel="Change Password" title="Change Admin Password">
                <p className="text-sm text-muted mb-4">
                  For security, please enter your current password before setting a new one.
                </p>
                <div className="space-y-4">
                  <Input label="Current Password" type="password" />
                  <Input label="New Password" type="password" />
                  <Input label="Confirm New Password" type="password" />
                  <Button onClick={() => alert('Password change logic here')} className="w-full">
                    Update Password
                  </Button>
                </div>
              </Dialog>
              <Input
                label="Owner Email for Notifications"
                type="email"
                value={ownerNotificationEmail}
                onChange={(e) => setOwnerNotificationEmail(e.target.value)}
                placeholder="email@example.com"
                className="rounded-radius_ui"
                description="This email will receive notifications for new inquiries and system alerts."
              />
            </div>
          </div>

          <Button onClick={handleSaveChanges} variant="default" className="w-full max-w-xs mx-auto">
            Save All Changes
          </Button>
        </div>
      </div>
    </OpsShell>
  );
}