import React, { useState } from 'react';
import { useAdminNavItems } from '@/lib/app-nav';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Input, Select, Button, ActivityFeed, UiIcon, Badge } from '@/ui';

const SKELETON_ID = "ops-detail" as const;

// Mock data for artwork details (as if fetched for editing)
const MOCK_ARTWORK_EDIT_DATA = {
  title: 'Emerald Depths',
  artist: 'Anya Aubert',
  medium: 'Oil on Canvas',
  height: 36,
  width: 24,
  year: 2023,
  description: 'A captivating oil painting that delves into the profound mysteries of the deep sea. Layers of rich greens and blues evoke a sense of calm and the boundless beauty hidden beneath the surface.',
  price: 5200,
  availabilityStatus: 'Available',
  primaryImage: 'https://images.pexels.com/photos/16397728/pexels-photo-16397728.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', // item1
  additionalImages: [
    'https://images.pexels.com/photos/3684544/pexels-photo-3684544.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', // item2
    'https://images.pexels.com/photos/1475951/pexels-photo-1475951.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' // item3
  ],
  keywords: ['Seascape', 'Abstract', 'Nature'],
  showPrice: true,
};

// Mock activity data for a specific artwork
const MOCK_ARTWORK_ACTIVITY = [
  { id: "act-1", title: "Artwork Created", detail: "by Genevieve", timestamp: "January 1, 2024" },
  { id: "act-2", title: "Status Changed", detail: "to On Hold by Anya Aubert", timestamp: "January 15, 2024" },
  { id: "act-3", title: "Price Updated", detail: "to €5200 by Anya Aubert", timestamp: "February 1, 2024" },
  { id: "act-4", title: "Primary Image Updated", detail: "Filename: emerald-depths.jpeg", timestamp: "February 10, 2024" },
  { id: "act-5", title: "Internal Note Added", detail: "Client Isabelle Dubois inquired about this piece.", timestamp: "February 12, 2024" },
];

export default function ArtworkEditPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const isNewArtwork = window.location.pathname.includes('/new-artwork');

  const [artwork, setArtwork] = useState(isNewArtwork ? {
    title: '',
    artist: 'Anya Aubert', // Pre-filled as per brief
    medium: '',
    height: undefined as number | undefined,
    width: undefined as number | undefined,
    year: undefined as number | undefined,
    description: '',
    price: undefined as number | undefined,
    availabilityStatus: 'Available',
    primaryImage: '',
    additionalImages: [] as string[],
    keywords: [] as string[],
    showPrice: true,
  } : {
    ...MOCK_ARTWORK_EDIT_DATA,
  });

  const [primaryImagePreview, setPrimaryImagePreview] = useState<string>(artwork.primaryImage);
  const [additionalImagePreviews, setAdditionalImagePreviews] = useState<string[]>(artwork.additionalImages);
  const [artworkHistory, setArtworkHistory] = useState(MOCK_ARTWORK_ACTIVITY);
  const [newNote, setNewNote] = useState('');
  const [keywordInput, setKeywordInput] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setArtwork(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setArtwork(prev => ({
      ...prev,
      [name]: checked,
    }));
  };

  const handleNumericInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setArtwork(prev => ({
      ...prev,
      [name]: value === '' ? undefined : Number(value),
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, isPrimary: boolean) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageUrl = reader.result as string;
        if (isPrimary) {
          setPrimaryImagePreview(imageUrl);
          setArtwork(prev => ({ ...prev, primaryImage: imageUrl }));
          setArtworkHistory(prev => ([
            { id: `act-${prev.length + 1}`, title: "Primary Image Uploaded", detail: file.name, timestamp: "Just now" },
            ...prev,
          ]));
        } else {
          setAdditionalImagePreviews(prev => [...prev, imageUrl]);
          setArtwork(prev => ({ ...prev, additionalImages: [...prev.additionalImages, imageUrl] }));
          setArtworkHistory(prev => ([
            { id: `act-${prev.length + 1}`, title: "Additional Image Uploaded", detail: file.name, timestamp: "Just now" },
            ...prev,
          ]));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveAdditionalImage = (indexToRemove: number) => {
    const updatedImages = additionalImagePreviews.filter((_, index) => index !== indexToRemove);
    setAdditionalImagePreviews(updatedImages);
    setArtwork(prev => ({ ...prev, additionalImages: updatedImages }));
    setArtworkHistory(prev => ([
      { id: `act-${prev.length + 1}`, title: "Additional Image Removed", detail: `Image ${indexToRemove + 1}`, timestamp: "Just now" },
      ...prev,
    ]));
  };

  const handleAddNote = () => {
    if (newNote.trim()) {
      setArtworkHistory(prev => ([
        { id: `act-${prev.length + 1}`, title: "Internal Note Added", detail: newNote, timestamp: "Just now" },
        ...prev,
      ]));
      setNewNote('');
    }
  };

  const handleAddKeyword = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && keywordInput.trim() !== '') {
      e.preventDefault();
      const newKeywords = keywordInput.split(',').map(tag => tag.trim()).filter(tag => tag !== '');
      setArtwork(prev => ({
        ...prev,
        keywords: [...new Set([...prev.keywords, ...newKeywords])], // Add unique keywords
      }));
      setKeywordInput('');
    }
  };

  const handleRemoveKeyword = (keywordToRemove: string) => {
    setArtwork(prev => ({
      ...prev,
      keywords: prev.keywords.filter(keyword => keyword !== keywordToRemove),
    }));
  };

  const handleSave = () => {
    console.log("Artwork details saved:", artwork);
    // In a real application, this would dispatch to a backend API
    setArtworkHistory(prev => ([
      { id: `act-${prev.length + 1}`, title: "Artwork Details Saved", detail: "All changes committed", timestamp: "Just now" },
      ...prev,
    ]));
    alert('Artwork details saved successfully!');
  };

  const handleCancel = () => {
    console.log("Edit cancelled.");
    // In a real application, you'd navigate back or reset the form to its initial state
    alert('Changes cancelled.');
  };

  const pageTitle = isNewArtwork ? 'Add New Artwork' : `Edit Artwork: ${artwork.title}`;

  const slots = {
    header: (
      <PageHeader
        title={pageTitle}
        actions={[
          { label: "Cancel", onClick: handleCancel, variant: "ghost" },
          { label: "Save Changes", onClick: handleSave, variant: "default" }
        ]}
      />
    ),
    table: ( // Using DataTable slot for the form as per skeleton contract
      <div className="space-y-6">
        {/* Artwork Information */}
        <div className="bg-surface p-6 rounded-[--radius-ui] shadow-sm">
          <h2 className="font-display text-xl text-text mb-4">Artwork Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Title" name="title" value={artwork.title} onChange={handleInputChange} className="col-span-2" />
            <Input label="Artist" name="artist" value={artwork.artist} disabled />
            <Input label="Medium" name="medium" value={artwork.medium} onChange={handleInputChange} placeholder="e.g., Oil on Canvas" />
            <div className="col-span-2 grid grid-cols-2 gap-4">
              <Input type="number" label="Height (in)" name="height" value={artwork.height ?? ''} onChange={handleNumericInputChange} placeholder="Height" />
              <Input type="number" label="Width (in)" name="width" value={artwork.width ?? ''} onChange={handleNumericInputChange} placeholder="Width" />
            </div>
            <Input type="number" label="Year" name="year" value={artwork.year ?? ''} onChange={handleNumericInputChange} placeholder="e.g., 2023" />
            <div className="col-span-2">
              <Input as="textarea" label="Description" name="description" value={artwork.description} onChange={handleInputChange} rows={4} placeholder="Detailed description of the artwork..." />
            </div>
            <Input type="number" label="Price (€)" name="price" value={artwork.price ?? ''} onChange={handleNumericInputChange} placeholder="e.g., 5200" />
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="showPrice"
                name="showPrice"
                checked={artwork.showPrice}
                onChange={handleCheckboxChange}
                className="rounded-[--radius-ui] border-muted text-brand focus:ring-brand"
              />
              <label htmlFor="showPrice" className="text-sm text-text">Display price publicly</label>
            </div>
            <Select
              label="Availability Status"
              name="availabilityStatus"
              options={[
                { label: 'Available', value: 'Available' },
                { label: 'On Hold', value: 'On Hold' },
                { label: 'Sold', value: 'Sold' },
              ]}
              value={artwork.availabilityStatus}
              onValueChange={(value) => setArtwork(prev => ({ ...prev, availabilityStatus: value }))}
            />
          </div>
        </div>

        {/* Image Upload & Management */}
        <div className="bg-surface p-6 rounded-[--radius-ui] shadow-sm">
          <h2 className="font-display text-xl text-text mb-4">Image Assets</h2>

          {/* Primary Image */}
          <div className="mb-6 border-b border-muted/10 pb-6">
            <label className="block text-sm font-medium text-muted mb-2">Primary Artwork Image</label>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="relative w-36 h-36 bg-background border border-muted/30 rounded-[--radius-ui] overflow-hidden flex items-center justify-center flex-shrink-0">
                {primaryImagePreview ? (
                  <>
                    <img src={primaryImagePreview} alt="Primary Artwork" className="object-cover w-full h-full" />
                    {/* Simulated Smart Image Cropping & Optimization */}
                    <div className="absolute inset-0 bg-brand/10 backdrop-blur-[1px] flex flex-col items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-200 cursor-pointer text-xs text-brand/80 p-2 text-center group">
                      <UiIcon name="scissors" className="h-5 w-5 mb-1 text-brand group-hover:scale-110 transition-transform" />
                      Optimize Image
                      <span className="sr-only"> (Simulated AI feature)</span>
                      <p className="text-[10px] text-brand/70 mt-1 italic leading-tight">AI will suggest optimal crops</p>
                    </div>
                  </>
                ) : (
                  <span className="text-muted text-sm">No Image</span>
                )}
              </div>
              <Input
                type="file"
                id="primaryImageUpload"
                onChange={(e) => handleImageUpload(e, true)}
                className="block w-full text-sm text-text file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand/10 file:text-brand hover:file:bg-brand/20 cursor-pointer"
                aria-label="Upload Primary Image"
              />
            </div>
            <p className="text-xs text-muted mt-2">Upload the main, high-resolution image for this artwork.
              <span className="italic ml-1 opacity-80"> (AI processing simulated)</span>
            </p>
          </div>

          {/* Additional Images */}
          <div>
            <label className="block text-sm font-medium text-muted mb-2">Additional Detail Images</label>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-4">
              {additionalImagePreviews.map((imgSrc, index) => (
                <div key={index} className="relative w-32 h-32 bg-background border border-muted/30 rounded-[--radius-ui] overflow-hidden group">
                  <img src={imgSrc} alt={`Additional artwork ${index + 1}`} className="object-cover w-full h-full" />
                  <div
                    className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 cursor-pointer text-white text-sm"
                    onClick={() => handleRemoveAdditionalImage(index)}
                  >
                    <UiIcon name="trash" className="h-4 w-4 mr-1" />
                    Remove
                  </div>
                </div>
              ))}
              <div className="w-32 h-32 border-2 border-dashed border-muted/30 rounded-[--radius-ui] flex items-center justify-center cursor-pointer hover:border-brand/50 transition-colors duration-200">
                <label htmlFor="additionalImageUpload" className="flex flex-col items-center justify-center text-sm text-muted cursor-pointer p-2 text-center">
                  <UiIcon name="plus" className="h-5 w-5 mb-1" />
                  Add Image
                </label>
                <Input
                  type="file"
                  id="additionalImageUpload"
                  multiple
                  onChange={(e) => handleImageUpload(e, false)}
                  className="hidden"
                  aria-label="Upload Additional Images"
                />
              </div>
            </div>
            <p className="text-xs text-muted mt-1">Add more images to showcase different angles or details of the artwork.</p>
          </div>
        </div>

        {/* Keywords/Tags */}
        <div className="bg-surface p-6 rounded-[--radius-ui] shadow-sm">
          <h2 className="font-display text-xl text-text mb-4">Keywords & Tags</h2>
          <div className="flex flex-wrap gap-2 mb-4">
            {artwork.keywords.map((keyword, index) => (
              <Badge key={index} variant="secondary" className="flex items-center gap-1">
                {keyword}
                <button
                  type="button"
                  onClick={() => handleRemoveKeyword(keyword)}
                  className="ml-1 -mr-0.5 h-4 w-4 rounded-full flex items-center justify-center text-muted hover:bg-muted/20 hover:text-text"
                  aria-label={`Remove keyword ${keyword}`}
                >
                  <UiIcon name="x" className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
          <Input
            label="Add Keywords"
            name="keywordInput"
            value={keywordInput}
            onChange={(e) => setKeywordInput(e.target.value)}
            onKeyDown={handleAddKeyword}
            placeholder="Type keyword and press Enter (e.g., Landscape, Abstract)"
          />
          <p className="text-xs text-muted mt-1">Add relevant keywords to help collectors discover this piece.</p>
        </div>
      </div>
    ),
    activity: (
      <ActivityFeed
        heading="Artwork History"
        items={artworkHistory}
      >
        <div className="mt-4 p-4 border-t border-muted/20">
          <h3 className="text-sm font-display text-text mb-2">Add Internal Note</h3>
          <Input
            as="textarea"
            placeholder="Add a private note about this artwork..."
            rows={3}
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            className="mb-2"
          />
          <Button onClick={handleAddNote} size="sm">Add Note</Button>
        </div>
      </ActivityFeed>
    ),
  };

  return (
    <OpsShell brandName={"Galerie Aubert"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page={isNewArtwork ? "admin-artwork-new" : "admin-artwork-edit"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}