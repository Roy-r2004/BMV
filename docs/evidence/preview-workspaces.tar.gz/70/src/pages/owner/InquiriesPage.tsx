// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function InquiriesPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Aubert Atelier Digital"}
        description={"Your digital storefront for Galerie Aubert."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Manage Artworks"}
            description={"Add new paintings, update details, and mark pieces as sold."}
            ctaLabel={"View Artworks"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Galerie Aubert"}
        description={"© 2024 Galerie Aubert"}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="admin-inquiries">
      </div>
      <PublicShell
      brandName={"Galerie Aubert"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
