// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed, aiFeatures } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, UiIcon, Button, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function DashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const kpisData = [
    { label: "New Inquiries", value: "3", delta: "+1", hint: "Last 7 days", icon: <UiIcon name="mail" /> },
    { label: "Available Artworks", value: "18", delta: "-2", hint: "Total in gallery", icon: <UiIcon name="image" /> },
    { label: "Artwork Views", value: "247", delta: "+15%", hint: "Last 24 hours", icon: <UiIcon name="eye" /> },
  ];

  const chartData = [
    { day: "Mon", inquiries: 5, views: 30 },
    { day: "Tue", inquiries: 7, views: 45 },
    { day: "Wed", inquiries: 6, views: 38 },
    { day: "Thu", inquiries: 9, views: 55 },
    { day: "Fri", inquiries: 8, views: 49 },
    { day: "Sat", inquiries: 12, views: 70 },
    { day: "Sun", inquiries: 10, views: 62 },
  ];

  const recentActivities = [
    { id: "activity-1", title: "New Inquiry for \"Whispering Pines\"", detail: "from Elena P.", time: "5 minutes ago" },
    { id: "activity-2", title: "Artwork \"Golden Hour\" marked 'Available'", detail: "by Genevieve", time: "1 hour ago" },
    { id: "activity-3", title: "New artwork \"City Lights\" uploaded", detail: "by Genevieve", time: "3 hours ago" },
    { id: "activity-4", title: "Inquiry for \"Ocean Breeze\" archived", detail: "by Genevieve", time: "Yesterday" },
  ];

  const tableColumns = [
    { key: "activity", header: "Activity" },
    { key: "details", header: "Details" },
    { key: "when", header: "When" },
  ];

  const tableRows = [
    { id: "tr1", activity: "New Inquiry for \"Whispering Pines\"", details: "from Elena P.", when: "Just now" },
    { id: "tr2", activity: "Artwork \"Golden Hour\" marked 'Available'", details: "by Genevieve", when: "1 hour ago" },
    { id: "tr3", activity: "New artwork \"City Lights\" uploaded", details: "by Genevieve", when: "3 hours ago" },
    { id: "tr4", activity: "Inquiry for \"Ocean Breeze\"", details: "from Marco R.", when: "Yesterday" },
  ];

  const slots = {
    header: (
      <PageHeader
        title="Aubert Atelier Digital Console"
        actions={[
          <div key="user-info" className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-brand-primary flex items-center justify-center text-background text-sm font-semibold">G</div>
            <Button variant="ghost" onClick={() => console.log('Logout clicked')}>Logout</Button>
          </div>
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {kpisData.map((kpi, index) => (
          <StatCard
            key={`kpi-${index}`}
            label={kpi.label}
            value={kpi.value}
            delta={kpi.delta}
            hint={kpi.hint}
            icon={kpi.icon}
            variant="card"
          />
        ))}
      </div>
    ),
    chart: (
      <ChartCard
        title="Artwork Views by Day"
        type="area"
        dataKey="views"
        xKey="day"
        data={chartData}
        description="Daily unique artwork views"
        insight="Views are trending up this week."
        density="comfortable"
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search activity"
        actions={[
          { label: "Add New Artwork", onClick: () => window.location.href = "/owner/artworks/new", variant: "primary" },
          { label: "View All Inquiries", onClick: () => window.location.href = "/owner/inquiries", variant: "secondary" },
          { label: "Manage Gallery Settings", onClick: () => window.location.href = "/owner/settings", variant: "ghost" },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={tableColumns}
        rows={tableRows.map(row => ({
          ...row,
          activity: <span className="font-medium text-text">{row.activity}</span>,
          details: <span className="text-muted">{row.details}</span>,
          when: <span className="text-muted">{row.when}</span>,
        }))}
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={recentActivities.map(activity => ({
          id: activity.id,
          title: activity.title,
          detail: activity.detail,
          time: activity.time,
        }))}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Galerie Aubert"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
          <div id="smart-image-cropping-optimization" data-ai-feature-panel="smart-image-cropping-optimization">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "smart-image-cropping-optimization") || { id: "smart-image-cropping-optimization", name: "smart-image-cropping-optimization" }}
          brandName={"Galerie Aubert"}
        />
      </div>
          <div id="inquiry-intent-classifier" data-ai-feature-panel="inquiry-intent-classifier">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "inquiry-intent-classifier") || { id: "inquiry-intent-classifier", name: "inquiry-intent-classifier" }}
          brandName={"Galerie Aubert"}
        />
      </div>
    </OpsShell>
  );
}