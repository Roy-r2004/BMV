// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, Input } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function LoginPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Aubert Atelier Digital"}
        description={"Secure access for Galerie Aubert owners."}
      />
    ),
    workspace: (
      <Card className="mx-auto w-full max-w-md space-y-4 p-6">
          <Input
            label={"Email"}
            type={"email"}
            placeholder={"you@example.com"}
          />
          <Input
            label={"Password"}
            type={"password"}
            placeholder={"••••••••"}
          />
          <Button className="w-full">{"Login"}</Button>
          <p className="text-center text-sm text-muted">
            {"Enter your credentials to manage your gallery and artworks."}
          </p>
        </Card>
    ),
    footer: (
      <BrandFooter
        brandName={"Galerie Aubert"}
        description={"© 2024 Galerie Aubert. All rights reserved."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="admin-login">
      </div>
      <PublicShell
      brandName={"Galerie Aubert"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"auth"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
