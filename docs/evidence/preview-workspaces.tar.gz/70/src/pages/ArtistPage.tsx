// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-service" as const;
const RECIPE_ORDER = ["hero", "features", "testimonials", "cta", "footer"] as const;

export default function ArtistPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Galerie Aubert"}
        headline={"Anya Aubert: The Artist"}
        subcopy={"Vision and Craft"}
        primaryCta={{ label: "View All Artworks", href: "/collection" }}
        imageSrc={images.hero2 || images.ambient}
        imageAlt="Anya Aubert in her studio, surrounded by her paintings"
        className="h-[60vh] max-h-[800px] flex items-end pb-16"
      />
    ),
    features: (
      <FeatureBento
        heading="A Journey in Oil"
        description="Explore the rich narrative behind Anya Aubert's captivating works."
        imagePool={[images.card1, images.card2, images.card3, images.ambient]}
        items={[
          {
            title: "Biography: A Life Dedicated to Light",
            description: `Born in the artistic heart of Provence, Anya Aubert's journey into painting began at an early age. Her formative years were spent immersed in the vibrant hues and sun-drenched landscapes of southern France, which profoundly shaped her understanding of light and color. After formal training at the École des Beaux-Arts in Paris, Anya refined her classical techniques, embracing the rigorous discipline of traditional oil painting while developing a distinctive modern voice. Her work is a testament to a lifelong pursuit of beauty and a deep connection to the natural world.`,
            imageSrc: images.card1,
            imageAlt: "Anya Aubert working on a painting in her studio",
          },
          {
            title: "Artistic Vision: Echoes of Nature",
            description: `Anya's canvases are an invitation to slow down and observe the subtle dance of light and shadow. "My art is an exploration of the ephemeral," she states. "I seek to capture those fleeting moments in nature – the way light filters through leaves, the quiet dignity of an old tree, the rhythmic motion of water." Her distinctive brushwork and meticulous layering of oil paint create a tactile quality, drawing the viewer into a contemplative space. Themes of resilience, introspection, and the sublime power of the landscape are woven throughout her body of work, inviting a personal dialogue with each piece.`,
            imageSrc: images.ambient,
            imageAlt: "Detail of an oil painting by Anya Aubert",
          },
          {
            title: "Selected Exhibitions & Recognitions",
            description: `
              <p><strong>2023</strong> – 'Solstice Reverie,' Galerie Montaigne, Paris</p>
              <p><strong>2021</strong> – 'Lumière Provençale,' Aubert Atelier, Saint-Rémy-de-Provence</p>
              <p><strong>2019</strong> – Award for Landscape Painting, Salon des Artistes Français</p>
              <p><strong>2017</strong> – Group Exhibition, Royal Academy of Arts, London</p>
              <p><strong>2015</strong> – 'Whispers of the Land,' Galerie Beaux Arts, New York</p>
            `,
            imageSrc: images.card3,
            imageAlt: "Gallery interior with Anya Aubert's paintings on display",
          },
        ]}
        className="py-16 md:py-24"
      />
    ),
    testimonials: (
      // This slot is required by the skeleton but not explicitly requested in the brief
      // for this page. We'll render an empty TestimonialRail to satisfy the contract.
      // If client feedback indicates a need for testimonials here, they can be added.
      <TestimonialRail heading="Collector Perspectives" items={[]} />
    ),
    cta: (
      <CTABand
        heading={"Experience Anya's work firsthand."}
        primaryCta={{ label: "View All Artworks", href: "/collection" }}
        className="py-16"
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Galerie Aubert"}
        description={"Galerie Aubert — original works, shown plainly."}
        links={[
          { label: "Collection", href: "/collection" },
          { label: "The Artist", href: "/artist" },
          { label: "Contact", href: "/contact" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Galerie Aubert"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="artist">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}