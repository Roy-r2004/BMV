// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Contact Galerie Aubert"}
        description={"We welcome your inquiries about our collection, the artist, or studio visits."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"General Inquiries"}
            description={"Have a general question or comment not related to a specific artwork?"}
            ctaLabel={"Send a Message"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Galerie Aubert"}
        description={"© 2024 Galerie Aubert. All rights reserved."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="contact">
      </div>
      <PublicShell
      brandName={"Galerie Aubert"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
          <div id="artwork-description-assistant" data-ai-feature-panel="artwork-description-assistant">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "artwork-description-assistant") || { id: "artwork-description-assistant", name: "artwork-description-assistant" }}
          brandName={"Galerie Aubert"}
        />
      </div>
    </PublicShell>
    </>
  );
}
