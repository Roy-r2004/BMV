// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function PrivacyPolicyPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Privacy Policy"}
        description={"At Aubert Atelier Digital, we are committed to protecting your privacy. This policy outlines how we collect, use, and safeguard your personal information when you visit our website or interact with our services."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Data Collection"}</h3>
            <p className="text-sm leading-6 text-muted">{"We collect information you provide when you submit inquiries (name, email, message) and automatically gather technical data (IP address, browser type) to improve site functionality. We do not collect sensitive personal data."}</p>
            <Button href={"/privacy#data-collection"} className="mt-auto w-fit">
              {"Learn More"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"How We Use Your Data"}</h3>
            <p className="text-sm leading-6 text-muted">{"Your information is used to respond to inquiries, process requests, improve our website, and ensure the security of our services. We do not sell your data to third parties."}</p>
            <Button href={"/privacy#data-usage"} className="mt-auto w-fit">
              {"Our Practices"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Data Security & Retention"}</h3>
            <p className="text-sm leading-6 text-muted">{"We implement robust security measures to protect your data. We retain personal information only for as long as necessary to fulfill the purposes for which it was collected or as required by law."}</p>
            <Button href={"/privacy#security"} className="mt-auto w-fit">
              {"Security Details"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Your Rights"}</h3>
            <p className="text-sm leading-6 text-muted">{"You have the right to access, correct, or request deletion of your personal data. Contact us to exercise these rights or for any privacy-related concerns."}</p>
            <Button href={"/contact"} className="mt-auto w-fit">
              {"Contact Us"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Galerie Aubert"}
        description={"This policy may be updated periodically. We encourage you to review it regularly. Last updated: October 26, 2023."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="privacy">
      </div>
      <PublicShell
      brandName={"Galerie Aubert"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"generic"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
