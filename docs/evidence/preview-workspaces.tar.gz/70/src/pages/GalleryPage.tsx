// directory listing scaffold — distinct from home marketing clone
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, PublicNav, PageHeader, CatalogGrid, CTABand, BrandFooter } from '@/ui';

// One catalogue for the whole app: `seed.items` is what the detail route resolves
// against, so a listing that invents its own array links every card to a page
// that renders "not found". `BRAND_MANIFEST.services` used to be read here and
// does not exist at that level — `tsc` reported it as TS2339 and the array below
// fell through to three hardcoded doctors on every business that took this path.
const catalogue: any[] = Array.isArray((seed as any).items) ? (seed as any).items : [];
const offerings: any[] = Array.isArray((seed as any).services) ? (seed as any).services : [];
const entries: any[] = catalogue.length ? catalogue : offerings;
const IMAGE_POOL = [images.item1, images.item2, images.item3, images.item4, images.item5, images.item6, images.item7, images.item8];
const LISTING_BASE = "/gallery";

export default function GalleryPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  // CatalogGrid renders every entry and links each into LISTING_BASE/:id.
  // ProductShowcase used to fill this slot and silently showed only three.
  const people = entries.map((s: any, i: number) => ({
    id: String(s.id || s.slug || i + 1),
    title: String(s.name || s.title || "Galerie Aubert" + ' ' + (i + 1)),
    description: String(s.description || s.specialty || s.role || ''),
    imageSrc: String(s.image || s.imageSrc || IMAGE_POOL[i % IMAGE_POOL.length]),
    imageAlt: String(s.name || s.title || 'Item'),
    meta: s.medium ? String(s.medium) : undefined,
    category: s.category ? String(s.category) : undefined,
    badge: s.badge ? String(s.badge) : undefined,
    status: s.status ? String(s.status) : undefined,
    // Written out per item with the target inlined, not left to CatalogGrid's
    // `detailBase` derivation: the journey walk reads links, and a page that only
    // named its base in a const looked like a browse face with no way out of it.
    href: `/gallery/${String(s.slug || s.id || i + 1)}`,
  }));

  return (
    <PublicShell brandName={"Galerie Aubert"} chrome="solid" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton="public-catalog" data-appspec-page="gallery">

      <div className="mx-auto w-full max-w-[92rem] px-6 pt-28 pb-10 lg:px-12 lg:pt-32 lg:pb-14">
        <PageHeader
          title={"Gallery"}
          description="Browse pieces and details — then inquire about availability."
        />
      </div>
      <CatalogGrid
        heading=""
        description="Each card opens a closer look. Inquire when you are ready."
        detailBase={LISTING_BASE}
        itemNoun="pieces"
        items={people}
      />
      <CTABand
        heading="Interested in a piece?"
        description="Ask about availability, commissions, or a studio visit."
        primaryCta={{ label: "Browse the collection", href: "#catalog" }}
        secondaryCta={{ label: "Back home", href: "/" }}
      />
      <BrandFooter brandName={"Galerie Aubert"} description="Browse the collection. Inquire when a piece speaks to you." />
      </div>
    </PublicShell>
  );
}
