// composed confirmation page (ConfirmStage)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, BrandFooter, ConfirmStage } from '@/ui';

export default function InquiryConfirmationPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();

  return (
    <>
      <div className="contents" data-appspec-page="inquiry-confirmation">
      </div>
      <PublicShell
      brandName={"Galerie Aubert"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <ConfirmStage
        eyebrow={"Confirmed"}
        title={"Inquiry Sent"}
        detail={"Confirmation on file"}
        description={"Thank you for your interest in Galerie Aubert. Your message has been received."}
        primaryCta={{"label": "Back to home", "href": "/"}}
        nextSteps={[{"title": "Confirmation", "description": "We appreciate you reaching out. We will review your inquiry and respond as soon as possible.", "ctaLabel": "Back to Collection", "href": "/collection"}, {"title": "Explore More Artworks", "description": "Discover other captivating oil paintings by our featured artist.", "ctaLabel": "View All Paintings", "href": "/collection"}, {"title": "Learn About the Artist", "description": "Dive deeper into the inspiration and biography of the artist.", "ctaLabel": "Artist Bio", "href": "/artist"}]}
      />
      <BrandFooter
        brandName={"Galerie Aubert"}
        description={"© 2024 Galerie Aubert. All Rights Reserved."}
      />
    </PublicShell>
    </>
  );
}
