export const brand = {
  name: "Galerie Aubert",
  tagline: "Showcasing original oil paintings and connecting collectors with art, effortlessly.",
  design_system: {
    primary_color: "#0f766e",
    secondary_color: "#0369a1",
    background_color: "#f8fafc",
    surface_color: "#ffffff",
    text_color: "#1c1917",
    muted_text_color: "#78716c",
    font_family: "Source Sans 3",
    display_font_family: "Fraunces",
    font_import_url:
      "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
    font_display: '"Fraunces", Georgia, serif',
    brand_locked: true,
    brand_brief_version: "1.0",
    mood: "modern",
    voice: "Confident and sparse. Let materials and type carry the tone.",
    signature: "Editorial asymmetry and display type that could only belong to Galerie Aubert.",
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    recipe_id: "editorial",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    recipe_prompt:
      "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    style_keywords: "Editorial · Warm paper",
    border_radius: "0.87rem",
    design_overlay_id: "warm_paper",
    design_overlay_label: "Warm paper",
    design_overlay_blurb: "Service warmth — paper surfaces, friendly radius, soft glow.",
    density: "comfortable",
    token_overrides: {
      radius_ui: "0.87rem",
      bg_mix: "5%",
      fg_mix: "40%",
      muted_mix: "30%",
      border_mix: "14%",
      shadow: "0 26px 52px -38px",
      shadow_alpha: "30%",
      glow: "10%",
      card: "#fffdf9",
      atmosphere:
        "radial-gradient(85% 50% at 100% 0%, color-mix(in srgb, var(--color-accent) 12%, transparent), transparent 55%), linear-gradient(165deg, #fffaf4 0%, color-mix(in srgb, var(--color-brand) 5%, #f7f1ea) 50%, #faf7f2 100%)",
    },
    font_import:
      "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700",
    design_brief_version: "1.0",
    design_brief_sealed: true,
  },

  services: [{"name": "Galerie Aubert Signature", "title": "Galerie Aubert Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Galerie Aubert experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Galerie Aubert experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Galerie", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Galerie Aubert clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/1973739/pexels-photo-1973739.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/22690827/pexels-photo-22690827.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/7718455/pexels-photo-7718455.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/36764894/pexels-photo-36764894.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/36766903/pexels-photo-36766903.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/26195107/pexels-photo-26195107.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item1": "https://images.pexels.com/photos/16397728/pexels-photo-16397728.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item2": "https://images.pexels.com/photos/3684544/pexels-photo-3684544.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item3": "https://images.pexels.com/photos/1475951/pexels-photo-1475951.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item4": "https://images.pexels.com/photos/1530709/pexels-photo-1530709.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item5": "https://images.pexels.com/photos/15377378/pexels-photo-15377378.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item6": "https://images.pexels.com/photos/16397723/pexels-photo-16397723.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item7": "https://images.pexels.com/photos/1023767/pexels-photo-1023767.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item8": "https://images.pexels.com/photos/1414327/pexels-photo-1414327.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "collection",
      "path": "/collection",
      "href": "/collection",
      "label": "Collection"
    },
    {
      "id": "privacy",
      "path": "/privacy",
      "href": "/privacy",
      "label": "Privacy"
    },
    {
      "id": "artist",
      "path": "/artist",
      "href": "/artist",
      "label": "Artist · Anya"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-login",
      "path": "/owner/login",
      "href": "/owner/login",
      "label": "Login"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-artworks",
      "path": "/owner/artworks",
      "href": "/owner/artworks",
      "label": "Artworks"
    },
    {
      "id": "owner-artworks-new",
      "path": "/owner/artworks/new",
      "href": "/owner/artworks/new",
      "label": "New"
    },
    {
      "id": "owner-inquiries",
      "path": "/owner/inquiries",
      "href": "/owner/inquiries",
      "label": "Inquiries"
    },
    {
      "id": "owner-settings",
      "path": "/owner/settings",
      "href": "/owner/settings",
      "label": "Settings"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "collection",
      "path": "/collection",
      "href": "/collection",
      "label": "Collection"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "inquiry-confirmation",
      "path": "/inquiry-confirmation",
      "href": "/inquiry-confirmation",
      "label": "Inquiry Confirmation"
    },
    {
      "id": "privacy",
      "path": "/privacy",
      "href": "/privacy",
      "label": "Privacy"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    }
  ],
  "owner": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-login",
      "path": "/owner/login",
      "href": "/owner/login",
      "label": "Login"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-artworks",
      "path": "/owner/artworks",
      "href": "/owner/artworks",
      "label": "Artworks"
    },
    {
      "id": "owner-artworks-new",
      "path": "/owner/artworks/new",
      "href": "/owner/artworks/new",
      "label": "New"
    },
    {
      "id": "owner-inquiries",
      "path": "/owner/inquiries",
      "href": "/owner/inquiries",
      "label": "Inquiries"
    },
    {
      "id": "owner-settings",
      "path": "/owner/settings",
      "href": "/owner/settings",
      "label": "Settings"
    }
  ]
};

export const roles = [
  {
    "id": "customer",
    "label": "Collector",
    "defaultPath": "/collection",
    "icon": "users"
  },
  {
    "id": "owner",
    "label": "Gallery Owner",
    "defaultPath": "/owner/dashboard",
    "icon": "chart"
  }
];

export const seed = {
  featuresHeading: 'What Galerie Aubert offers',
  showcaseHeading: 'From Galerie Aubert',
  credentialsHeading: 'Why Galerie Aubert',
  trustLabels: [
    'Galerie Aubert quality\', \'On schedule\', \'Repeat guests\', \'Local favorite',
  ],
  hero: {
    headline: "Discover Original Oil Paintings by Anya Aubert",
    subcopy:
      "Explore a curated collection of original oil paintings, each a unique expression of color, light, and narrative. Connect directly with the gallery for acquisitions and studio visits.",
    primaryCta: {
      label: "View Collection",
      href: "/collection",
    },
    secondaryCta: {
      label: "About the Artist",
      href: "/artist",
    },
  },
  features: [
    {
      title: "Exquisite Detail",
      description: "Experience each brushstroke with high-resolution imagery and zoom capabilities.",
    },
    {
      title: "Seamless Inquiry",
      description: "Connect directly with the gallery for purchase or studio visit arrangements.",
    },
    {
      title: "Curated Collection",
      description: "Browse a thoughtfully presented selection of original oil paintings.",
    },
  ],
  credentials: [
    { title: "Original Artworks", detail: "Every piece is a unique creation by Anya Aubert." },
    { title: "Direct Artist Representation", detail: "Connect directly with the gallery." },
    { title: "Secure Inquiries", detail: "Your privacy is our priority." },
  ],
  testimonials: [
    {
      quote: "The online gallery captures the essence of the paintings beautifully. My recent acquisition is even more stunning in person.",
      author: "Isabelle Dubois",
      role: "Collector",
    },
    {
      quote: "The inquiry process was so smooth, and the follow-up from Galerie Aubert was prompt and personal. A true pleasure.",
      author: "Marc Lefevre",
      role: "Collector",
    },
    {
      quote: "I appreciate the detailed information provided for each artwork. It truly enhances the viewing experience from home.",
      author: "Sophie Moreau",
      role: "Collector",
    },
  ],
  cta: {
    heading: "Elevate Your Space with Original Art",
    description: "Find the perfect piece to inspire and captivate. Reach out to Galerie Aubert today.",
    primaryLabel: "View Collection",
    primaryHref: "/collection",
    secondaryLabel: "Contact Us",
    secondaryHref: "/contact",
  },
  footer: {
    description: "Galerie Aubert – Passionate about connecting art with collectors.",
  },
  opsHero: {
    headline: "Aubert Atelier Digital Console",
    subcopy: "Manage your collection, review inquiries, and oversee your digital gallery operations.",
  },
  kpis: [
    { label: "New Inquiries", value: "3", delta: "+1", hint: "Last 7 days" },
    { label: "Available Artworks", value: "18", delta: "-2", hint: "Total in gallery" },
    { label: "Artwork Views", value: "247", delta: "+15%", hint: "Last 24 hours" },
  ],
  items: [
    {
      id: "emerald-depths",
      title: "Emerald Depths",
      medium: "Oil on Linen",
      dimensions: '30" x 40"',
      year: 2023,
      price: "Inquire",
      status: "Available",
      category: "Abstract Landscapes",
      description: "A dynamic interplay of deep greens and blues, evoking the mystery of ancient forests.",
      image: images.item1,
    },
    {
      id: "golden-hour",
      title: "Golden Hour on the Loire",
      medium: "Oil on Canvas",
      dimensions: '24" x 36"',
      year: 2022,
      price: "Inquire",
      status: "Available",
      category: "Landscapes",
      description: "Warm light washing over the riverbanks, capturing the serene beauty of a French sunset.",
      image: images.item2,
    },
    {
      id: "urban-reflection-i",
      title: "Urban Reflection I",
      medium: "Oil on Board",
      dimensions: '18" x 24"',
      year: 2023,
      price: "Inquire",
      status: "Available",
      category: "Cityscapes",
      description: "The city's vibrant energy mirrored in a rain-slicked street, a modern urban meditation.",
      image: images.item3,
    },
    {
      id: "whispering-pines",
      title: "Whispering Pines",
      medium: "Oil on Linen",
      dimensions: '36" x 48"',
      year: 2021,
      price: "Inquire",
      status: "On Hold",
      category: "Landscapes",
      description: "Tall pines sway in a gentle breeze, their soft whispers echoing through a tranquil forest.",
      image: images.item4,
    },
    {
      id: "coastal-serenity",
      title: "Coastal Serenity",
      medium: "Oil on Canvas",
      dimensions: '20" x 28"',
      year: 2022,
      price: "Inquire",
      status: "Available",
      category: "Seascapes",
      description: "A calming scene of the ocean meeting the shore, with soft waves and distant horizons.",
      image: images.item5,
    },
    {
      id: "sunrise-over-the-mesa",
      title: "Sunrise Over the Mesa",
      medium: "Oil on Panel",
      dimensions: '12" x 16"',
      year: 2023,
      price: "Inquire",
      status: "Sold",
      category: "Landscapes",
      description: "The dramatic light of dawn painting the rugged desert landscape in hues of orange and red.",
      image: images.item6,
    },
    {
      id: "city-lights-abstract",
      title: "City Lights Abstract",
      medium: "Oil on Canvas",
      dimensions: '40" x 30"',
      year: 2023,
      price: "Inquire",
      status: "Available",
      category: "Abstract",
      description: "A vibrant abstract composition capturing the dazzling, blurred lights of a bustling city night.",
      image: images.item7,
    },
    {
      id: "port-de-marseille",
      title: "Port de Marseille",
      medium: "Oil on Linen",
      dimensions: '24" x 36"',
      year: 2022,
      price: "Inquire",
      status: "Available",
      category: "Cityscapes",
      description: "The historic port city at dusk, with boats gently rocking and city lights beginning to glow.",
      image: images.item8,
    },
    {
      id: "lavender-fields-provence",
      title: "Lavender Fields, Provence",
      medium: "Oil on Canvas",
      dimensions: '20" x 28"',
      year: 2021,
      price: "Inquire",
      status: "Available",
      category: "Landscapes",
      description: "An iconic view of the fragrant lavender fields under the warm Provençal sun.",
      image: images.card1,
    },
    {
      id: "still-life-with-pears",
      title: "Still Life with Pears",
      medium: "Oil on Panel",
      dimensions: '12" x 12"',
      year: 2023,
      price: "Inquire",
      status: "Available",
      category: "Still Life",
      description: "A classic still life composition, showcasing the subtle textures and colors of ripe pears.",
      image: images.card2,
    },
    {
      id: "forest-edge-path",
      title: "Forest Edge Path",
      medium: "Oil on Linen",
      dimensions: '30" x 24"',
      year: 2022,
      price: "Inquire",
      status: "Available",
      category: "Landscapes",
      description: "A secluded path winding through the dappled light at the edge of a deep forest.",
      image: images.card3,
    },
  ],
  tableRows: [
    {
      id: "inq-001",
      artwork: "Emerald Depths",
      sender: "Elara Vance",
      email: "elara.v@example.com",
      status: "New",
      date: "2024-07-28",
      time: "10:30 AM",
      intent: "Purchase Interest",
    },
    {
      id: "inq-002",
      artwork: "Urban Reflection I",
      sender: "Marcus Thorne",
      email: "m.thorne@example.com",
      status: "Replied",
      date: "2024-07-27",
      time: "03:15 PM",
      intent: "Studio Visit Request",
    },
    {
      id: "inq-003",
      artwork: "Whispering Pines",
      sender: "Sophia Rossi",
      email: "sophia.r@example.com",
      status: "New",
      date: "2024-07-28",
      time: "11:45 AM",
      intent: "Purchase Interest",
    },
    {
      id: "inq-004",
      artwork: "Coastal Serenity",
      sender: "David Chen",
      email: "david.c@example.com",
      status: "Archived",
      date: "2024-07-26",
      time: "09:00 AM",
      intent: "General Question",
    },
    {
      id: "inq-005",
      artwork: "Golden Hour on the Loire",
      sender: "Lena Petrova",
      email: "lena.p@example.com",
      status: "New",
      date: "2024-07-28",
      time: "09:10 AM",
      intent: "Purchase Interest",
    },
    {
      id: "inq-006",
      artwork: "Sunrise Over the Mesa",
      sender: "Anand Singh",
      email: "anand.s@example.com",
      status: "Replied",
      date: "2024-07-25",
      time: "01:20 PM",
      intent: "Purchase Interest",
    },
    {
      id: "inq-007",
      artwork: "City Lights Abstract",
      sender: "Chloe Dubois",
      email: "chloe.d@example.com",
      status: "New",
      date: "2024-07-28",
      time: "02:00 PM",
      intent: "General Question",
    },
    {
      id: "inq-008",
      artwork: "Port de Marseille",
      sender: "Olivier Moreau",
      email: "o.moreau@example.com",
      status: "Archived",
      date: "2024-07-24",
      time: "04:50 PM",
      intent: "Studio Visit Request",
    },
    {
      id: "inq-009",
      artwork: "Lavender Fields, Provence",
      sender: "Isabelle Dupont",
      email: "i.dupont@example.com",
      status: "New",
      date: "2024-07-28",
      time: "08:00 AM",
      intent: "Purchase Interest",
    },
    {
      id: "inq-010",
      artwork: "Still Life with Pears",
      sender: "Felix Grand",
      email: "f.grand@example.com",
      status: "New",
      date: "2024-07-27",
      time: "06:00 PM",
      intent: "General Question",
    },
  ],
  activity: [
    {
      title: "New Inquiry for 'Whispering Pines'",
      detail: "From Sophia Rossi (sophia.r@example.com)",
      when: "5 minutes ago",
    },
    {
      title: "Artwork 'Golden Hour on the Loire' marked as 'Available'",
      detail: "Updated by Genevieve Aubert",
      when: "1 hour ago",
    },
    {
      title: "New artwork 'City Lights Abstract' uploaded",
      detail: "Dimensions, medium, year added.",
      when: "3 hours ago",
    },
    {
      title: "Replied to inquiry for 'Urban Reflection I'",
      detail: "Status changed to 'Replied' for Marcus Thorne.",
      when: "Yesterday, 3:30 PM",
    },
    {
      title: "Artwork 'Sunrise Over the Mesa' marked as 'Sold'",
      detail: "Updated by Genevieve Aubert",
      when: "2 days ago",
    },
  ],
  services: [
    {
      name: "Original Oil Paintings",
      description: "Discover a curated collection of original oil paintings.",
      duration: null,
      badge: "Available Works"
    },
    {
      name: "Artist Portfolio",
      description: "Explore the complete portfolio of the featured artist.",
      duration: null,
      badge: "The Artist"
    },
    {
      name: "Private Viewings",
      description: "Arrange a studio visit to experience art firsthand.",
      duration: null,
      badge: "Inquire Now"
    }
  ],
};

export const stats = [
  { label: "New Inquiries", value: "3", delta: "+1", hint: "Last 7 days" },
  { label: "Available Artworks", value: "18", delta: "-2", hint: "Total in gallery" },
  { label: "Artwork Views", value: "247", delta: "+15%", hint: "Last 24 hours" },
  { label: "Sold Artworks (YTD)", value: "5", delta: "+1", hint: "This year" },
  { label: "Unique Visitors", value: "897", delta: "+8%", hint: "Last month" },
  { label: "Website Conversion", value: "1.2%", delta: "-0.1%", hint: "Inquiries / Visits" },
];

export const aiFeatures = [
  {
    id: "smart-image-cropping-optimization",
    name: "Smart Image Cropping & Optimization",
    description:
      "Automatically suggests optimal crops for thumbnail and detail views, and compresses images for faster loading without sacrificing visual quality.",
    category: "ops",
    surface: "ops",
    demo_hint: "Route ops work the way Galerie Aubert runs",
    demo_prompts: [
      "Triage new requests about yet user",
      "Assign an owner for this or arrange issue",
      "What should the Galerie Aubert team do next?",
    ],
    demo_results: {
      "Triage new requests about yet user":
        "Routed “Triage new requests about yet user” → queue + owner + checklist for yet user. Status: In progress.",
      "Assign an owner for this or arrange issue":
        "Assigned “Assign an owner for this or arrange issue” to the best available owner with a or arrange checklist and due time today.",
      "What should the Galerie Aubert team do next?":
        "Next for Galerie Aubert: clear the yet user backlog, confirm or arrange, then review tonight's handoff.",
    },
    placement_label: "Ops AI",
    placement_path: "/owner/dashboard",
    placement_component: "src/pages/owner/DashboardPage.tsx",
    placement_title: "Dashboard · Aubert Atelier Digital",
  },
  {
    id: "inquiry-intent-classifier",
    name: "Inquiry Intent Classifier",
    description:
      'Automatically categorizes incoming inquiries (e.g., "Purchase Interest," "Studio Visit Request," "General Question") to help the owner prioritize responses.',
    category: "scoring",
    surface: "scoring",
    demo_hint: "Score a lead the way Galerie Aubert would",
    demo_prompts: [
      "Score this inquiry about Inquiry Intent Classifier",
      "Who should we call first about yet user?",
      "Rank today's leads for Galerie Aubert",
    ],
    demo_results: {
      "Score this inquiry about Inquiry Intent Classifier":
        "Score 86/100 for “Score this inquiry about Inquiry Intent Classifier” — high intent on Inquiry Intent Classifier. Suggested next step: call within 2 hours.",
      "Who should we call first about yet user?":
        "Call first: the lead asking about yet user. Reason: urgency + fit with Galerie Aubert's core offer.",
      "Rank today's leads for Galerie Aubert":
        "Lead ranking for Galerie Aubert: 1) Inquiry Intent Classifier inquiry 2) yet user follow-up 3) browse-only. Focus staff time on the top two.",
    },
    placement_label: "Lead scoring",
    placement_path: "/owner/dashboard",
    placement_component: "src/pages/owner/DashboardPage.tsx",
    placement_title: "Dashboard · Aubert Atelier Digital",
  },
  {
    id: "artwork-description-assistant",
    name: "Artwork Description Assistant",
    description:
      "Suggests evocative descriptive phrases or keywords for artwork titles and descriptions based on image analysis and existing art terminology.",
    category: "chat",
    surface: "chat",
    demo_hint: "Ask the way a real guest would ask Galerie Aubert",
    demo_prompts: [
      "What should I know about yet user?",
      "How does or arrange work at Galerie Aubert?",
      "Can beginners join a studio visit this week?",
    ],
    demo_results: {
      "What should I know about yet user?":
        "Galerie Aubert: For “What should I know about yet user?” — Suggests evocative descriptive phrases or keywords for artwork titles and descriptions based on image analysis and existing art terminology Here’s the short answer, what to prepare, and when a human should join.",
      "How does or arrange work at Galerie Aubert?":
        "Galerie Aubert: “How does or arrange work at Galerie Aubert?” — we walk guests through or arrange step by step, including timing, cost cues, and the next action to take.",
      "Can beginners join a s":
        "Galerie Aubert: “Can beginners join a studio visit this week?” — yes! We offer beginner-friendly studio visits. Here's what to expect and how to book.",
    },
    placement_label: "Customer assistant",
    placement_path: "/ai-features",
    placement_component: "src/pages/AiFeaturesPage.tsx",
    placement_title: "AI Features · Aubert Atelier Digital",
  },
];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;