export const brand = {
  name: 'Jeanne Kassab Art',
  tagline: 'Discover original oil paintings, crafted by hand in Lebanon, for a serene and curated gallery experience.',
  design_system: {
    primary_color: '#0f766e',
    secondary_color: '#0369a1',
    background_color: '#f8fafc',
    surface_color: '#ffffff',
    text_color: '#1c1917',
    muted_text_color: '#78716c',
    font_family: 'Source Sans 3',
    display_font_family: 'Fraunces',
    font_import_url:
      'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap',
    font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
    font_display: '"Fraunces", Georgia, serif',
    brand_locked: true,
    brand_brief_version: '1.0',
    mood: 'modern',
    voice: 'Confident and sparse. Let materials and type carry the tone.',
    signature: 'Editorial asymmetry and display type that could only belong to Jeanne Kassab Art.',
    avoid: [
      'purple-on-white or purple-to-indigo default themes',
      'Inter / Roboto / Arial as the display face',
      'card grids in the hero',
      'generic SaaS marketing copy',
      'inventing a second palette per page',
    ],
    rules: [
      'Every page inherits this palette and type stack via CSS tokens only.',
      'Use bg-brand / text-brand / font-display — never hardcode hex colors.',
      'First viewport must feature the brand name as a hero-level signal.',
    ],
    recipe_id: 'editorial',
    hub_variant: 'marketing',
    hero_variant: 'editorial',
    feature_variant: 'alternating',
    recipe_prompt:
      'RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.',
    style_keywords: 'Editorial · Bold ink',
    border_radius: '0.31rem',
    design_overlay_id: 'bold_ink',
    design_overlay_label: 'Bold ink',
    design_overlay_blurb: 'High-contrast retail energy — sharp type, punchy surfaces.',
    density: 'punchy',
    token_overrides: {
      radius_ui: '0.31rem',
      bg_mix: '6%',
      fg_mix: '48%',
      muted_mix: '34%',
      border_mix: '18%',
      shadow: '0 20px 40px -28px',
      shadow_alpha: '40%',
      glow: '9%',
      card: '#ffffff',
      atmosphere:
        'linear-gradient(135deg, color-mix(in srgb, var(--color-brand) 14%, #0f172a) 0%, transparent 42%), radial-gradient(70% 50% at 100% 0%, color-mix(in srgb, var(--color-accent) 18%, transparent), transparent 55%), linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%)',
    },
    font_import:
      'Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700',
    design_brief_version: '1.0',
    design_brief_sealed: true,
  },

  services: [{"name": "Jeanne Kassab Art Signature", "title": "Jeanne Kassab Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jeanne Kassab Art clients.",
};

export const images = {
  hero: 'https://images.unsplash.com/photo-1549880338-65ddcdfd017b?auto=format&fit=crop&q=80&w=2670&h=1000&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  hero2:
    'https://images.unsplash.com/photo-1551434678-e076c223a691?w=1400&h=800&q=80&fit=crop&auto=format&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  card1:
    'https://images.unsplash.com/photo-1579738541097-f5424756b10d?auto=format&fit=crop&q=80&w=600&h=400&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  card2:
    'https://images.unsplash.com/photo-1628178122394-ae9d53c617dc?auto=format&fit=crop&q=80&w=600&h=400&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  card3:
    'https://images.unsplash.com/photo-1629864228994-0cf53e5e49e5?auto=format&fit=crop&q=80&w=600&h=400&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  ambient:
    'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=700&q=80&fit=crop&auto=format',
  detailMain:
    'https://images.unsplash.com/photo-1579738541097-f5424756b10d?auto=format&fit=crop&q=80&w=1200&h=800&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', // A specific image for the ArtworkDetailPage main image
};

export const roles = [
  {
    "id": "ROLE-VISITOR",
    "label": "Site Visitor",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "ROLE-ARTIST",
    "label": "Jeanne Kassab (Artist)",
    "defaultPath": "/admin/dashboard",
    "icon": "palette"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Homepage"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    },
    {
      "id": "gallery-v2",
      "path": "/gallery/v2",
      "href": "/gallery/v2",
      "label": "Artwork Detail Page"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery Page"
    }
  ],
  "admin": [
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-artwork",
      "path": "/admin/artwork",
      "href": "/admin/artwork",
      "label": "Admin Artwork Edit Page"
    },
    {
      "id": "admin-about",
      "path": "/admin/about",
      "href": "/admin/about",
      "label": "Admin About Page Edit"
    }
  ],
  "ROLE-VISITOR": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Homepage"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    },
    {
      "id": "gallery-v2",
      "path": "/gallery/v2",
      "href": "/gallery/v2",
      "label": "Artwork Detail Page"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery Page"
    }
  ],
  "ROLE-ARTIST": [
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-artwork",
      "path": "/admin/artwork",
      "href": "/admin/artwork",
      "label": "Admin Artwork Edit Page"
    },
    {
      "id": "admin-about",
      "path": "/admin/about",
      "href": "/admin/about",
      "label": "Admin About Page Edit"
    }
  ]
};

export const seed = {
  hero: {
    eyebrow: 'Jeanne Kassab Art',
    headline: 'Where light and pigment meet canvas. Discover original oils by Jeanne Kassab.',
    subcopy: 'Explore abstract landscapes and layered compositions, handcrafted with quiet elegance in Lebanon.',
    primaryCta: { label: 'View the Collection', href: '/gallery' },
    secondaryCta: { label: 'About Jeanne', href: '/about' },
  },
  credentialsHeading: 'Trusted by Collectors Worldwide',
  credentials: [
    {
      label: 'International Collectors',
      value: '22+',
      subtext: 'Across Europe, the Middle East, and North America',
    },
    { label: 'Original Works', value: '75+', subtext: 'Created and sold since 2018' },
    { label: 'Exhibitions', value: '5+', subtext: 'Group and solo shows' },
  ],
  featuresHeading: 'The Kassab Atelier Experience',
  features: [
    {
      title: 'A Curated Viewing Experience',
      description: 'Each artwork is presented with care, offering multiple high-resolution views and detailed information, akin to an intimate gallery visit.',
      icon: 'palette',
    },
    {
      title: 'Direct Dialogue with the Artist',
      description: 'Inquire about any piece or commission directly with Jeanne via WhatsApp, ensuring a personal and attentive response.',
      icon: 'messageSquare',
    },
    {
      title: 'One-of-a-Kind Original Paintings',
      description: 'Invest in unique, handcrafted oil paintings that bring a distinct serenity and a timeless aesthetic to any space.',
      icon: 'award',
    },
  ],
  showcaseHeading: 'Latest Additions to the Collection',
  items: [
    {
      title: 'Whispers of Green',
      description: 'An abstract exploration of verdant Lebanese hills.',
      imageSrc: images.card1,
      imageAlt: 'Whispers of Green painting',
      href: '/gallery/whispers-of-green',
    },
    {
      title: 'Desert Hues',
      description: 'Warm earth tones capturing the essence of arid landscapes.',
      imageSrc: images.card2,
      imageAlt: 'Desert Hues painting',
      href: '/gallery/desert-hues',
    },
    {
      title: 'Azure Depths',
      description: 'Deep blues and whites reminiscent of the Mediterranean sea.',
      imageSrc: images.card3,
      imageAlt: 'Azure Depths painting',
      href: '/gallery/azure-depths',
    },
    {
      title: 'Crimson Ascent',
      description: 'Dynamic reds and oranges depicting an abstract climb.',
      imageSrc: images.card1, // Reusing for more items
      imageAlt: 'Crimson Ascent painting',
      href: '/gallery/crimson-ascent',
    },
    {
      title: 'Golden Embrace',
      description: 'Warm, inviting yellows and golds in a layered composition.',
      imageSrc: images.card2,
      imageAlt: 'Golden Embrace painting',
      href: '/gallery/golden-embrace',
    },
    {
      title: 'Shadowed Peaks',
      description: 'A cooler palette capturing mountain vistas at dusk.',
      imageSrc: images.card3,
      imageAlt: 'Shadowed Peaks painting',
      href: '/gallery/shadowed-peaks',
    },
    {
      title: 'Riverbend Serenity',
      description: 'Flowing lines and greens evoking peaceful waters.',
      imageSrc: images.card1,
      imageAlt: 'Riverbend Serenity painting',
      href: '/gallery/riverbend-serenity',
    },
    {
      title: 'Urban Echoes',
      description: 'Subtle grays and muted tones reflecting cityscapes.',
      imageSrc: images.card2,
      imageAlt: 'Urban Echoes painting',
      href: '/gallery/urban-echoes',
    },
  ],
  testimonialsHeading: 'From Our Valued Collectors',
  testimonials: [
    {
      quote:
        "The online gallery beautifully captures the essence of Jeanne's work. It's truly like stepping into her atelier.",
      author: 'Sarah J.',
      service: 'Art Collection',
    },
    {
      quote:
        'The detail pages were incredibly helpful, and inquiring via WhatsApp was seamless. A truly special piece now hangs in my home.',
      author: 'Michael K.',
      service: 'Art Acquisition',
    },
    {
      quote:
        "Jeanne's art transformed my living space. The depth and emotion in her landscapes are simply breathtaking. It's more than a painting; it's a conversation piece.",
      author: 'Layla M., Collector',
    },
    {
      quote:
        'The moment I saw Jeanne\'s work, I knew I had to have it. Her use of color and texture is masterfully unique. It brings a profound sense of calm and beauty to my home.',
      author: 'Karim S., Interior Designer',
    },
  ],
  cta: {
    heading: 'Ready to discover your next unique artwork?',
    description: 'Explore the collection or connect with Jeanne directly to inquire about a piece or commission.',
    primaryLabel: 'View the Collection',
    primaryHref: '/gallery',
    secondaryLabel: 'Message on WhatsApp',
    secondaryHref: 'https://wa.me/MESSAGE_NUMBER', // Placeholder
  },
  footer: {
    description: 'Jeanne Kassab Art — original oil paintings, crafted with passion in Lebanon.',
  },
  artistProfile: {
    bio: `Born in Lebanon, bathed in its vibrant light and ancient rhythms, my artistic path began with a deep fascination for the interplay of color and texture. From early sketches to formal training, my passion for oil painting grew, leading me to explore abstract landscapes—not as depictions of specific places, but as echoes of internal feeling, memory, and the unseen forces of nature.
    Each canvas is a conversation with the material, a dance between intention and intuition. My work is deeply personal, an extension of my soul expressed through the rich language of oil.`,
    process: `In the quiet sanctuary of my atelier, the creation begins. I work primarily with high-quality oil paints on linen canvas, building layers upon layers. This meticulous process allows for a depth and luminosity that synthetic mediums simply cannot achieve.
    Each stroke is deliberate, each color chosen to resonate with the last. The layering technique creates a visual history within the painting, hinting at what lies beneath, much like the layers of experience that shape our lives. It’s a slow, contemplative craft—a true collaboration between artist, pigment, and canvas.`,
  },
  artworks: [
    {
      id: 'the-emerald-shore',
      title: 'The Emerald Shore',
      medium: 'Oil on Canvas',
      year: '2023',
      dimensions: '120 cm x 90 cm (47.2 in x 35.4 in)',
      price: '$9,500 USD',
      description:
        'A vibrant abstract landscape, capturing the serene interplay of light and shadow across a verdant valley, typical of Jeanne Kassab’s Lebanese-inspired works. This piece evokes the tranquility of a hidden coastline at dawn, with luminous greens meeting cool blues.',
      status: 'Available',
      mainImage: images.detailMain,
      images: [
        images.detailMain,
        'https://images.unsplash.com/photo-1579738541171-d4198f192b02?auto=format&fit=crop&q=80&w=700&h=500&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', // Close-up 1
        'https://images.unsplash.com/photo-1579738541005-72861e641776?auto=format&fit=crop&q=80&w=700&h=500&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', // Close-up 2
      ],
    },
    {
      id: 'whispers-of-green',
      title: 'Whispers of Green',
      medium: 'Oil on Linen',
      year: '2022',
      dimensions: '100 cm x 80 cm (39.4 in x 31.5 in)',
      price: '$8,200 USD',
      description:
        'An ethereal abstract landscape dominating with soft, blending greens and subtle hints of gold. This piece invites introspection, akin to a quiet moment in a sun-dappled forest.',
      status: 'Available',
      mainImage: images.card1,
      images: [images.card1, images.card2, images.card3], // Placeholder images
    },
    {
      id: 'crimson-ascent',
      title: 'Crimson Ascent',
      medium: 'Oil on Canvas',
      year: '2023',
      dimensions: '130 cm x 100 cm (51.2 in x 39.4 in)',
      price: '$10,100 USD',
      description:
        'A powerful composition featuring dynamic reds and oranges, suggesting movement and an upward journey. Inspiring and dramatic, perfect for an impactful statement.',
      status: 'Reserved',
      mainImage: images.card2,
      images: [images.card2, images.card3, images.card1], // Placeholder images
    },
    {
      id: 'azure-depths',
      title: 'Azure Depths',
      medium: 'Oil on Panel',
      year: '2021',
      dimensions: '75 cm x 110 cm (29.5 in x 43.3 in)',
      price: '$6,800 USD',
      description:
        'Cool blues and aquamarine flow across the canvas, reminiscent of deep ocean currents or vast open skies. A calming and contemplative piece.',
      status: 'Sold',
      mainImage: images.card3,
      images: [images.card3, images.card1, images.card2], // Placeholder images
    },
  ],
};

export const stats = [
  { label: 'Total Inquiries (Last 30 Days)', value: '18', change: '+5 from last month' },
  { label: 'Artworks Sold (YTD)', value: '7', change: '+2 from last year' },
  { label: 'Website Visitors (Last 30 Days)', value: '452', change: '+12% traffic' },
  { label: 'Active Artworks', value: '14', change: '2 new since last update' },
];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
