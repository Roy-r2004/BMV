// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Jeanne Kassab Art"} eyebrow={seed.hero?.eyebrow ?? "Jeanne Kassab Art"} headline={seed.hero?.headline || "Homepage"} subcopy={seed.hero?.subcopy} primaryCta={seed.hero?.primaryCta} secondaryCta={seed.hero?.secondaryCta} imageSrc={images.hero} imageAlt="" />
    ),
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    features: (
      <FeatureBento heading={seed.featuresHeading ?? "What Jeanne Kassab Art offers"} imagePool={[images.card1, images.card2, images.card3]} items={seed.features ?? []} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Jeanne Kassab Art"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.card1, images.card2, images.card3][index % 3], imageAlt: item.title }))} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Jeanne Kassab Art?"} description={seed.cta?.description ?? "Tell Jeanne Kassab Art what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={seed.footer?.description ?? "Jeanne Kassab Art — clear choices and real bookings."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-HOME">

        <span className="sr-only" data-appspec-action="ACTION-NAV-GALLERY">ACTION-NAV-GALLERY</span>
        <span className="sr-only" data-appspec-action="ACTION-NAV-ABOUT">ACTION-NAV-ABOUT</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-HOME-HERO">EVIDENCE-HOME-HERO</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-HOME-NAV">EVIDENCE-HOME-NAV</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}
