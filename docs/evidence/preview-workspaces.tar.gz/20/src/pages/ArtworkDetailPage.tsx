// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Brand"} headline={"Artwork Detail Page"} subcopy={"Artwork Detail Page \u2014 browse what\u2019s here, then book. This page is not the homepage story."} primaryCta={{ label: "Book a visit", href: "/book-appointment" }} secondaryCta={{ label: "Back home", href: "/" }} imageSrc={images.card1} imageAlt="" />
    ),
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Brand"} items={seed.credentials ?? []} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Brand"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.card1, images.card2, images.card3][index % 3], imageAlt: item.title }))} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Brand"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Brand?"} description={seed.cta?.description ?? "Tell Brand what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "#details" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "#contact" }} />
    ),
    footer: (
      <BrandFooter brandName={"Brand"} description={seed.footer?.description ?? "Brand — clear choices and real bookings."} />
    ),
  };

  return (
    <PublicShell brandName={"Brand"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ARTWORK-DETAIL">

        <span className="sr-only" data-appspec-action="ACTION-INQUIRE-WHATSAPP">ACTION-INQUIRE-WHATSAPP</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ARTWORK-IMAGES">EVIDENCE-ARTWORK-IMAGES</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ARTWORK-INFO">EVIDENCE-ARTWORK-INFO</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-WHATSAPP-BUTTON">EVIDENCE-WHATSAPP-BUTTON</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}
