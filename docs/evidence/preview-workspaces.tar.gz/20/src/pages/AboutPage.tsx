// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, TestimonialRail, CTABand, BrandFooter, Button, UiIcon } from '@/ui';

const SKELETON_ID = "public-service" as const;
const RECIPE_ORDER = ["hero", "features", "testimonials", "cta", "footer"] as const;

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"The Artist: Jeanne Kassab"}
        subcopy={"Layered oils, timeless stories, from the heart of Lebanon."}
        imageSrc={images.hero2}
        imageAlt="Jeanne Kassab in her studio"
        className="text-brand font-display"
      />
    ),
    features: (
      <FeatureBento
        heading="My Work, My Story"
        description="A journey of art, inspiration, and dedicated craft."
        imagePool={[images.card3]}
        items={[
          {
            title: "My Journey",
            description: `
              <p class="mb-4 text-brand font-sans">Born in Lebanon, bathed in its vibrant light and ancient rhythms, my artistic path began with a deep fascination for the interplay of color and texture. From early sketches to formal training, my passion for oil painting grew, leading me to explore abstract landscapes—not as depictions of specific places, but as echoes of internal feeling, memory, and the unseen forces of nature.</p>
              <p class="mb-4 text-brand font-sans">Each canvas is a conversation with the material, a dance between intention and intuition. My work is deeply personal, an extension of my soul expressed through the rich language of oil.</p>
            `,
            image: images.card1,
            imagePosition: "right",
          },
          {
            title: "The Atelier Process",
            description: `
              <p class="mb-4 text-brand font-sans">In the quiet sanctuary of my atelier, the creation begins. I work primarily with high-quality oil paints on linen canvas, building layers upon layers. This meticulous process allows for a depth and luminosity that synthetic mediums simply cannot achieve.</p>
              <p class="mb-4 text-brand font-sans">Each stroke is deliberate, each color chosen to resonate with the last. The layering technique creates a visual history within the painting, hinting at what lies beneath, much like the layers of experience that shape our lives. It’s a slow, contemplative craft—a true collaboration between artist, pigment, and canvas.</p>
            `,
            image: images.card3,
            imagePosition: "left",
          },
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading="What Collectors Say"
        items={[
          {
            quote: "Jeanne's art transformed my living space. The depth and emotion in her landscapes are simply breathtaking. It's more than a painting; it's a conversation piece.",
            author: "Sarah J., Art Collector",
          },
          {
            quote: "The moment I saw Jeanne's work, I knew I had to have it. Her use of color and texture is masterfully unique. It brings a profound sense of calm and beauty to my home.",
            author: "Michael K., Interior Designer",
          },
        ]}
      />
    ),
    cta: (
      <CTABand
        heading={"Connect with Jeanne"}
        description={"I welcome inquiries and discussions about my work. Reach out directly."}
        primaryCta={{
          label: (
            <>
              <UiIcon name="whatsapp" className="inline-block mr-2" /> Message on WhatsApp
            </>
          ),
          href: "https://wa.me/YOUR_WHATSAPP_NUMBER", // Replace with actual WhatsApp number
          variant: "default",
          className: "bg-brand text-white hover:bg-secondary",
        }}
        className="bg-background text-brand"
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings for collectors and art lovers worldwide. Handcrafted in Lebanon."}
        links={[
          { label: "Collection", href: "/collection" },
          { label: "About", href: "/about" },
          { label: "Instagram", href: "https://www.instagram.com/jeannekassabart" },
        ]}
        meta={[{ label: "© 2024 Jeanne Kassab Art" }]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ABOUT">
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ABOUT-CONTENT">EVIDENCE-ABOUT-CONTENT</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}