// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, Button } from '@/ui';
import { useNavigate } from 'react-router-dom';

const SKELETON_ID = "ops-dashboard" as const;

export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const navigate = useNavigate();

  // Sample data for KPIs, Chart, Table, and Activity Feed based on the brief
  const kpisData = [
    { label: 'Available Works', value: '18', delta: '+2', hint: 'Published & Ready for Inquiry' },
    { label: 'Inquiries (Last 7 Days)', value: '5', delta: '+1', hint: 'Via WhatsApp' },
    { label: 'Reserved Pieces', value: '3', delta: '0', hint: 'Pending Purchase' },
  ];

  const chartData = [
    { day: "Day 1", value: 0 }, { day: "Day 3", value: 1 }, { day: "Day 5", value: 0 }, { day: "Day 7", value: 2 },
    { day: "Day 9", value: 0 }, { day: "Day 11", value: 1 }, { day: "Day 13", value: 0 }, { day: "Day 15", value: 1 },
    { day: "Day 17", value: 0 }, { day: "Day 19", value: 0 }, { day: "Day 21", value: 1 }, { day: "Day 23", value: 0 },
    { day: "Day 25", value: 0 }, { day: "Day 27", value: 0 }, { day: "Day 29", value: 0 }, { day: "Day 30", value: 1 }
  ];


  const artworkTableRows = [
    { id: "artwork-1", title: "Azure Heights (New)", status: "Available", inquiries: 2, lastUpdated: "Just now", route: "/admin/artworks/azure-heights", dataAppspecAction: "ACTION-ADMIN-NAV-ARTWORK" },
    { id: "artwork-2", title: "Golden Fields", status: "Sold", inquiries: 5, lastUpdated: "2 days ago", route: "/admin/artworks/golden-fields", dataAppspecAction: "ACTION-ADMIN-NAV-ARTWORK" },
    { id: "artwork-3", title: "Whispers of Beirut", status: "Reserved", inquiries: 3, lastUpdated: "1 week ago", route: "/admin/artworks/whispers-of-beirut", dataAppspecAction: "ACTION-ADMIN-NAV-ARTWORK" },
    { id: "artwork-4", title: "Mountain Embrace", status: "Available", inquiries: 1, lastUpdated: "3 weeks ago", route: "/admin/artworks/mountain-embrace", dataAppspecAction: "ACTION-ADMIN-NAV-ARTWORK" },
    { id: "artwork-5", title: "Coastal Serenity", status: "Available", inquiries: 0, lastUpdated: "1 month ago", route: "/admin/artworks/coastal-serenity", dataAppspecAction: "ACTION-ADMIN-NAV-ARTWORK" },
  ];

  const activityFeedItems = [
    { id: "act-1", title: "New artwork uploaded: 'Azure Heights'", detail: "", time: "Just now" },
    { id: "act-2", title: "Artwork status updated: 'Golden Fields' to Sold", detail: "", time: "2 days ago" },
    { id: "act-3", title: "About page content updated", detail: "", time: "5 days ago" },
    { id: "act-4", title: "New inquiry for 'Whispers of Beirut'", detail: "", time: "1 week ago" },
  ];

  const handleArtworkClick = (artworkId: string) => {
    navigate(`/admin/artworks/${artworkId}`);
  };

  const slots = {
    header: (
      <PageHeader
        title="Welcome, Jeanne!"
        description="Your Collection at a Glance"
        actions={[
          {
            label: "Add New Artwork",
            onClick: () => navigate("/admin/artwork"), // Changed to /admin/artwork as per routes
            variant: "default",
            'data-appspec-action': "ACTION-ADMIN-NAV-ARTWORK" // Specific action for adding new artwork
          },
          {
            label: "Edit About Page",
            onClick: () => navigate("/admin/about"),
            variant: "secondary",
            'data-appspec-action': "ACTION-ADMIN-NAV-ABOUT"
          }
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {kpisData.map((kpi, index) => (
          <StatCard
            key={index}
            label={kpi.label}
            value={kpi.value}
            delta={kpi.delta}
            hint={kpi.hint}
            variant="card"
          />
        ))}
      </div>
    ),
    chart: (
      <ChartCard
        title="Last 30 Days Activity"
        type="bar" // Using bar chart for inquiry volume as per brief
        dataKey="value"
        xKey="day"
        data={chartData}
        description="Inquiry volume trend"
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search artworks..."
        filters={[
          { id: "all", label: "All", active: true },
          { id: "available", label: "Available", active: false },
          { id: "reserved", label: "Reserved", active: false },
          { id: "sold", label: "Sold", active: false },
        ]}
        actions={[
          <Button key="refresh" variant="ghost">Refresh</Button>
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "title", header: "Title" },
          { key: "status", header: "Status" },
          { key: "inquiries", header: "Inquiries" },
          { key: "lastUpdated", header: "Last Updated" },
        ]}
        rows={artworkTableRows.map((row) => ({
          ...row,
          onClick: () => handleArtworkClick(row.id),
          'data-appspec-action': row['data-appspec-action']
        }))}
        emptyMessage="No artworks found."
      />
    ),
    activity: (
      <ActivityFeed heading="Recent Actions Timeline" items={activityFeedItems} />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems} rail={rail} appearance="soft">
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ADMIN-DASHBOARD">
        <span className="sr-only" data-appspec-action="ACTION-ADMIN-NAV-ARTWORK">ACTION-ADMIN-NAV-ARTWORK</span>
        <span className="sr-only" data-appspec-action="ACTION-ADMIN-NAV-ABOUT">ACTION-ADMIN-NAV-ABOUT</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ADMIN-NAV">EVIDENCE-ADMIN-NAV</span>
        {main}
      </div>
    </OpsShell>
  );
}