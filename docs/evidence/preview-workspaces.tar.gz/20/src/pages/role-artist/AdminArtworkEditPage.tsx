// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Input, Select, Button, ActivityFeed } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-detail" as const;

export default function AdminArtworkEditPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const [artworkDetails, setArtworkDetails] = useState({
    title: 'The Silent Shore',
    medium: 'Oil on Canvas',
    year: '2023',
    dimensions: '100cm x 120cm',
    price: 'Upon Request',
    description: 'A serene abstract landscape depicting the quietude of a hidden coastline, rendered with layered oil paints and nuanced textures. The piece invites contemplation of the natural world and its untouched beauty.',
    status: 'Available',
    mainImageUrl: 'https://via.placeholder.com/600x800/d6d3d1/444444?text=Main+Artwork+Image',
    closeupImageUrls: [
      'https://via.placeholder.com/300x200/d6d3d1/444444?text=Close-up+1',
      'https://via.placeholder.com/300x200/d6d3d1/444444?text=Close-up+2',
    ],
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setArtworkDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value: string) => {
    setArtworkDetails(prev => ({ ...prev, status: value }));
  };

  // Simplified image upload logic for placeholder
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'main' | 'closeup') => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result && typeof event.target.result === 'string') {
          if (type === 'main') {
            setArtworkDetails(prev => ({ ...prev, mainImageUrl: event.target.result as string }));
          } else {
            // For closer-ups, we'd ideally manage an array. This is a simplification.
            const newCloseUps = [...prev.closeupImageUrls];
            if (newCloseUps.length < 2) { // Allow up to 2 example closeups
              newCloseUps.push(event.target.result as string);
            } else {
              newCloseUps[0] = event.target.result as string; // Replace first for simplicity
            }
            setArtworkDetails(prev => ({ ...prev, closeupImageUrls: newCloseUps }));
          }
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(true);
      console.log('Artwork saved:', artworkDetails);
      // In a real app, you'd navigate or show a persistent success message
    }, 1500);
  };

  const slots = {
    header: (
      <PageHeader
        title={"Edit Artwork: The Silent Shore"}
        description={"Manage details, status, and images for this piece."}
        actions={[
          <Button key="cancel" variant="outline" onClick={() => console.log('Cancel')}>
            Cancel
          </Button>,
          <Button
            key="save"
            type="submit"
            onClick={handleSubmit}
            disabled={isSaving}
            data-appspec-action="ACTION-ADMIN-SAVE-ARTWORK"
          >
            {isSaving ? 'Saving...' : 'Save Changes'}
          </Button>,
        ]}
      />
    ),
    table: ( // Using DataTable for the form structure, as there's no specific Form component in the provided kit
      <form onSubmit={handleSubmit} className="p-4 bg-brand-surface rounded-lg shadow-sm grid grid-cols-1 md:grid-cols-2 gap-6" data-appspec-evidence="EVIDENCE-ARTWORK-EDIT-FORM">
        <div className="col-span-1 md:col-span-2">
          {saveSuccess && (
            <div className="p-3 mb-4 bg-teal-100 text-teal-800 rounded-md" data-appspec-evidence="EVIDENCE-ARTWORK-SAVED-CONFIRMATION">
              Artwork details saved successfully!
            </div>
          )}
        </div>
        <div className="space-y-4">
          <Input name="title" label="Title" value={artworkDetails.title} onChange={handleInputChange} required />
          <Input name="medium" label="Medium" value={artworkDetails.medium} onChange={handleInputChange} required />
          <Input name="year" label="Year" type="number" value={artworkDetails.year} onChange={handleInputChange} required />
          <Input name="dimensions" label="Dimensions" value={artworkDetails.dimensions} onChange={handleInputChange} placeholder="e.g., 100cm x 120cm" required />
          <Input name="price" label="Price" value={artworkDetails.price} onChange={handleInputChange} placeholder="e.g., Upon Request or 2400 USD" />
          <Select
            label="Status"
            options={[
              { label: 'Available', value: 'Available' },
              { label: 'Reserved', value: 'Reserved' },
              { label: 'Sold', value: 'Sold' },
            ]}
            value={artworkDetails.status}
            onValueChange={handleSelectChange}
            required
          />
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-brand-text mb-1">Description (Optional)</label>
            <Input as="textarea" name="description" rows={5} value={artworkDetails.description} onChange={handleInputChange} className="resize-y" />
          </div>
          <div>
            <label className="block text-sm font-medium text-brand-text mb-1">Main Image</label>
            <div className="flex items-center space-x-4">
              {artworkDetails.mainImageUrl && (
                <img src={artworkDetails.mainImageUrl} alt="Main Artwork" className="w-32 h-32 object-cover rounded-md" />
              )}
              <Input type="file" accept="image/*" onChange={(e) => handleImageUpload(e, 'main')} />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-brand-text mb-1">Close-up Images</label>
            <div className="flex flex-wrap items-center gap-4">
              {artworkDetails.closeupImageUrls.map((url, index) => (
                <img key={index} src={url} alt={`Close-up ${index + 1}`} className="w-24 h-24 object-cover rounded-md" />
              ))}
              <Input type="file" accept="image/*" onChange={(e) => handleImageUpload(e, 'closeup')} />
            </div>
          </div>
        </div>
      </form>
    ),
    activity: (
      <ActivityFeed
        heading="Artwork Activity Log"
        items={[
          { id: '1', title: 'Artwork created', detail: 'By Jeanne Kassab', time: '2 days ago' },
          { id: '2', title: 'Price updated', detail: 'From $9,000 to Upon Request', time: '1 day ago' },
        ]}
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ADMIN-ARTWORK-EDIT">
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ADMIN-ARTWORK-DETAIL-CONTENT">EVIDENCE-ADMIN-ARTWORK-DETAIL-CONTENT</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}