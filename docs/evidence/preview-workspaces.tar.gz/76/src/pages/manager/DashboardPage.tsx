// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed, aiFeatures } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, RiskQueue, ChartCard, FilterBar, DataTable, ActivityFeed, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function DashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title="Lodge Operations Overview" description="Welcome, Eleanor!" />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Upcoming Bookings (Next 7 days)" value="12" delta="+3 new" variant="card" />
        <StatCard label="Rooms Available (Today)" value="5" delta="-2 since yesterday" variant="card" />
        <StatCard label="Avg. Occupancy (This Month)" value="78%" delta="+5% from last month" variant="card" />
        <StatCard label="New Inquiries (Last 24 hrs)" value="3" delta="+1" variant="card" />
      </div>
    ),
    risk: (
      <RiskQueue heading="Urgent Alerts" items={[{ id: "risk-low-availability", title: "Low availability for upcoming weekend", detail: "Only 2 rooms remaining for Friday and Saturday.", severity: "high" }]} />
    ),
    chart: (
      <ChartCard title="Monthly Bookings" type="area" dataKey="bookings" xKey="month" data={[
        { month: "Jan", bookings: 18 },
        { month: "Feb", bookings: 22 },
        { month: "Mar", bookings: 30 },
        { month: "Apr", bookings: 25 },
        { month: "May", bookings: 35 },
        { month: "Jun", bookings: 42 },
      ]} />
    ),
    filters: (
      <FilterBar searchPlaceholder="Search bookings..." filters={[
        { id: "today", label: "Today" },
        { id: "this-week", label: "This Week" },
        { id: "next-7-days", label: "Next 7 Days", active: true },
        { id: "all", label: "All Bookings" },
      ]} />
    ),
    table: (
      <DataTable
        columns={[
          { key: "guestName", header: "Guest Name" },
          { key: "room", header: "Room" },
          { key: "checkIn", header: "Check-in" },
          { key: "checkOut", header: "Check-out" },
          { key: "status", header: "Status" },
        ]}
        rows={[
          { id: "b1", guestName: "The Miller Family", room: "Lakeview Suite (Room 5)", checkIn: "2024-09-10", checkOut: "2024-09-13", status: "Confirmed" },
          { id: "b2", guestName: "Ms. Evelyn Reed", room: "Forest Nook (Room 7)", checkIn: "2024-09-11", checkOut: "2024-09-12", status: "Confirmed" },
          { id: "b3", guestName: "Dr. Alistair Finch", room: "River's Edge (Room 1)", checkIn: "2024-09-14", checkOut: "2024-09-16", status: "Pending Payment" },
          { id: "b4", guestName: "The Chen Group", room: "Mountain Vista (Room 3)", checkIn: "2024-09-15", checkOut: "2024-09-19", status: "Confirmed" },
          { id: "b5", guestName: "Mr. Thomas O'Malley", room: "Lakeview Suite (Room 6)", checkIn: "2024-09-17", checkOut: "2024-09-18", status: "Confirmed" },
        ]}
      />
    ),
    activity: (
      <ActivityFeed heading="Recent Activity" items={[
        { id: "a1", title: "New booking confirmed for Room 7", detail: "Ms. Evelyn Reed checking in Sep 11.", time: "5 min ago" },
        { id: "a2", title: "Availability updated for Forest Nook", detail: "Room 7 now marked as booked.", time: "15 min ago" },
        { id: "a3", title: "Guest inquiry from David Chen", detail: "Question about canoe trip availability in October.", time: "1 hour ago" },
        { id: "a4", title: "Room rate adjusted for Winter Season", detail: "Rates for all suites updated for Q4.", time: "3 hours ago" },
      ]} />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="manager-dashboard">
        {main}
      </div>
          <div id="dynamic-room-recommendation" data-ai-feature-panel="dynamic-room-recommendation">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "dynamic-room-recommendation") || { id: "dynamic-room-recommendation", name: "dynamic-room-recommendation" }}
          brandName={"Cedar Point Lodge"}
        />
      </div>
    </OpsShell>
  );
}