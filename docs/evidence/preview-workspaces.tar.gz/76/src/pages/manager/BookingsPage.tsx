import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Select } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-list" as const;

export default function BookingsPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  const [filterRoomType, setFilterRoomType] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const roomTypes = [
    { value: 'lakeside_suite', label: 'Lakeside Suite' },
    { value: 'forest_cabin', label: 'Forest Cabin' },
    { value: 'wilderness_room', label: 'Wilderness Room' },
  ];

  const bookingStatuses = [
    { value: 'confirmed', label: 'Confirmed' },
    { value: 'pending', label: 'Pending' },
    { value: 'cancelled', label: 'Cancelled' },
  ];

  const allBookings = [
    {
      id: 'CP1001',
      guestName: 'Eleanor Vance',
      roomType: 'Lakeside Suite',
      checkIn: '2024-07-15',
      checkOut: '2024-07-20',
      totalPrice: '$1,500.00',
      paymentStatus: 'Paid',
      status: 'Confirmed',
    },
    {
      id: 'CP1002',
      guestName: 'Thomas Green',
      roomType: 'Forest Cabin',
      checkIn: '2024-08-01',
      checkOut: '2024-08-05',
      totalPrice: '$950.00',
      paymentStatus: 'Pending',
      status: 'Pending',
    },
    {
      id: 'CP1003',
      guestName: 'Isabella Chen',
      roomType: 'Wilderness Room',
      checkIn: '2024-09-10',
      checkOut: '2024-09-12',
      totalPrice: '$500.00',
      paymentStatus: 'Paid',
      status: 'Confirmed',
    },
    {
      id: 'CP1004',
      guestName: 'James Miller',
      roomType: 'Lakeside Suite',
      checkIn: '2024-07-22',
      checkOut: '2024-07-25',
      totalPrice: '$900.00',
      paymentStatus: 'Paid',
      status: 'Confirmed',
    },
    {
      id: 'CP1005',
      guestName: 'Sophia White',
      roomType: 'Forest Cabin',
      checkIn: '2024-08-15',
      checkOut: '2024-08-18',
      totalPrice: '$700.00',
      paymentStatus: 'Cancelled',
      status: 'Cancelled',
    },
  ];

  const filteredBookings = allBookings.filter(booking => {
    const matchesStatus = filterStatus ? booking.status.toLowerCase() === filterStatus : true;
    const matchesRoomType = filterRoomType ? booking.roomType.toLowerCase().replace(' ', '_') === filterRoomType : true;
    const matchesSearch = searchQuery
      ? booking.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        booking.guestName.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    return matchesStatus && matchesRoomType && matchesSearch;
  });

  const handleSendPreArrivalEmail = (guestName: string, bookingId: string) => {
    alert(`Simulating sending a personalized pre-arrival guide to ${guestName} for booking ${bookingId}.`);
    // In a real application, this would trigger an API call to send the email
  };

  const slots = {
    header: (
      <PageHeader
        title="Manage All Bookings"
        actions={[
          { label: "New Booking", onClick: () => alert('Navigate to new booking page'), variant: "default" }
        ]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search by Booking ID or Guest Name"
        searchValue={searchQuery}
        onSearchChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
        filters={[
          {
            id: "status",
            label: "Status",
            render: (
              <Select
                options={[{ value: '', label: 'All Statuses' }, ...bookingStatuses]}
                value={filterStatus || ''}
                onValueChange={(value) => setFilterStatus(value === '' ? null : value)}
                className="w-[180px]"
              />
            ),
          },
          {
            id: "room-type",
            label: "Room Type",
            render: (
              <Select
                options={[{ value: '', label: 'All Room Types' }, ...roomTypes]}
                value={filterRoomType || ''}
                onValueChange={(value) => setFilterRoomType(value === '' ? null : value)}
                className="w-[180px]"
              />
            ),
          },
          // Date range filter could be added here if a suitable component were available.
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "id", header: "Booking ID" },
          { key: "guestName", header: "Guest Name" },
          { key: "roomType", header: "Room Type" },
          { key: "checkIn", header: "Check-in" },
          { key: "checkOut", header: "Check-out" },
          { key: "totalPrice", header: "Total Price" },
          { key: "paymentStatus", header: "Payment Status" },
          {
            key: "status",
            header: "Status",
            render: (row: typeof allBookings[0]) => (
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                row.status === 'Confirmed' ? 'bg-green-100 text-green-800' :
                row.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'
              }`}>
                {row.status}
              </span>
            ),
          },
          {
            key: "actions",
            header: "Actions",
            render: (row: typeof allBookings[0]) => (
              <div className="flex space-x-2">
                <Button variant="ghost" size="sm" onClick={() => alert(`Viewing details for ${row.id}`)}>
                  View Details
                </Button>
                <Button variant="ghost" size="sm" onClick={() => handleSendPreArrivalEmail(row.guestName, row.id)}>
                  Send Pre-Arrival Email
                </Button>
              </div>
            ),
          },
        ]}
        rows={filteredBookings}
      />
    )
  };

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="manage-bookings">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={["header", "filters", "table"]} />
      </div>
    </OpsShell>
  );
}