// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Dialog, Input, Select, UiIcon } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-list" as const;

export default function RoomInventoryPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // Mock data for rooms, statuses, and room types
  const initialRooms = [
    {
      id: 'room-1',
      type: 'Lakeview Suite',
      roomName: 'Suite 101',
      capacity: 4,
      basePrice: 450,
      currentStatus: 'Available',
      description: 'Spacious suite with stunning lake views, king bed, and private balcony.',
      amenities: ['King Bed', 'Private Balcony', 'Lake View', 'Fireplace'],
      photos: ['https://images.pexels.com/photos/6790752/pexels-photo-6790752.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940'],
    },
    {
      id: 'room-2',
      type: 'Forest Cabin',
      roomName: 'Cabin 1',
      capacity: 2,
      basePrice: 300,
      currentStatus: 'Occupied',
      description: 'Cozy cabin nestled in the woods, perfect for a romantic getaway.',
      amenities: ['Queen Bed', 'Forest View', 'Outdoor Deck'],
      photos: ['https://images.pexels.com/photos/33534993/pexels-photo-33534993.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940'],
    },
    {
      id: 'room-3',
      type: 'Lakeview Suite',
      roomName: 'Suite 102',
      capacity: 4,
      basePrice: 450,
      currentStatus: 'Maintenance',
      description: 'Another beautiful lakeview suite with modern rustic decor.',
      amenities: ['King Bed', 'Private Balcony', 'Lake View'],
      photos: ['https://images.pexels.com/photos/210588/pexels-photo-210588.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
    },
    {
      id: 'room-4',
      type: 'Standard Room',
      roomName: 'Room 201',
      capacity: 2,
      basePrice: 200,
      currentStatus: 'Available',
      description: 'Comfortable standard room with a view of the lodge grounds.',
      amenities: ['Queen Bed', 'Desk'],
      photos: ['https://images.pexels.com/photos/29851821/pexels-photo-29851821.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
    },
  ];

  const roomTypes = Array.from(new Set(initialRooms.map(room => room.type))).map(type => ({ value: type, label: type }));
  const roomStatuses = Array.from(new Set(initialRooms.map(room => room.currentStatus))).map(status => ({ value: status, label: status }));

  const [rooms, setRooms] = useState(initialRooms);
  const [filteredRooms, setFilteredRooms] = useState(initialRooms);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRoomType, setSelectedRoomType] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [currentRoom, setCurrentRoom] = useState<typeof initialRooms[0] | null>(null);

  React.useEffect(() => {
    let tempRooms = rooms;

    if (searchTerm) {
      tempRooms = tempRooms.filter(room =>
        room.roomName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        room.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        room.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedRoomType) {
      tempRooms = tempRooms.filter(room => room.type === selectedRoomType);
    }

    if (selectedStatus) {
      tempRooms = tempRooms.filter(room => room.currentStatus === selectedStatus);
    }

    setFilteredRooms(tempRooms);
  }, [searchTerm, selectedRoomType, selectedStatus, rooms]);

  const handleEditRoom = (room: typeof initialRooms[0]) => {
    setCurrentRoom(room);
    setIsEditDialogOpen(true);
  };

  const handleUpdateRoom = (updatedRoom: typeof initialRooms[0]) => {
    setRooms(prev => prev.map(room => room.id === updatedRoom.id ? updatedRoom : room));
    setIsEditDialogOpen(false);
  };

  const handleAddRoom = (newRoom: Omit<typeof initialRooms[0], 'id'>) => {
    const newId = `room-${rooms.length + 1}`;
    setRooms(prev => [...prev, { ...newRoom, id: newId }]);
    setIsAddDialogOpen(false);
  };

  const roomColumns = [
    {
      key: 'roomName',
      header: 'Room Name/Type',
      render: (row: typeof initialRooms[0]) => (
        <div>
          <div className="font-semibold">{row.roomName}</div>
          <div className="text-muted text-sm">{row.type}</div>
        </div>
      ),
    },
    {
      key: 'capacity',
      header: 'Capacity',
      render: (row: typeof initialRooms[0]) => `${row.capacity} guests`,
    },
    {
      key: 'basePrice',
      header: 'Base Price',
      render: (row: typeof initialRooms[0]) => `$${row.basePrice.toFixed(2)} / night`,
    },
    {
      key: 'currentStatus',
      header: 'Current Status',
    },
    {
      key: 'description',
      header: 'Description Snippet',
      render: (row: typeof initialRooms[0]) => row.description.substring(0, 70) + (row.description.length > 70 ? '...' : ''),
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (row: typeof initialRooms[0]) => (
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" onClick={() => handleEditRoom(row)}>
            Edit Details
          </Button>
          <Button variant="ghost" size="sm" onClick={() => alert(`Showing availability for ${row.roomName}`)}>
            Availability
          </Button>
        </div>
      ),
    },
  ];

  const slots = {
    header: (
      <PageHeader
        title="Room Inventory & Pricing"
        actions={[
          {
            label: "Add New Room Type",
            onClick: () => setIsAddDialogOpen(true),
            variant: "default",
          }
        ]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search rooms by name, type, or description..."
        searchValue={searchTerm}
        onSearchChange={setSearchTerm}
        filters={[
          {
            id: 'room-type',
            label: 'Room Type',
            render: (
              <Select
                options={[{ value: '', label: 'All Room Types' }, ...roomTypes]}
                value={selectedRoomType}
                onValueChange={setSelectedRoomType}
                label="Filter by Room Type"
                className="w-[180px]"
              />
            ),
          },
          {
            id: 'status',
            label: 'Status',
            render: (
              <Select
                options={[{ value: '', label: 'All Statuses' }, ...roomStatuses]}
                value={selectedStatus}
                onValueChange={setSelectedStatus}
                label="Filter by Status"
                className="w-[180px]"
              />
            ),
          },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={roomColumns}
        rows={filteredRooms}
        emptyMessage="No rooms found matching your criteria."
      />
    ),
  };

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="room-inventory">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />

        {/* Edit Room Dialog */}
        <Dialog
          title="Edit Room Details"
          description={`Editing details for ${currentRoom?.roomName || ''}`}
          open={isEditDialogOpen}
          onOpenChange={setIsEditDialogOpen}
          showTrigger={false}
          footer={
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
              <Button variant="default" onClick={() => currentRoom && handleUpdateRoom(currentRoom)}>Save Changes</Button>
            </div>
          }
        >
          {currentRoom && (
            <div className="grid gap-4 py-4 bg-surface px-4 rounded-md">
              <Input
                label="Room Name"
                value={currentRoom.roomName}
                onChange={(e) => setCurrentRoom({ ...currentRoom, roomName: e.target.value })}
              />
              <Select
                label="Room Type"
                options={roomTypes.map(type => ({ value: type.value, label: type.label }))}
                value={currentRoom.type}
                onValueChange={(value) => setCurrentRoom({ ...currentRoom, type: value })}
              />
              <Input
                label="Capacity (guests)"
                type="number"
                value={currentRoom.capacity.toString()}
                onChange={(e) => setCurrentRoom({ ...currentRoom, capacity: parseInt(e.target.value) || 0 })}
              />
              <Input
                label="Base Price ($)"
                type="number"
                value={currentRoom.basePrice.toString()}
                onChange={(e) => setCurrentRoom({ ...currentRoom, basePrice: parseFloat(e.target.value) || 0 })}
              />
              <Input
                label="Current Status"
                value={currentRoom.currentStatus}
                onChange={(e) => setCurrentRoom({ ...currentRoom, currentStatus: e.target.value })}
              />
              <Input
                label="Description"
                as="textarea"
                rows={4}
                value={currentRoom.description}
                onChange={(e) => setCurrentRoom({ ...currentRoom, description: e.target.value })}
              />
              {/* Photo upload functionality would be more complex and require file handling */}
              <div className="text-sm text-muted">Photo upload feature coming soon.</div>
            </div>
          )}
        </Dialog>

        {/* Add New Room Dialog */}
        <Dialog
          title="Add New Room Type"
          description="Enter details for the new room type to be added to your inventory."
          open={isAddDialogOpen}
          onOpenChange={setIsAddDialogOpen}
          showTrigger={false}
          footer={
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
              <Button variant="default" onClick={() => {
                // Simplified creation for demo
                const newRoom: Omit<typeof initialRooms[0], 'id'> = {
                  roomName: 'New Room',
                  type: 'Standard Room',
                  capacity: 2,
                  basePrice: 250,
                  currentStatus: 'Available',
                  description: 'A newly added room.',
                  amenities: [],
                  photos: [],
                };
                handleAddRoom(newRoom);
              }}>Add Room</Button>
            </div>
          }
        >
          {/* Form for adding a new room type */}
          <div className="grid gap-4 py-4 bg-surface px-4 rounded-md">
            <Input label="Room Name" placeholder="e.g., Suite 305" />
            <Select
              label="Room Type"
              options={roomTypes.map(type => ({ value: type.value, label: type.label }))}
              placeholder="Select a type"
            />
            <Input label="Capacity (guests)" type="number" placeholder="2" />
            <Input label="Base Price ($)" type="number" placeholder="250.00" />
            <Input label="Description" as="textarea" rows={3} placeholder="Brief description of the room." />
          </div>
        </Dialog>
      </div>
    </OpsShell>
  );
}