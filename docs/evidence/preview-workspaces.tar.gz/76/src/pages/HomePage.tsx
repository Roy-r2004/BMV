import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Cedar Point Lodge"} headline={seed.hero?.headline || "Welcome to Cedar Point Lodge"} subcopy={seed.hero?.subcopy} primaryCta={seed.hero?.primaryCta} secondaryCta={seed.hero?.secondaryCta} imageSrc={images.hero} imageAlt="" />
    ),
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Cedar Point Lodge"} items={seed.credentials ?? []} />
    ),
    features: (
      <FeatureBento heading={seed.featuresHeading ?? "What Cedar Point Lodge offers"} imagePool={[images.card1, images.card2, images.card3]} items={seed.features?.length ? seed.features : [{"title": "Work with Cedar Point Lodge", "description": "Clear scope, clear pricing, and a real timeline."}, {"title": "Straight answers", "description": "One point of contact from first call to handover."}, {"title": "Finished properly", "description": "Work you can check over before you pay for it."}]} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Cedar Point Lodge"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.item1, images.item2, images.item3, images.item4, images.item5, images.item6, images.item7, images.item8][index % 8], imageAlt: item.title, badge: String((item as any).badge || (item as any).category || "Featured"), href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "What our guests say"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Cedar Point Lodge?"} description={seed.cta?.description ?? "Tell Cedar Point Lodge what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "/contact#inquire" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "/contact#inquire" }} />
    ),
    footer: (
      <BrandFooter brandName={"Cedar Point Lodge"} description={seed.footer?.description ?? "Cedar Point Lodge — clear choices and real bookings."} />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home-page">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}