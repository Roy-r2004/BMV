// deterministic catalogue contract scaffold
import { useParams } from 'react-router-dom';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, Button, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, InquiryPanel, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "inquire", "cta", "footer"] as const;

export default function AboutUsPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const params = useParams();
  const catalogItems = (seed.items ?? []) as any[];
  const itemKey = String(params.id ?? params.slug ?? '').trim();
  const itemToken = (value: any) =>
    String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  const wantedToken = itemToken(itemKey);
  const itemIndex = catalogItems.findIndex(
    (entry: any, index: number) =>
      wantedToken !== '' &&
      (itemToken(entry?.id) === wantedToken ||
        itemToken(entry?.slug) === wantedToken ||
        itemToken(entry?.title) === wantedToken ||
        String(index + 1) === itemKey),
  );
  const item: any = itemIndex >= 0 ? catalogItems[itemIndex] : undefined;
  const notFound = itemKey !== '' && itemIndex < 0;
  const itemTitle = String(item?.title ?? 'This piece');
  const itemImage = String(
    item?.image ??
      [images.item1, images.item2, images.item3, images.item4,
       images.item5, images.item6, images.item7, images.item8][
        (itemIndex >= 0 ? itemIndex : 0) % 8
      ],
  );
  const itemSpecs = [
    { title: 'Reference', detail: itemKey || String(itemIndex + 1) },
    item?.medium ? { title: 'Medium', detail: String(item.medium) } : null,
    item?.dimensions ? { title: 'Dimensions', detail: String(item.dimensions) } : null,
    item?.price ? { title: 'Price', detail: String(item.price) } : null,
    item?.status ? { title: 'Availability', detail: String(item.status) } : null,
    item?.category ? { title: 'Collection', detail: String(item.category) } : null,
  ].filter(Boolean) as { title: string; detail: string }[];
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Cedar Point Lodge"} eyebrow={"Cedar Point Lodge"} headline={itemTitle} subcopy={String(item?.description ?? "")} variant="item" primaryCta={{ label: "Inquire about this piece", href: "#inquire" }} secondaryCta={{ label: "Back to the collection", href: "/about-us" }} imageSrc={itemImage} imageAlt={itemTitle} />
    ),
    credentials: (
      <CredentialStrip heading="Details" items={itemSpecs} />
    ),
    inquire: (
      <InquiryPanel heading="Ask Cedar Point Lodge a question" itemId={itemKey} itemTitle={itemTitle} />
    ),
    cta: (
      <CTABand heading={seed.cta?.heading ?? "Ready for Cedar Point Lodge?"} description={seed.cta?.description ?? "Tell Cedar Point Lodge what you need — clear options, real next steps."} primaryCta={{ label: seed.cta?.primaryLabel ?? "Get started", href: seed.cta?.primaryHref ?? "/contact#inquire" }} secondaryCta={{ label: seed.cta?.secondaryLabel ?? "Talk to us", href: seed.cta?.secondaryHref ?? "/contact#inquire" }} />
    ),
    footer: (
      <BrandFooter brandName={"Cedar Point Lodge"} description={seed.footer?.description ?? "Cedar Point Lodge — clear choices and real bookings."} />
    ),
  };

  if (notFound) {
    return (
      <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
        <div data-skeleton={skeleton.id} data-detail-not-found="" data-appspec-page="about-us">
          <div className="mx-auto w-full max-w-3xl px-6 pt-32 pb-24 lg:pt-40">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-brand">
              Not found
            </p>
            <h1 className="mt-4 font-display text-[clamp(2rem,4vw,3rem)] leading-tight tracking-tight text-foreground">
              We could not find that one
            </h1>
            <p className="mt-4 text-base leading-7 text-muted">
              It may have sold or moved. Browse what is available now.
            </p>
            <Button href={"/about-us"} className="mt-8">Back to the collection</Button>
          </div>
        </div>
      </PublicShell>
    );
  }

  return (
    <PublicShell brandName={"Cedar Point Lodge"} chrome="solid" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="about-us">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}
