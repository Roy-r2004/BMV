// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

const SKELETON_ID = "public-utility" as const;

export default function ContactUsPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Contact Cedar Point Lodge"}
        description={"Have a question about your stay or our amenities? Reach out to us directly."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Send Us a Message"}
            description={"Fill out our form for general inquiries, booking questions, or special requests."}
            ctaLabel={"Go to Form"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Cedar Point Lodge"}
        description={"Cedar Point Lodge. Your Adirondack escape."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="contact-us">
      </div>
      <PublicShell
      brandName={"Cedar Point Lodge"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
          <div id="automated-guest-inquiry-responder" data-ai-feature-panel="automated-guest-inquiry-responder">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "automated-guest-inquiry-responder") || { id: "automated-guest-inquiry-responder", name: "automated-guest-inquiry-responder" }}
          brandName={"Cedar Point Lodge"}
        />
      </div>
    </PublicShell>
    </>
  );
}
