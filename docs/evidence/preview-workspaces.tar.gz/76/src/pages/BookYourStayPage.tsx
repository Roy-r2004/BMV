import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, BookingPanel, BrandFooter } from '@/ui';

const SKELETON_ID = "public-booking" as const;
const RECIPE_ORDER = ["hero", "credentials", "booking", "footer"] as const;

export default function BookYourStayPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero brandName={"Cedar Point Lodge"} headline={"Book Your Stay"} subcopy={"Book Your Stay — pick a time that works. This page is not the homepage story."} primaryCta={{ label: "Book a visit", href: "/book" }} secondaryCta={{ label: "Back home", href: "/" }} imageSrc={images.card1} imageAlt="" />
    ),
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Cedar Point Lodge"} items={seed.credentials ?? []} />
    ),
    booking: (
      <BookingPanel
        heading="Choose a time"
        treatments={(
          seed.treatments ?? [
            { id: '1', name: 'Standard Massage', duration: '60 minutes', capacity: '1' },
            { id: '2', name: 'Couples Retreat', duration: '90 minutes', capacity: '2' },
            { id: '3', name: 'Facial Treatment', duration: '45 minutes', capacity: '1' },
          ]
        ).map((treatment) => ({
          id: treatment.id,
          name: treatment.name,
          duration: treatment.duration || 'Variable',
          capacity: treatment.capacity || 'N/A',
        }))}
        slots={[{ id: "slot-1", startsAt: "2026-07-14T10:00:00" }]} />
    ),
    footer: (
      <BrandFooter brandName={"Cedar Point Lodge"} description={seed.footer?.description ?? "Cedar Point Lodge — clear choices and real bookings."} />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="book-your-stay">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}