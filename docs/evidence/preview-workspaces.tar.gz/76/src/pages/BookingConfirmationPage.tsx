// composed confirmation page (ConfirmStage)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, BrandFooter, ConfirmStage, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

export default function BookingConfirmationPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();

  return (
    <>
      <div className="contents" data-appspec-page="booking-confirmation">
      </div>
      <PublicShell
      brandName={"Cedar Point Lodge"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <ConfirmStage
        eyebrow={"Confirmed"}
        title={"Your Adirondack Escape is Confirmed!"}
        detail={"Confirmation on file"}
        description={"Thank you for choosing Cedar Point Lodge. We can't wait to welcome you."}
        primaryCta={{"label": "Back to home", "href": "/"}}
        nextSteps={[{"title": "Booking Details", "description": "Confirmation Number: CPL-2024-56789<br>Guest: Amelia Earhart<br>Check-in: August 15, 2024<br>Check-out: August 18, 2024<br>Room Type: Lakeside Suite<br>Total: 1250", "ctaLabel": "View Full Itinerary", "href": "/my-bookings/CPL-2024-56789"}, {"title": "What's Next?", "description": "A detailed confirmation email has been sent to your inbox. It includes check-in instructions, lodge policies, and more.", "ctaLabel": "Email Me Again", "href": "/resend-confirmation/CPL-2024-56789"}, {"title": "Enhance Your Stay", "description": "Add a guided canoe trip, reserve a spot in our sauna, or book a table at our restaurant before you arrive.", "ctaLabel": "Explore Activities", "href": "/experiences"}]}
      />
      <BrandFooter
        brandName={"Cedar Point Lodge"}
        description={"Cedar Point Lodge, 123 Lakefront Drive, Adirondacks, NY. Questions? Contact us at reservations@cedarpointlodge.com"}
      />
          <div id="personalized-pre-arrival-guide" data-ai-feature-panel="personalized-pre-arrival-guide">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "personalized-pre-arrival-guide") || { id: "personalized-pre-arrival-guide", name: "personalized-pre-arrival-guide" }}
          brandName={"Cedar Point Lodge"}
        />
      </div>
    </PublicShell>
    </>
  );
}
