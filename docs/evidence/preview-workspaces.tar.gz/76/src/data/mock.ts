export const brand = {
  name: "Cedar Point Lodge",
  tagline: "Your tranquil lakeside retreat in the heart of the Adirondacks.",
  accent: "#0f766e",
  accent_dark: "#0b5c55",
  accent_light: "#e0f2f1",
  font: "Source Sans 3",

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  services: [{"name": "Cedar Point Lodge Signature", "title": "Cedar Point Lodge Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Cedar Point Lodge experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Cedar Point Lodge experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Cedar", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Cedar Point Lodge clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/33534993/pexels-photo-33534993.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/6790752/pexels-photo-6790752.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/210588/pexels-photo-210588.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/29851821/pexels-photo-29851821.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/9462742/pexels-photo-9462742.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/32175828/pexels-photo-32175828.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item1": "https://images.pexels.com/photos/6466217/pexels-photo-6466217.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item2": "https://images.pexels.com/photos/3872908/pexels-photo-3872908.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item3": "https://images.pexels.com/photos/6394682/pexels-photo-6394682.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item4": "https://images.pexels.com/photos/9145354/pexels-photo-9145354.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item5": "https://images.pexels.com/photos/3872899/pexels-photo-3872899.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item6": "https://images.pexels.com/photos/36328107/pexels-photo-36328107.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item7": "https://images.pexels.com/photos/4820811/pexels-photo-4820811.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item8": "https://images.pexels.com/photos/9146376/pexels-photo-9146376.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Cedar Point Lodge"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Us"
    },
    {
      "id": "about-us",
      "path": "/about-us",
      "href": "/about-us",
      "label": "About Cedar Point Lodge"
    },
    {
      "id": "experiences",
      "path": "/experiences",
      "href": "/experiences",
      "label": "Adirondack Experiences"
    },
    {
      "id": "rooms",
      "path": "/rooms",
      "href": "/rooms",
      "label": "Our Rooms & Suites"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "manager-bookings",
      "path": "/manager/bookings",
      "href": "/manager/bookings",
      "label": "Bookings"
    },
    {
      "id": "manager-guests",
      "path": "/manager/guests",
      "href": "/manager/guests",
      "label": "Guest Profiles"
    },
    {
      "id": "manager-dashboard",
      "path": "/manager/dashboard",
      "href": "/manager/dashboard",
      "label": "Lodge Manager Dashboard"
    },
    {
      "id": "manager-settings",
      "path": "/manager/settings",
      "href": "/manager/settings",
      "label": "Lodge Settings"
    },
    {
      "id": "manager-rooms",
      "path": "/manager/rooms",
      "href": "/manager/rooms",
      "label": "Rooms"
    }
  ],
  "guest": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Cedar Point Lodge"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Us"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "about-us",
      "path": "/about-us",
      "href": "/about-us",
      "label": "About Cedar Point Lodge"
    },
    {
      "id": "experiences",
      "path": "/experiences",
      "href": "/experiences",
      "label": "Adirondack Experiences"
    },
    {
      "id": "rooms",
      "path": "/rooms",
      "href": "/rooms",
      "label": "Our Rooms & Suites"
    }
  ],
  "manager": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "manager-bookings",
      "path": "/manager/bookings",
      "href": "/manager/bookings",
      "label": "Bookings"
    },
    {
      "id": "manager-guests",
      "path": "/manager/guests",
      "href": "/manager/guests",
      "label": "Guest Profiles"
    },
    {
      "id": "manager-dashboard",
      "path": "/manager/dashboard",
      "href": "/manager/dashboard",
      "label": "Lodge Manager Dashboard"
    },
    {
      "id": "manager-settings",
      "path": "/manager/settings",
      "href": "/manager/settings",
      "label": "Lodge Settings"
    },
    {
      "id": "manager-rooms",
      "path": "/manager/rooms",
      "href": "/manager/rooms",
      "label": "Rooms"
    }
  ]
};

export const roles = [
  {
    "id": "guest",
    "label": "Guest",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "manager",
    "label": "Lodge Manager",
    "defaultPath": "/manager/dashboard",
    "icon": "chart"
  }
];

export const seed = {
  featuresHeading: 'What Cedar Point Lodge offers',
  showcaseHeading: 'From Cedar Point Lodge',
  // Public-facing content
  hero: {
    headline: "Your Lakeside Escape Awaits in the Adirondacks",
    subcopy: "Discover the tranquility of Cedar Point Lodge, an intimate retreat with unparalleled hospitality and natural beauty.",
    primaryCta: { label: "Check Availability", href: "/book" },
    secondaryCta: { label: "Explore Our Rooms", href: "/rooms" },
  },
  services: [
    {
      id: "riverside-dining",
      title: "Riverside Dining",
      description: "Savor locally-sourced cuisine with breathtaking lake views at our on-site restaurant.",
      imageSrc: images.card3,
      badge: "Culinary"
    },
    {
      id: "adirondack-sauna",
      title: "Adirondack Sauna",
      description: "Unwind and rejuvenate in our traditional lakeside sauna, offering ultimate relaxation.",
      imageSrc: images.card2,
      badge: "Relaxation"
    },
    {
      id: "guided-canoe-trips",
      title: "Guided Canoe Trips",
      description: "Explore the pristine waters of the Adirondacks with our expert-guided canoe adventures.",
      imageSrc: images.hero2,
      badge: "Adventure"
    },
  ],
  features: [
    {
      id: "intimate-accommodations",
      title: "Intimate Accommodations",
      description: "Eighteen uniquely appointed rooms, each offering comfort and serene lakeside or forest views.",
      imageSrc: images.item1
    },
    {
      id: "direct-booking-advantage",
      title: "Direct Booking Advantage",
      description: "Enjoy the best rates and personalized service when you book directly with us.",
      imageSrc: images.card1
    },
    {
      id: "seamless-planning",
      title: "Seamless Planning",
      description: "Easily check availability, compare rooms, and reserve your stay online.",
      imageSrc: images.card3
    },
  ],
  process: [
    { title: "Select Dates", description: "Choose your desired check-in and check-out dates to see what's available." },
    { title: "Browse Rooms", description: "Explore our room types with detailed descriptions and stunning photos." },
    { title: "Confirm & Relax", description: "Complete your booking securely and start planning your Adirondack adventure." },
  ],
  testimonials: [
    {
      quote: "Cedar Point Lodge offered the perfect blend of rustic charm and modern comfort. The guided canoe trip was unforgettable!",
      author: "Sarah M.",
      role: "Guest from New York"
    },
    {
      quote: "The restaurant's fresh, local ingredients and lake views were incredible. A truly memorable dining experience.",
      author: "David R.",
      role: "Guest from Vermont"
    },
    {
      quote: "Pure bliss in the sauna after a day exploring. Cedar Point Lodge is exactly what we needed to unwind.",
      author: "Jessica T.",
      role: "Guest from Boston"
    },
    {
      quote: "Booking was straightforward, and the staff were exceptionally welcoming. Our lakeside suite was perfect.",
      author: "Robert & Emily G.",
      role: "Guests from Montreal"
    },
  ],
  credentials: [
    { title: "Lakeside Retreat", detail: "Nestled on the tranquil shores of Lake Placid." },
    { title: "Eighteen Rooms", detail: "Intimate, personalized stays for every guest." },
    { title: "Est. 1985", detail: "Decades of Adirondack hospitality." },
  ],
  credentialsHeading: "Experience the Cedar Point Difference",
  trustLabels: [
    "Direct Booking Benefits",
    "Personalized Service",
    "Local Adirondack Experience",
  ],
  cta: {
    heading: "Ready for Your Adirondack Escape?",
    description: "Plan your perfect getaway to Cedar Point Lodge. Check availability and book your serene lakeside retreat today.",
    primaryLabel: "Book Your Stay",
    primaryHref: "/book",
    secondaryLabel: "Explore Rooms",
    secondaryHref: "/rooms",
  },
  footer: {
    description: "Cedar Point Lodge — your tranquil lakeside retreat in the heart of the Adirondacks.",
  },

  // Room & Suites Page data
  items: [
    {
      id: "lakeview-suite",
      title: "Lakeview Suite",
      description: "Spacious suite with a private balcony overlooking Lake Placid. Features a king bed, sitting area, and spa-like bathroom.",
      capacity: "2-4 guests",
      amenities: ["King Bed", "Private Balcony", "Lake View", "Jacuzzi Tub", "Mini-fridge"],
      price: "$450/night",
      image: images.item5,
    },
    {
      id: "forest-nook-room",
      title: "Forest Nook Room",
      description: "Cozy room nestled among the pines, offering serene forest views. Perfect for a quiet retreat.",
      capacity: "2 guests",
      amenities: ["Queen Bed", "Forest View", "Ensuite Bathroom", "Coffee Maker"],
      price: "$280/night",
      image: images.item1,
    },
    {
      id: "adirondack-cabin",
      title: "Adirondack Cabin",
      description: "A rustic-chic standalone cabin with a fireplace and private patio, ideal for extended stays.",
      capacity: "2-3 guests",
      amenities: ["King Bed", "Private Patio", "Fireplace", "Kitchenette", "Forest View"],
      price: "$550/night",
      image: images.item6,
    },
    {
      id: "riverside-deluxe",
      title: "Riverside Deluxe",
      description: "Elegant room with direct access to the riverbank, perfect for early morning nature walks.",
      capacity: "2 guests",
      amenities: ["Queen Bed", "River Access", "Reading Nook", "Spa Shower"],
      price: "$320/night",
      image: images.item4,
    },
    {
      id: "sunset-balcony",
      title: "Sunset Balcony Room",
      description: "Enjoy stunning Adirondack sunsets from your private balcony in this comfortable room.",
      capacity: "2 guests",
      amenities: ["Queen Bed", "Sunset View", "Private Balcony", "Smart TV"],
      price: "$300/night",
      image: images.item5,
    },
  ],

  // Booking Page content
  treatments: [
    { id: "room", name: "Room Booking", duration: null, capacity: null },
    { id: "canoe-trip", name: "Guided Canoe Trip", duration: "2 hours", capacity: "4 people" },
    { id: "sauna-session", name: "Private Sauna Session", duration: "1 hour", capacity: "2 people" },
    { id: "dining-reservation", name: "Restaurant Reservation", duration: "1.5 hours", capacity: "6 people" },
  ],

  // Admin Dashboard Content
  opsHero: {
    headline: "Adirondack Lakeside Concierge: Lodge Operations Dashboard",
    subcopy: "Manage bookings, guests, and inventory for Cedar Point Lodge."
  },
  tableRows: [
    {
      id: "bk001",
      guest: "Miller Family",
      room: "Lakeview Suite (Rm 5)",
      checkIn: "2024-09-10",
      checkOut: "2024-09-15",
      status: "Confirmed",
      total: "$2250",
    },
    {
      id: "bk002",
      guest: "Sarah Johnson",
      room: "Forest Nook (Rm 12)",
      checkIn: "2024-09-12",
      checkOut: "2024-09-14",
      status: "Confirmed",
      total: "$560",
    },
    {
      id: "bk003",
      guest: "David Chen",
      room: "Adirondack Cabin (Cabin 1)",
      checkIn: "2024-09-18",
      checkOut: "2024-09-22",
      status: "Pending Deposit",
      total: "$2200",
    },
    {
      id: "bk004",
      guest: "Eleanor Vance",
      room: "Riverside Deluxe (Rm 8)",
      checkIn: "2024-09-15",
      checkOut: "2024-09-18",
      status: "Confirmed",
      total: "$960",
    },
    {
      id: "bk005",
      guest: "Robert Green",
      room: "Sunset Balcony (Rm 14)",
      checkIn: "2024-09-20",
      checkOut: "2024-09-23",
      status: "Confirmed",
      total: "$900",
    },
    {
      id: "bk006",
      guest: "Sophia Patel",
      room: "Lakeview Suite (Rm 6)",
      checkIn: "2024-09-25",
      checkOut: "2024-09-28",
      status: "Confirmed",
      total: "$1350",
    },
    {
      id: "bk007",
      guest: "Michael Ramirez",
      room: "Forest Nook (Rm 10)",
      checkIn: "2024-09-28",
      checkOut: "2024-09-30",
      status: "Confirmed",
      total: "$560",
    },
    {
      id: "bk008",
      guest: "Jessica Thompson",
      room: "Adirondack Cabin (Cabin 2)",
      checkIn: "2024-10-01",
      checkOut: "2024-10-05",
      status: "Confirmed",
      total: "$2200",
    },
    {
      id: "bk009",
      guest: "Daniel Lee",
      room: "Riverside Deluxe (Rm 9)",
      checkIn: "2024-10-03",
      checkOut: "2024-10-06",
      status: "Pending Payment",
      total: "$960",
    },
    {
      id: "bk010",
      guest: "Olivia White",
      room: "Sunset Balcony (Rm 16)",
      checkIn: "2024-10-05",
      checkOut: "2024-10-07",
      status: "Confirmed",
      total: "$600",
    },
  ],
  activity: [
    { title: "New booking confirmed for Lakeview Suite (Rm 5)", detail: "Guest: Miller Family (Sep 10-15)", time: "Just now" },
    { title: "Canoe Trip (Sep 12, 10 AM) - 2 spots filled", detail: "Booking: Sarah Johnson", time: "15 minutes ago" },
    { title: "Guest inquiry received about pet policy", detail: "From: David Chen", time: "45 minutes ago" },
    { title: "Sauna session (Sep 11, 4 PM) added to booking", detail: "Booking: Eleanor Vance", time: "2 hours ago" },
    { title: "Room 18 blocked for maintenance", detail: "Dates: Sep 16-18", time: "Yesterday" },
  ],
};

export const stats = {
  kpis: [
    { label: "Upcoming Bookings", value: "12", delta: "+2", hint: "Next 7 days" },
    { label: "Rooms Available", value: "5", delta: "-1", hint: "Today" },
    { label: "Avg. Occupancy", value: "78%", delta: "+5%", hint: "This Month" },
    { label: "New Inquiries", value: "3", delta: "+1", hint: "Last 24 hrs" },
  ],
  items: [
    { title: "Lakeview Suite (Room 5)", description: "Booked by the Miller Family, Check-in: Sep 10" },
    { title: "Forest Nook (Room 12)", description: "Available, Minimum 2-night stay" },
    { title: "Canoe Trip Slot (Sep 12, 10 AM)", description: "2/4 spots filled" },
  ],
  risks: [
    { id: "risk-1", title: "Low availability for upcoming weekend", detail: "Only 1 room remaining for Sep 10-12. Recommend adjusting pricing or promoting add-ons.", severity: "medium" },
    { id: "risk-2", title: "Outstanding payment for booking BK009", detail: "Guest Daniel Lee's payment is still pending. Send reminder.", severity: "high" },
  ],
};


export const aiFeatures = [
  {
    id: "dynamic-room-recommendation",
    name: "Dynamic Room Recommendation",
    description: "Analyzes guest's selected dates and preferences (e.g., number of guests) to suggest the most suitable room types, potentially highlighting unique features that align with typical guest needs for those dates.",
    category: "automation",
    surface: "automation",
    demo_hint: "Trigger the automation Cedar Point Lodge actually needs",
    demo_prompts: [
      "Suggest best room for 2 adults, 3 nights in October",
      "Recommend rooms for family with young children",
      "Find dog-friendly rooms available next month"
    ],
    placement_label: "Room AI",
    demo_results: {
      "Suggest best room for 2 adults, 3 nights in October": "For 2 adults, 3 nights in October: Lakeview Suite (Rm 5) is available with stunning views. Offers privacy and a balcony perfect for autumn mornings. Consider the Adirondack Cabin if you prefer more space and a fireplace.",
      "Recommend rooms for family with young children": "For families with young children: Adirondack Cabins offer more space and a kitchenette. Forest Nook rooms (Rm 10, 12) can be connected if multiple rooms are needed. Availability varies by date.",
      "Find dog-friendly rooms available next month": "Dog-friendly rooms (Forest Nook Rm 10 & Riverside Deluxe Rm 8) show good availability next month. We can provide a pet bed and bowls upon request."
    },
    placement_path: "/book",
    placement_component: "src/pages/BookYourStayPage.tsx",
    placement_title: "Book Your Stay",
  },
  {
    id: "personalized-pre-arrival-guide",
    name: "Personalized Pre-Arrival Guide",
    description: "Generates a tailored pre-arrival email for each guest, incorporating details from their booking (e.g., room type, duration) and suggesting relevant local activities or lodge amenities based on historical guest interests.",
    category: "communications",
    surface: "communications",
    demo_hint: "Ask for a personalized guide for a specific guest",
    demo_prompts: [
      "Generate guide for Miller Family (Lakeview Suite)",
      "Create pre-arrival email for Sarah Johnson (Forest Nook)",
      "Draft guide for David Chen (Adirondack Cabin)"
    ],
    placement_label: "Guest Communications",
    demo_results: {
      "Generate guide for Miller Family (Lakeview Suite)": "Personalized guide for Miller Family: Highlights Lakeview Suite features, suggests sunset canoe trip, and dinner reservation at 7 PM. Draft sent for your review.",
      "Create pre-arrival email for Sarah Johnson (Forest Nook)": "Pre-arrival email for Sarah Johnson: Includes Forest Nook details, notes proximity to hiking trails, and offers guided nature walk booking. Ready to send.",
      "Draft guide for David Chen (Adirondack Cabin)": "Guide for David Chen (Adirondack Cabin): Emphasizes fireplace use, suggests local fall foliage tours, and reminds about check-in procedures. Draft complete."
    },
    placement_path: "/admin/bookings",
    placement_component: "src/pages/admin/BookingsPage.tsx",
    placement_title: "Bookings Management",
  },
  {
    id: "automated-guest-inquiry-responder",
    name: "Automated Guest Inquiry Responder",
    description: "Provides instant, accurate answers to common guest questions submitted via the contact form or a dedicated chat interface, freeing up staff time for complex inquiries.",
    category: "chat",
    surface: "chat",
    demo_hint: "Ask the way a real guest would ask Cedar Point Lodge",
    demo_prompts: [
      "What is your pet policy?",
      "Are children allowed in the sauna?",
      "Do you offer vegetarian options at the restaurant?"
    ],
    placement_label: "Customer Assistant",
    demo_results: {
      "What is your pet policy?": "Our pet policy: Small, well-behaved dogs are welcome in designated Forest Nook rooms and Adirondack Cabins with a nightly fee. Please review our full policy on our website or contact us for details.",
      "Are children allowed in the sauna?": "Children under 16 must be accompanied by an adult in the sauna. We recommend consulting with a doctor for children's use. Full sauna guidelines are available at the lodge.",
      "Do you offer vegetarian options at the restaurant?": "Yes, our restaurant offers a selection of delicious vegetarian and vegan options, crafted with seasonal, local ingredients. Please inform us of any dietary restrictions when making your reservation."
    },
    placement_path: "/contact",
    placement_component: "src/pages/ContactUsPage.tsx",
    placement_title: "Contact Us",
  },
];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
