// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter, Button } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const; // Adjusted order to fit page brief

export default function GalleryHomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const heroImage = images.hero2; // Using hero2 for full-width hero as per page brief

  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Jeanne Kassab Art"} items={seed.credentials ?? []} />
    ),
    features: (
      <FeatureBento heading={seed.featuresHeading ?? "What Jeanne Kassab Art offers"} imagePool={[images.card1, images.card2, images.card3]} items={seed.features?.length ? seed.features : [{"title": "Original works", "description": "Signed pieces, each one photographed as it hangs."}, {"title": "Commissions", "description": "A piece scaled to your room, your light, your palette."}, {"title": "Collector support", "description": "Framing, shipping, and placement handled end to end."}]} />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    hero: (
      <div className="relative">
        <img
          src={heroImage}
          alt="Abstract landscape oil painting"
          className="w-full h-[60vh] object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-background to-transparent flex flex-col justify-center items-center p-8 text-center text-white">
          <h1 className="font-display text-text-brand text-6xl md:text-8xl lg:text-9xl mb-4 text-shadow-lg" style={{ /* Tailwind text-shadow-lg is defined via theme config, no explicit style attr needed here if properly configured */}}>
            Jeanne Kassab Art
          </h1>
          <h2 className="font-sans text-brand-muted text-xl md:text-2xl lg:text-3xl mb-8">
            Original Oil Paintings
          </h2>
          <div className="flex space-x-4">
            <Button variant="outline" size="lg" href="/gallery" className="text-brand-text border-brand-text hover:bg-brand-muted/20">
              Explore the Collection
            </Button>
            <Button variant="solid" size="lg" href="/about" className="bg-brand-primary text-white hover:bg-brand-primary/80">
              About the Artist
            </Button>
          </div>
        </div>
      </div>
    ), // Not used in this brief    // Not used in this brief
    showcase: (
      <div className="container mx-auto px-4 py-16">
        <h2 className="font-display text-text-brand text-5xl mb-12 text-center">Recent & Featured Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {/* Using ProductShowcase structure - each item should ideally be a link to detail page */}
          {/* Placeholder for 8 paintings as noted in sample data, adjusting items to fit ProductShowcase prop shape */}
          {[
            { title: 'Coastal Reverie', description: 'Oil on Canvas', imageSrc: images.card1, href: '/gallery/coastal-reverie' },
            { title: 'Whispers of the Deep', description: 'Oil on Canvas', imageSrc: images.card2, href: '/gallery/whispers-of-the-deep' },
            { title: 'Ethereal Layers I', description: 'Oil on Canvas', imageSrc: images.card3, href: '/gallery/ethereal-layers-i' },
            { title: 'Blue Ridge Echoes', description: 'Oil on Canvas', imageSrc: images.card1, href: '/gallery/blue-ridge-echoes' },
            { title: 'Golden Hour Abstract', description: 'Oil on Canvas', imageSrc: images.card2, href: '/gallery/golden-hour-abstract' },
            { title: 'Forest Canopy', description: 'Oil on Canvas', imageSrc: images.card3, href: '/gallery/forest-canopy' },
            { title: 'Oceanic Depths', description: 'Oil on Canvas', imageSrc: images.card1, href: '/gallery/oceanic-depths' },
            { title: 'Desert Bloom', description: 'Oil on Canvas', imageSrc: images.card2, href: '/gallery/desert-bloom' },
          ].map((item, index) => (
            <div key={index} className="relative group overflow-hidden">
              <img src={item.imageSrc} alt={item.title} className="w-full aspect-square object-cover transition-transform duration-300 group-hover:scale-105" />
              <a href={item.href} className="absolute inset-0 bg-black bg-opacity-50 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-white p-4">
                <h3 className="font-display text-2xl font-bold text-white">{item.title}</h3>
                <p className="font-sans text-lg text-white">{item.description}</p>
              </a>
            </div>
          ))}
        </div>
        {/* Editorial Message section */}
        <div className="max-w-3xl mx-auto text-center py-16 px-4">
          <h2 className="font-display text-text-brand text-4xl leading-tight mb-6">The Canvas Collection</h2>
          <p className="font-sans text-muted-text text-lg leading-relaxed">
            Every brushstroke in The Canvas Collection tells a story, capturing the fleeting beauty of nature and the profound depth of human emotion. Jeanne Kassab's process involves extensive layering and subtle shifts in color, inviting viewers into an intimate experience with each piece. These aren't just paintings; they are portals to moments of calm, reflection, and quiet wonder, designed to bring a profound sense of presence to any space.
          </p>
        </div>
      </div>
    ), // Not used in this brief
    cta: (
      <CTABand
        heading="Connect with the Canvas"
        description="Discover your next cherished artwork. Every piece holds a unique story, waiting to become a part of yours."
        primaryCta={{ label: "Explore the Gallery", href: "/gallery" }}
        secondaryCta={{ label: "Inquire Directly", href: "https://wa.me/YOUR_WHATSAPP_NUMBER", target: "_blank" }}
        className="bg-brand-surface py-20"
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings for collectors and designers. Created with intention, shared with care."}
        links={[
          { label: "Gallery", href: "/gallery" },
          { label: "About", href: "/about" },
          { label: "Contact", href: "/contact" },
          { label: "Privacy Policy", href: "/privacy" },
        ]}
        className="bg-brand-background text-text-brand border-t border-brand-muted/20"
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="gallery-home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}