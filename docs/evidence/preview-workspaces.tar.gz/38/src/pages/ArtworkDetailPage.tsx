import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"Unveiling 'Whispers of the Horizon'"}
        subcopy={"An original oil painting by Jeanne Kassab, exploring abstract landscapes with layered depth."}
        variant="atelier"
        primaryCta={{ label: "Inquire about this piece", href: "https://wa.me/YOUR_PHONE_NUMBER?text=Hello%20Jeanne%2C%20I'm%20interested%20in%20'Whispers%20of%20the%20Horizon'.", }}
        imageSrc={images.hero}
        imageAlt="Detail of an oil painting titled 'Whispers of the Horizon' by Jeanne Kassab"
      />
    ),
    credentials: (
      <CredentialStrip
        heading={"My Process & Materials"}
        items={[
          { title: "Layered Oils", detail: "Each piece built with luminous layers for depth and translucency." },
          { title: "Archival Quality", detail: "Dedicated to professional-grade pigments and canvases." },
          { title: "Original Works", detail: "Every painting is a unique, one-of-a-kind creation." },
          { title: "Direct from Studio", detail: "Curated and presented directly from my creative space." },
        ]}
      />
    ),
    showcase: (
      <ProductShowcase
        heading={"From The Canvas Collection"}
        items={[
          {
            title: "Azure Depths",
            description: "A calming abstract landscape with deep blues.",
            imageSrc: images.card1,
            imageAlt: "Abstract landscape painting named Azure Depths",
            badge: "Available",
            href: `/gallery/azure-depths`,
          },
          {
            title: "Golden Hour Bloom",
            description: "Warm, textured oils capturing ephemeral light.",
            imageSrc: images.card2,
            imageAlt: "Textured oil painting named Golden Hour Bloom",
            badge: "Available",
            href: `/gallery/golden-hour-bloom`,
          },
          {
            title: "Silent Shores",
            description: "Meditative study of coastal tranquility.",
            imageSrc: images.card3,
            imageAlt: "Coastal abstract painting named Silent Shores",
            badge: "Available",
            href: `/gallery/silent-shores`,
          },
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading={"From Collectors Like You"}
        items={[
          {
            quote: "Jeanne's work brings such a profound sense of calm to our living space. The textures are simply breathtaking.",
            author: "Eleanor V.",
            role: "Collector",
          },
          {
            quote: "Working with Jeanne was a dream. The painting arrived beautifully packaged and even more vibrant in person.",
            author: "Marcus T.",
            role: "Interior Designer",
          },
          {
            quote: "Each brushstroke tells a story. We feel incredibly fortunate to own a piece of Jeanne's world.",
            author: "Sophia R.",
            role: "Art Enthusiast",
          },
        ]}
      />
    ),
    cta: (
      <CTABand
        heading={"Connect with the Studio"}
        description={"Have a question about a painting? Interested in a commission? I'm here to help."}
        primaryCta={{ label: "Message me on WhatsApp", href: "https://wa.me/YOUR_PHONE_NUMBER?text=Hello%20Jeanne%2C%20I%20have%20a%20question%20about%20your%20art." }}
        secondaryCta={{ label: "Explore the Gallery", href: "/gallery" }}
      />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={"Original oil paintings for collectors and designers. Cultivating beauty, one brushstroke at a time."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="gallery_detail">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}