// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Dialog, Input } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-list" as const;

export default function AdminCollectionsPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // Sample data for collections, mimicking structure for a real application
  const [collections, setCollections] = useState([
    { id: '1', name: 'Abstract Landscapes', paintingsCount: 12 },
    { id: '2', name: 'Layered Oils', paintingsCount: 8 },
    { id: '3', name: 'Coastal Visions', paintingsCount: 5 },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');

  const filteredCollections = collections.filter(collection =>
    collection.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDeleteCollection = (id: string) => {
    // In a real app, this would involve an API call
    if (window.confirm("Are you sure you want to delete this collection? This action cannot be undone.")) {
      setCollections(collections.filter(collection => collection.id !== id));
    }
  };

  const handleAddCollection = () => {
    if (newCollectionName.trim()) {
      const newCollection = {
        id: (collections.length + 1).toString(),
        name: newCollectionName.trim(),
        paintingsCount: 0,
      };
      setCollections([...collections, newCollection]);
      setNewCollectionName('');
      setIsDialogOpen(false);
    }
  };

  const slots = {
    header: (
      <PageHeader
        title="Manage Collections"
        actions={[
          <Dialog
            key="add-collection-dialog"
            title="Create New Collection"
            description="Enter a name for your new art collection."
            showTrigger={true}
            triggerLabel="Add New Collection"
            open={isDialogOpen}
            onOpenChange={setIsDialogOpen}
            footer={
              <>
                <Button variant="ghost" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleAddCollection}>Create Collection</Button>
              </>
            }
          >
            <Input
              label="Collection Name"
              placeholder="e.g., 'Mediterranean Series'"
              value={newCollectionName}
              onChange={(e) => setNewCollectionName(e.target.value)}
              className="mt-4"
            />
          </Dialog>
        ]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search collection names"
        searchValue={searchTerm}
        onSearchChange={(value) => setSearchTerm(value)}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "name", header: "Collection Name" },
          {
            key: "paintingsCount",
            header: "Number of Paintings",
            render: (row) => `${row.paintingsCount} Paintings`
          },
          {
            key: "actions",
            header: "Actions",
            render: (row) => (
              <div className="flex gap-2">
                {/* Placeholder for actual edit/view logic specific to each row's ID */}
                <Button variant="ghost" size="sm" onClick={() => alert(`Edit ${row.name}`)}>Edit</Button>
                <Button variant="ghost" size="sm" onClick={() => alert(`View paintings in ${row.name}`)}>View Paintings</Button>
                <Button variant="destructive" size="sm" onClick={() => handleDeleteCollection(row.id)}>Delete</Button>
              </div>
            ),
          },
        ]}
        rows={filteredCollections.map(col => ({
          ...col,
          id: col.id, // Ensure id is passed for unique keys if needed internally by DataTable for other actions
        }))}
        emptyMessage="No collections found. Start by adding a new one!"
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-collections">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}