// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed, aiFeatures } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, Button, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // Mock data for the chart
  const paintingInquiriesTrendData = [
    { day: "Day 1", value: 1 }, { day: "Day 2", value: 2 }, { day: "Day 3", value: 3 },
    { day: "Day 4", value: 2 }, { day: "Day 5", value: 4 }, { day: "Day 6", value: 3 },
    { day: "Day 7", value: 5 }, { day: "Day 8", value: 2 }, { day: "Day 9", value: 3 },
    { day: "Day 10", value: 1 }, { day: "Day 11", value: 2 }, { day: "Day 12", value: 4 },
    { day: "Day 13", value: 3 }, { day: "Day 14", value: 5 }, { day: "Day 15", value: 2 },
    { day: "Day 16", value: 4 }, { day: "Day 17", value: 1 }, { day: "Day 18", value: 3 },
    { day: "Day 19", value: 2 }, { day: "Day 20", value: 5 }, { day: "Day 21", value: 3 },
    { day: "Day 22", value: 1 }, { day: "Day 23", value: 4 }, { day: "Day 24", value: 2 },
    { day: "Day 25", value: 5 }, { day: "Day 26", value: 3 }, { day: "Day 27", value: 1 },
    { day: "Day 28", value: 4 }, { day: "Day 29", value: 2 }, { day: "Day 30", value: 5 }
  ];

  const slots = {
    header: (
      <PageHeader
        title="The Canvas Collection Admin"
        description="Welcome back, Jeanne. Here's a glimpse into your gallery's pulse."
        actions={[
          { label: "Add New Painting", href: "/admin/paintings/new", variant: "default" },
          { label: "Manage Collections", href: "/admin/collections", variant: "secondary" },
          { label: "Update About Page", href: "/admin/about", variant: "secondary" }
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard 
          label="Total Paintings" 
          value="28" 
          delta="+2 Last 30 days" 
          variant="card" 
          className="bg-surface text-text" 
          deltaClassName="text-brand-primary"
        />
        <StatCard 
          label="Active Inquiries" 
          value="4" 
          delta="0 Via WhatsApp today" 
          variant="card" 
          className="bg-surface text-text" 
          deltaClassName="text-brand-secondary"
        />
        <StatCard 
          label="Sold This Month" 
          value="1" 
          delta="New sale" 
          variant="card" 
          className="bg-surface text-text" 
          deltaClassName="text-brand-primary"
        />
      </div>
    ),
    chart: (
      <ChartCard 
        title="Painting Inquiries Trend (Last 30 Days)" 
        type="area" 
        dataKey="value" 
        xKey="day" 
        data={paintingInquiriesTrendData} 
        description="Daily inquiries across all artworks."
      />
    ),
    filters: (
      <FilterBar searchPlaceholder="Search updates..." filters={[]} actions={[]} />
    ),
    table: (
      <DataTable
        columns={[
          { key: "Title", header: "Title" }, 
          { key: "Description", header: "Description" }, 
          { key: "When", header: "When" }
        ]}
        rows={[
          { Title: "Abstract Horizon VI", Description: "New painting added to 'Abstract Landscapes' collection.", When: "2 days ago" },
          { Title: "Coastal Reverie", Description: "Artwork marked as 'Available, inquire for price'.", When: "5 days ago" },
          { Title: "Layered Depth III", Description: "Updated dimensions and artistic statement.", When: "1 week ago" }
        ]}
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { title: "New painting: 'Coastal Reverie'", timestamp: "Just now" },
          { title: "WhatsApp Inquiry: 'Blue Ridge Echoes'", timestamp: "10 min ago" },
          { title: "Updated 'About' page content", timestamp: "2 hours ago" },
          { title: "Painting 'Abstract Horizon VI' added", timestamp: "2 days ago" },
          { title: "Image updated for 'Golden Vista'", timestamp: "3 days ago" },
          { title: "WhatsApp Inquiry: 'Crimson Tide'", timestamp: "5 days ago" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems} rail={rail} appearance="soft">
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
          <div id="intelligent-image-cropping" data-ai-feature-panel="intelligent-image-cropping">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "intelligent-image-cropping") || { id: "intelligent-image-cropping", name: "intelligent-image-cropping" }}
          brandName={"Jeanne Kassab Art"}
        />
      </div>
          <div id="ai-powered-tagging-suggestions" data-ai-feature-panel="ai-powered-tagging-suggestions">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "ai-powered-tagging-suggestions") || { id: "ai-powered-tagging-suggestions", name: "ai-powered-tagging-suggestions" }}
          brandName={"Jeanne Kassab Art"}
        />
      </div>
    </OpsShell>
  );
}