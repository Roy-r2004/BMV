// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Input, Button } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-settings" as const;
export default function AdminAboutPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // State for form fields
  const [artistName, setArtistName] = useState('Jeanne Kassab');
  const [artistBio, setArtistBio] = useState('Jeanne Kassab is a contemporary artist known for her evocative abstract landscapes and deeply layered oil paintings. Her work explores the interplay of light, texture, and emotion, drawing inspiration from natural forms and atmospheric shifts. With a dedication to traditional techniques combined with a modern sensibility, Jeanne invites viewers into contemplative spaces where art becomes a dialogue between the canvas and the soul. Her pieces grace private collections and design projects worldwide, reflecting a serene yet powerful presence.');
  const [artistStatement, setArtistStatement] = useState('My artistic journey is a continuous exploration of nature’s quiet grandeur and the unseen energies that shape our world. Through oil and cold wax, I build layers that echo the passage of time and the complexities of memory. Each brushstroke is an attempt to capture a fleeting moment, a feeling, or the profound silence found within vast open spaces. I aim to create work that resonates deeply, offering a moment of pause and reflection.');
  const [artistEmail, setArtistEmail] = useState('hello@jeannekassabart.com');

  const handleSave = () => {
    // In a real application, this would dispatch an action to save the data
    console.log('Saving changes:', { artistName, artistBio, artistStatement, artistEmail });
    alert('Changes saved successfully!');
  };

  const slots = {
    header: (
      <PageHeader title={"Edit About Page"} />
    ),
    // Additional content goes below the header, within the OpsShell's children
    // The skeleton does not define specific slots for form elements, so we place them directly as children
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-about">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />

        <div className="p-8 space-y-6">
          {/* Artist Name */}
          <div>
            <label htmlFor="artist-name" className="block text-sm font-medium text-muted mb-1">Artist Name</label>
            <Input
              id="artist-name"
              className="w-full"
              value={artistName}
              onChange={(e) => setArtistName(e.target.value)}
              placeholder="Enter artist's full name"
            />
          </div>

          {/* Artist Email */}
          <div>
            <label htmlFor="artist-email" className="block text-sm font-medium text-muted mb-1">Email</label>
            <Input
              id="artist-email"
              type="email"
              className="w-full"
              value={artistEmail}
              onChange={(e) => setArtistEmail(e.target.value)}
              placeholder="Enter contact email"
            />
          </div>

          {/* Artist Biography */}
          <div>
            <label htmlFor="artist-bio" className="block text-sm font-medium text-muted mb-1">Artist Biography</label>
            <Input
              id="artist-bio"
              as="textarea"
              rows={8}
              className="w-full resize-y"
              value={artistBio}
              onChange={(e) => setArtistBio(e.target.value)}
              placeholder="Introduce yourself and your artistic journey."
            />
          </div>

          {/* Artist Statement */}
          <div>
            <label htmlFor="artist-statement" className="block text-sm font-medium text-muted mb-1">Artist Statement</label>
            <Input
              id="artist-statement"
              as="textarea"
              rows={6}
              className="w-full resize-y"
              value={artistStatement}
              onChange={(e) => setArtistStatement(e.target.value)}
              placeholder="Share the inspiration and philosophy behind your art."
            />
          </div>

          {/* Save Changes Button */}
          <div className="flex justify-end pt-4">
            <Button
              variant="primary"
              onClick={handleSave}
            >
              Save Changes
            </Button>
          </div>
        </div>
      </div>
    </OpsShell>
  );
}