// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Select, UiIcon } from '@/ui';

const SKELETON_ID = "ops-list" as const;

export default function AdminPaintingsPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const paintingData = [
    {
      id: "p1",
      thumbnail: "https://d1xsc6yrf0t25x.cloudfront.net/01-full-bleed-art-grid-image-2-720w.jpg", // Mock image, replace with actual path
      title: "Abstract Horizon VI",
      collection: "Abstract Landscapes",
      status: "Available",
    },
    {
      id: "p2",
      thumbnail: "https://d1xsc6yrf0t25x.cloudfront.net/01-full-bleed-art-grid-image-4-720w.jpg", // Mock image, replace with actual path
      title: "Whispers of the Coast",
      collection: "Layered Oils",
      status: "Sold",
    },
    {
      id: "p3",
      thumbnail: "https://d1xsc6yrf0t25x.cloudfront.net/01-full-bleed-art-grid-image-12-720w.jpg", // Mock image, replace with actual path
      title: "Emerald Depth",
      collection: "Deep Sea Series",
      status: "Upon Inquiry",
    },
    {
      id: "p4",
      thumbnail: "https://d1xsc6yrf0t25x.cloudfront.net/01-full-bleed-art-grid-image-10-720w.jpg", // Mock image, replace with actual path
      title: "Morning Mist",
      collection: "Abstract Landscapes",
      status: "Available",
    },
  ];

  const columns = [
    {
      key: "thumbnail",
      header: "Image Thumbnail",
      render: (row: typeof paintingData[number]) => (
        <img src={row.thumbnail} alt={row.title} className="w-16 h-16 object-cover rounded-md" />
      ),
    },
    { key: "title", header: "Title" },
    { key: "collection", header: "Collection" },
    { key: "status", header: "Status" },
    {
      key: "actions",
      header: "Actions",
      render: (row: typeof paintingData[number]) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" aria-label={`Edit ${row.title}`}>
            <UiIcon name="pencil" className="w-4 h-4" />
          </Button>
          <Button variant="destructive" size="sm" aria-label={`Delete ${row.title}`}>
            <UiIcon name="trash" className="w-4 h-4" />
          </Button>
          <Button variant="secondary" size="sm" aria-label={`Mark ${row.title} as Sold`}>
            <UiIcon name="tag" className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];

  const slots = {
    header: (
      <PageHeader
        title={"Manage Paintings"}
        actions={[
          { label: "Add New Painting", onClick: () => console.log("Add New Painting"), variant: "primary" }
        ]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search paintings..."
        filters={[
          {
            id: "collection-filter",
            label: (
              <Select
                options={[
                  { value: "all", label: "All Collections" },
                  { value: "abstract-landscapes", label: "Abstract Landscapes" },
                  { value: "layered-oils", label: "Layered Oils" },
                  { value: "deep-sea-series", label: "Deep Sea Series" }
                ]}
                placeholder="Filter by Collection"
                onValueChange={(value) => console.log("Filter by collection:", value)}
                className="w-[180px]"
              />
            ),
          },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={columns}
        rows={paintingData}
        emptyMessage="No paintings found. Time to create some new art!"
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-paintings">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}