// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Connect with Jeanne Kassab Art"}
        description={"For inquiries regarding original paintings, commissions, or collaborations, please reach out directly."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Email Jeanne Directly"}</h3>
            <p className="text-sm leading-6 text-muted">{"Send a detailed message regarding an artwork, commission request, or general inquiry. Jeanne personally reads and responds to every email."}</p>
            <Button href={"mailto:jeanne@jeannekassabart.com"} className="mt-auto w-fit">
              {"Send Email"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Inquire via WhatsApp"}</h3>
            <p className="text-sm leading-6 text-muted">{"For a quick question or direct inquiry about a specific piece you’ve seen in the gallery, connect instantly on WhatsApp."}</p>
            <Button href={"https://wa.me/15551234567?text=Hello%20Jeanne%2C%20I%20have%20an%20inquiry%20from%20JeanneKassabArt.com"} className="mt-auto w-fit">
              {"Message on WhatsApp"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Studio Visits"}</h3>
            <p className="text-sm leading-6 text-muted">{"Visits to Jeanne's studio are by appointment only. Please email to schedule a viewing of available original works."}</p>
            <Button href={"mailto:jeanne@jeannekassabart.com?subject=Studio%20Visit%20Request"} className="mt-auto w-fit">
              {"Request an Appointment"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Thank you for your interest in Jeanne Kassab Art. We look forward to connecting with you."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="contact-page" />
      <PublicShell
        brandName={"Jeanne Kassab Art"}
        chrome="solid"
        nav={<PublicNav items={navItems} cta={navCta} />}
      >
        <div data-skeleton={skeleton.id} data-utility-type={"generic"}>
          <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
        </div>
            <div id="description-enhancement-assistant" data-ai-feature-panel="description-enhancement-assistant">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "description-enhancement-assistant") || { id: "description-enhancement-assistant", name: "description-enhancement-assistant" }}
          brandName={"Jeanne Kassab Art"}
        />
      </div>
    </PublicShell>
    </>
  );
}