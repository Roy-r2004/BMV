// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-service" as const;
const RECIPE_ORDER = ["hero", "features", "testimonials", "cta", "footer"] as const; // Removed testimonials as it's not needed for this page

export default function AboutJeannePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  
  const artist = {
    biography: `From the serene landscapes of British Columbia to the vibrant art scenes of Europe, Jeanne Kassab's artistic journey has been a tapestry woven with discovery and transformation. A self-taught artist, Jeanne began her exploration with a profound appreciation for nature's subtle hues and dramatic forms. Her early works captured the essence of the Pacific Northwest, focusing on light's interplay with water and wood. Through years of dedicated practice and study, she honed her unique approach to oil painting, blending classical techniques with a modern sensibility.
<br/><br/>
Her travels across Europe, particularly the rich artistic heritage of Italy and France, deeply influenced her evolving style. Jeanne's connection to the land and her intuitive understanding of color and texture became the bedrock of her abstract landscapes. She is continuously inspired by the concept of memory and the way light transforms a scene, striving to evoke an emotional resonance rather than a mere representation.
<br/><br/>
Jeanne’s work has been featured in various local galleries and private collections, earning her a reputation for evocative compositions and a mastery of layered oils. She believes art should be an invitation to pause, to feel, and to connect with a deeper sense of beauty.`,
    statement: `My art is an ongoing conversation with the earth and the sky. I find immense joy in the tactile process of oil painting, building layers upon layers to create depth and luminescence that mirrors the complexity of the natural world. Each brushstroke is a meditation, an attempt to capture the fleeting moments of light and shadow that define our landscapes.
<br/><br/>
I am particularly drawn to the interplay of abstraction and realism – allowing the viewer's imagination to complete the narrative, while grounding the piece in a sense of place. My palette often leans towards earthy tones, punctuated by unexpected bursts of color, reflecting the quiet drama inherent in nature.
<br/><br/>
Ultimately, I hope my paintings offer a sanctuary, a moment of calm and introspection, inviting you to journey through the textures and hues as you would through a beloved memory. They are a testament to the persistent wonder I find in the world around us, translated through my hands onto canvas.`,
  };

  const slots = {
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Jeanne Kassab Art"} items={seed.testimonials ?? []} />
    ),
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"Jeanne Kassab"}
        subcopy={"Artist & Painter"}
        primaryCta={{ label: "View The Canvas Collection", href: "/gallery" }}
        imageSrc={images.ambient} 
        imageAlt="Portrait of Jeanne Kassab, the artist"
        className="max-w-[1200px] mx-auto " // Keeping `max-w-*` for layout control as per legibility rules
      />
    ),
    features: (
      <FeatureBento
        heading={"My Artistic Journey & Vision"}
        items={[
          {
            title: "My Journey",
            description: artist.biography,
            imageSrc: images.card1,
            imageAlt: "Jeanne Kassab painting in her studio",
          },
          {
            title: "The Creative Process",
            description: artist.statement,
            imageSrc: images.card2,
            imageAlt: "Close-up of an oil painting in progress",
          },
        ]}
        className="max-w-[1200px] mx-auto py-16 text-text-brand-muted" // Added text-text-brand-muted
      />
    ),
    cta: (
      <CTABand
        heading={"Connect with the Collection"}
        description={"Explore the full gallery of original oil paintings or reach out directly with your inquiries."}
        primaryCta={{ label: "Browse Paintings", href: "/gallery" }}
        secondaryCta={{ label: "Inquire on WhatsApp", href: "https://wa.me/your_whatsapp_number" }} // Placeholder WhatsApp link
       />
    ),
    // Removed testimonials slot as per page brief and RECIPE_ORDER update
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={"Original oil paintings for collectors and designers. A calm, editorial gallery."} />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="about-jeanne">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}