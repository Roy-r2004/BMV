// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, ProductShowcase, TestimonialRail, CTABand, BrandFooter, Button } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

// Mock painting data for this page
const painting = {
  title: "Abstract Horizon VI",
  heroImage: images.hero,
  altText: "Abstract Horizon VI - Vibrant abstract landscape painting with layered oils.",
  dimensions: "36 x 48 inches",
  medium: "Oil on Canvas",
  description: "Abstract Horizon VI explores the subtle interplay of light and shadow at dawn, evoking a sense of calm and expansive possibility. Layered oils capture the transient beauty of the atmosphere, inviting contemplation and introspection. This piece is a journey into the expansive desert sky, rendered with a vibrant palette and rich textures that shift with the light.",
  whatsappMessage: "Hello Jeanne, I am interested in \"Abstract Horizon VI\".",
};

export default function PaintingDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const slots = {
    hero: (
      // The hero section for a painting detail page should contain the primary painting image and its core details.
      // We'll create a custom layout within the hero slot without using the MarketingHero's default structure.
      <div className="relative isolate overflow-hidden bg-background py-16 sm:py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 grid md:grid-cols-2 gap-x-8 gap-y-16">
          {/* Painting Image - Left Column or Top */}
          <div className="md:col-span-1 flex justify-center">
            <img
              src={painting.heroImage}
              alt={painting.altText}
              className="w-full max-w-lg aspect-[4/3] object-cover rounded-lg shadow-xl"
            />
          </div>

          {/* Painting Details - Right Column or Bottom */}
          <div className="md:col-span-1 flex flex-col justify-center text-text min-h-[300px] md:min-h-0">
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-normal tracking-tight leading-none text-text-brand mt-4 sm:mt-0">
              {painting.title}
            </h1>
            <p className="mt-4 text-lg leading-relaxed text-muted">
              {painting.dimensions}
            </p>
            <p className="text-lg leading-relaxed text-muted">
              {painting.medium}
            </p>
            <p className="mt-8 text-xl leading-relaxed text-text">
              {painting.description}
            </p>
            <div className="mt-10">
              <Button
                variant="default"
                href={`https://wa.me/?text=${encodeURIComponent(painting.whatsappMessage)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-surface bg-brand px-8 py-4 text-lg font-semibold rounded-md shadow-lg hover:bg-brand/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
              >
                Inquire on WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </div>
    ),
    credentials: (
      // Credentials strip is optional on a detail page but included in the skeleton.
      // If no relevant credentials for a specific painting, consider removing or providing general artist credentials.
      <CredentialStrip heading="About Jeanne Kassab Art" items={[
        { title: "Original Oil Paintings", detail: "Abstract Landscapes & Layered" },
        { title: "Collector Series", detail: "Unique & One-of-a-Kind Works" },
        { title: "Studio Direct", detail: "Personalized Client Experience" },
      ]} />
    ),
    showcase: (
      // For this detail page, ProductShowcase will display "Related Works"
      <ProductShowcase
        heading="More from The Canvas Collection"
        description="Discover other unique works."
        className="py-16 sm:py-24 lg:py-32 bg-background/50"
        items={
          (seed.items ?? []).slice(0, 3).map((item, index) => ({
            title: item.title,
            description: item.description,
            imageSrc: [images.card1, images.card2, images.card3][index % 3], // Cycle through available card images
            imageAlt: item.title,
            href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}`
          }))
        }
      >
        <div className="mt-12 text-center">
            <Button
                variant="outline"
                href="/gallery"
                className="max-w-xs mx-auto py-3 text-lg"
            >
                Browse Full Gallery
            </Button>
        </div>
      </ProductShowcase>
    ),
    testimonials: (
      // Testimonials are optional for a painting detail page, but included in the skeleton.
      // Keeping it simple or removing if not directly relevant to a specific painting.
      <TestimonialRail
        heading="From Those Who Collect"
        items={seed.testimonials ?? []}
        className="bg-background"
      />
    ),
    cta: (
      <CTABand
        heading="Connect with Jeanne"
        description="For commission inquiries, studio visits, or general questions, Jeanne is delighted to hear from you."
        primaryCta={{ label: "Contact Jeanne Directly", href: "/contact" }}
        secondaryCta={{ label: "Learn About the Artist", href: "/about" }}
        className="bg-bg-brand/5"
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings, elegantly presented. Experience the depth of each unique creation."}
        links={[
          { label: "Gallery", href: "/gallery" },
          { label: "About", href: "/about" },
          { label: "Contact", href: "/contact" },
        ]}
        // Add more meta links if available
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="painting-detail">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}