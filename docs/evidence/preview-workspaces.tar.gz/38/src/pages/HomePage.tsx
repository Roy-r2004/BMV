// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        eyebrow={"Original Paintings"}
        headline={"The Canvas Collection"}
        subcopy={"An exquisite digital gallery artfully showcasing original oil paintings, inviting collectors and designers to intimately connect and inquire."}
        primaryCta={{ label: "View Available Work", href: "/gallery" }}
        secondaryCta={{ label: "Inquire on WhatsApp", href: "https://wa.me/yourphonenumber" }}
        imageSrc={images.hero}
        imageAlt="An abstract landscape oil painting with soft, layered colors"
      />
    ),
    credentials: (
      <CredentialStrip
        heading={"Dedicated to the Art"}
        items={[
          { title: "Original Oil Paintings", detail: "Each piece a unique expression" },
          { title: "Direct from the Artist", detail: "Connect with Jeanne Kassab" },
          { title: "Curated Collections", detail: "Abstract landscapes, layered oils" },
        ]}
      />
    ),
    features: (
      <FeatureBento
        heading={"A Living Gallery Experience"}
        imagePool={[images.card1, images.card2, images.card3]}
        items={[
          { title: "Latest Works", description: "Discover newly completed original oil paintings." },
          { title: "Direct Inquiry", description: "Connect with Jeanne Kassab via WhatsApp for details or acquisition." },
          { title: "Artist's Vision", description: "Explore the inspiration and techniques behind each stroke." },
        ]}
      />
    ),
    showcase: (
      <ProductShowcase
        heading={"Featured Paintings"}
        items={
          (seed.items ?? []).map((item, index) => ({
            title: item.title,
            description: item.description,
            imageSrc: [images.card1, images.card2, images.card3][index % 3], // Use available mock images
            imageAlt: item.title,
            badge: String((item as any).badge || (item as any).category || "Available"),
            href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}`
          }))
        }
      />
    ),
    testimonials: (
      <TestimonialRail
        heading={"From Collectors and Designers"}
        items={[
          { quote: "Jeanne's paintings bring such a serene energy into a space. They are truly captivating.", author: "Sarah L.", role: "Interior Designer" },
          { quote: "The online gallery made finding the perfect abstract piece effortless. The detail images are fantastic.", author: "Michael P.", role: "Collector" },
          { quote: "Connecting directly with Jeanne was a wonderful experience. Her passion for art shines through.", author: "Emily R.", role: "Art Enthusiast" },
        ]}
      />
    ),
    cta: (
      <CTABand
        heading={"Discover Your Next Masterpiece"}
        description={"Explore the full collection of original oil paintings and find a piece that resonates with your space and spirit."}
        primaryCta={{ label: "Browse All Art", href: "/gallery" }}
        secondaryCta={{ label: "Learn About Jeanne", href: "/about" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Jeanne Kassab Art — original oils, abstract landscapes, and layered canvases."}
        links={[
          { label: "Gallery", href: "/gallery" },
          { label: "About", href: "/about" },
          { label: "Contact", href: "/contact" },
          { label: "Privacy Policy", href: "/privacy" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}