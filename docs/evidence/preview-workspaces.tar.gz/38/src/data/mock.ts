export const BRAND_MANIFEST = {
  brand_name: "Jeanne Kassab Art",
  tagline: "An exquisite digital gallery that artfully showcases original oil paintings, inviting collectors and designers to intimately connect and inquire.",
  accent: "#0f766e",
  accent_dark: "#0b5c56",
  accent_light: "#e0f2f1",
  font: "Source Sans 3",
  services: [
    {
      id: "abstract-landscapes",
      name: "Abstract Landscapes",
      description: "Expansive, evocative landscapes capturing nature's essence.",
    },
    {
      id: "layered-oils",
      name: "Layered Oils",
      description: "Depth and texture through meticulous layering and rich tonal shifts.",
    },
    {
      id: "recent-works",
      name: "Recent Works",
      description: "Newly completed and available for acquisition or inquiry.",
    },
  ],
  owner_name: "Jeanne",
  client_names: [
    "Sarah Jenkins",
    "Michael Chen",
    "Eleanor Vance",
    "David Rodriguez",
    "Olivia Kim",
    "William Sterling",
  ],
  testimonials: [
    {
      quote: "Jeanne's work brings such a profound sense of calm to our living space. The textures are simply breathtaking.",
      author: "Eleanor V.",
      role: "Collector",
    },
    {
      quote: "Working with Jeanne was a dream. The painting arrived beautifully packaged and even more vibrant in person.",
      author: "Marcus T.",
      role: "Interior Designer",
    },
    {
      quote: "Each brushstroke tells a story. We feel incredibly fortunate to own a piece of Jeanne's world.",
      author: "Sophia R.",
      role: "Art Enthusiast",
    },
    {
      quote: "The piece I acquired from Jeanne Kassab Art transformed my office space. It’s a constant source of inspiration.",
      author: "David L.",
      role: "Collector",
    },
    {
      quote: "Jeanne has an incredible talent for capturing mood. Her abstract landscapes are truly transportive.",
      author: "Olivia K.",
      role: "Gallery Visitor",
    },
  ],
  social_proof: "Trusted by collectors and interior designers worldwide.",
  design_system: {
    primary_color: "#0f766e",
    secondary_color: "#0369a1",
    background_color: "#f8fafc",
    surface_color: "#ffffff",
    text_color: "#042f2e",
    muted_text_color: "#5f7a78",
    font_family: "Source Sans 3",
    display_font_family: "Fraunces",
    font_import_url:
      "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
    font_display: '"Fraunces", Georgia, serif',
    brand_locked: true,
    brand_brief_version: "1.0",
    mood: "modern",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature: "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.",
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    recipe_id: "editorial",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    recipe_prompt:
      "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    style_keywords: "Editorial · Soft glass",
    border_radius: "0.83rem",
    design_overlay_id: "soft_glass",
    design_overlay_label: "Soft glass",
    design_overlay_blurb: "Modern product glass — translucent cards, medium radius, brand wash.",
    density: "comfortable",
    token_overrides: {
      radius_ui: "0.83rem",
      bg_mix: "7%",
      fg_mix: "40%",
      muted_mix: "32%",
      border_mix: "16%",
      shadow: "0 22px 48px -32px",
      shadow_alpha: "34%",
      glow: "10%",
      card: "#ffffff",
      atmosphere:
        "radial-gradient(90% 60% at 0% 0%, color-mix(in srgb, var(--color-brand) 16%, transparent), transparent 55%), radial-gradient(55% 45% at 100% 0%, color-mix(in srgb, var(--color-accent) 12%, transparent), transparent 50%), linear-gradient(165deg, color-mix(in srgb, var(--color-brand) 8%, #f4f6f8), #f7f8fa 55%, #eef1f5)",
    },
    font_import:
      "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700",
    design_brief_version: "1.0",
    design_brief_sealed: true,
  },
  design_brief: {
    version: "1.0",
    sealed: true,
    brand_name: "Jeanne Kassab Art",
    brand_locked: true,
    recipe_id: "editorial",
    recipe_label: "Editorial",
    recipe_blurb: "Gallery pacing, large display type, airy whitespace, soft surfaces.",
    recipe_prompt:
      "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    product_kind: "storefront",
    product_subtype: "storefront",
    product_kind_note: "Storefront — public marketing home is the product surface.",
    industry_template_id: "art-gallery-portfolio-home",
    ops_template_id: null,
    template_prompt: null,
    ops_template_prompt: null,
    overlay_id: "soft_glass",
    overlay_label: "Soft glass",
    overlay_blurb: "Modern product glass — translucent cards, medium radius, brand wash.",
    density: "comfortable",
    mood: "modern",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature: "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.",
    palette: {
      primary: "#0f766e",
      secondary: "#0369a1",
      background: "#f8fafc",
      surface: "#ffffff",
      text: "#042f2e",
      muted: "#5f7a78",
    },
    typography: {
      font_family: "Source Sans 3",
      display_font_family: "Fraunces",
      font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
      font_display: '"Fraunces", Georgia, serif',
      font_import:
        "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700",
      font_import_url:
        "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    },
    token_overrides: {
      radius_ui: "0.83rem",
      bg_mix: "7%",
      fg_mix: "40%",
      muted_mix: "32%",
      border_mix: "16%",
      shadow: "0 22px 48px -32px",
      shadow_alpha: "34%",
      glow: "10%",
      card: "#ffffff",
      atmosphere:
        "radial-gradient(90% 60% at 0% 0%, color-mix(in srgb, var(--color-brand) 16%, transparent), transparent 55%), radial-gradient(55% 45% at 100% 0%, color-mix(in srgb, var(--color-accent) 12%, transparent), transparent 50%), linear-gradient(165deg, color-mix(in srgb, var(--color-brand) 8%, #f4f6f8), #f7f8fa 55%, #eef1f5)",
    },
    border_radius: "0.83rem",
    section_order: ["hero", "showcase", "features", "process", "credentials", "testimonials", "cta", "footer"],
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    style_keywords: "Editorial · Soft glass",
    direction:
      "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid. · Editorial: Gallery pacing, large display type, airy whitespace, soft surfaces. · Soft glass: Modern product glass — translucent cards, medium radius, brand wash. · Product kind storefront/storefront: Storefront — public marketing home is the product surface.",
  },
};

export const brand = {
  name: "Jeanne Kassab Art",
  tagline: "An exquisite digital gallery that artfully showcases your original oil paintings, inviting collectors and designers to intimately connect and inquire.",
  design_system: BRAND_MANIFEST.design_system,

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  services: [{"name": "Jeanne Kassab Art Signature", "title": "Jeanne Kassab Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jeanne Kassab Art clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/4442076/pexels-photo-4442076.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/36764903/pexels-photo-36764903.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/16397728/pexels-photo-16397728.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/1671016/pexels-photo-1671016.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/36764930/pexels-photo-36764930.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/1970337/pexels-photo-1970337.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const roles = [
  {
    "id": "customer",
    "label": "Collector & Visitor",
    "defaultPath": "/gallery",
    "icon": "users"
  },
  {
    "id": "admin",
    "label": "Studio Host",
    "defaultPath": "/admin/dashboard",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "collections",
      "path": "/collections",
      "href": "/collections",
      "label": "Collections"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Login"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "admin-paintings",
      "path": "/admin/paintings",
      "href": "/admin/paintings",
      "label": "Paintings"
    },
    {
      "id": "admin-collections",
      "path": "/admin/collections",
      "href": "/admin/collections",
      "label": "Collections"
    },
    {
      "id": "admin-about",
      "path": "/admin/about",
      "href": "/admin/about",
      "label": "About"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "collections",
      "path": "/collections",
      "href": "/collections",
      "label": "Collections"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    }
  ]
};

export const aiFeatures = [
  {
    id: "intelligent-image-cropping",
    name: "Intelligent Image Cropping",
    description:
      "Automatically suggests optimal crops for thumbnails and gallery views based on artistic composition, saving manual adjustment time.",
    category: "ops",
    surface: "ops",
    demo_hint: "Route ops work the way Jeanne Kassab Art runs",
    demo_prompts: [
      "Triage new requests about intake",
      "Assign an owner for this booking issue",
      "What should the Jeanne Kassab Art team do next?",
    ],
    placement_label: "Ops AI",
    demo_results: {
      "Triage new requests about intake":
        "Routed “Triage new requests about intake” → queue + owner + checklist for intake. Status: In progress.",
      "Assign an owner for this booking issue":
        "Assigned “Assign an owner for this booking issue” to the best available owner with a booking checklist and due time today.",
      "What should the Jeanne Kassab Art team do next?":
        "Next for Jeanne Kassab Art: clear the intake backlog, confirm booking, then review tonight's handoff.",
    },
    placement_path: "/admin/dashboard",
    placement_component: "src/pages/admin/AdminDashboardPage.tsx",
    placement_title: "Admin Dashboard · The Canvas Collection",
  },
  {
    id: "ai-powered-tagging-suggestions",
    name: "AI-Powered Tagging Suggestions",
    description:
      "Analyzes painting descriptions and visual elements to suggest relevant tags (e.g., 'abstract,' 'landscape,' 'oceanic') for better organization and search.",
    category: "ops",
    surface: "automation",
    demo_hint: "Route ops work the way Jeanne Kassab Art runs",
    demo_prompts: [
      "Triage new requests about intake",
      "Assign an owner for this booking issue",
      "What should the Jeanne Kassab Art team do next?",
    ],
    placement_label: "Ops AI",
    demo_results: {
      "Triage new requests about intake":
        "Routed “Triage new requests about intake” → queue + owner + checklist for intake. Status: In progress.",
      "Assign an owner for this booking issue":
        "Assigned “Assign an owner for this booking issue” to the best available owner with a booking checklist and due time today.",
      "What should the Jeanne Kassab Art team do next?":
        "Next for Jeanne Kassab Art: clear the intake backlog, confirm booking, then review tonight's handoff.",
    },
    placement_path: "/admin/dashboard",
    placement_component: "src/pages/admin/AdminDashboardPage.tsx",
    placement_title: "Admin Dashboard · The Canvas Collection",
  },
  {
    id: "description-enhancement-assistant",
    name: "Description Enhancement Assistant",
    description:
      "Provides stylistic suggestions or elaborations for painting descriptions, ensuring consistent tone and engaging narratives, based on Jeanne's established writing style.",
    category: "chat",
    surface: "chat",
    demo_hint: "Ask the way a real guest would ask Jeanne Kassab Art",
    demo_prompts: [
      "What should I know about intake?",
      "How does booking work at Jeanne Kassab Art?",
      "Can beginners join a treatment this week?",
    ],
    placement_label: "Customer assistant",
    demo_results: {
      "What should I know about intake?":
        "Jeanne Kassab Art: For “What should I know about intake?” — Provides stylistic suggestions or elaborations for painting descriptions, ensuring consistent tone and engaging narratives, based on Jeanne's established writing style Here’s the short answer, what to prepare, and when a human should join.",
      "How does booking work at Jeanne Kassab Art?":
        "Jeanne Kassab Art: “How does booking work at Jeanne Kassab Art?” — we walk guests through booking step by step, including timing, cost cues, and the next action to take.",
      "Can beginners join a treatment this week?":
        "Jeanne Kassab Art: Yes for “Can beginners join a treatment this week?” — offers suggestions to answer common questions and assist with simple booking.",
    },
    placement_path: "/",
    placement_component: "src/layouts/PublicLayout.tsx",
    placement_title: "Jeanne Kassab Art · Gallery",
  },
];

export const seed = {
  hero: {
    headline: "Original Oil Paintings by Jeanne Kassab",
    subcopy: "Abstract landscapes and layered oils – a living gallery of unique works.",
    primaryCta: {
      label: "Explore the Collection",
      href: "/gallery",
    },
    secondaryCta: {
      label: "About the Artist",
      href: "/about",
    },
  },
  services: [
    {
      title: "Abstract Landscapes",
      description: "Discover expansive, evocative landscapes rendered in oil, capturing the essence of the natural world through abstraction.",
    },
    {
      title: "Layered Oils",
      description: "Experience the depth and texture of paintings built through meticulous layering, revealing hidden narratives and rich tonal shifts.",
    },
    {
      title: "Recent Works",
      description: "Browse the latest additions to the collection, freshly completed and available for acquisition or inquiry.",
    },
  ],
  features: [
    {
      title: "Immersive Gallery View",
      description: "Dive into a beautifully curated selection of paintings, each presented with pristine clarity and generous scale.",
    },
    {
      title: "Direct Inquiry",
      description: "Connect with Jeanne directly via WhatsApp to discuss any artwork, commissioning, or acquisition details.",
    },
    {
      title: "Artist's Story",
      description: "Journey through Jeanne Kassab's artistic vision, techniques, and inspirations in a dedicated artist statement.",
    },
  ],
  process: [],
  testimonials: BRAND_MANIFEST.testimonials, // Reusing from BRAND_MANIFEST
  testimonialsHeading: "From Collectors Like You", // This key is read by TestimonialRail
  credentials: [
    { title: "Layered Oils", detail: "Each piece built with luminous layers for depth and translucency." },
    { title: "Archival Quality", detail: "Dedicated to professional-grade pigments and canvases." },
    { title: "Original Works", detail: "Every painting is a unique, one-of-a-kind creation." },
    { title: "Direct from Studio", detail: "Curated and presented directly from my creative space." },
  ],
  trustLabels: [],

  // OPS_SEED related data
  opsHero: {
    headline: "The Canvas Collection Admin",
    subcopy: "Manage your gallery: paintings, collections, and inquiries.",
  },
  kpis: [
    {
      label: "Total Paintings",
      value: "22", // A bit more than initially stated 28 but allows room for growth
      delta: "+3",
      hint: "Last 30 days",
    },
    {
      label: "Active Inquiries",
      value: "3",
      delta: "+1",
      hint: "Via WhatsApp",
    },
    {
      label: "Sold This Month",
      value: "2",
      delta: "New sale",
      hint: "Increased by 1",
    },
  ],
  items: [
    {
      title: "Abstract Horizon VII",
      description: "New painting added to 'Abstract Landscapes'.",
      when: "1 day ago",
    },
    {
      title: "Ocean's Embrace",
      description: "Status updated to 'Sold'.",
      when: "3 days ago",
    },
    {
      title: "Ethereal Layers III",
      description: "Description updated for clarity.",
      when: "1 week ago",
    },
    {
      title: "Whispers of the Summit",
      description: "Image updated to a higher resolution version.",
      when: "2 weeks ago",
    },
    {
      title: "Golden Dusk",
      description: "Moved from 'Recent Works' to 'Abstract Landscapes'.",
      when: "3 weeks ago",
    },
    {
      title: "Coastal Reverie",
      description: "New painting added to 'Recent Works'.",
      when: "4 weeks ago",
    },
    {
      title: "Forest Echoes I",
      description: "Price updated.",
      when: "1 month ago",
    },
  ],
  activity: [
    {
      title: "New painting: 'Coastal Reverie'",
      detail: "Uploaded high-res images and description.",
      when: "Just now",
    },
    {
      title: "WhatsApp Inquiry: 'Blue Ridge Echoes'",
      detail: "From Sarah L. (Interior Designer)",
      when: "10 min ago",
    },
    {
      title: "Updated 'About' page content",
      detail: "Refined artist statement.",
      when: "2 hours ago",
    },
    {
      title: "Painting 'Ocean's Embrace' marked as sold",
      detail: "Invoice sent to client.",
      when: "Yesterday",
    },
    {
      title: "New collection created: 'Serene Abstracts'",
      detail: "Added 3 paintings to the new collection.",
      when: "2 days ago",
    },
    {
      title: "Login from new device detected",
      detail: "IP: 203.0.113.45, Location: Vancouver, BC",
      when: "3 days ago",
    },
  ],
  tableRows: [ // For admin-paintings
    {
      id: "P001",
      title: "Whispers of the Horizon",
      collection: "Abstract Landscapes",
      status: "Available",
      lastUpdated: "2024-03-20 14:30",
    },
    {
      id: "P002",
      title: "Ocean's Embrace",
      collection: "Layered Oils",
      status: "Sold",
      lastUpdated: "2024-03-18 10:15",
    },
    {
      id: "P003",
      title: "Golden Dusk",
      collection: "Abstract Landscapes",
      status: "Available",
      lastUpdated: "2024-03-15 11:00",
    },
    {
      id: "P004",
      title: "Ethereal Layers II",
      collection: "Layered Oils",
      status: "Available",
      lastUpdated: "2024-03-10 09:45",
    },
    {
      id: "P005",
      title: "Forest Echoes I",
      collection: "Abstract Landscapes",
      status: "Available",
      lastUpdated: "2024-03-05 16:20",
    },
    {
      id: "P006",
      title: "Coastal Reverie",
      collection: "Recent Works",
      status: "Available",
      lastUpdated: "2024-03-01 13:00",
    },
    {
      id: "P007",
      title: "Azure Depths",
      collection: "Abstract Landscapes",
      status: "Available",
      lastUpdated: "2024-02-28 17:00",
    },
    {
      id: "P008",
      title: "Silent Shores",
      collection: "Layered Oils",
      status: "Available",
      lastUpdated: "2024-02-25 08:30",
    },
    {
      id: "P009",
      title: "Crimson Sky",
      collection: "Abstract Landscapes",
      status: "Sold",
      lastUpdated: "2024-02-20 09:00",
    },
    {
      id: "P010",
      title: "Mountain Myst",
      collection: "Layered Oils",
      status: "Available",
      lastUpdated: "2024-02-18 11:40",
    },
  ],
  collectionsTableRows: [ // For admin-collections
    {
        id: "C001",
        name: "Abstract Landscapes",
        paintingCount: 12,
        lastUpdated: "2024-03-20 14:30",
    },
    {
        id: "C002",
        name: "Layered Oils",
        paintingCount: 8,
        lastUpdated: "2024-03-18 10:15",
    },
    {
        id: "C003",
        name: "Recent Works",
        paintingCount: 3,
        lastUpdated: "2024-03-01 13:00",
    },
    {
        id: "C004",
        name: "Serene Abstracts",
        paintingCount: 3,
        lastUpdated: "2024-03-19 11:00",
    },
  ],
  artistBio: `From the serene landscapes of British Columbia to the vibrant art scenes of Europe, Jeanne Kassab's artistic journey has been a tapestry woven with discovery and transformation. A self-taught artist, Jeanne began her exploration with a profound appreciation for nature's subtle hues and dramatic forms. Her early works captured the essence of the Pacific Northwest, focusing on light's interplay with water and wood. Through years of dedicated practice and study, she honed her unique approach to oil painting, blending classical techniques with a modern sensibility.
  <br/><br/>
  Her travels across Europe, particularly the rich artistic heritage of Italy and France, deeply influenced her evolving style. Jeanne's connection to the land and her intuitive understanding of color and texture became the bedrock of her abstract landscapes. She is continuously inspired by the concept of memory and the way light transforms a scene, striving to evoke an emotional resonance rather hand a mere representation.
  <br/><br/>
  Jeanne’s work has been featured in various local galleries and private collections, earning her a reputation for evocative compositions and a mastery of layered oils. She believes art should be an invitation to pause, to feel, and to connect with a deeper sense of beauty.`,
  artistStatement: `My art is an ongoing conversation with the earth and the sky. I find immense joy in the tactile process of oil painting, building layers upon layers to create depth and luminescence that mirrors the complexity of the natural world. Each brushstroke is a meditation, an attempt to capture the fleeting moments of light and shadow that define our landscapes.
  <br/><br/>
  I am particularly drawn to the interplay of abstraction and realism – allowing the viewer's imagination to complete the narrative, while grounding the piece in a sense of place. My palette often leans towards earthy tones, punctuated by unexpected bursts of color, reflecting the quiet drama inherent in nature.
  <br/><br/>
  Ultimately, I hope my paintings offer a sanctuary, a moment of calm and introspection, inviting you to journey through the textures and hues as you would through a beloved memory. They are a testament to the persistent wonder I find in the world around us, translated through my hands onto canvas.`,
  aboutPageImage: images.ambient, // Use an existing image for the About page hero
};
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
