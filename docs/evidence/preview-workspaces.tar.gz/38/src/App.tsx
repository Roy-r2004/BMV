import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutJeannePage from './pages/AboutJeannePage';
import AdminAboutPage from './pages/admin/AdminAboutPage';
import AdminCollectionsPage from './pages/admin/AdminCollectionsPage';
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import AdminLoginPage from './pages/AdminLoginPage';
import AdminPaintingsPage from './pages/admin/AdminPaintingsPage';
import AiFeaturesPage from './pages/AiFeaturesPage';
import ArtworkDetailPage from './pages/ArtworkDetailPage';
import CollectionDetailPage from './pages/CollectionDetailPage';
import CollectionsListPage from './pages/CollectionsListPage';
import ContactPage from './pages/ContactPage';
import GalleryHomePage from './pages/GalleryHomePage';
import HomePage from './pages/HomePage';
import PaintingDetailPage from './pages/PaintingDetailPage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/gallery');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/gallery" element={<GalleryHomePage />} />
          <Route path="/collections" element={<CollectionsListPage />} />
          <Route path="/about" element={<AboutJeannePage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
          <Route path="/admin/paintings" element={<AdminPaintingsPage />} />
          <Route path="/admin/collections" element={<AdminCollectionsPage />} />
          <Route path="/admin/about" element={<AdminAboutPage />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/collection/:slug" element={<CollectionDetailPage />} />
          <Route path="/painting/:slug" element={<PaintingDetailPage />} />
          <Route path="/gallery/:id" element={<ArtworkDetailPage />} />
          <Route path="/ai-features" element={<AiFeaturesPage />} />
          <Route path="/gallery/:slug" element={<PaintingDetailPage />} />
          <Route path="/collections/:id" element={<PaintingDetailPage />} />
          <Route path="/collections/:slug" element={<PaintingDetailPage />} />
          <Route path="/collection/:slug/:id" element={<PaintingDetailPage />} />
          <Route path="/collection/:slug/:slug" element={<PaintingDetailPage />} />
          <Route path="/gallery/:id/:id" element={<PaintingDetailPage />} />
          <Route path="/gallery/:id/:slug" element={<PaintingDetailPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}