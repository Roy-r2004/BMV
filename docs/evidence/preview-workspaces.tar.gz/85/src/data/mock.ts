export const brand = {
  name: "Cedar Point Lodge",
  tagline: "Your seamless gateway to an unforgettable Adirondack escape.",
  accent: "#0f766e",
  accent_dark: "#0b5a54",
  accent_light: "#e0f2f1",
  font: "Nunito Sans",
  owner_name: "Eleanor",
  client_names: [
    "Sarah & Tom Davies",
    "Michael Chen",
    "Jessica Rodriguez",
    "David & Emily Green",
    "Olivia White",
    "Daniel Lee"
  ],
  social_proof: "Trusted by hundreds of guests for memorable Adirondack getaways.",

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "nunitosans", "font_import_url": "https://fonts.googleapis.com/css2?family=nunito+sans:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  services: [{"name": "Cedar Point Lodge Signature", "title": "Cedar Point Lodge Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Cedar Point Lodge experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Cedar Point Lodge experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
};

export const images = {
  "hero": "https://images.pexels.com/photos/18446070/pexels-photo-18446070.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/6517084/pexels-photo-6517084.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/6363792/pexels-photo-6363792.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/3771811/pexels-photo-3771811.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/3768095/pexels-photo-3768095.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/35259529/pexels-photo-35259529.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item1": "https://images.pexels.com/photos/6466217/pexels-photo-6466217.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item2": "https://images.pexels.com/photos/3872908/pexels-photo-3872908.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item3": "https://images.pexels.com/photos/6394682/pexels-photo-6394682.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item4": "https://images.pexels.com/photos/9145354/pexels-photo-9145354.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item5": "https://images.pexels.com/photos/3872899/pexels-photo-3872899.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item6": "https://images.pexels.com/photos/36328107/pexels-photo-36328107.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item7": "https://images.pexels.com/photos/4820811/pexels-photo-4820811.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item8": "https://images.pexels.com/photos/9146376/pexels-photo-9146376.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "home",
      "path": "/home",
      "href": "/home",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Cedar Point Lodge"
    },
    {
      "id": "activities",
      "path": "/activities",
      "href": "/activities",
      "label": "Activities"
    },
    {
      "id": "rooms-stays",
      "path": "/rooms-stays",
      "href": "/rooms-stays",
      "label": "Rooms Stays"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "admin-bookings",
      "path": "/admin/bookings",
      "href": "/admin/bookings",
      "label": "Bookings"
    },
    {
      "id": "admin-rooms",
      "path": "/admin/rooms",
      "href": "/admin/rooms",
      "label": "Rooms"
    },
    {
      "id": "admin-packages",
      "path": "/admin/packages",
      "href": "/admin/packages",
      "label": "Packages"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "home",
      "path": "/home",
      "href": "/home",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Cedar Point Lodge"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "activities",
      "path": "/activities",
      "href": "/activities",
      "label": "Activities"
    }
  ],
  "lodge_manager": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "admin-bookings",
      "path": "/admin/bookings",
      "href": "/admin/bookings",
      "label": "Bookings"
    },
    {
      "id": "admin-rooms",
      "path": "/admin/rooms",
      "href": "/admin/rooms",
      "label": "Rooms"
    },
    {
      "id": "admin-packages",
      "path": "/admin/packages",
      "href": "/admin/packages",
      "label": "Packages"
    }
  ]
};

export const roles = [
  {
    "id": "customer",
    "label": "Guest",
    "defaultPath": "/home",
    "icon": "users"
  },
  {
    "id": "lodge_manager",
    "label": "Lodge Manager",
    "defaultPath": "/admin/dashboard",
    "icon": "chart"
  }
];

export const aiFeatures = [
  {
    id: "personalized-package-recommendations",
    name: "Personalized Package Recommendations",
    description: "Analyzes guest booking history and stated preferences to suggest relevant activity or dining packages for future stays.",
    category: "guest engagement",
    surface: "booking",
    demo_hint: "See how we recommend packages during booking.",
    demo_prompts: [
      "Show popular winter packages for a couple's retreat.",
      "Suggest family-friendly activities for a summer booking.",
      "What package would a guest who booked a canoe trip last year like?",
    ],
    demo_results: {
      "Show popular winter packages for a couple's retreat.": "Recommended: 'Sauna & Stargaze' (includes private sauna session and a stargazing kit) and 'Cozy Fireside Escape' (gourmet hot chocolate and s'mores kit).",
      "Suggest family-friendly activities for a summer booking.": "Recommended: 'Guided Nature Walk' (easy terrain, wildlife spotting) and 'Family Canoe Adventure' (stable canoes, life vests for all ages).",
      "What package would a guest who booked a canoe trip last year like?": "Recommended: 'Adirondack Explorer Package' (guided hike with picnic) or 'Paddle & Pine Retreat' (multi-day canoe rental and massage).",
    },
    placement_label: "Booking Flow",
    placement_path: "/book-your-stay",
    placement_component: "src/pages/BookingFlowPage.tsx",
    placement_title: "Book Your Stay - Cedar Point Lodge",
  },
  {
    id: "dynamic-room-description-generator",
    name: "Dynamic Room Description Generator",
    description: "Crafts engaging and unique descriptions for rooms and lodge amenities based on key features and Adirondack themes, saving marketing time.",
    category: "content creation",
    surface: "marketing",
    demo_hint: "Generate a captivating description for a new room.",
    demo_prompts: [
      "Write a description for the new 'Lake View King' room, emphasizing luxury and serenity.",
      "Generate a description for the 'Cozy Nook Double' highlighting its intimate feel and forest view.",
      "Create marketing copy for our 'Adirondack Spa Bathroom' amenity.",
    ],
    demo_results: {
      "Write a description for the new 'Lake View King' room, emphasizing luxury and serenity.": "Draft generated: 'Wake to breathtaking views of Lake Placid from your private King-sized bed. The Lake View King offers refined comfort, bespoke local art, and a tranquil ambiance, perfect for unwinding after a day of adventure.'",
      "Generate a description for the 'Cozy Nook Double' highlighting its intimate feel and forest view.": "Draft generated: 'Nestled amidst whispering pines, the Cozy Nook Double offers an intimate escape. This charming room features a comfortable double bed and a private window overlooking the serene Adirondack forest, ideal for quiet contemplation.'",
      "Create marketing copy for our 'Adirondack Spa Bathroom' amenity.": "Draft generated: 'Indulge in our Adirondack Spa Bathroom, a private sanctuary designed for rejuvenation. Featuring a deep soaking tub, rainfall shower, and organic, locally sourced toiletries, it’s a perfect complement to your lakeside escape.'",
    },
    placement_label: "Admin Room Management",
    placement_path: "/admin/rooms",
    placement_component: "src/pages/admin/AdminRoomsPage.tsx",
    placement_title: "Room Management - Cedar Point Lodge",
  },
  {
    id: "sentiment-analysis-for-guest-feedback",
    name: "Sentiment Analysis for Guest Feedback",
    description: "Automatically processes guest messages or reviews to quickly identify common themes and areas for improvement, helping the lodge prioritize guest satisfaction.",
    category: "operations",
    surface: "dashboard",
    demo_hint: "Analyze recent guest feedback for quick insights.",
    demo_prompts: [
      "Summarize sentiment from all reviews this month.",
      "Identify common complaints from last quarter's feedback.",
      "What are guests saying about the guided canoe trips?",
    ],
    demo_results: {
      "Summarize sentiment from all reviews this month.": "Overall sentiment: 92% Positive. Key themes: 'friendly staff', 'beautiful views', 'delicious breakfast'. Areas for improvement: 'Wi-Fi speed'.",
      "Identify common complaints from last quarter's feedback.": "Top complaints: 'slow Wi-Fi' (28% mentions), 'limited dinner options' (15% mentions).",
      "What are guests saying about the guided canoe trips?": "Sentiment for canoe trips: 98% Positive. Common feedback: 'knowledgeable guides', 'stunning scenery', 'peaceful experience'.",
    },
    placement_label: "Admin Dashboard",
    placement_path: "/admin",
    placement_component: "src/pages/admin/AdminDashboardPage.tsx",
    placement_title: "Admin Dashboard - Cedar Point Lodge",
  },
];


export const seed = {
  hero: {
    eyebrow: 'Cedar Point Lodge',
    headline: 'Cedar Point Lodge',
    subcopy: 'A clear next step from Cedar Point Lodge — warm, specific, and ready when you are.',
    primaryCta: { label: 'Explore the collection', href: '/gallery' },
    secondaryCta: { label: 'Talk to us', href: '/contact#inquire' },
  },
  features: [
    { title: 'What Cedar Point Lodge is known for', description: 'Concrete offerings guests can book without guessing.' },
    { title: 'Guided next step', description: 'Every section points toward a clear action.' },
    { title: 'Built for return visits', description: 'Details that make Cedar Point Lodge easy to come back to.' },
  ],
  showcaseHeading: 'From Cedar Point Lodge',
  credentialsHeading: 'Why Cedar Point Lodge',
  credentials: [
    { title: 'Known for', detail: 'Clear work and a straightforward next step at Cedar Point Lodge.' },
    { title: 'Next step', detail: 'Browse, then inquire or book — no dead ends.' },
  ],
  trustLabels: [
    'Cedar Point Lodge quality\', \'On schedule\', \'Repeat guests\', \'Local favorite',
  ],
  public: {
    hero: {
      headline: "Your Adirondack Escape Awaits",
      subcopy: "Discover serene lakeside comfort, guided adventures, and culinary delights at Cedar Point Lodge.",
      primaryCta: {
        label: "View Rooms & Book",
        href: "/rooms-stays"
      },
      secondaryCta: {
        label: "Explore Activities",
        href: "/activities"
      }
    },
    services: [
      {
        name: "Lakeside Dining",
        description: "Savor seasonal Adirondack cuisine with breathtaking lake views."
      },
      {
        name: "Guided Canoe Trips",
        description: "Explore hidden coves and tranquil waters with our experienced guides."
      },
      {
        name: "Relaxing Sauna",
        description: "Unwind and rejuvenate in our traditional lakeside sauna."
      }
    ],
    features: [
      {
        title: "Intimate Accommodations",
        description: "Eighteen uniquely appointed rooms, each a private sanctuary."
      },
      {
        title: "Direct Booking Advantage",
        description: "Enjoy the best rates and personalized service when you book directly with us."
      },
      {
        title: "Seamless Stay Planning",
        description: "Effortlessly check availability, select rooms, and add experiences."
      }
    ],
    process: [
      {
        title: "Choose Your Dates",
        description: "Select your desired check-in and check-out to see available rooms."
      },
      {
        title: "Discover Your Room",
        description: "Browse our unique room types with detailed descriptions and photos."
      },
      {
        title: "Add an Adventure",
        description: "Enhance your stay with guided canoe trips or a relaxing sauna session."
      }
    ],
    testimonials: [
      {
        quote: "A truly magical stay! The lodge is beautiful, the food exquisite, and the canoe trip was unforgettable.",
        author: "Eleanor V.",
        role: "Guest"
      },
      {
        quote: "Booking was incredibly easy, and the personalized recommendations made our trip perfect.",
        author: "Marcus R.",
        role: "Guest"
      }
    ],
    credentials: [
      {
        title: "Lakeside Serenity",
        detail: "Nestled on the tranquil shores of Lake Placid."
      }
    ],
    trustLabels: [
      "Secure Direct Booking",
      "Adirondack Hospitality",
      "Personalized Service"
    ]
  },
  ops: {
    hero: {
      headline: "Cedar Point Lodge Operations Console",
      subcopy: "Manage bookings, rooms, and guest experiences with Adirondack Concierge Connect."
    },
    kpis: [
      {
        label: "Upcoming Check-ins",
        value: "4",
        delta: "+1",
        hint: "Today & Tomorrow"
      },
      {
        label: "Occupancy Rate",
        value: "78%",
        delta: "+3%",
        hint: "This Week"
      },
      {
        label: "Pending Bookings",
        value: "2",
        delta: "—",
        hint: "Awaiting Confirmation"
      },
      {
        label: "Avg. Daily Rate",
        value: "$325",
        delta: "+$15",
        hint: "This Month"
      }
    ],
    items: [
      {
        title: "Jamie R. - Room 7 (Lakeside)",
        description: "Check-in: Tomorrow, 3 PM. Sauna & Stay Package."
      },
      {
        title: "Taylor S. - Room 12 (Mountain View)",
        description: "Check-out: Today, 11 AM. Canoe Explorer Package."
      },
      {
        title: "Jordan P. - Room 3 (Forest Nook)",
        description: "Check-in: Friday, 3 PM. Basic Stay."
      }
    ],
    activity: [
      {
        title: "New booking received",
        detail: "Jamie R. booked Room 7 for Oct 20-23.",
        when: "Just now"
      },
      {
        title: "Availability updated",
        detail: "Room 10 availability opened due to cancellation.",
        when: "15 min ago"
      },
      {
        title: "Package 'Canoe Explorer' edited",
        detail: "Description updated for seasonal offering.",
        when: "1 hour ago"
      }
    ],
    risk: []
  },
  items: [
    {
      id: "lakeside-suite",
      name: "Lakeside Suite",
      title: "Lakeside Suite",
      description: "Our most luxurious offering, featuring panoramic lake views, a private balcony, and a king-sized bed.",
      image: "https://images.pexels.com/photos/6466217/pexels-photo-6466217.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      medium: "King Bed",
      dimensions: "450 sq ft",
      price: "$450/night",
      status: "Available",
      category: "Suite",
      amenities: ["Private Balcony", "Lake View", "King Bed", "Jacuzzi Tub"]
    },
    {
      id: "mountain-view-double",
      name: "Mountain View Double",
      title: "Mountain View Double",
      description: "Cozy room with two double beds and stunning views of the Adirondack mountains.",
      image: "https://images.pexels.com/photos/3872908/pexels-photo-3872908.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      medium: "Two Double Beds",
      dimensions: "300 sq ft",
      price: "$280/night",
      status: "Available",
      category: "Standard Room",
      amenities: ["Mountain View", "Two Double Beds", "Ensuite Bathroom"]
    },
    {
      id: "forest-nook-queen",
      name: "Forest Nook Queen",
      title: "Forest Nook Queen",
      description: "Secluded queen-sized room nestled amongst the peaceful forest, offering ultimate tranquility.",
      image: "https://images.pexels.com/photos/6394682/pexels-photo-6394682.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      medium: "Queen Bed",
      dimensions: "280 sq ft",
      price: "$250/night",
      status: "Available",
      category: "Standard Room",
      amenities: ["Forest View", "Queen Bed", "Quiet Location"]
    },
    {
      id: "family-cottage",
      name: "Family Cottage",
      title: "Family Cottage",
      description: "A spacious cottage with multiple bedrooms, perfect for families or small groups, with a private entrance.",
      image: "https://images.pexels.com/photos/9145354/pexels-photo-9145354.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      medium: "2 Bedrooms",
      dimensions: "800 sq ft",
      price: "$600/night",
      status: "Available",
      category: "Cottage",
      amenities: ["Multiple Bedrooms", "Living Area", "Kitchenette", "Private Entrance"]
    },
    {
      id: "sauna-session",
      name: "Sauna & Refresh Package",
      title: "Sauna & Refresh Package",
      description: "Indulge in a relaxing sauna session followed by a refreshing dip in the lake (seasonal).",
      image: "https://images.pexels.com/photos/3872899/pexels-photo-3872899.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      medium: "1 Hour",
      price: "$75",
      status: "Available",
      category: "Activity",
    },
    {
      id: "canoe-expedition",
      name: "Guided Canoe Expedition",
      title: "Guided Canoe Expedition",
      description: "Explore the tranquil waters of the Adirondacks with an experienced guide, suitable for all skill levels.",
      image: "https://images.pexels.com/photos/36328107/pexels-photo-36328107.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      medium: "3 Hours",
      price: "$120",
      status: "Available",
      category: "Activity",
    },
    {
      id: "adirondack-explorer",
      name: "Adirondack Explorer Package",
      title: "Adirondack Explorer Package",
      description: "Combine your stay with a guided hike and a gourmet picnic lunch amidst stunning natural beauty.",
      image: "https://images.pexels.com/photos/4820811/pexels-photo-4820811.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      medium: "Full Day",
      price: "$180",
      status: "Available",
      category: "Package",
    },
    {
      id: "culinary-experience",
      name: "Lakeside Culinary Experience",
      title: "Lakeside Culinary Experience",
      description: "A multi-course dinner at our lodge restaurant focusing on local, seasonal ingredients.",
      image: "https://images.pexels.com/photos/9146376/pexels-photo-9146376.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      medium: "Evening",
      price: "$95/person",
      status: "Available",
      category: "Dining",
    },
  ],
  services: [
    {
      name: "Lakeside Suite Booking",
      description: "Secure your stay in our spacious Lakeside Suite with breathtaking views.",
      duration: "N/A",
      badge: "Premium"
    },
    {
      name: "Guided Canoe Expedition",
      description: "Explore the tranquil waters of the Adirondacks with an experienced guide.",
      duration: "3 hours",
      badge: "Adventure"
    },
    {
      name: "Sauna & Refresh Package",
      description: "Indulge in a relaxing sauna session followed by a refreshing dip.",
      duration: "1 hour",
      badge: "Relaxation"
    },
    {
      name: "Adirondack Explorer Package",
      description: "Combine your stay with a guided hike and a gourmet picnic lunch.",
      duration: "Full Day",
      badge: "Nature"
    }
  ],
  cta: {
    heading: "Ready for your Cedar Point Lodge escape?",
    description: "Effortlessly book your serene getaway and add personalized experiences.",
    primaryLabel: "Book Your Stay Now",
    primaryHref: "/book-your-stay",
    secondaryLabel: "Explore All Activities",
    secondaryHref: "/activities"
  },
  footer: {
    description: "Cedar Point Lodge — clear options, real availability."
  },
  featuresHeading: "Experience Cedar Point Lodge",
  roomTypes: [
    {
      id: "lakeside-suite",
      name: "Lakeside Suite",
      description: "Our most luxurious offering, featuring panoramic lake views, a private balcony, and a king-sized bed.",
      imageUrl: "https://images.pexels.com/photos/6466217/pexels-photo-6466217.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      beds: "1 King",
      capacity: 2,
      price: 450,
      amenities: ["Private Balcony", "Lake View", "Jacuzzi Tub", "Minibar"],
      availability: "Available"
    },
    {
      id: "mountain-view-double",
      name: "Mountain View Double",
      description: "Cozy room with two double beds and stunning views of the Adirondack mountains.",
      imageUrl: "https://images.pexels.com/photos/3872908/pexels-photo-3872908.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      beds: "2 Doubles",
      capacity: 4,
      price: 280,
      amenities: ["Mountain View", "Writing Desk", "Coffee Maker"],
      availability: "Available"
    },
    {
      id: "forest-nook-queen",
      name: "Forest Nook Queen",
      description: "Secluded queen-sized room nestled amongst the peaceful forest, offering ultimate tranquility.",
      imageUrl: "https://images.pexels.com/photos/6394682/pexels-photo-6394682.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      beds: "1 Queen",
      capacity: 2,
      price: 250,
      amenities: ["Forest View", "Reading Chair", "Private Bathroom"],
      availability: "Available"
    },
    {
      id: "executive-king",
      name: "Executive King",
      description: "Spacious room with a king bed, ideal for business travelers or couples seeking extra space.",
      imageUrl: "https://images.pexels.com/photos/3771811/pexels-photo-3771811.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      beds: "1 King",
      capacity: 2,
      price: 320,
      amenities: ["Desk Area", "King Bed", "Smart TV"],
      availability: "Limited"
    },
    {
      id: "riverside-twin",
      name: "Riverside Twin",
      description: "Charming room with two twin beds, overlooking the gentle flow of the nearby river.",
      imageUrl: "https://images.pexels.com/photos/6363792/pexels-photo-6363792.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
      beds: "2 Twins",
      capacity: 2,
      price: 260,
      amenities: ["River View", "Twin Beds", "Shared Balcony Access"],
      availability: "Booked"
    }
  ],
  packages: [
    {
      id: "sauna-stay",
      name: "Sauna & Stay Package",
      description: "Includes a private sauna session and a complimentary wellness drink.",
      price: 50,
      duration: "1 Hour",
      type: "Add-on",
      image: "https://images.pexels.com/photos/3872899/pexels-photo-3872899.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
    },
    {
      id: "canoe-explorer",
      name: "Canoe Explorer Package",
      description: "A guided 3-hour canoe trip with an experienced local guide.",
      price: 120,
      duration: "3 Hours",
      type: "Activity",
      image: "https://images.pexels.com/photos/36328107/pexels-photo-36328107.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
    },
    {
      id: "romantic-getaway",
      name: "Romantic Getaway",
      description: "A bottle of local wine, chocolates, and late checkout for couples.",
      price: 80,
      duration: "N/A",
      type: "Add-on",
      image: "https://images.pexels.com/photos/3768095/pexels-photo-3768095.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
    }
  ],
  availableDates: [
    { date: "2024-10-20", status: "available" },
    { date: "2024-10-21", status: "available" },
    { date: "2024-10-22", status: "booked" },
    { date: "2024-10-23", status: "available" },
    { date: "2024-10-24", status: "available" },
    { date: "2024-10-25", status: "available" },
    { date: "2024-10-26", status: "available" },
    { date: "2024-10-27", status: "booked" },
  ],
  testimonials: [
    {
      name: "Sarah & Tom Davies",
      initials: "SD",
      text: "Booking our anniversary trip to Cedar Point Lodge was incredibly easy. The online system was intuitive, and we loved being able to see all the room options and add a canoe trip right away. The confirmation email arrived instantly!",
      service: "Lakeside Suite Booking"
    },
    {
      name: "Michael Chen",
      initials: "MC",
      text: "The Room Type Showcase made it so simple to choose the perfect room. The descriptions and photos were accurate, and knowing the availability beforehand saved so much time. A truly smooth booking experience.",
      service: "Direct Booking Engine"
    },
    {
      name: "Jessica Rodriguez",
      initials: "JR",
      text: "As a lodge manager, the Admin Dashboard has been a game-changer. I can quickly view all bookings, manage room availability, and even get insights from guest feedback. It's transformed our daily operations.",
      service: "Booking Management Dashboard"
    },
    {
      name: "David & Emily Green",
      initials: "DG",
      text: "The personalized package recommendations during booking were fantastic! We added a guided hike we never would have thought of, making our stay even more memorable.",
      service: "Personalized Package Recommendations"
    }
  ],
  opsHero: {
    headline: "Welcome, Eleanor!",
    subcopy: "Here's a quick overview of Cedar Point Lodge's performance today.",
  },
  tableRows: [
    {
      id: "B-001",
      guest: "Sarah & Tom Davies",
      room: "Lakeside Suite",
      checkIn: "2024-10-20",
      checkOut: "2024-10-23",
      status: "Confirmed",
      total: "$1350",
      package: "Sauna & Stay"
    },
    {
      id: "B-002",
      guest: "Michael Chen",
      room: "Mountain View Double",
      checkIn: "2024-10-21",
      checkOut: "2024-10-24",
      status: "Confirmed",
      total: "$840",
      package: "Canoe Explorer"
    },
    {
      id: "B-003",
      guest: "Jessica Rodriguez",
      room: "Forest Nook Queen",
      checkIn: "2024-10-25",
      checkOut: "2024-10-27",
      status: "Pending",
      total: "$500",
      package: "None"
    },
    {
      id: "B-004",
      guest: "David & Emily Green",
      room: "Executive King",
      checkIn: "2024-10-28",
      checkOut: "2024-10-31",
      status: "Confirmed",
      total: "$960",
      package: "Romantic Getaway"
    },
    {
      id: "B-005",
      guest: "Olivia White",
      room: "Lakeside Suite",
      checkIn: "2024-11-01",
      checkOut: "2024-11-05",
      status: "Confirmed",
      total: "$1800",
      package: "Adirondack Explorer"
    },
    {
      id: "B-006",
      guest: "Daniel Lee",
      room: "Mountain View Double",
      checkIn: "2024-11-03",
      checkOut: "2024-11-06",
      status: "Cancelled",
      total: "$0",
      package: "None"
    },
    {
      id: "B-007",
      guest: "Grace Kim",
      room: "Forest Nook Queen",
      checkIn: "2024-11-08",
      checkOut: "2024-11-10",
      status: "Confirmed",
      total: "$500",
      package: "Sauna & Stay"
    },
    {
      id: "B-008",
      guest: "Henry Wilson",
      room: "Executive King",
      checkIn: "2024-11-12",
      checkOut: "2024-11-15",
      status: "Confirmed",
      total: "$960",
      package: "None"
    }
  ],
  activity: [
    {
      title: "New booking received",
      detail: "Sarah & Tom Davies booked Lakeside Suite for Oct 20-23.",
      when: "Just now"
    },
    {
      title: "Room 10 availability opened",
      detail: "Due to cancellation by Daniel Lee.",
      when: "15 min ago"
    },
    {
      title: "Package 'Canoe Explorer' updated",
      detail: "Seasonal offering adjusted for fall pricing.",
      when: "1 hour ago"
    },
    {
      title: "Guest inquiry received",
      detail: "Jessica Rodriguez asked about pet policy.",
      when: "2 hours ago"
    },
    {
      title: "Housekeeping request",
      detail: "Room 5 needs extra towels for tomorrow's check-in.",
      when: "3 hours ago"
    },
    {
      title: "Payment processed",
      detail: "Full payment received for Olivia White's booking.",
      when: "Yesterday"
    },
    {
      title: "New review submitted",
      detail: "5-star rating from Marcus R. about the booking process.",
      when: "Yesterday"
    },
    {
      title: "Maintenance alert",
      detail: "Minor leak reported in Room 14 bathroom.",
      when: "2 days ago"
    },
  ],
  chartData: [
    { label: "Jan", value: 30 },
    { label: "Feb", value: 35 },
    { label: "Mar", value: 42 },
    { label: "Apr", value: 38 },
    { label: "May", value: 55 },
    { label: "Jun", value: 65 },
    { label: "Jul", value: 78 },
    { label: "Aug", value: 82 },
    { label: "Sep", value: 70 },
    { label: "Oct", value: 60 },
    { label: "Nov", value: 45 },
    { label: "Dec", value: 33 },
  ],
  booking: {
    services: [
      {
        id: "lakeside-suite-booking",
        name: "Lakeside Suite (1 King Bed)",
        description: "Our premier room with stunning lake views.",
        price: 450,
        type: "room",
        capacity: 2,
        imageUrl: "https://images.pexels.com/photos/6466217/pexels-photo-6466217.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
      },
      {
        id: "mountain-view-double-booking",
        name: "Mountain View Double (2 Double Beds)",
        description: "Comfortable room with mountain scenery.",
        price: 280,
        type: "room",
        capacity: 4,
        imageUrl: "https://images.pexels.com/photos/3872908/pexels-photo-3872908.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
      },
      {
        id: "forest-nook-queen-booking",
        name: "Forest Nook Queen (1 Queen Bed)",
        description: "Secluded and tranquil forest-facing room.",
        price: 250,
        type: "room",
        capacity: 2,
        imageUrl: "https://images.pexels.com/photos/6394682/pexels-photo-6394682.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
      },
      {
        id: "guided-canoe-trip",
        name: "Guided Canoe Trip",
        description: "Explore the lake with an experienced guide.",
        price: 120,
        type: "activity",
        duration: "3 hours",
        capacity: 4,
        imageUrl: "https://images.pexels.com/photos/36328107/pexels-photo-36328107.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
      },
      {
        id: "sauna-session",
        name: "Private Sauna Session",
        description: "Relax and rejuvenate in our lakeside sauna.",
        price: 75,
        type: "activity",
        duration: "1 hour",
        capacity: 2,
        imageUrl: "https://images.pexels.com/photos/3872899/pexels-photo-3872899.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
      }
    ],
    customer: {
      name: "Jamie R.",
      email: "jamie.r@example.com",
      phone: "555-123-4567"
    },
    selected: {
      serviceId: "lakeside-suite-booking",
      date: "2024-11-15",
      time: "15:00",
      guests: 2,
      duration: "3 nights",
      addons: ["sauna-session"],
    },
  }
,
  kpis: "0",
  process: [{ title: "Process — Cedar Point Lodge", description: "Prepared by Cedar Point Lodge." }],
  treatments: [{ title: "Treatments — Cedar Point Lodge", description: "Prepared by Cedar Point Lodge." }],
};
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;