// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed, aiFeatures } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, RiskQueue, ChartCard, FilterBar, DataTable, ActivityFeed, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  
  const today = new Date();
  const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const formattedDate = today.toLocaleDateString('en-US', options);

  const slots = {
    header: (
      <PageHeader
        title="Adirondack Concierge Connect Dashboard"
        meta={<span className="text-sm text-muted">{formattedDate}</span>}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Upcoming Check-ins" value="4" hint="Today & Tomorrow" />
        <StatCard label="Occupancy Rate" value="78%" hint="This Week" />
        <StatCard label="Pending Bookings" value="2" hint="Awaiting Confirmation" />
        <StatCard label="Avg. Daily Rate" value="$325" hint="This Month" />
      </div>
    ),
    risk: (
      <RiskQueue 
        heading="Guest Feedback Sentiment" 
        items={[
          { 
            id: "sentiment-1", 
            title: "Overall Positive Sentiment: 92%", 
            detail: "Guests are consistently happy with their stays. Monitor specific feedback for continuous improvement.", 
            severity: "low" 
          }
        ]} 
      />
    ),
    chart: (
      // The brief does not provide specific data for a chart, so using placeholder data for a basic area chart.
      // This slot is required by the skeleton, so it must be rendered.
      <ChartCard 
        title="Booking Trends (Last 7 Days)" 
        type="area" 
        dataKey="bookings" 
        xKey="day" 
        data={[
          { day: "Sun", bookings: 5 },
          { day: "Mon", bookings: 7 },
          { day: "Tue", bookings: 6 },
          { day: "Wed", bookings: 9 },
          { day: "Thu", bookings: 8 },
          { day: "Fri", bookings: 12 },
          { day: "Sat", bookings: 10 },
        ]} 
        description="Daily bookings over the past week."
      />
    ),
    filters: (
      <FilterBar searchPlaceholder="Search bookings" filters={[
        { id: "all", label: "All Bookings", active: true },
        { id: "today", label: "Today", active: false },
        { id: "this-week", label: "This Week", active: false },
        { id: "next-30-days", label: "Next 30 Days", active: false }
      ]} />
    ),
    table: (
      <DataTable
        columns={[
          { key: "guestName", header: "Guest Name" },
          { key: "room", header: "Room" },
          { key: "checkIn", header: "Check-in" },
          { key: "checkOut", header: "Check-out" },
          { key: "package", header: "Package" },
        ]}
        rows={[
          { id: "b1", guestName: "Eleanor Vance", room: "Room 1 (Lake View)", checkIn: "Oct 20, 2024", checkOut: "Oct 23, 2024", package: "Canoe Explorer" },
          { id: "b2", guestName: "Michael Chang", room: "Room 7 (Adirondack Suite)", checkIn: "Oct 21, 2024", checkOut: "Oct 25, 2024", package: "Sauna & Stay" },
          { id: "b3", guestName: "Sophia Rossi", room: "Room 12 (Forest Nook)", checkIn: "Oct 22, 2024", checkOut: "Oct 24, 2024", package: "No Package" },
          { id: "b4", guestName: "David Lee", room: "Room 4 (Twin Peaks)", checkIn: "Oct 24, 2024", checkOut: "Oct 26, 2024", package: "Canoe Explorer" },
          { id: "b5", guestName: "Jamie R.", room: "Room 7 (Lakeside)", checkIn: "Oct 20, 2024", checkOut: "Oct 23, 2024", package: "Sauna & Stay" },
        ]}
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "a1", title: "New booking received", detail: "Eleanor Vance booked Room 1 for Oct 20-23.", time: "Just now" },
          { id: "a2", title: "Room 7 availability updated", detail: "Blocked for maintenance until Oct 19.", time: "15m ago" },
          { id: "a3", title: "Package 'Sauna & Stay' edited", detail: "Description updated for clarity.", time: "1h ago" },
          { id: "a4", title: "Guest Michael Chang checked in", detail: "Room 7 assigned.", time: "2h ago" },
          { id: "a5", title: "New booking received", detail: "Jamie R. booked Room 7 for Oct 20-23.", time: "Just now" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
          <div id="sentiment-analysis-for-guest-feedback" data-ai-feature-panel="sentiment-analysis-for-guest-feedback">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "sentiment-analysis-for-guest-feedback") || { id: "sentiment-analysis-for-guest-feedback", name: "sentiment-analysis-for-guest-feedback" }}
          brandName={"Cedar Point Lodge"}
        />
      </div>
    </OpsShell>
  );
}