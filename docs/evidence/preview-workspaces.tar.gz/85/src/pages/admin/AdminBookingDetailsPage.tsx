// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, StatCard, DataTable, ActivityFeed } from '@/ui';

const SKELETON_ID = "ops-detail" as const;
export default function AdminBookingDetailsPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={seed.opsHero?.headline || "Booking Details - Cedar Point Lodge"} description={seed.opsHero?.subcopy || "Appointments, check-ins, and the work that needs attention now."} meta={<span className="text-sm text-muted">Live</span>} actions={[{ label: "AI features", href: "/ai-features", variant: "secondary" }, { label: "Check in", href: "#queue" }]} />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard label={seed.kpis?.[0]?.label ?? "Active today"} value={seed.kpis?.[0]?.value ?? "24"} delta={seed.kpis?.[0]?.delta ?? "+8%"} hint={seed.kpis?.[0]?.hint ?? "Compared with last week"} /><StatCard label={seed.kpis?.[1]?.label ?? "In progress"} value={seed.kpis?.[1]?.value ?? "11"} delta={seed.kpis?.[1]?.delta ?? "+2"} hint={seed.kpis?.[1]?.hint ?? "Open work items"} /><StatCard label={seed.kpis?.[2]?.label ?? "Resolved"} value={seed.kpis?.[2]?.value ?? "93%"} delta={seed.kpis?.[2]?.delta ?? "-2%"} hint={seed.kpis?.[2]?.hint ?? "Rolling 7-day rate"} /></div>
    ),
    table: (
      <DataTable columns={[{ key: "name", header: "Name" }, { key: "status", header: "Status" }, { key: "owner", header: "Owner" }]} rows={(seed.tableRows ?? [{ id: "t1", name: "Primary record", status: "In progress", owner: "Ops" }, { id: "t2", name: "Follow-up item", status: "On hold", owner: "Ops" }, { id: "t3", name: "Completed item", status: "Done", owner: "Ops" }]).map((row: any) => ({ name: String(row?.name ?? row?.title ?? row?.label ?? row?.id ?? ""), status: String(row?.status ?? row?.state ?? ""), owner: String(row?.owner ?? row?.collector ?? row?.assignee ?? row?.client ?? "—") }))} />
    ),
    activity: (
      <ActivityFeed heading="Activity" items={(seed.activity ?? [{ id: "activity-1", title: "Record updated", detail: "The latest details are ready.", time: "Just now" }, { id: "activity-2", title: "Owner assigned", detail: "Waiting on confirmation.", time: "12m ago" }, { id: "activity-3", title: "Note added", detail: "Internal handoff logged.", time: "1h ago" }])} />
    ),
  };

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-booking-details">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}
