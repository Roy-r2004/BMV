// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Contact Cedar Point Lodge"}
        description={"We're here to help you plan your perfect Adirondack getaway."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Reach Us Directly"}
            description={"Our team is ready to answer your questions or assist with bookings."}
            ctaLabel={"Call Us: (518) 555-1234"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Cedar Point Lodge"}
        description={"Cedar Point Lodge – Your Adirondack Escape Awaits."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="contact">
      </div>
      <PublicShell
      brandName={"Cedar Point Lodge"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
