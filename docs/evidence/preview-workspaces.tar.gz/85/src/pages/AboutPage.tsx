// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, LogoMarquee, FeatureBento, ProcessSection, TestimonialRail, BookingPanel, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "trust", "features", "process", "testimonials", "booking", "cta", "footer"] as const;

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Cedar Point Lodge"}
        headline={"Our Story: Cedar Point Lodge"}
        subcopy={"A legacy of lakeside hospitality in the heart of the Adirondacks."}
        primaryCta={{ label: "Discover Your Escape", href: "/contact" }}
        imageSrc={'https://images.pexels.com/photos/35259529/pexels-photo-35259529.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'}
        imageAlt="Exterior of Cedar Point Lodge at sunset"
      />
    ),
    trust: (
      <LogoMarquee
        size="display"
        heading="Our Roots"
        items={[
          { label: "Family Owned Since 1952" },
          { label: "Adirondack Heritage" },
          { label: "Commitment to Conservation" },
          { label: "Guest-Centric Service" },
        ]}
      />
    ),
    features: (
      <FeatureBento
        heading={"Our Philosophy: Harmony with Nature"}
        description={"At Cedar Point Lodge, we believe in creating an experience that nourishes the soul and respects the breathtaking beauty of the Adirondacks."}
        imagePool={[images.card1, images.card2, images.card3]}
        items={[
          {
            title: "Lakeside Tranquility",
            description: "Nestled on the serene shores of Lake Champlain, offering unparalleled peace and natural beauty.",
            imageSrc: images.card1,
            imageAlt: "Serene lakeside view from Cedar Point Lodge"
          },
          {
            title: "Authentic Adirondack Charm",
            description: "Our lodge blends rustic elegance with modern comforts, reflecting the timeless spirit of the region.",
            imageSrc: images.card2,
            imageAlt: "Cozy interior of a lodge room with rustic decor"
          },
          {
            title: "Guided Canoe Trips",
            description: "Explore hidden coves and untouched waterways with our experienced local guides.",
            imageSrc: images.card3,
            imageAlt: "Canoe on a calm lake with mountains in the background"
          },
          {
            title: "Farm-to-Table Dining",
            description: "Savor exquisite meals crafted from the freshest local ingredients in our lodge restaurant.",
            imageSrc: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            imageAlt: "Plate of beautifully presented food in a restaurant setting"
          },
          {
            title: "Relaxing Sauna Experience",
            description: "Unwind and rejuvenate in our traditional lakeside sauna after a day of adventure.",
            imageSrc: "https://images.pexels.com/photos/305236/pexels-photo-305236.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            imageAlt: "Interior of a warm wooden sauna"
          },
          {
            title: "Sustainable Practices",
            description: "We are committed to minimizing our environmental footprint and preserving our pristine surroundings.",
            imageSrc: "https://images.pexels.com/photos/2088204/pexels-photo-2088204.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            imageAlt: "Green leaves and sunlight, symbolizing nature"
          },
        ]}
      />
    ),
    process: (
      <ProcessSection heading={seed.processHeading ?? "How Cedar Point Lodge works"} steps={seed.process ?? []} />
    ),
    testimonials: (
      <TestimonialRail
        heading={"Voices from Our Guests"}
        items={[
          {
            quote: "Cedar Point Lodge is a true gem. The serene lake views, the delicious food, and the incredibly warm staff made for an unforgettable escape. We can't wait to return!",
            author: "Eleanor V.",
            role: "Frequent Guest"
          },
          {
            quote: "The guided canoe trip was the highlight of our stay! Our guide was knowledgeable and passionate, showing us parts of the lake we would never have found on our own. Pure magic.",
            author: "Thomas M.",
            role: "Adventure Seeker"
          },
          {
            quote: "From the moment we arrived, we felt like family. The attention to detail in our room and the personalized service in the restaurant were exceptional. A truly restorative experience.",
            author: "Sophia R.",
            role: "Relaxation Enthusiast"
          }
        ]}
      />
    ),
    booking: (
      <BookingPanel heading="Choose a time" treatments={seed.treatments ?? []} slots={[{ id: "slot-1", startsAt: "2026-07-14T10:00:00" }]} />
    ),
    cta: (
      <CTABand
        heading={"Ready to Experience the Adirondacks?"}
        description={"Begin your Cedar Point Lodge story. Explore our rooms and book your tranquil lakeside retreat today."}
        primaryCta={{ label: "Discover Your Escape", href: "/contact" }}
        secondaryCta={{ label: "View Our Rooms", href: "/admin/rooms" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Cedar Point Lodge"}
        description={"An intimate lakeside lodge offering a serene escape and authentic Adirondack experiences. Book your stay directly with us."}
        links={[
          { label: "Home", href: "/" },
          { label: "Rooms", href: "/admin/rooms" },
          { label: "Dining", href: "/dining" },
          { label: "Activities", href: "/activities" },
          { label: "Contact", href: "/contact" },
          { label: "Privacy Policy", href: "#" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="about">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}