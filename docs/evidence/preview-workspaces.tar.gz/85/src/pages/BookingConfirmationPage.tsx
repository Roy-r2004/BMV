// composed confirmation page (ConfirmStage)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, BrandFooter, ConfirmStage, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

export default function BookingConfirmationPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();

  return (
    <>
      <div className="contents" data-appspec-page="booking-confirmation">
      </div>
      <PublicShell
      brandName={"Cedar Point Lodge"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <ConfirmStage
        eyebrow={"Confirmed"}
        title={"Booking Confirmed!"}
        detail={"Confirmation on file"}
        description={"Thank you for choosing Cedar Point Lodge."}
        primaryCta={{"label": "Back to home", "href": "/"}}
        nextSteps={[{"title": "Your Reservation is Confirmed!", "description": "Your booking reference is #CPL-198305. A detailed confirmation has been sent to your email address. We can't wait to welcome you!", "ctaLabel": "View My Booking", "href": "/my-bookings/CPL-198305"}, {"title": "Explore Our Lodge", "description": "Discover all the amenities and activities available during your stay, from our lakeside restaurant to guided canoe trips.", "ctaLabel": "Discover Cedar Point Lodge", "href": "/lodge-experience"}, {"title": "Need to Make Changes?", "description": "If you need to adjust your reservation, please contact our concierge team directly.", "ctaLabel": "Contact Us", "href": "/contact"}]}
      />
      <BrandFooter
        brandName={"Cedar Point Lodge"}
        description={"Cedar Point Lodge, where the Adirondacks meet unparalleled hospitality."}
      />
          <div id="personalized-package-recommendations" data-ai-feature-panel="personalized-package-recommendations">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "personalized-package-recommendations") || { id: "personalized-package-recommendations", name: "personalized-package-recommendations" }}
          brandName={"Cedar Point Lodge"}
        />
      </div>
    </PublicShell>
    </>
  );
}
