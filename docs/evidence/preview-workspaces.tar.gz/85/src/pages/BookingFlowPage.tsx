// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProcessSection, BookingPanel, TestimonialRail, BrandFooter, Input, Button } from '@/ui';
import { useState } from 'react';

const SKELETON_ID = "public-booking" as const;
const RECIPE_ORDER = ["hero", "process", "booking", "testimonials", "footer"] as const;

export default function BookingFlowPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const [currentStep, setCurrentStep] = useState(0);
  const [selectedDates, setSelectedDates] = useState<{ start: Date | null, end: Date | null }>({ start: null, end: null });
  const [selectedRoom, setSelectedRoom] = useState<any | null>(null);
  const [selectedPackages, setSelectedPackages] = useState<any[]>([]);
  const [guestDetails, setGuestDetails] = useState({ name: '', email: '', phone: '', specialRequests: '' });

  const handleDateSelect = (start: Date, end: Date) => {
    setSelectedDates({ start, end });
    setCurrentStep(1); // Move to room selection
  };

  const handleRoomSelect = (room: any) => {
    setSelectedRoom(room);
    setCurrentStep(2); // Move to package selection
  };

  const handlePackageToggle = (pkg: any) => {
    setSelectedPackages(prev =>
      prev.includes(pkg) ? prev.filter(p => p !== pkg) : [...prev, pkg]
    );
  };

  const mockRooms = [
    { id: 'room-1', name: 'Lakeside Serenity Suite', description: 'Panoramic lake views and a private balcony.', price: 350, imageUrl: images.card1 },
    { id: 'room-2', name: 'Forest Retreat Cabin', description: 'Cozy cabin nestled in the pines, perfect for quiet escapes.', price: 280, imageUrl: images.card2 },
    { id: 'room-3', name: 'Cedar Haven Room', description: 'Charming room with a queen bed and garden views.', price: 220, imageUrl: images.card3 },
  ];

  const mockPackages = [
    { id: 'pkg-1', name: 'Sauna & Stay', description: 'Enjoy exclusive access to our lakeside sauna during your stay.', price: 50 },
    { id: 'pkg-2', name: 'Canoe Explorer', description: 'Includes a guided two-hour canoe trip on the lake.', price: 75 },
    { id: 'pkg-3', name: 'Adirondack Breakfast Basket', description: 'A delightful breakfast basket delivered to your room each morning.', price: 30 },
  ];

  const renderBookingStep = () => {
    switch (currentStep) {
      case 0: // Date Selection (using BookingPanel's slots for calendar mock)
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-display text-text">When would you like to visit?</h3>
            <div className="bg-surface p-6 rounded-lg shadow-sm">
              <h4 className="font-semibold text-lg text-text">Live Availability Calendar</h4>
              <p className="text-muted mb-4">Select your check-in and check-out dates.</p>
              {/* This would be a real calendar component in a full implementation */}
              <div className="grid grid-cols-2 gap-4">
                <Input type="date" label="Check-in Date" onChange={(e) => setSelectedDates(prev => ({ ...prev, start: new Date(e.target.value) }))} />
                <Input type="date" label="Check-out Date" onChange={(e) => setSelectedDates(prev => ({ ...prev, end: new Date(e.target.value) }))} />
              </div>
              <Button onClick={() => selectedDates.start && selectedDates.end && setCurrentStep(1)} className="mt-4" disabled={!selectedDates.start || !selectedDates.end}>Check Availability</Button>
            </div>
          </div>
        );
      case 1: // Room Selection
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-display text-text">Choose your perfect retreat.</h3>
            <p className="text-muted">Available rooms for your selected dates ({selectedDates.start?.toLocaleDateString()} - {selectedDates.end?.toLocaleDateString()}):</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mockRooms.map(room => (
                <div key={room.id} className={`bg-surface p-6 rounded-lg shadow-sm flex flex-col ${selectedRoom?.id === room.id ? 'border-2 border-primary' : 'border border-surface'}`}>
                  <img src={room.imageUrl} alt={room.name} className="w-full h-48 object-cover rounded-md mb-4" />
                  <h4 className="font-semibold text-lg text-text mb-2">{room.name}</h4>
                  <p className="text-muted text-sm flex-grow mb-4">{room.description}</p>
                  <div className="flex justify-between items-center mt-auto pt-4 border-t border-muted/20">
                    <span className="font-bold text-primary">${room.price} / night</span>
                    <Button onClick={() => handleRoomSelect(room)} variant={selectedRoom?.id === room.id ? 'primary' : 'default'}>
                      {selectedRoom?.id === room.id ? 'Selected' : 'Select Room'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-6">
              <Button onClick={() => setCurrentStep(0)} variant="ghost">Back</Button>
              <Button onClick={() => selectedRoom && setCurrentStep(2)} disabled={!selectedRoom}>Continue to Packages</Button>
            </div>
          </div>
        );
      case 2: // Package Selection
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-display text-text">Enhance your stay with personalized experiences.</h3>
            <p className="text-muted">Add special packages to make your visit unforgettable.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mockPackages.map(pkg => (
                <div key={pkg.id} className={`bg-surface p-6 rounded-lg shadow-sm flex flex-col ${selectedPackages.includes(pkg) ? 'border-2 border-primary' : 'border border-surface'}`}>
                  <h4 className="font-semibold text-lg text-text mb-2">{pkg.name}</h4>
                  <p className="text-muted text-sm flex-grow mb-4">{pkg.description}</p>
                  <div className="flex justify-between items-center mt-auto pt-4 border-t border-muted/20">
                    <span className="font-bold text-primary">${pkg.price}</span>
                    <Button onClick={() => handlePackageToggle(pkg)} variant={selectedPackages.includes(pkg) ? 'primary' : 'default'}>
                      {selectedPackages.includes(pkg) ? 'Added' : 'Add Package'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-primary/10 p-4 rounded-lg mt-6 text-text">
              <p className="font-semibold text-sm">Personalized Recommendation:</p>
              <p className="text-sm">Guests often add the <span className="font-bold">Guided Canoe Trip!</span> Explore the lake with our experienced guides.</p>
            </div>
            <div className="flex justify-between mt-6">
              <Button onClick={() => setCurrentStep(1)} variant="ghost">Back</Button>
              <Button onClick={() => setCurrentStep(3)}>Continue to Details</Button>
            </div>
          </div>
        );
      case 3: // Guest Details
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-display text-text">Tell us a little about yourself.</h3>
            <div className="bg-surface p-6 rounded-lg shadow-sm space-y-4">
              <Input label="Full Name" type="text" value={guestDetails.name} onChange={(e) => setGuestDetails(prev => ({ ...prev, name: e.target.value }))} required />
              <Input label="Email Address" type="email" value={guestDetails.email} onChange={(e) => setGuestDetails(prev => ({ ...prev, email: e.target.value }))} required />
              <Input label="Phone Number" type="tel" value={guestDetails.phone} onChange={(e) => setGuestDetails(prev => ({ ...prev, phone: e.target.value }))} required />
              <Input label="Special Requests (optional)" as="textarea" rows={3} value={guestDetails.specialRequests} onChange={(e) => setGuestDetails(prev => ({ ...prev, specialRequests: e.target.value }))} />
            </div>
            <div className="flex justify-between mt-6">
              <Button onClick={() => setCurrentStep(2)} variant="ghost">Back</Button>
              <Button onClick={() => guestDetails.name && guestDetails.email && guestDetails.phone && setCurrentStep(4)} disabled={!guestDetails.name || !guestDetails.email || !guestDetails.phone}>Proceed to Payment</Button>
            </div>
          </div>
        );
      case 4: // Payment
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-display text-text">Complete your booking.</h3>
            <div className="bg-surface p-6 rounded-lg shadow-sm space-y-4">
              <h4 className="font-semibold text-lg text-text mb-2">Order Summary</h4>
              <p><strong>Dates:</strong> {selectedDates.start?.toLocaleDateString()} - {selectedDates.end?.toLocaleDateString()}</p>
              <p><strong>Room:</strong> {selectedRoom?.name} (${selectedRoom?.price}/night)</p>
              {selectedPackages.length > 0 && (
                <>
                  <p><strong>Packages:</strong></p>
                  <ul className="list-disc list-inside ml-4">
                    {selectedPackages.map(pkg => <li key={pkg.id}>{pkg.name} (${pkg.price})</li>)}
                  </ul>
                </>
              )}
              <div className="pt-4 border-t border-muted/20">
                <p className="text-lg font-bold text-primary">Total: ${
                  (selectedRoom ? selectedRoom.price * ((selectedDates.end && selectedDates.start) ? Math.ceil((selectedDates.end.getTime() - selectedDates.start.getTime()) / (1000 * 60 * 60 * 24)) : 1) : 0) +
                  selectedPackages.reduce((acc, pkg) => acc + pkg.price, 0)
                }</p>
              </div>

              <h4 className="font-semibold text-lg text-text mt-6 mb-2">Payment Information</h4>
              <Input label="Card Number" type="text" placeholder="**** **** **** ****" required />
              <div className="grid grid-cols-2 gap-4">
                <Input label="Expiry Date" type="text" placeholder="MM/YY" required />
                <Input label="CVC" type="text" placeholder="***" required />
              </div>
              <p className="text-muted text-sm">Secure payment powered by Stripe.</p>
            </div>
            <div className="flex justify-between mt-6">
              <Button onClick={() => setCurrentStep(3)} variant="ghost">Back</Button>
              <Button onClick={() => alert('Booking Confirmed!')}>Confirm & Pay</Button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const slots = {
    hero: (
      <MarketingHero
        brandName="Cedar Point Lodge"
        headline="Your Adirondack Stay: Step-by-Step Booking"
        subcopy="Select your dates, choose your room, and add personalized experiences."
        primaryCta={{ label: "Begin Your Reservation", href: "#booking-start" }}
        imageSrc={images.hero}
        imageAlt="Lakeside lodge view with canoes"
      />
    ),
    process: (
      <ProcessSection
        heading="Seamless Booking Journey"
        steps={[
          { title: "Dates", description: "Find the perfect time for your escape." },
          { title: "Room", description: "Discover your ideal lakeside haven." },
          { title: "Packages", description: "Enhance your stay with unique activities." },
          { title: "Details", description: "Provide your guest information." },
          { title: "Payment", description: "Securely confirm your reservation." },
          { title: "Confirm", description: "Receive instant booking confirmation." },
        ]}
      />
    ),
    booking: (
      <BookingPanel heading="Reserve Your Experience" description="Follow the steps below to customize and confirm your stay at Cedar Point Lodge.">
        {renderBookingStep()}
      </BookingPanel>
    ),
    testimonials: (
      <TestimonialRail
        heading="What Our Guests Say"
        items={[
          { quote: "The most serene escape! The lakeside view from our room was breathtaking, and the guided canoe trip was unforgettable.", author: "Sarah L.", role: "Repeat Guest" },
          { quote: "Cedar Point Lodge offered the perfect blend of relaxation and adventure. Booking direct was so easy, and the staff felt like family.", author: "Michael P.", role: "First-time Visitor" },
          { quote: "From the cozy sauna to the delicious meals, every detail was perfect. We can't wait to come back next year!", author: "Emily R.", role: "Weekend Getaway Enthusiast" },
        ]}
      />
    ),
    footer: (
      <BrandFooter
        brandName="Cedar Point Lodge"
        description="Nestled on the serene shores of the Adirondacks, Cedar Point Lodge offers an intimate escape with unparalleled natural beauty and warm hospitality."
        links={[
          { label: "Our Rooms", href: "#" },
          { label: "Dining", href: "#" },
          { label: "Activities", href: "#" },
          { label: "Contact Us", href: "#" },
          { label: "Privacy Policy", href: "#" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="booking-flow">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}