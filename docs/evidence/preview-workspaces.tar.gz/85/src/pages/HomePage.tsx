// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, LogoMarquee, FeatureBento, ProcessSection, TestimonialRail, BookingPanel, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "trust", "features", "process", "testimonials", "booking", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero 
        brandName={"Cedar Point Lodge"} 
        eyebrow="Your Adirondack Escape" 
        headline="Your Adirondack Escape Awaits" 
        subcopy="Discover serene lakeside comfort, guided adventures, and culinary delights at Cedar Point Lodge." 
        primaryCta={{ label: "View Rooms & Book", href: "/rooms-stays" }} 
        secondaryCta={{ label: "Explore Activities", href: "/activities" }} 
        imageSrc="https://images.pexels.com/photos/18446070/pexels-photo-18446070.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" 
        imageAlt="Cedar Point Lodge at sunset by the lake" 
      />
    ),
    trust: (
      <LogoMarquee 
        size="display" 
        items={[
          { label: "Secure Direct Booking" },
          { label: "Adirondack Hospitality" },
          { label: "Personalized Service" },
        ]} 
      />
    ),
    features: (
      <FeatureBento 
        heading="Experience the Heart of the Adirondacks" 
        imagePool={[images.card1, images.card2, images.card3]} 
        items={[
          {
            title: "Intimate Accommodations",
            description: "Eighteen unique rooms, each designed for comfort and tranquility with stunning lake views.",
            imageSrc: images.card1,
            imageAlt: "Cozy room interior at Cedar Point Lodge"
          },
          {
            title: "Direct Booking Advantage",
            description: "Book directly with us for the best rates and personalized service, bypassing third-party fees.",
            imageSrc: images.card2,
            imageAlt: "Online booking interface"
          },
          {
            title: "Seamless Stay Planning",
            description: "Easily check availability, compare room types, and add guided canoe trips or sauna sessions to your stay.",
            imageSrc: images.card3,
            imageAlt: "Canoes on a calm lake"
          },
        ]} 
      />
    ),
    process: (
      <ProcessSection 
        heading="Planning Your Perfect Getaway" 
        steps={[
          { title: "Choose Your Dates", description: "Select your desired check-in and check-out dates on our real-time calendar." },
          { title: "Discover Your Room", description: "Browse our eighteen unique room types, complete with photos and amenities." },
          { title: "Add an Adventure", description: "Enhance your stay with guided canoe trips, a relaxing sauna session, or dining reservations." },
        ]} 
      />
    ),
    testimonials: (
      <TestimonialRail 
        heading="What Our Guests Say" 
        items={[
          {
            quote: "Booking our stay was so easy and the details about each room helped us pick the perfect one. The personalized service truly made our anniversary special!",
            author: "Sarah & Tom Davies",
            role: "Anniversary Guests"
          },
          {
            quote: "The direct booking process was seamless, and their website clearly showcased all the room types. We loved the guided canoe trip we added on!",
            author: "Michael Chen",
            role: "Adventure Seeker"
          },
        ]} 
      />
    ),
    booking: (
      // This slot is optional per skeletal contract, and not explicitly requested for home page content.
      // Retaining the scaffold default, but it would typically be used on a dedicated booking page.
      <BookingPanel heading="Choose a time" treatments={seed.treatments ?? []} slots={[{ id: "slot-1", startsAt: "2026-07-14T10:00:00" }]} />
    ),
    cta: (
      <CTABand 
        heading="Begin Your Cedar Point Lodge Experience" 
        description="Ready to trade the everyday for serene lakeside mornings and starlit Adirondack nights? Your perfect escape awaits." 
        primaryCta={{ label: "Book Your Stay Now", href: "/rooms-stays" }} 
      />
    ),
    footer: (
      <BrandFooter brandName={"Cedar Point Lodge"} description={"Cedar Point Lodge — Your intimate lakeside retreat in the Adirondacks. Experience nature, comfort, and personalized hospitality."} />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}