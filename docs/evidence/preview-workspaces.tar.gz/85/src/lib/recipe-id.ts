export const RECIPE_ID = "warm-service" as const;
