// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Contact Atelier Vaugirard"}
        description={"We welcome your inquiries about any painting, studio visits, or general questions about the collection. Reach out to us through the following options."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Email Us Directly"}
            description={"For any questions or detailed inquiries, please send us an email. We aim to respond within 24 hours."}
            ctaLabel={"Send an Email"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Atelier Vaugirard"}
        description={"Atelier Vaugirard · Preserving the art of oil painting."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="contact">
      </div>
      <PublicShell
      brandName={"Atelier Vaugirard"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
          <div id="inquiry-prioritization-assistant" data-ai-feature-panel="inquiry-prioritization-assistant">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "inquiry-prioritization-assistant") || { id: "inquiry-prioritization-assistant", name: "inquiry-prioritization-assistant" }}
          brandName={"Atelier Vaugirard"}
        />
      </div>
    </PublicShell>
    </>
  );
}
