// deterministic catalogue contract scaffold
import { useParams } from 'react-router-dom';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, Button, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, InquiryPanel, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "credentials", "inquire", "cta", "footer"] as const;

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const params = useParams();
  const catalogItems = (seed.items ?? []) as any[];
  const itemKey = String(params.id ?? params.slug ?? '').trim();
  const itemToken = (value: any) =>
    String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  const wantedToken = itemToken(itemKey);
  const itemIndex = catalogItems.findIndex(
    (entry: any, index: number) =>
      wantedToken !== '' &&
      (itemToken(entry?.id) === wantedToken ||
        itemToken(entry?.slug) === wantedToken ||
        itemToken(entry?.title) === wantedToken ||
        String(index + 1) === itemKey),
  );
  const item: any = itemIndex >= 0 ? catalogItems[itemIndex] : undefined;
  const notFound = itemKey !== '' && itemIndex < 0;
  const itemTitle = String(item?.title ?? 'This piece');
  const itemImage = String(
    item?.image ??
      [images.item1, images.item2, images.item3, images.item4,
       images.item5, images.item6, images.item7, images.item8][
        (itemIndex >= 0 ? itemIndex : 0) % 8
      ],
  );
  const itemSpecs = [
    { title: 'Reference', detail: itemKey || String(itemIndex + 1) },
    item?.medium ? { title: 'Medium', detail: String(item.medium) } : null,
    item?.dimensions ? { title: 'Dimensions', detail: String(item.dimensions) } : null,
    item?.year ? { title: 'Year', detail: String(item.year) } : null,
    item?.price ? { title: 'Price', detail: String(item.price) } : null,
    item?.status ? { title: 'Availability', detail: String(item.status) } : null,
    item?.category ? { title: 'Collection', detail: String(item.category) } : null,
  ].filter(Boolean) as { title: string; detail: string }[];
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Atelier Vaugirard"}
        eyebrow={"Original Oil Painting"}
        headline={itemTitle}
        subcopy={String(item?.description ?? "Discover the intricate details and unique brushwork of this original oil painting.")}
        variant="item"
        primaryCta={{ label: "Inquire about this piece", href: "#inquire" }}
        secondaryCta={{ label: "View the collection", href: "/gallery" }}
        imageSrc={itemImage}
        imageAlt={itemTitle}
      />
    ),
    credentials: (
      <CredentialStrip heading="Artwork Details" items={itemSpecs} />
    ),
    inquire: (
      <InquiryPanel
        heading="Inquire about this Artwork"
        description="Please provide your contact information and any specific questions you have about this piece. We will respond promptly."
        itemId={itemKey}
        itemTitle={itemTitle}
        messagePlaceholder="I am interested in purchasing this painting, or I would like to arrange a studio visit to see it."
        ctaLabel="Send Inquiry"
        confirmationHeading="Thank you for your inquiry."
        confirmationBody="We have received your message regarding this artwork and will be in touch shortly to discuss further."
      />
    ),
    cta: (
      <CTABand
        heading="Explore More Original Works"
        description="The Atelier Vaugirard collection offers a unique perspective through each brushstroke."
        primaryCta={{ label: "Browse the Collection", href: "/gallery" }}
        secondaryCta={{ label: "About the Artist", href: "/about-artist" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Atelier Vaugirard"}
        description={"Atelier Vaugirard showcases original oil paintings, connecting collectors with unique artistic visions."}
        links={[
          { label: "Gallery", href: "/gallery" },
          { label: "About", href: "/about-artist" },
          { label: "Contact", href: "/contact" },
        ]}
      />
    ),
  };

  if (notFound) {
    return (
      <PublicShell brandName={"Atelier Vaugirard"} nav={<PublicNav items={navItems} cta={navCta} />}>
        <div data-skeleton={skeleton.id} data-detail-not-found="" data-appspec-page="gallery_detail">
          <div className="mx-auto w-full max-w-3xl px-6 pt-32 pb-24 lg:pt-40">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-brand">
              Not found
            </p>
            <h1 className="mt-4 font-display text-[clamp(2rem,4vw,3rem)] leading-tight tracking-tight text-foreground">
              We could not find that one
            </h1>
            <p className="mt-4 text-base leading-7 text-muted">
              It may have sold or moved. Browse what is available now.
            </p>
            <Button href={"/gallery"} className="mt-8">Back to the collection</Button>
          </div>
        </div>
      </PublicShell>
    );
  }

  return (
    <PublicShell brandName={"Atelier Vaugirard"} chrome="solid" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="gallery_detail">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}