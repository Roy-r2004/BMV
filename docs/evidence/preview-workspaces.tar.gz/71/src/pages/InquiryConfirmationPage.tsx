// composed confirmation page (ConfirmStage)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, BrandFooter, ConfirmStage } from '@/ui';

export default function InquiryConfirmationPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();

  return (
    <>
      <div className="contents" data-appspec-page="contact-confirm">
      </div>
      <PublicShell
      brandName={"Atelier Vaugirard"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <ConfirmStage
        eyebrow={"Confirmed"}
        title={"Inquiry Received"}
        detail={"Confirmation on file"}
        description={"Thank you for contacting Atelier Vaugirard. We have received your message and will be in touch shortly regarding your interest in the artwork."}
        primaryCta={{"label": "Back to home", "href": "/"}}
        nextSteps={[{"title": "Explore the Collection", "description": "Discover more original oil paintings by the artist.", "ctaLabel": "View All Paintings", "href": "/"}, {"title": "About the Artist", "description": "Learn more about the vision and practice behind Atelier Vaugirard.", "ctaLabel": "Artist's Biography", "href": "/about"}, {"title": "Return to Painting", "description": "Go back to the artwork you were viewing.", "ctaLabel": "View Artwork", "href": "/paintings/return-to-previous"}]}
      />
      <BrandFooter
        brandName={"Atelier Vaugirard"}
        description={"Atelier Vaugirard · Fine Art Gallery"}
      />
    </PublicShell>
    </>
  );
}
