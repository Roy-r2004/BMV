// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed, aiFeatures } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, Badge, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function OwnerDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title="Gallery Operations Dashboard"
        description="Manage your collection, track inquiries, and oversee your digital salon's performance."
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          label="New Inquiries"
          value="3"
          delta="+1 last 24h"
          hint="Total inquiries since last login"
          variant="card"
          className="bg-surface shadow"
        />
        <StatCard
          label="Available Works"
          value="18"
          delta="-1 since last week"
          hint="Original oil paintings currently for sale"
          variant="card"
          className="bg-surface shadow"
        />
        <StatCard
          label="Artwork Views"
          value="2,145"
          delta="+15% this month"
          hint="Total unique views across all pieces"
          variant="card"
          className="bg-surface shadow"
        />
      </div>
    ),
    chart: (
      // The chart slot is required by the skeleton but not explicitly briefed for this page.
      // Providing a plausible default based on general dashboard needs.
      <ChartCard
        title="Inquiries Trend (Last 7 Days)"
        type="bar"
        dataKey="inquiries"
        xKey="day"
        data={[
          { day: "Mon", inquiries: 2 },
          { day: "Tue", inquiries: 1 },
          { day: "Wed", inquiries: 0 },
          { day: "Thu", inquiries: 3 },
          { day: "Fri", inquiries: 1 },
          { day: "Sat", inquiries: 2 },
          { day: "Sun", inquiries: 0 },
        ]}
        description="Daily count of new inquiries received."
      />
    ),
    filters: (
      // The filters slot is required by the skeleton but not explicitly briefed for this page.
      // Providing a plausible default.
      <FilterBar
        searchPlaceholder="Search listings or inquiries..."
        filters={[
          { id: "all", label: "All", active: true },
          { id: "available", label: "Available", active: false },
          { id: "sold", label: "Sold", active: false },
          { id: "pending", label: "Pending Inquiry", active: false },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          {
            key: "painting",
            header: "Painting",
            render: ({ painting, imageUrl }) => (
              <div className="flex items-center space-x-3">
                {imageUrl && <img src={imageUrl} alt={painting} className="w-10 h-10 object-cover rounded" />}
                <span>{painting}</span>
              </div>
            ),
          },
          {
            key: "status",
            header: "Status",
            render: ({ status }) => (
              <Badge variant={status === "Available" ? "default" : status === "Sold" ? "destructive" : "secondary"}>
                {status}
              </Badge>
            ),
          },
          { key: "lastUpdated", header: "Last Updated" },
        ]}
        rows={[
          { id: "p1", painting: "Radiant Dawn", status: "Available", lastUpdated: "2 hours ago", imageUrl: "https://d23sdqop38g373.cloudfront.net/v5/gallery-images/radiant-dawn-small.jpg" },
          { id: "p2", painting: "Coastal Serenity", status: "Sold", lastUpdated: "Yesterday", imageUrl: "https://d23sdqop38g373.cloudfront.net/v5/gallery-images/coastal-serenity-small.jpg" },
          { id: "p3", painting: "Urban Canvas", status: "Available", lastUpdated: "3 days ago", imageUrl: "https://d23sdqop38g373.cloudfront.net/v5/gallery-images/urban-canvas-small.jpg" },
          { id: "p4", painting: "Forest Whispers", status: "Available", lastUpdated: "1 week ago", imageUrl: "https://d23sdqop38g373.cloudfront.net/v5/gallery-images/forest-whispers-small.jpg" },
        ]}
        emptyMessage="No recent listings or updates."
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "a1", title: "New inquiry for 'Radiant Dawn'", time: "Just now", icon: "Mail" },
          { id: "a2", title: "Artwork 'Coastal Serenity' marked as 'Sold'", time: "2 hours ago", icon: "Tag" },
          { id: "a3", title: "Image for 'Urban Canvas' optimized by AI", time: "5 hours ago", icon: "Sparkles" },
          { id: "a4", title: "Login from owner", time: "Yesterday", icon: "User" },
          { id: "a5", title: "Updated availability for 'Forest Whispers'", time: "2 days ago", icon: "RefreshCw" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Atelier Vaugirard"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="owner-dashboard">
        {main}
      </div>
          <div id="intelligent-image-cropping" data-ai-feature-panel="intelligent-image-cropping">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "intelligent-image-cropping") || { id: "intelligent-image-cropping", name: "intelligent-image-cropping" }}
          brandName={"Atelier Vaugirard"}
        />
      </div>
    </OpsShell>
  );
}