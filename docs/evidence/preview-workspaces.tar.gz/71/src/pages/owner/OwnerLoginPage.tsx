// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, Input, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

const SKELETON_ID = "public-utility" as const;

export default function OwnerLoginPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Owner Login · Atelier Vaugirard"}
        description={"Securely access your Digital Salon administrative tools."}
      />
    ),
    workspace: (
      <Card className="mx-auto w-full max-w-md space-y-4 p-6">
          <Input
            label={"Email"}
            type={"email"}
            placeholder={"you@example.com"}
          />
          <Input
            label={"Password"}
            type={"password"}
            placeholder={"••••••••"}
          />
          <Button className="w-full">{"Go to Inventory"}</Button>
          <p className="text-center text-sm text-muted">
            {"Add new paintings, update details, and track availability."}
          </p>
        </Card>
    ),
    footer: (
      <BrandFooter
        brandName={"Atelier Vaugirard"}
        description={"Atelier Vaugirard Digital Salon © 2024"}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="owner-login">
      </div>
      <PublicShell
      brandName={"Atelier Vaugirard"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"auth"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
          <div id="automated-artwork-description-generation" data-ai-feature-panel="automated-artwork-description-generation">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "automated-artwork-description-generation") || { id: "automated-artwork-description-generation", name: "automated-artwork-description-generation" }}
          brandName={"Atelier Vaugirard"}
        />
      </div>
    </PublicShell>
    </>
  );
}
