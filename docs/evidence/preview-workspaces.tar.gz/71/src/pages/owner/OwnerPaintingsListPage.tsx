// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Select, UiIcon } from '@/ui';
import React, { useState } from 'react';
import type { ChangeEvent } from 'react';

const SKELETON_ID = "ops-list" as const;

// Realistic painting data
const initialPaintings = [
  {
    id: 'p1',
    image: 'https://images.pexels.com/photos/4442076/pexels-photo-4442076.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    title: 'Floral Study in Blue',
    artist: 'A. Vaugirard',
    status: 'Available',
    price: '€4,500',
    year: '2023',
    dimensions: '30x40cm',
    medium: 'Oil on canvas'
  },
  {
    id: 'p2',
    image: 'https://images.pexels.com/photos/16397788/pexels-photo-16397788.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    title: 'Rue de Rivoli Café',
    artist: 'A. Vaugirard',
    status: 'Sold',
    price: '€6,200',
    year: '2022',
    dimensions: '50x70cm',
    medium: 'Oil on linen'
  },
  {
    id: 'p3',
    image: 'https://images.pexels.com/photos/6607754/pexels-photo-6607754.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    title: 'Still Life with Quince',
    artist: 'A. Vaugirard',
    status: 'On Hold',
    price: '€3,800',
    year: '2024',
    dimensions: '20x30cm',
    medium: 'Oil on panel'
  },
  {
    id: 'p4',
    image: 'https://images.pexels.com/photos/12359537/pexels-photo-12359537.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    title: 'Abstract Horizon',
    artist: 'A. Vaugirard',
    status: 'Available',
    price: '€5,900',
    year: '2023',
    dimensions: '60x60cm',
    medium: 'Oil on canvas'
  },
  {
    id: 'p5',
    image: 'https://images.pexels.com/photos/4588831/pexels-photo-4588831.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    title: 'Portrait of Élise',
    artist: 'A. Vaugirard',
    status: 'Available',
    price: '€7,100',
    year: '2024',
    dimensions: '40x50cm',
    medium: 'Oil on linen'
  }
];

export default function OwnerPaintingsListPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const filteredPaintings = initialPaintings.filter(painting => {
    const matchesSearch = painting.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          painting.artist.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'All' || painting.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const slots = {
    header: (
      <PageHeader
        title="Manage Paintings"
        actions={[
          { label: "Add New Painting", href: "/owner/paintings/add", variant: "default" }
        ]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search paintings..."
        searchValue={searchQuery}
        onSearchChange={(e: ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
        filters={[
          {
            id: 'status-filter',
            label: (
              <Select
                options={[
                  { label: 'All Statuses', value: 'All' },
                  { label: 'Available', value: 'Available' },
                  { label: 'Sold', value: 'Sold' },
                  { label: 'On Hold', value: 'On Hold' },
                ]}
                value={statusFilter}
                onValueChange={setStatusFilter}
                placeholder="Filter by Status"
                aria-label="Filter by Status"
              />
            ),
            active: true
          },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          {
            key: 'image',
            header: 'Image Thumbnail',
            render: (row: typeof initialPaintings[0]) => (
              <img src={row.image} alt={row.title} className="w-16 h-16 object-cover rounded-sm" />
            ),
          },
          { key: 'title', header: 'Title' },
          { key: 'artist', header: 'Artist' },
          { key: 'status', header: 'Status' },
          { key: 'price', header: 'Price' },
          {
            key: 'actions',
            header: 'Actions',
            render: (row: typeof initialPaintings[0]) => (
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" href={`/owner/paintings/${row.id}/edit`} aria-label={`Edit ${row.title}`}>
                  <UiIcon name="Pencil" className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" aria-label={`Delete ${row.title}`}>
                  <UiIcon name="Trash" className="h-4 w-4 text-red-500" />
                </Button>
              </div>
            ),
          },
        ]}
        rows={filteredPaintings}
        emptyMessage="No paintings found matching your criteria."
      />
    ),
  };

  return (
    <OpsShell brandName={"Atelier Vaugirard"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="owner-paintings-list">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}