// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function OwnerInquiriesPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"All Inquiries"}
        description={"Review and manage incoming messages from collectors regarding paintings and studio visits."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"New Purchase Inquiries"}
            description={"View messages from collectors interested in acquiring a painting."}
            ctaLabel={"Review New"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Atelier Vaugirard"}
        description={"Atelier Vaugirard · All rights reserved."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="owner-inquiries">
      </div>
      <PublicShell
      brandName={"Atelier Vaugirard"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
