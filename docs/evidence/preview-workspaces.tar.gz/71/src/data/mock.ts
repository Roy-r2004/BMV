export const brand = {"name": "Atelier Vaugirard", "tagline": "", "design_system": {"primary_color": "#0f172a", "secondary_color": "#0369a1", "background_color": "#f8fafc", "surface_color": "#ffffff", "text_color": "#1c1917", "muted_text_color": "#78716c", "font_family": "Source Sans 3", "display_font_family": "Fraunces", "font_import_url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap", "font_sans": "\"Source Sans 3\", \"Segoe UI\", sans-serif", "font_display": "\"Fraunces\", Georgia, serif", "brand_locked": true, "brand_brief_version": "1.0", "mood": "modern", "voice": "Confident and sparse. Let materials and type carry the tone.", "signature": "Editorial asymmetry and display type that could only belong to Atelier Vaugirard.", "avoid": ["purple-on-white or purple-to-indigo default themes", "Inter / Roboto / Arial as the display face", "card grids in the hero", "generic SaaS marketing copy", "inventing a second palette per page"], "rules": ["Every page inherits this palette and type stack via CSS tokens only.", "Use bg-brand / text-brand / font-display — never hardcode hex colors.", "First viewport must feature the brand name as a hero-level signal."], "recipe_id": "editorial", "hub_variant": "marketing", "hero_variant": "editorial", "feature_variant": "alternating", "recipe_prompt": "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.", "style_keywords": "Editorial · Warm paper", "border_radius": "0.91rem", "design_overlay_id": "warm_paper", "design_overlay_label": "Warm paper", "design_overlay_blurb": "Service warmth — paper surfaces, friendly radius, soft glow.", "density": "comfortable", "token_overrides": {"radius_ui": "0.91rem", "bg_mix": "5%", "fg_mix": "40%", "muted_mix": "30%", "border_mix": "14%", "shadow": "0 26px 52px -38px", "shadow_alpha": "30%", "glow": "6%", "card": "#fffdf9", "atmosphere": "radial-gradient(85% 50% at 100% 0%, color-mix(in srgb, var(--color-accent) 12%, transparent), transparent 55%), linear-gradient(165deg, #fffaf4 0%, color-mix(in srgb, var(--color-brand) 5%, #f7f1ea) 50%, #faf7f2 100%)"}, "font_import": "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700", "design_brief_version": "1.0", "design_brief_sealed": true},
  services: [{"name": "Atelier Vaugirard Signature", "title": "Atelier Vaugirard Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Atelier Vaugirard experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Atelier Vaugirard experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Atelier", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Atelier Vaugirard clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/12359537/pexels-photo-12359537.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/4442076/pexels-photo-4442076.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/16397788/pexels-photo-16397788.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/4588831/pexels-photo-4588831.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/6607754/pexels-photo-6607754.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/1530709/pexels-photo-1530709.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item1": "https://images.pexels.com/photos/16397728/pexels-photo-16397728.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item2": "https://images.pexels.com/photos/3684544/pexels-photo-3684544.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item3": "https://images.pexels.com/photos/1475951/pexels-photo-1475951.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item4": "https://images.pexels.com/photos/15377378/pexels-photo-15377378.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item5": "https://images.pexels.com/photos/16397723/pexels-photo-16397723.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item6": "https://images.pexels.com/photos/1023767/pexels-photo-1023767.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item7": "https://images.pexels.com/photos/1414327/pexels-photo-1414327.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item8": "https://images.pexels.com/photos/16397773/pexels-photo-16397773.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const roles = [
  {
    "id": "customer",
    "label": "Collector & Visitor",
    "defaultPath": "/gallery",
    "icon": "users"
  },
  {
    "id": "owner",
    "label": "Gallery Owner",
    "defaultPath": "/owner/dashboard",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "about-artist",
      "path": "/about-artist",
      "href": "/about-artist",
      "label": "About Artist"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-login",
      "path": "/owner/login",
      "href": "/owner/login",
      "label": "Login"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-paintings",
      "path": "/owner/paintings",
      "href": "/owner/paintings",
      "label": "Paintings"
    },
    {
      "id": "owner-paintings-add",
      "path": "/owner/paintings/add",
      "href": "/owner/paintings/add",
      "label": "Add"
    },
    {
      "id": "owner-inquiries",
      "path": "/owner/inquiries",
      "href": "/owner/inquiries",
      "label": "Inquiries"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "about-artist",
      "path": "/about-artist",
      "href": "/about-artist",
      "label": "About Artist"
    },
    {
      "id": "inquiry-confirm",
      "path": "/inquiry-confirm",
      "href": "/inquiry-confirm",
      "label": "Inquiry Confirm"
    }
  ],
  "owner": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-login",
      "path": "/owner/login",
      "href": "/owner/login",
      "label": "Login"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-paintings",
      "path": "/owner/paintings",
      "href": "/owner/paintings",
      "label": "Paintings"
    },
    {
      "id": "owner-paintings-add",
      "path": "/owner/paintings/add",
      "href": "/owner/paintings/add",
      "label": "Add"
    },
    {
      "id": "owner-inquiries",
      "path": "/owner/inquiries",
      "href": "/owner/inquiries",
      "label": "Inquiries"
    }
  ]
};

export const seed = {
  "tone": "editorial-gallery",
  "hero": {
    "eyebrow": "Atelier Vaugirard",
    "headline": "Discover the Original Works of Art by [Artist Name]",
    "subcopy": "Explore a curated collection of original oil paintings, each a unique expression of the artist's vision and craft.",
    "primaryCta": {
      "label": "View Collection",
      "href": "/gallery"
    },
    "secondaryCta": {
      "label": "About the Artist",
      "href": "/about"
    }
  },
  "items": [
    {
      "title": "Interactive Gallery Showcase",
      "description": "Browse our full collection of available original oil paintings with ease."
    },
    {
      "title": "Detailed Artwork View",
      "description": "Experience each piece up close with high-resolution images and comprehensive specifications."
    },
    {
      "title": "Live Inquiry Form",
      "description": "Seamlessly express interest in a painting or arrange a studio visit."
    }
  ],
  "features": [
    {
      "title": "Unrivaled Presentation",
      "description": "Each painting is meticulously presented with high-resolution imagery to convey its true essence online."
    },
    {
      "title": "Comprehensive Details",
      "description": "Access full specifications including medium, dimensions, year, and price for every artwork."
    },
    {
      "title": "Direct Connection",
      "description": "Easily contact the gallery for purchase inquiries or to schedule a private viewing."
    }
  ],
  "process": [
    {
      "title": "Explore the Gallery",
      "description": "Begin your journey by browsing our curated collection of original oil paintings."
    },
    {
      "title": "Discover Your Piece",
      "description": "Click on any artwork to delve into its full details, from dimensions to artist's notes."
    },
    {
      "title": "Initiate Inquiry",
      "description": "Use the dedicated form to express your interest in a piece or arrange a studio visit."
    },
    {
      "title": "Personalized Response",
      "description": "Receive a direct, timely response from the gallery owner to facilitate your acquisition."
    }
  ],
  "credentials": [
    {
      "title": "Original Oil Paintings",
      "detail": "Every piece is a unique, hand-painted original."
    },
    {
      "title": "Expertly Curated",
      "detail": "A refined selection showcasing significant works by the artist."
    }
  ],
  "testimonials": [
    {
      "quote": "The Atelier Vaugirard Digital Salon is a beautifully curated space. The detail views are exceptional, making online acquisition a joy.",
      "author": "Eleanor Vance",
      "role": "Collector"
    }
  ],
  "treatments": [
    {
      "id": "offer-1",
      "name": "Interactive Gallery Showcase",
      "duration": "60 min"
    },
    {
      "id": "offer-2",
      "name": "Detailed Artwork View",
      "duration": "60 min"
    },
    {
      "id": "offer-3",
      "name": "Live Inquiry Form",
      "duration": "60 min"
    }
  ],
  "showcaseHeading": "Available works",
  "featuresHeading": "How the work is made",
  "processHeading": "From the wall to your wall",
  "credentialsHeading": "Studio record",
  "testimonialsHeading": "Collector notes",
  "cta": {
    "heading": "Found a piece that stays with you?",
    "description": "Ask about price, framing, and delivery — or arrange a studio visit.",
    "primaryLabel": "Inquire about a piece",
    "primaryHref": "/contact",
    "secondaryLabel": "See the collection",
    "secondaryHref": "/gallery"
  },
  "footer": {
    "description": "A working painter's gallery of original oils — abstract landscapes and layered studies."
  },
  "trustLabels": [
    "Secure Inquiries",
    "Private Viewings Available",
    "Direct Artist Representation"
  ],
  "kpis": [
    {
      "label": "New Inquiries",
      "value": "3",
      "delta": "+1",
      "hint": "Last 24 hours"
    },
    {
      "label": "Available Works",
      "value": "18",
      "delta": "-1",
      "hint": "Since last week"
    },
    {
      "label": "Artwork Views",
      "value": "2,145",
      "delta": "+15%",
      "hint": "This month"
    }
  ],
  "activity": [
    {
      "id": "activity-1",
      "title": "New inquiry for 'Radiant Dawn'",
      "detail": "Sophie Dubois expressed interest.",
      "time": "Just now"
    },
    {
      "id": "activity-2",
      "title": "Artwork 'Coastal Serenity' marked as 'Sold'",
      "detail": "Updated by owner.",
      "time": "15 minutes ago"
    },
    {
      "id": "activity-3",
      "title": "Image for 'Urban Canvas' optimized by AI",
      "detail": "Aspect ratio adjusted for gallery display.",
      "time": "1 hour ago"
    },
    {
      "id": "activity-4",
      "title": "Login from owner",
      "detail": "IP: 192.168.1.1",
      "time": "2 hours ago"
    }
  ],
  "risk": [
    {
      "id": "risk-1",
      "title": "Unresponded Inquiry (48h+)",
      "detail": "Inquiry for 'Crimson Skies' is past response window.",
      "severity": "high"
    }
  ],
  "tableRows": [
    {
      "id": "row-1",
      "name": "Interactive Gallery Showcase",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-2",
      "name": "Detailed Artwork View",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-3",
      "name": "Live Inquiry Form",
      "status": "Open",
      "owner": "Team"
    }
  ]
,
  images: { card1: "Card1 — Atelier Vaugirard" },
  opsHero: { headline: "Discover Atelier Vaugirard", subcopy: "See what Atelier Vaugirard offers, and get in touch about anything you like." },
  services: "Services — Atelier Vaugirard",
};

export const aiFeatures = [
  {
    "id": "intelligent-image-cropping",
    "name": "Intelligent Image Cropping",
    "description": "Automatically suggests optimal crops for uploaded artwork images to fit various display ratios within the gallery, maintaining artistic integrity.",
    "category": "ops",
    "surface": "ops",
    "demo_hint": "Route ops work the way Atelier Vaugirard runs",
    "demo_prompts": [
      "Triage new requests about or arrange",
      "Assign an owner for this studio visit issue",
      "What should the Atelier Vaugirard team do next?"
    ],
    "placement_label": "Ops AI",
    "demo_results": {
      "Triage new requests about or arrange": "Routed “Triage new requests about or arrange” → queue + owner + checklist for or arrange. Status: In progress.",
      "Assign an owner for this studio visit issue": "Assigned “Assign an owner for this studio visit issue” to the best available owner with a studio visit checklist and due time today.",
      "What should the Atelier Vaugirard team do next?": "Next for Atelier Vaugirard: clear the or arrange backlog, confirm studio visit, then review tonight's handoff."
    },
    "placement_path": "/owner/dashboard",
    "placement_component": "src/pages/owner/OwnerDashboardPage.tsx",
    "placement_title": "Owner Dashboard · Atelier Vaugirard"
  },
  {
    "id": "automated-artwork-description-generation",
    "name": "Automated Artwork Description Generation",
    "description": "Generates a concise, evocative descriptive blurb for each painting based on its title, medium, and year, which the owner can then refine.",
    "category": "automation",
    "surface": "automation",
    "demo_hint": "Trigger the automation Atelier Vaugirard actually needs",
    "demo_prompts": [
      "Notify the next person waiting for and year",
      "Chase what's missing for or arrange",
      "Run tonight's follow-ups for Atelier Vaugirard"
    ],
    "placement_label": "Automation",
    "demo_results": {
      "Notify the next person waiting for and year": "Automation for “Notify the next person waiting for and year”: message drafted, spot held for 30 minutes, next guest in line ready if they decline.",
      "Chase what's missing for or arrange": "Chase sequence for “Chase what's missing for or arrange”: reminder #1 sent about or arrange, escalates tomorrow if still open.",
      "Run tonight's follow-ups for Atelier Vaugirard": "Tonight's follow-ups for Atelier Vaugirard are queued — review → approve → run. Covers and year and or arrange."
    },
    "placement_path": "/owner/login",
    "placement_component": "src/pages/owner/OwnerLoginPage.tsx",
    "placement_title": "Owner Login · Atelier Vaugirard"
  },
  {
    "id": "inquiry-prioritization-assistant",
    "name": "Inquiry Prioritization Assistant",
    "description": "Flags inquiries that contain specific keywords indicating high purchase intent (e.g., \"immediate purchase,\" \"arrange viewing ASAP\") to help the owner prioritize.",
    "category": "chat",
    "surface": "chat",
    "demo_hint": "Ask the way a real guest would ask Atelier Vaugirard",
    "demo_prompts": [
      "What should I know about or arrange?",
      "How does studio visit work at Atelier Vaugirard?",
      "Can beginners join a Project Type this week?"
    ],
    "placement_label": "Customer assistant",
    "demo_results": {
      "What should I know about or arrange?": "Atelier Vaugirard: For “What should I know about or arrange?” — Flags inquiries that contain specific keywords indicating high purchase intent (e.g., \"immediate purchase,\" \"arrange viewing ASAP\") to help the owner prioritize Here’s the short answer, what to prepare, and when a human should join.",
      "How does studio visit work at Atelier Vaugirard?": "Atelier Vaugirard: “How does studio visit work at Atelier Vaugirard?” — we walk guests through studio visit step by step, including timing, cost cues, and the next action to take.",
      "Can beginners join a Project Type this week?": "Atelier Vaugirard: Yes — for “Can beginners join a Project Type this week?”, the assistant qualifies the request, shares what Project Type involves, and offers the best next booking path."
    },
    "placement_path": "/contact",
    "placement_component": "src/pages/ContactPage.tsx",
    "placement_title": "Contact Atelier Vaugirard"
  }
] as const;
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;

// build-correctness guard: auto-added missing exports
export const services = [{"id": "services-1", "name": "services 1", "title": "services 1", "label": "services 1", "status": "In progress", "detail": "Sample Atelier Vaugirard record for demo lists", "message": "services update 1", "amount": 52, "count": 4, "date": "2026-08-01", "time": "10:00", "startDate": "2026-08-01", "endDate": "2026-08-01", "dropOffDate": "2026-08-01", "dropOffTime": "10:00", "pickupDate": "2026-08-03", "scheduledAt": "2026-08-01T10:00:00", "createdAt": "2026-08-01T10:00:00", "timestamp": "2026-08-01T10:00:00", "instructor": "Maya R.", "memberName": "Member 1", "loadType": "Bisque", "registered": 5, "capacity": 12, "isFull": false}, {"id": "services-2", "name": "services 2", "title": "services 2", "label": "services 2", "status": "Done", "detail": "Sample Atelier Vaugirard record for demo lists", "message": "services update 2", "amount": 64, "count": 5, "date": "2026-08-02", "time": "11:30", "startDate": "2026-08-02", "endDate": "2026-08-02", "dropOffDate": "2026-08-02", "dropOffTime": "11:30", "pickupDate": "2026-08-04", "scheduledAt": "2026-08-02T11:30:00", "createdAt": "2026-08-02T11:30:00", "timestamp": "2026-08-02T11:30:00", "instructor": "Jordan K.", "memberName": "Member 2", "loadType": "Glaze", "registered": 6, "capacity": 12, "isFull": false}, {"id": "services-3", "name": "services 3", "title": "services 3", "label": "services 3", "status": "Scheduled", "detail": "Sample Atelier Vaugirard record for demo lists", "message": "services update 3", "amount": 76, "count": 6, "date": "2026-08-03", "time": "12:00", "startDate": "2026-08-03", "endDate": "2026-08-03", "dropOffDate": "2026-08-03", "dropOffTime": "12:00", "pickupDate": "2026-08-05", "scheduledAt": "2026-08-03T12:00:00", "createdAt": "2026-08-03T12:00:00", "timestamp": "2026-08-03T12:00:00", "instructor": "Sam T.", "memberName": "Member 3", "loadType": "Cone 6", "registered": 7, "capacity": 12, "isFull": false}, {"id": "services-4", "name": "services 4", "title": "services 4", "label": "services 4", "status": "Open", "detail": "Sample Atelier Vaugirard record for demo lists", "message": "services update 4", "amount": 88, "count": 7, "date": "2026-08-04", "time": "13:30", "startDate": "2026-08-04", "endDate": "2026-08-04", "dropOffDate": "2026-08-04", "dropOffTime": "13:30", "pickupDate": "2026-08-06", "scheduledAt": "2026-08-04T13:30:00", "createdAt": "2026-08-04T13:30:00", "timestamp": "2026-08-04T13:30:00", "instructor": "Noa B.", "memberName": "Member 4", "loadType": "Raku", "registered": 8, "capacity": 12, "isFull": false}];
export const stats = [{"id": "stats-1", "name": "stats 1", "title": "stats 1", "label": "stats 1", "status": "In progress", "detail": "Sample Atelier Vaugirard record for demo lists", "message": "stats update 1", "amount": 52, "count": 4, "date": "2026-08-01", "time": "10:00", "startDate": "2026-08-01", "endDate": "2026-08-01", "dropOffDate": "2026-08-01", "dropOffTime": "10:00", "pickupDate": "2026-08-03", "scheduledAt": "2026-08-01T10:00:00", "createdAt": "2026-08-01T10:00:00", "timestamp": "2026-08-01T10:00:00", "instructor": "Maya R.", "memberName": "Member 1", "loadType": "Bisque", "registered": 5, "capacity": 12, "isFull": false}, {"id": "stats-2", "name": "stats 2", "title": "stats 2", "label": "stats 2", "status": "Done", "detail": "Sample Atelier Vaugirard record for demo lists", "message": "stats update 2", "amount": 64, "count": 5, "date": "2026-08-02", "time": "11:30", "startDate": "2026-08-02", "endDate": "2026-08-02", "dropOffDate": "2026-08-02", "dropOffTime": "11:30", "pickupDate": "2026-08-04", "scheduledAt": "2026-08-02T11:30:00", "createdAt": "2026-08-02T11:30:00", "timestamp": "2026-08-02T11:30:00", "instructor": "Jordan K.", "memberName": "Member 2", "loadType": "Glaze", "registered": 6, "capacity": 12, "isFull": false}, {"id": "stats-3", "name": "stats 3", "title": "stats 3", "label": "stats 3", "status": "Scheduled", "detail": "Sample Atelier Vaugirard record for demo lists", "message": "stats update 3", "amount": 76, "count": 6, "date": "2026-08-03", "time": "12:00", "startDate": "2026-08-03", "endDate": "2026-08-03", "dropOffDate": "2026-08-03", "dropOffTime": "12:00", "pickupDate": "2026-08-05", "scheduledAt": "2026-08-03T12:00:00", "createdAt": "2026-08-03T12:00:00", "timestamp": "2026-08-03T12:00:00", "instructor": "Sam T.", "memberName": "Member 3", "loadType": "Cone 6", "registered": 7, "capacity": 12, "isFull": false}, {"id": "stats-4", "name": "stats 4", "title": "stats 4", "label": "stats 4", "status": "Open", "detail": "Sample Atelier Vaugirard record for demo lists", "message": "stats update 4", "amount": 88, "count": 7, "date": "2026-08-04", "time": "13:30", "startDate": "2026-08-04", "endDate": "2026-08-04", "dropOffDate": "2026-08-04", "dropOffTime": "13:30", "pickupDate": "2026-08-06", "scheduledAt": "2026-08-04T13:30:00", "createdAt": "2026-08-04T13:30:00", "timestamp": "2026-08-04T13:30:00", "instructor": "Noa B.", "memberName": "Member 4", "loadType": "Raku", "registered": 8, "capacity": 12, "isFull": false}];
