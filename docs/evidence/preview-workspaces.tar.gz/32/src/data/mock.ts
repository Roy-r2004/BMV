// src/data/mock.ts
// Jeanne Kassab Art — Canvas Gallery (static preview)
// Exports: BRAND_MANIFEST, brand, images, navigation, roles, seed

export const brand = {
  name: "Jeanne Kassab Art",
  tagline: "Original oil paintings — abstract landscapes and layered oils",
  design_system: {
    primary_color: "#0f766e",
    secondary_color: "#0369a1",
    background_color: "#f8fafc",
    surface_color: "#ffffff",
    text_color: "#042f2e",
    muted_text_color: "#5f7a78",
    font_family: "Source Sans 3",
    display_font_family: "Fraunces",
    font_import_url:
      "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    font_sans: '"Source Sans 3", "Segoe UI", sans-serif',
    font_display: '"Fraunces", Georgia, serif',
    brand_locked: true,
    brand_brief_version: "1.0",
    mood: "modern",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature:
      "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.",
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    recipe_id: "editorial",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    recipe_prompt:
      "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    style_keywords: "Editorial · Calm air",
    border_radius: "0.89rem",
    design_overlay_id: "calm_air",
    design_overlay_label: "Calm air",
    design_overlay_blurb: "Airy clinical calm — soft surfaces, quiet type, low density.",
    density: "airy",
    token_overrides: {
      radius_ui: "0.89rem",
      bg_mix: "3%",
      fg_mix: "38%",
      muted_mix: "28%",
      border_mix: "12%",
      shadow: "0 28px 56px -40px",
      shadow_alpha: "22%",
      glow: "4%",
      card: "#ffffff",
      atmosphere:
        "radial-gradient(90% 55% at 8% -5%, color-mix(in srgb, var(--color-brand) 9%, transparent), transparent 58%), linear-gradient(180deg, #fbfcfd 0%, color-mix(in srgb, var(--color-brand) 3%, #f5f7f9) 55%, #f8fafb 100%)",
    },
    font_import:
      "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700",
    design_brief_version: "1.0",
    design_brief_sealed: true,
  },

  services: [{"name": "Jeanne Kassab Art Signature", "title": "Jeanne Kassab Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jeanne Kassab Art clients.",
} as const;

export const BRAND_MANIFEST = brand;

export const images = {
  hero:
    "https://images.pexels.com/photos/6812572/pexels-photo-6812572.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  hero2:
    "https://images.pexels.com/photos/7788509/pexels-photo-7788509.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  card1:
    "https://images.pexels.com/photos/6812478/pexels-photo-6812478.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  card2:
    "https://images.pexels.com/photos/19976571/pexels-photo-19976571.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  card3:
    "https://images.pexels.com/photos/12917343/pexels-photo-12917343.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  ambient:
    "https://images.pexels.com/photos/12917343/pexels-photo-12917343.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
} as const;

export const roles = [
  { id: "visitor", defaultPath: "/" },
  { id: "artist", defaultPath: "/admin/dashboard" },
];

export const seed = {
  credentialsHeading: "Trusted by Collectors",
  credentials: ["Original Fine Art", "Direct from Artist", "Secure Inquiry"],
  showcaseHeading: "Featured Paintings",
  items: [
    { id: "sunset-horizons", title: "Sunset Horizons", description: "Oil & Cold Wax on Linen", slug: "sunset-horizons" },
    { id: "layered-sky", title: "Layered Sky", description: "Oil on Canvas", slug: "layered-sky" },
    { id: "deep-forest", title: "Deep Forest Depths", description: "Oil on Wood Panel", slug: "deep-forest" },
    { id: "whispering-winds", title: "Whispering Winds", description: "Oil on Canvas", slug: "whispering-winds" },
    { id: "coastal-layers", title: "Coastal Layers", description: "Oil on Wood Panel", slug: "coastal-layers" },
    { id: "golden-hour", title: "Golden Hour Study", description: "Oil on Board", slug: "golden-hour" },
  ],
  testimonialsHeading: "Guests of Jeanne Kassab",
  testimonials: brand.testimonials,
  cta: {
    heading: "Ready for Jeanne Kassab Art?",
    description: "Browse the collection — clear options, real next steps.",
    primaryLabel: "View Collection",
    primaryHref: "/gallery",
    secondaryLabel: "Contact",
    secondaryHref: "/contact",
  },
  footer: {
    description: "Original oil paintings by Jeanne Kassab. Abstract landscapes and layered oils, available for inquiry.",
  },
  opsHero: {
    headline: "Canvas Gallery Admin",
    subcopy: "Manage artworks, track inquiries, and keep your gallery fresh.",
  },
  kpis: [
    { label: "Artworks", value: "12", delta: "+2", hint: "Added this month" },
    { label: "Inquiries", value: "8", delta: "+3", hint: "Pending" },
    { label: "Active Listings", value: "10", delta: "", hint: "Live on site" },
    { label: "Views", value: "1.2k", delta: "+18%", hint: "This week" },
  ],
  tableRows: [
    { id: "a1", name: "Sunset Horizons", status: "Available", owner: "Jeanne" },
    { id: "a2", name: "Layered Sky", status: "Inquiry", owner: "Jeanne" },
    { id: "a3", name: "Deep Forest Depths", status: "Sold", owner: "Jeanne" },
  ],
  activity: [
    { id: "act1", title: "New inquiry for Sunrise Horizons", detail: "Client via WhatsApp", time: "10m ago" },
    { id: "act2", title: "Artwork updated", detail: "Layered Sky – new image uploaded", time: "1h ago" },
    { id: "act3", title: "Inventory sync", detail: "Gallery refreshed automatically", time: "3h ago" },
  ],
  artworks: [
    {
      id: "a1",
      title: "Sunset Horizons",
      description: "Warm gradients reminiscent of dusk over the Mediterranean.",
      medium: "oil-on-canvas",
      dimensions: { width: 120, height: 90, unit: "cm" },
      year: 2024,
      imageUrl: images.card1,
      altText: "Sunset Horizons oil painting",
      availability: "available",
    },
    {
      id: "a2",
      title: "Layered Sky",
      description: "Layered hues shift from dawn to noon in abstract form.",
      medium: "oil-on-canvas",
      dimensions: { width: 100, height: 80, unit: "cm" },
      year: 2023,
      imageUrl: images.card2,
      altText: "Layered Sky oil painting",
      availability: "inquiry-pending",
    },
    {
      id: "a3",
      title: "Deep Forest Depths",
      description: "Texture and shadow evoke the density of an ancient woodland.",
      medium: "oil-on-wood-panel",
      dimensions: { width: 90, height: 120, unit: "cm" },
      year: 2024,
      imageUrl: images.card3,
      altText: "Deep Forest Depths oil painting",
      availability: "available",
    },
  ],
} as const;