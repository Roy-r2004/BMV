import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images } from '@/data/mock';
import {
  PublicShell,
  getSkeleton,
  SkeletonComposer,
  PublicNav,
  MarketingHero,
  ProductShowcase,
  FeatureBento,
  CTABand,
  BrandFooter,
  Badge,
  Button,
  UiIcon,
  CredentialStrip,
  TestimonialRail,
} from '@/ui';

const SKELETON_ID = 'public-detail' as const;
const RECIPE_ORDER = ["hero", "credentials", "showcase", "testimonials", "cta", "footer"] as const;

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const slots = {
    hero: (
      <MarketingHero
        brandName="Jeanne Kassab Art"
        headline="Elysian Fields"
        subcopy="A serene meditation on light breaking through morning mist. Layers of translucent oils capture the quiet tension between permanence and ephemerality."
        primaryCta={{ label: "Inquire", href: "/contact" }}
        secondaryCta={{ label: "Back to Gallery", href: "/gallery" }}
        imageSrc={images.hero2}
        imageAlt="Elysian Fields oil painting by Jeanne Kassab"
        eyebrow="Original Oil Painting · 2024"
        variant="editorial"
      />
    ),
    showcase: (
      <ProductShowcase
        heading="The Artwork"
        description="Explore the details of Elysian Fields, from the sweeping color transitions to the delicate textured brushstrokes."
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="flex flex-col gap-2">
            <img src={images.hero} alt="Detail view of the painting, highlighting layered brushstrokes" className="w-full h-auto rounded-lg" />
            <span className="text-sm text-muted-foreground">Detail view</span>
          </div>
          <div className="flex flex-col gap-2">
            <img src={images.card1} alt="Alternate angle of the artwork in natural light" className="w-full h-auto rounded-lg" />
            <span className="text-sm text-muted-foreground">Natural light</span>
          </div>
          <div className="flex flex-col gap-2">
            <img src={images.card2} alt="Close‑up of texture and subtle color transitions" className="w-full h-auto rounded-lg" />
            <span className="text-sm text-muted-foreground">Texture close-up</span>
          </div>
        </div>
      </ProductShowcase>
    ),
    credentials: (
      <CredentialStrip
        heading="Authenticity & Provenance"
        items={[
          { title: 'Certificate of Authenticity', description: 'Signed and dated by the artist, included with purchase.' },
          { title: 'Direct Provenance', description: 'Acquired directly from the artist’s studio in 2024.' },
          { title: 'Archival Materials', description: 'Oil on stretched canvas, prepared for conservation.' },
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading="Collector Voices"
        items={[
          { quote: "Jeanne's work transformed our living space. The layers of oil paint bring such depth and serenity.", author: "Elena R." },
          { quote: "A truly stunning piece. The attention to detail and emotion in the brushstrokes is unparalleled.", author: "Marcus B." },
          { quote: "Bringing Elysian Fields into our home has been a daily source of inspiration. Highly recommend.", author: "Sophie L." },
        ]}
      />
    ),
    cta: (
      <CTABand
        heading="Continue Browsing"
        description="Explore the full collection of original oil paintings."
        primaryCta={{ label: "View Collection", href: "/gallery" }}
        secondaryCta={{ label: "About the Artist", href: "/about" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName="Jeanne Kassab Art"
        description="Original oil paintings by Jeanne Kassab. Abstract landscapes and layered oils, available for inquiry."
      />
    ),
  };

  return (
    <PublicShell brandName="Jeanne Kassab Art" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="artwork-detail">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}