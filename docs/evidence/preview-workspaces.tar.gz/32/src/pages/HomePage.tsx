// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName="Jeanne Kassab Art"
        headline="Original Paintings that Stir the Soul"
        subcopy="Explore Jeanne Kassab's collection of abstract landscapes and layered oils, where intuition meets exquisite technique."
        primaryCta={{ label: "View the Collection", href: "/gallery" }}
        secondaryCta={{ label: "About the Artist", href: "/about" }}
        imageSrc={images.hero}
        imageAlt="Jeanne Kassab studio atmosphere"
      />
    ),
    credentials: (
      <CredentialStrip items={["Original Fine Art", "Direct from Artist", "Secure Inquiry"]} />
    ),
    features: (
      <FeatureBento
        heading="Why Collectors Choose Jeanne Kassab"
        description="Each painting is a conversation between pigment and emotion, crafted with layered oils and cold wax techniques."
        items={[
          { title: "Authentic Originals", description: "Every piece is hand-painted by Jeanne, with a unique artistic voice." },
          { title: "Intuitive Landscapes", description: "Abstract compositions inspired by light, earth, and emotional memory." },
          { title: "Collector-Ready Presentation", description: "Professionally finished, ready to hang or frame." }
        ]}
        imagePool={[images.card1, images.card2, images.card3]}
      />
    ),
    showcase: (
      <ProductShowcase
        heading="Featured Paintings"
        items={[
          { title: "Sunset Horizons", description: "Oil & Cold Wax on Linen", imageSrc: images.card1, imageAlt: "Sunset Horizons", href: "/artwork/sunset-horizons" },
          { title: "Layered Sky", description: "Oil on Canvas", imageSrc: images.card2, imageAlt: "Layered Sky", href: "/artwork/layered-sky" },
          { title: "Deep Forest Depths", description: "Oil on Wood Panel", imageSrc: images.card3, imageAlt: "Deep Forest Depths", href: "/artwork/deep-forest" },
          { title: "Whispering Winds", description: "Oil on Canvas", imageSrc: images.card1, imageAlt: "Whispering Winds", href: "/artwork/whispering-winds" },
          { title: "Coastal Layers", description: "Oil on Wood Panel", imageSrc: images.card2, imageAlt: "Coastal Layers", href: "/artwork/coastal-layers" },
          { title: "Golden Hour Study", description: "Oil on Board", imageSrc: images.card3, imageAlt: "Golden Hour Study", href: "/artwork/golden-hour" }
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Business"} items={seed.testimonials ?? []} />
    ),
    cta: (
      <CTABand
        heading="Ready to discover your next favorite piece?"
        description="Explore the full collection of original paintings, each one a unique expression."
        primaryCta={{ label: "Browse the full collection", href: "/gallery" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName="Jeanne Kassab Art"
        description="Original oil paintings by Jeanne Kassab. Abstract landscapes and layered oils, available for inquiry."
        links={[
          { label: "Instagram", href: "https://instagram.com/jeannekassabart" },
          { label: "Pinterest", href: "https://pinterest.com/jeannekassabart" },
        ]}
        meta="© 2025 Jeanne Kassab Art. All rights reserved."
        variant="columns"
      />
    ),
  };

  return (
    <PublicShell brandName="Jeanne Kassab Art" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="gallery-home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}