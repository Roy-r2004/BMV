// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Contact Jeanne"}
        description={"Have a question about a painting, interested in a commission, or want to visit the studio? I'd love to hear from you."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Email"}</h3>
            <p className="text-sm leading-6 text-muted">{"For general inquiries, press, or collaboration."}</p>
            <Button href={"mailto:hello@jeannekassabart.com"} className="mt-auto w-fit">
              {"Send an Email"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"WhatsApp"}</h3>
            <p className="text-sm leading-6 text-muted">{"Quickest way to reach me directly. Send a message anytime."}</p>
            <Button href={"https://wa.me/96171234567"} className="mt-auto w-fit">
              {"Chat on WhatsApp"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Studio Visit"}</h3>
            <p className="text-sm leading-6 text-muted">{"Visit my studio in Beirut by appointment. Experience the works in person."}</p>
            <Button href={"mailto:studio@jeannekassabart.com"} className="mt-auto w-fit">
              {"Book a Visit"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Commission a Piece"}</h3>
            <p className="text-sm leading-6 text-muted">{"Interested in a custom painting? Let's discuss your vision."}</p>
            <Button href={"mailto:commissions@jeannekassabart.com"} className="mt-auto w-fit">
              {"Start a Conversation"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"© Jeanne Kassab Art. All rights reserved."}
      />
    ),
  };

  return (
    <PublicShell
      brandName={"Jeanne Kassab Art"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"generic"} data-appspec-page="contact">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}