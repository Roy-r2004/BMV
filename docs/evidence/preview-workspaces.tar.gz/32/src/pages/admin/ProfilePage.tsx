// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, DataTable, ActivityFeed } from '@/ui';

const SKELETON_ID = "ops-detail" as const;
export default function ProfilePage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={seed.opsHero?.headline || "Artist Profile"} description={seed.opsHero?.subcopy || "Appointments, check-ins, and the work that needs attention now."} meta={<span className="text-sm text-muted">Live</span>} actions={[{ label: "AI features", href: "/ai-features", variant: "secondary" }, { label: "Check in", href: "#queue" }]} />
    ),
    table: (
      <DataTable columns={[{ key: "name", header: "Name" }, { key: "status", header: "Status" }, { key: "owner", header: "Owner" }]} rows={(seed.tableRows ?? [{ id: "t1", name: "Primary record", status: "In progress", owner: "Ops" }, { id: "t2", name: "Follow-up item", status: "On hold", owner: "Ops" }, { id: "t3", name: "Completed item", status: "Done", owner: "Ops" }]).map((row) => ({ name: row.name, status: row.status, owner: row.owner || row.updated || "—" }))} />
    ),
    activity: (
      <ActivityFeed heading="Activity" items={(seed.activity ?? [{ id: "activity-1", title: "Record updated", detail: "The latest details are ready.", time: "Just now" }, { id: "activity-2", title: "Owner assigned", detail: "Waiting on confirmation.", time: "12m ago" }, { id: "activity-3", title: "Note added", detail: "Internal handoff logged.", time: "1h ago" }])} />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-profile">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}
