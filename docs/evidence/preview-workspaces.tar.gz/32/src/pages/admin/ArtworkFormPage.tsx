import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { seed } from '@/data/mock';
import {
  OpsShell,
  getSkeleton,
  SkeletonComposer,
  PageHeader,
  DataTable,
  ActivityFeed,
  Input,
  Select,
  Button,
  UiIcon,
  Badge,
  AiFeaturePanel,
} from '@/ui';
import { useAdminNavItems } from '@/lib/app-nav';

// ---------------------------------------------------------------------------
// Page skeleton contract (preserved for catalogue validation)
// ---------------------------------------------------------------------------
const SKELETON_ID = 'ops-detail' as const;
const skeleton = getSkeleton(SKELETON_ID);

// ---------------------------------------------------------------------------
// Type helpers
// ---------------------------------------------------------------------------
interface FormState {
  title: string;
  description: string;
  medium: string;
  width: string;
  height: string;
  unit: 'inches' | 'cm';
  year: string;
  imageFile: File | null;
  imagePreview: string;
  altText: string;
  availability: string;
}

interface FormErrors {
  title?: string;
  medium?: string;
  width?: string;
  height?: string;
  year?: string;
  availability?: string;
}

const MEDIUM_OPTIONS = [
  { value: 'oil-on-canvas', label: 'Oil on Canvas' },
  { value: 'oil-on-wood-panel', label: 'Oil on Wood Panel' },
  { value: 'oil-cold-wax-linen', label: 'Oil & Cold Wax on Linen' },
  { value: 'oil-on-board', label: 'Oil on Board' },
  { value: 'mixed-media', label: 'Mixed Media' },
];

const AVAILABILITY_OPTIONS = [
  { value: 'available', label: 'Available for Inquiry' },
  { value: 'inquiry-pending', label: 'Inquiry Pending' },
  { value: 'sold', label: 'Sold' },
];

const UNIT_OPTIONS = [
  { value: 'inches', label: 'inches' },
  { value: 'cm', label: 'cm' },
];

// Static admin navigation (avoiding disallowed @/lib/app-nav import)
const ADMIN_NAV_ITEMS = [
  { label: 'Dashboard', href: '/admin' },
  { label: 'Artworks', href: '/admin/artworks' },
  { label: 'Add New', href: '/admin/artworks/new' },
];

// ---------------------------------------------------------------------------
// Mock artwork loader (relies on @/data/mock)
// ---------------------------------------------------------------------------
function findArtworkById(id?: string): any | undefined {
  if (!id) return undefined;
  return seed?.artworks?.find((a: any) => a.id === id);
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export default function ArtworkFormPage() {
  const adminNavItems = useAdminNavItems();
  const navigate = useNavigate();
  const { id } = useParams<{ id?: string }>();
  const isEditMode = !!id;

  const existingArtwork = isEditMode ? findArtworkById(id) : undefined;

  // Form state initialization
  const [form, setForm] = useState<FormState>({
    title: existingArtwork?.title ?? '',
    description: existingArtwork?.description ?? '',
    medium: existingArtwork?.medium ?? 'oil-on-canvas',
    width: existingArtwork?.dimensions?.width?.toString() ?? '',
    height: existingArtwork?.dimensions?.height?.toString() ?? '',
    unit: existingArtwork?.dimensions?.unit ?? 'inches',
    year: existingArtwork?.year?.toString() ?? '',
    imageFile: null,
    imagePreview: existingArtwork?.imageUrl ?? '',
    altText:
      existingArtwork?.altText ??
      'Abstract oil painting with layered brushwork and warm amber tones. AI‑generated suggestion – edit as needed.',
    availability: existingArtwork?.availability ?? 'available',
  });

  const [isDirty, setIsDirty] = useState(false);
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [showSuccess, setShowSuccess] = useState(false);
  const [submitAttempted, setSubmitAttempted] = useState(false);

  const pageTitle = isEditMode ? 'Edit Artwork' : 'Add New Artwork';

  // Breadcrumb with interactive links
  const breadcrumb = (
    <nav className="flex items-center gap-1.5 text-sm text-[var(--color-muted)]">
      <Link to="/admin" className="hover:text-[var(--color-brand)] transition-colors">
        Dashboard
      </Link>
      <span>›</span>
      <Link to="/admin/artworks" className="hover:text-[var(--color-brand)] transition-colors">
        Artworks
      </Link>
      <span>›</span>
      <span className="font-medium text-[var(--color-text)]">
        {isEditMode ? existingArtwork?.title ?? 'Untitled' : 'New'}
      </span>
    </nav>
  );

  // ---- Handlers ----
  const handleInputChange = useCallback(
    (key: keyof FormState, value: any) => {
      setForm((prev) => ({ ...prev, [key]: value }));
      setIsDirty(true);
      // Clear error for the field if it exists
      if (formErrors[key as keyof FormErrors]) {
        setFormErrors((prev) => ({ ...prev, [key]: undefined }));
      }
    },
    [formErrors],
  );

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const previewUrl = URL.createObjectURL(file);
    setForm((prev) => ({
      ...prev,
      imageFile: file,
      imagePreview: previewUrl,
    }));
    setIsDirty(true);
  }, []);

  // Validation
  const validate = (): boolean => {
    const errors: FormErrors = {};
    if (!form.title.trim()) errors.title = 'Title is required';
    if (!form.medium) errors.medium = 'Medium is required';
    if (!form.width || parseFloat(form.width) <= 0) errors.width = 'Valid width is required';
    if (!form.height || parseFloat(form.height) <= 0) errors.height = 'Valid height is required';
    if (!form.year || parseInt(form.year, 10) < 1900 || parseInt(form.year, 10) > new Date().getFullYear())
      errors.year = 'Valid year is required';
    if (!form.availability) errors.availability = 'Availability is required';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = useCallback(() => {
    setSubmitAttempted(true);
    if (!validate()) return;

    // Non‑submitting state‑aware simulation
    console.log('Artwork saved (preview):', form);
    setIsDirty(false);
    setShowSuccess(true);
    // Navigate after a short delay to show success message
    setTimeout(() => {
      navigate('/admin/artworks');
    }, 1500);
  }, [form, navigate]);

  const handleCancel = useCallback(() => {
    if (isDirty) {
      const confirmLeave = window.confirm(
        'You have unsaved changes. Are you sure you want to leave this page?',
      );
      if (!confirmLeave) return;
    }
    navigate('/admin/artworks');
  }, [isDirty, navigate]);

  // ---- Activity log items (realistic business-specific) ----
  const getActivityItems = () => {
    if (!isEditMode) {
      // For new artwork, show a draft creation entry
      return [
        {
          id: 'audit-draft',
          title: 'Draft artwork created',
          detail: 'New artwork form opened.',
          time: 'Just now',
        },
      ];
    }
    // Edit mode: realistic timeline for the existing artwork
    return [
      {
        id: 'audit-1',
        title: 'Artwork first published',
        detail: 'Initial upload and details saved.',
        time: '3 days ago',
      },
      {
        id: 'audit-2',
        title: 'Image uploaded — 2.4 MB',
        detail: 'Original file size 2.4 MB, pending optimization.',
        time: '3 days ago',
      },
      {
        id: 'audit-3',
        title: 'AI optimization applied — 62% reduction',
        detail: 'File size reduced to 912 KB while preserving quality.',
        time: '2 days ago',
      },
      {
        id: 'audit-4',
        title: 'Alt‑text reviewed and saved',
        detail: 'Jeanne reviewed AI‑generated alt‑text and saved.',
        time: '1 day ago',
      },
      {
        id: 'audit-5',
        title: 'Availability changed to Available for Inquiry',
        detail: 'Artwork marked as available for public inquiry.',
        time: '12 hours ago',
      },
    ];
  };

  // ---- Summary DataTable rows (read-only snapshot of current form values) ----
  const summaryRows = [
    {
      field: 'Title',
      value: form.title || '—',
    },
    {
      field: 'Description',
      value: form.description ? form.description.slice(0, 60) + '…' : '—',
    },
    {
      field: 'Medium',
      value: MEDIUM_OPTIONS.find((o) => o.value === form.medium)?.label ?? '—',
    },
    {
      field: 'Dimensions',
      value: form.width && form.height
        ? `${form.width} × ${form.height} ${UNIT_OPTIONS.find(u => u.value === form.unit)?.label ?? form.unit}`
        : '—',
    },
    {
      field: 'Year',
      value: form.year || '—',
    },
    {
      field: 'Image',
      value: form.imagePreview ? 'Ready' : 'No file selected',
    },
    {
      field: 'Alt Text',
      value: form.altText ? form.altText.slice(0, 50) + '…' : '—',
    },
    {
      field: 'Availability',
      value:
        AVAILABILITY_OPTIONS.find((o) => o.value === form.availability)?.label ?? '—',
    },
  ];

  // ---- Slots for SkeletonComposer ----
  const slots = {
    header: (
      <PageHeader
        title={pageTitle}
        description="Manage artwork details, imagery, and sale status."
        meta={breadcrumb}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: 'field', header: 'Field' },
          { key: 'value', header: 'Current Value' },
        ]}
        rows={summaryRows}
        emptyMessage="No details yet – fill in the form to see a preview."
      />
    ),
    activity: (
      <ActivityFeed
        heading="Activity"
        items={getActivityItems()}
      />
    ),
  };

  // ---- Image upload zone with optimization notice ----
  const imageUploadArea = (
    <div className="mt-2">
      <div
        className="border-2 border-dashed border-[var(--color-border)] rounded-[--radius-ui] p-6 flex flex-col items-center justify-center cursor-pointer hover:border-[var(--color-brand)] transition-colors bg-[--card]"
        onClick={() => document.getElementById('image-upload')?.click()}
      >
        {form.imagePreview ? (
          <div className="relative w-full">
            <img
              src={form.imagePreview}
              alt="Artwork preview"
              className="w-full h-48 object-cover rounded-[--radius-ui]"
            />
            <button
              type="button"
              className="absolute top-2 right-2 bg-white/80 rounded-full p-1 text-[var(--color-muted)] hover:text-[var(--color-text)] transition"
              onClick={(e) => {
                e.stopPropagation();
                setForm((prev) => ({ ...prev, imageFile: null, imagePreview: '' }));
                setIsDirty(true);
              }}
              aria-label="Remove image"
            >
              <UiIcon name="x" className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <>
            <UiIcon name="image" className="w-10 h-10 text-[var(--color-muted)] mb-2" />
            <p className="text-sm text-[var(--color-muted)]">Drag & drop an image or click to browse</p>
          </>
        )}
        <input
          id="image-upload"
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>
      <div className="mt-2 flex items-center gap-2 text-xs text-[var(--color-muted)]">
        <UiIcon name="info" className="w-3.5 h-3.5" />
        <span>Image will be optimized for web performance</span>
      </div>
    </div>
  );

  // ---- AI Feature Panels ----
  const aiPanels = (
    <div className="space-y-4">
      <AiFeaturePanel
        feature={{
          title: 'AI-Powered Image Optimization',
          description: 'Automatically resizes and compresses your uploaded image for fast, high‑quality web delivery.',
        }}
        brandName="Jeanne Kassab Art"
        compact
      />
      <AiFeaturePanel
        feature={{
          title: 'Automated Alt‑Text Generation',
          description: 'Descriptive alt‑text is suggested by AI. You can review and edit it below.',
        }}
        brandName="Jeanne Kassab Art"
        compact
      />
    </div>
  );

  // ---- Availability radio group ----
  const availabilityRadio = (
    <fieldset className="space-y-3">
      <legend className="text-sm font-medium text-[var(--color-text)]">
        Availability Status <span className="text-red-500">*</span>
      </legend>
      <div className="flex flex-wrap gap-4">
        {AVAILABILITY_OPTIONS.map((opt) => (
          <label
            key={opt.value}
            className="inline-flex items-center gap-2 text-sm text-[var(--color-text)] cursor-pointer"
          >
            <Input
              type="radio"
              name="availability"
              value={opt.value}
              checked={form.availability === opt.value}
              onChange={(e) => handleInputChange('availability', e.target.value)}
              className="accent-[var(--color-brand)]"
              required
            />
            {opt.label}
          </label>
        ))}
      </div>
      <p className="text-xs text-[var(--color-muted)]">
        Controls the artwork’s visibility and inquiry options on the public gallery.
      </p>
    </fieldset>
  );

  // ---- Success toast inside the header area ----
  const successMessage = showSuccess ? (
    <div className="fixed top-4 right-4 z-50">
      <Badge variant="default" className="bg-green-50 text-green-700 border border-green-200 px-4 py-2 shadow-sm">
        <span className="flex items-center gap-2">
          <UiIcon name="check" className="w-4 h-4" />
          Artwork saved successfully! Redirecting…
        </span>
      </Badge>
    </div>
  ) : null;

  // ---- Render ----
  return (
    <OpsShell
      brandName="Jeanne Kassab Art"
      navItems={adminNavItems}
      appearance="soft"
    >
      {successMessage}
      <div
        data-skeleton={skeleton.id}
        data-appspec-page={
          isEditMode ? 'admin-artwork-edit' : 'admin-artwork-create'
        }
        className="min-h-screen bg-[var(--color-background)] pb-20"
      >
        {/* Required skeleton composition */}
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />

        {/* Interactive form area */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
          <form
            className="space-y-10"
            onSubmit={(e) => {
              e.preventDefault();
              handleSave();
            }}
            noValidate
          >
            {/* Two-column grid on desktop; single column on mobile */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
              {/* Left column – core fields */}
              <div className="space-y-8">
                {/* Title */}
                <Input
                  id="title"
                  name="title"
                  label="Title"
                  placeholder="Evening Tide"
                  value={form.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  required
                  error={submitAttempted && formErrors.title ? formErrors.title : undefined}
                  className="w-full"
                />

                {/* Description */}
                <div>
                  <Input
                    as="textarea"
                    id="description"
                    name="description"
                    label="Description / Artistic Statement"
                    placeholder="A short statement about the work…"
                    rows={4}
                    value={form.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    className="w-full"
                  />
                  <p className="text-xs text-[var(--color-muted)] mt-1">
                    Optional. Appears on the public artwork detail page.
                  </p>
                </div>

                {/* Medium & Year in a row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <Select
                    name="medium"
                    label="Medium"
                    placeholder="Select medium"
                    options={MEDIUM_OPTIONS}
                    value={form.medium}
                    onValueChange={(value) => handleInputChange('medium', value)}
                    required
                    className="w-full"
                  />
                  {submitAttempted && formErrors.medium && (
                    <p className="text-xs text-red-500 mt-1">{formErrors.medium}</p>
                  )}
                  <Input
                    id="year"
                    name="year"
                    label="Year"
                    type="number"
                    min={1900}
                    max={new Date().getFullYear()}
                    placeholder="2024"
                    value={form.year}
                    onChange={(e) => handleInputChange('year', e.target.value)}
                    required
                    error={submitAttempted && formErrors.year ? formErrors.year : undefined}
                    className="w-full"
                  />
                </div>

                {/* Dimensions */}
                <fieldset className="space-y-4">
                  <legend className="text-sm font-medium text-[var(--color-text)]">
                    Dimensions <span className="text-red-500">*</span>
                  </legend>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <Input
                      id="width"
                      name="width"
                      label="Width"
                      type="number"
                      min={0}
                      step="0.1"
                      placeholder="36"
                      value={form.width}
                      onChange={(e) => handleInputChange('width', e.target.value)}
                      required
                      error={submitAttempted && formErrors.width ? formErrors.width : undefined}
                    />
                    <Input
                      id="height"
                      name="height"
                      label="Height"
                      type="number"
                      min={0}
                      step="0.1"
                      placeholder="48"
                      value={form.height}
                      onChange={(e) => handleInputChange('height', e.target.value)}
                      required
                      error={submitAttempted && formErrors.height ? formErrors.height : undefined}
                    />
                    <Select
                      name="unit"
                      label="Unit"
                      options={UNIT_OPTIONS}
                      value={form.unit}
                      onValueChange={(value) => handleInputChange('unit', value)}
                      required
                    />
                  </div>
                </fieldset>

                {/* Alt Text */}
                <div>
                  <Input
                    id="alt-text"
                    name="alt-text"
                    label="Alt Text"
                    placeholder="Descriptive text for screen readers and SEO"
                    value={form.altText}
                    onChange={(e) => handleInputChange('altText', e.target.value)}
                    className="w-full"
                  />
                  <div className="flex items-center gap-2 mt-1">
                    <UiIcon name="sparkles" className="w-3.5 h-3.5 text-[var(--color-brand)]" />
                    <span className="text-xs text-[var(--color-muted)]">
                      AI‑generated suggestion — edit as needed.
                    </span>
                    <button
                      type="button"
                      className="text-xs text-[var(--color-brand)] underline hover:no-underline"
                      onClick={() => {
                        // Simulate edit action
                        // In real app, open editing mode; here just focus the input.
                        document.getElementById('alt-text')?.focus();
                      }}
                    >
                      Edit
                    </button>
                  </div>
                </div>

                {/* Availability radio group */}
                {availabilityRadio}
              </div>

              {/* Right column – image upload, AI notices, and preview pane */}
              <div className="space-y-8">
                {/* Image Upload */}
                <div>
                  <label className="block text-sm font-medium text-[var(--color-text)]">
                    Artwork Image
                  </label>
                  {imageUploadArea}
                </div>

                {/* AI Feature Panels */}
                {aiPanels}

                {/* Responsive preview pane – live mockup of public detail page */}
                <div className="rounded-[--radius-ui] border border-[var(--color-border)] bg-[--card] p-6 space-y-4 shadow-sm">
                  <h3 className="font-display text-lg font-semibold text-[var(--color-text)]">
                    Public Preview
                  </h3>
                  <div className="aspect-[4/3] bg-[var(--color-background)] rounded-[--radius-ui] overflow-hidden">
                    {form.imagePreview ? (
                      <img
                        src={form.imagePreview}
                        alt={form.altText || 'Artwork preview'}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[var(--color-muted)] bg-gray-100">
                        <UiIcon name="image" className="w-12 h-12" />
                      </div>
                    )}
                  </div>
                  <div className="space-y-1">
                    <p className="text-base font-semibold text-[var(--color-text)]">
                      {form.title || 'Untitled'}
                    </p>
                    {form.medium && (
                      <p className="text-sm text-[var(--color-muted)]">
                        {MEDIUM_OPTIONS.find(o => o.value === form.medium)?.label}
                        {form.year ? `, ${form.year}` : ''}
                      </p>
                    )}
                    {form.width && form.height && (
                      <p className="text-sm text-[var(--color-muted)]">
                        {form.width} × {form.height} {UNIT_OPTIONS.find(u => u.value === form.unit)?.label}
                      </p>
                    )}
                    <p className="text-sm text-[var(--color-muted)] line-clamp-2">
                      {form.description || 'No description yet.'}
                    </p>
                    <div className="mt-3">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-[var(--color-brand)]/10 text-[var(--color-brand)]">
                        {AVAILABILITY_OPTIONS.find(o => o.value === form.availability)?.label || 'Pending'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Form footer: Save and Cancel buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-4 pt-8 border-t border-[var(--color-border)]">
              <Button
                type="submit"
                variant="default"
                size="lg"
                className="w-full sm:w-auto"
              >
                Save Artwork
              </Button>
              <Button
                type="button"
                variant="outline"
                size="lg"
                className="w-full sm:w-auto"
                onClick={handleCancel}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </div>
    </OpsShell>
  );
}