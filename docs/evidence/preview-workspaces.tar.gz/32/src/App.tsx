import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutPage from './pages/AboutPage';
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import ArtworkDetailPage from './pages/ArtworkDetailPage';
import ArtworkFormPage from './pages/admin/ArtworkFormPage';
import ArtworkManagementPage from './pages/admin/ArtworkManagementPage';
import ContactPage from './pages/ContactPage';
import GalleryPage from './pages/GalleryPage';
import HomePage from './pages/HomePage';
import ProfilePage from './pages/admin/ProfilePage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/artwork/:id" element={<ArtworkDetailPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
          <Route path="/admin/artworks" element={<ArtworkManagementPage />} />
          <Route path="/admin/:id" element={<ArtworkManagementPage />} />
          <Route path="/admin/:slug" element={<ArtworkManagementPage />} />
          <Route path="/admin/artworks/new" element={<ArtworkFormPage />} />
          <Route path="/admin/artworks/:id" element={<ArtworkFormPage />} />
          <Route path="/admin/artworks/:slug" element={<ArtworkFormPage />} />
          <Route path="/admin/profile" element={<ProfilePage />} />
          <Route path="/gallery/:id" element={<ArtworkDetailPage />} />
          <Route path="/gallery/:slug" element={<ArtworkDetailPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}