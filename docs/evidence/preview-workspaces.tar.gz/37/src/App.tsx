import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AboutArtistPage from './pages/AboutArtistPage';
import AddArtworkPage from './pages/owner/AddArtworkPage';
import AiFeaturesPage from './pages/AiFeaturesPage';
import ArtworkDetailPage from './pages/ArtworkDetailPage';
import EditArtworkPage from './pages/owner/EditArtworkPage';
import EditProfilePage from './pages/owner/EditProfilePage';
import GalleryHomePage from './pages/GalleryHomePage';
import HomePage from './pages/HomePage';
import ManageArtworksPage from './pages/owner/ManageArtworksPage';
import OwnerDashboardPage from './pages/owner/OwnerDashboardPage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/gallery');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/gallery" element={<GalleryHomePage />} />
          <Route path="/about" element={<AboutArtistPage />} />
          <Route path="/owner/dashboard" element={<OwnerDashboardPage />} />
          <Route path="/owner/artworks" element={<ManageArtworksPage />} />
          <Route path="/owner/:id" element={<ManageArtworksPage />} />
          <Route path="/owner/:slug" element={<ManageArtworksPage />} />
          <Route path="/owner/artworks/new" element={<AddArtworkPage />} />
          <Route path="/owner/artworks/:id" element={<AddArtworkPage />} />
          <Route path="/owner/artworks/:slug" element={<AddArtworkPage />} />
          <Route path="/owner/profile" element={<EditProfilePage />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/artworks/:artworkSlug" element={<ArtworkDetailPage />} />
          <Route path="/artworks/:id" element={<ArtworkDetailPage />} />
          <Route path="/artworks/:slug" element={<ArtworkDetailPage />} />
          <Route path="/owner/artworks/:artworkId/edit" element={<EditArtworkPage />} />
          <Route path="/owner/artworks/:artworkId/:id" element={<EditArtworkPage />} />
          <Route path="/owner/artworks/:artworkId/:slug" element={<EditArtworkPage />} />
          <Route path="/ai-features" element={<AiFeaturesPage />} />
          <Route path="/gallery/:id" element={<ManageArtworksPage />} />
          <Route path="/gallery/:slug" element={<ManageArtworksPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}