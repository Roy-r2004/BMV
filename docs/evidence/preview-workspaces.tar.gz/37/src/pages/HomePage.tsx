// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        eyebrow={"Original Paintings"} // Business-specific eyebrow
        headline={"Abstract Landscapes & Layered Oils"} // Brand-specific headline
        subcopy={"Discover a living gallery of latest works, vibrant with color and texture, capturing the essence of memory and light."} // Brand-specific subcopy
        primaryCta={{ label: "View Available Work", href: "/gallery" }} // Business-specific primary CTA
        secondaryCta={{ label: "About the Artist", href: "/about" }} // Business-specific secondary CTA
        imageSrc={images.hero}
        imageAlt="An abstract oil painting by Jeanne Kassab, featuring soft textures and blended colors" // Ensured editorial variant
      />
    ),
    credentials: (
      <CredentialStrip
        heading={"Experience the Art"}
        items={[
          { title: "Original Creations", detail: "Each painting is a unique, hand-crafted oil on canvas from Jeanne's studio." },
          { title: "Art-First Display", detail: "Generous presentation of works, designed for thoughtful appreciation." },
          { title: "Personal Inquiry", detail: "Direct connection with the artist for details and acquisition." }
        ]}
      />
    ),
    features: (
      <FeatureBento
        heading={"Collecting Original Art"}
        description={"Navigating the journey of acquiring art should be as inspiring as the pieces themselves. We ensure a seamless and supportive experience."}
        imagePool={[images.card1, images.card2, images.card3]}
        items={[
          { title: "Browse the Gallery", description: "Explore abstract landscapes and layered oils, each with its own story.", imageSrc: images.card1, imageAlt: "Close-up of a textured oil painting" },
          { title: "Detailed Views", description: "In-depth displays for every piece, capturing texture and depth.", imageSrc: images.card2, imageAlt: "Detail of a painting showing brushstrokes" },
          { title: "Direct Inquiries", description: "Connect with Jeanne Kassab personally via WhatsApp for any questions.", imageSrc: images.card3, imageAlt: "WhatsApp icon over an art background" }
        ]} // Or 'grid' or 'bento' depending on desired layout
      />
    ),
    showcase: (
      <ProductShowcase
        heading={"Latest Works"}
        description={"A curated selection of recently completed paintings, ready to find their new home."}
        items={(seed.items ?? []).slice(0, 3).map((item, index) => ({ // Limiting to 3 for a curated feel
          title: item.title,
          description: item.description,
          imageSrc: [images.card1, images.card2, images.card3][index % 3], // Using various card images from mock
          imageAlt: item.title,
          badge: String((item as any).badge || "Available"), // Set badge to "Available"
          href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}`
        }))}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading={"Words from Collectors"}
        items={[
          { quote: "Jeanne's paintings bring such a calming presence to my home. Each one is a conversation piece.", author: "Elara V.", role: "Collector" },
          { quote: "The online gallery truly captures the depth and emotion of her work. A pleasure to browse.", author: "Marcus T.", role: "Interior Designer" },
          { quote: "The process of acquiring a piece was incredibly personal and smooth. I highly recommend.", author: "Sophia L.", role: "Enthusiast" }
        ]}
      />
    ),
    cta: (
      <CTABand
        heading={"Find Your Next Inspiration"}
        description={"Whether you're looking for a specific piece or a unique commission, Jeanne welcomes your inquiry."}
        primaryCta={{ label: "View All Available Art", href: "/gallery" }}
        secondaryCta={{ label: "Connect with Jeanne", href: "https://wa.me/YOURPHONENUMBER", target: "_blank" }} // Direct WhatsApp link
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings by Jeanne Kassab. Abstract landscapes and layered oils for discerning collectors."}
        links={[
          { label: "Home", href: "/" },
          { label: "Gallery", href: "/gallery" },
          { label: "About Jeanne", href: "/about" },
          { label: "Contact", href: "/contact" }
        ]}
        variant="columns"
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
          <div id="smart-image-cropping" data-ai-feature-panel="smart-image-cropping">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "smart-image-cropping") || { id: "smart-image-cropping", name: "smart-image-cropping" }}
          brandName={"Jeanne Kassab Art"}
        />
      </div>
    </PublicShell>
  );
}