// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed, aiFeatures } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, Button, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function OwnerDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title="The Canvas Gallery: Admin Portal"
        description="Manage your art collection, inquiries, and artist profile."
        actions={[
          { label: "Add New Painting", onClick: () => console.log('Add New Painting clicked'), variant: "primary" },
          { label: "View All Artworks", onClick: () => console.log('View All Artworks clicked'), variant: "secondary" }
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Current Paintings" value="18" delta="+2" hint="Last 30 days" />
        <StatCard label="Total Inquiries" value="7" delta="+3" hint="This week" />
        <StatCard label="Pending Responses" value="2" delta="—" hint="WhatsApp" />
      </div>
    ),
    chart: (
      <ChartCard
        title="Inquiry Trends"
        type="area"
        dataKey="inquiries"
        xKey="day"
        data={[
          { day: "Mon", inquiries: 1 },
          { day: "Tue", inquiries: 0 },
          { day: "Wed", inquiries: 2 },
          { day: "Thu", inquiries: 1 },
          { day: "Fri", inquiries: 3 },
          { day: "Sat", inquiries: 0 },
          { day: "Sun", inquiries: 0 },
        ]}
        description="Last 7 days"
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search artworks..."
        actions={[
          { label: "Filter by Status", onClick: () => console.log('Filter by Status clicked') },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "title", header: "Title" },
          { key: "description", header: "Description" },
          { key: "status", header: "Status" },
        ]}
        rows={[
          { id: "1", title: "Morning Mist", description: "Abstract Landscape (48x48in)", status: "Available" },
          { id: "2", title: "Coastal Fragment", description: "Layered Oil on Canvas (36x24in)", status: "Pending Inquiry" },
          { id: "3", title: "Desert Bloom", description: "Impressionistic Desert Scene (30x30in)", status: "Available" },
          { id: "4", title: "Whispering Pines", description: "Textured Oil Study (20x16in)", status: "Sold" },
        ]}
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "a1", text: "New Inquiry for 'Coastal Fragment'", message: "via WhatsApp from David R.", time: "5 minutes ago" },
          { id: "a2", text: "New painting 'Desert Bloom' published", message: "Visible in Gallery", time: "2 days ago" },
          { id: "a3", text: "Painting 'Morning Mist' status updated", message: "from Sold to Available", time: "4 days ago" },
          { id: "a4", text: "Artist profile updated", message: "Biography refined", time: "1 week ago" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
          <div id="art-style-suggestion" data-ai-feature-panel="art-style-suggestion">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "art-style-suggestion") || { id: "art-style-suggestion", name: "art-style-suggestion" }}
          brandName={"Jeanne Kassab Art"}
        />
      </div>
          <div id="description-polishing" data-ai-feature-panel="description-polishing">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "description-polishing") || { id: "description-polishing", name: "description-polishing" }}
          brandName={"Jeanne Kassab Art"}
        />
      </div>
    </OpsShell>
  );
}