// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Input, Select, Button, ActivityFeed, AiFeaturePanel } from '@/ui';
import React, { useState } from 'react';

// Mock data for artwork (in a real app, this would come from an API)
const mockArtwork = {
  id: 'artwork-1',
  title: 'Golden Hour Fields',
  description: 'A vibrant abstract landscape capturing the essence of a tranquil sunset over rolling fields, rendered in rich, layered oils with expressive brushwork and a warm, inviting palette.',
  dimensions: '30 x 40 inches',
  medium: 'Oil on canvas',
  status: 'available',
  imageUrl: 'https://images.pexels.com/photos/16397760/pexels-photo-16397760.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  createdAt: '2023-01-15T10:00:00Z',
  updatedAt: '2023-11-01T14:30:00Z',
};

const SKELETON_ID = "ops-detail" as const;

export default function EditArtworkPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  // State for form fields, pre-filled with mock artwork data
  const [title, setTitle] = useState(mockArtwork.title);
  const [description, setDescription] = useState(mockArtwork.description);
  const [dimensions, setDimensions] = useState(mockArtwork.dimensions);
  const [medium, setMedium] = useState(mockArtwork.medium);
  const [status, setStatus] = useState(mockArtwork.status);
  const [imageUrl, setImageUrl] = useState(mockArtwork.imageUrl);

  // Mock activity history for the artwork
  const artworkActivity = [
    { id: "act-1", title: "Painting uploaded", text: "Initial creation", createdAt: "2023-01-15T10:00:00Z", label: "Created by Jeanne Kassab" },
    { id: "act-2", title: "Details updated", text: "Description refined", createdAt: "2023-03-20T11:45:00Z", label: "Updated by Jeanne Kassab" },
    { id: "act-3", title: "Status changed", text: "Marked as available", createdAt: "2023-03-20T11:50:00Z", label: "Updated by Jeanne Kassab" },
    { id: "act-4", title: "Image revised", text: "New high-resolution image added", createdAt: "2023-11-01T14:30:00Z", label: "Updated by Jeanne Kassab" },
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const statusOptions = [
    { value: 'available', label: 'Available' },
    { value: 'sold', label: 'Sold' },
    { value: 'on_hold', label: 'On Hold' },
  ];

  const slots = {
    header: (
      <PageHeader
        title={`Edit Artwork: ${mockArtwork.title}`}
        actions={[
          { label: "Cancel", onClick: () => console.log('Cancel clicked'), variant: "ghost" },
          { label: "Save Changes", type: "submit", onClick: () => console.log('Save Changes clicked'), variant: "primary" },
        ]}
      />
    ),
    table: (
      <div className="space-y-6 max-w-2xl mx-auto">
        <Input
          label="Artwork Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <Input
          label="Description"
          as="textarea"
          rows={5}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <Input
          label="Dimensions (e.g., 30 x 40 inches)"
          value={dimensions}
          onChange={(e) => setDimensions(e.target.value)}
        />
        <Input
          label="Medium (e.g., Oil on canvas)"
          value={medium}
          onChange={(e) => setMedium(e.target.value)}
        />
        <Select
          label="Status"
          options={statusOptions}
          value={status}
          onValueChange={setStatus}
          required
        />

        <div className="space-y-2">
          <label className="block text-sm font-medium text-text-brand">Artwork Image</label>
          {imageUrl && (
            <div className="relative w-full h-64 border border-muted/30 rounded-lg overflow-hidden flex items-center justify-center bg-surface">
              <img src={imageUrl} alt="Artwork Preview" className="max-w-full max-h-full object-contain" />
            </div>
          )}
          <Input
            type="file"
            id="image-upload"
            label="Upload New Image"
            onChange={handleImageUpload}
            className="block w-full text-sm text-text-brand file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
          />
          <p className="text-sm text-muted">Upload a high-resolution image of the painting.</p>
        </div>
        <div className="mt-8 flex justify-end space-x-2">
          {/* Actions are already in PageHeader for better layout consistency.
              Keeping these here as a fallback or if additional buttons are needed. */}
        </div>
        <AiFeaturePanel feature="Smart Image Cropping" className="mt-8" />
        <AiFeaturePanel feature="Description Polishing" className="mt-4" />


      </div>
    ),
    activity: (
      <ActivityFeed
        heading="Artwork History"
        items={artworkActivity.map(activity => ({
          id: activity.id,
          title: activity.title,
          description: activity.text,
          timestamp: activity.createdAt,
          label: activity.label, // This maps to the 'label' prop the component expects
        }))}
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-artwork-edit">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}