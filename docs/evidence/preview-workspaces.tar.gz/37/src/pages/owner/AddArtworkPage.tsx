// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Input, Select, Button, ActivityFeed, UiIcon } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-detail" as const;

export default function AddArtworkPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dimensions, setDimensions] = useState('');
  const [medium, setMedium] = useState('');
  const [status, setStatus] = useState('Available');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      setImageFile(file);
      // Simulate upload progress
      let progress = 0;
      const interval = setInterval(() => {
        progress += 5;
        setUploadProgress(progress);
        if (progress >= 100) {
          clearInterval(interval);
        }
      }, 100);
    }
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    console.log({
      title,
      description,
      dimensions,
      medium,
      status,
      imageFile: imageFile?.name,
    });
    // Here you would typically send this data to an API
    alert('Artwork submitted!');
    // Reset form
    setTitle('');
    setDescription('');
    setDimensions('');
    setMedium('');
    setStatus('Available');
    setImageFile(null);
    setUploadProgress(0);
  };

  const slots = {
    header: (
      <PageHeader title={"Add New Artwork"} />
    ),
    table: (
      <form onSubmit={handleSubmit} className="p-8 space-y-6 max-w-2xl mx-auto bg-surface rounded-lg shadow-sm">
        <h2 className="text-xl font-display text-text-brand leading-none">Artwork Details</h2>
        <Input
          label="Title"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g., 'Whispers of the Horizon'"
          required
        />
        <Input
          label="Description"
          as="textarea"
          rows={5}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Describe the painting's inspiration, technique, and mood."
          className="resize-y"
        />
        <Input
          label="Dimensions"
          type="text"
          value={dimensions}
          onChange={(e) => setDimensions(e.target.value)}
          placeholder="e.g., '48x48in'"
          required
        />
        <Input
          label="Medium"
          type="text"
          value={medium}
          onChange={(e) => setMedium(e.target.value)}
          placeholder="e.g., 'Oil on Canvas'"
          required
        />
        <Select
          label="Status"
          options={[
            { value: 'Available', label: 'Available' },
            { value: 'On Hold', label: 'On Hold' },
            { value: 'Sold', label: 'Sold' },
          ]}
          value={status}
          onValueChange={setStatus}
          required
        />

        <div>
          <label htmlFor="image-upload" className="block text-sm font-medium text-text-brand mb-2">
            Image Upload
          </label>
          <div className="flex items-center space-x-4">
            <input
              id="image-upload"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="block w-full text-sm text-muted
                file:mr-4 file:py-2 file:px-4
                file:rounded-md file:border-0
                file:text-sm file:font-semibold
                file:bg-muted/10 file:text-text-brand
                hover:file:bg-muted/20
                cursor-pointer"
            />
            {imageFile && (
              <span className="text-muted text-sm flex items-center">
                <UiIcon name="Paperclip" className="h-4 w-4 mr-1"/>
                {imageFile.name}
              </span>
            )}
          </div>
          {uploadProgress > 0 && uploadProgress < 100 && (
            <div className="w-full bg-muted/20 rounded-full h-2.5 mt-2">
              <div className="bg-primary h-2.5 rounded-full" style={{ width: `${uploadProgress}%` }}></div>
            </div>
          )}
          {uploadProgress === 100 && (
            <p className="text-sm text-primary mt-2 flex items-center">
              <UiIcon name="Check" className="h-4 w-4 mr-1"/>
              Upload Complete!
            </p>
          )}
        </div>

        <Button type="submit" className="w-full">
          Publish Artwork
        </Button>
      </form>
    ),
    activity: (
      <ActivityFeed
        heading="Upload Progress"
        items={[
          {
            id: "upload-progress",
            title: imageFile ? `Uploading: ${imageFile.name}` : "Awaiting image upload",
            detail: uploadProgress > 0 ? `${uploadProgress}% complete` : "Select an image file to begin",
            time: uploadProgress === 100 ? "Finished" : "In progress",
          },
          {
            id: "view-all",
            title: "Quick Link",
            detail: "View all artworks",
            time: "Go",
            href: "/owner/artworks" // Assuming there's a route to view all artworks
          },
        ]}
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-artwork-new">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}