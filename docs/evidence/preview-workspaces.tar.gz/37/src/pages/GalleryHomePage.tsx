// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProductShowcase, TestimonialRail, CTABand, BrandFooter, Button } from '@/ui';
import { useRef } from 'react';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function GalleryHomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  
  const featuredWorksRef = useRef<HTMLDivElement>(null);

  const scrollToFeaturedWorks = () => {
    featuredWorksRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const currentYear = new Date().getFullYear();

  const slots = {
    hero: (
      <MarketingHero 
        brandName={"Jeanne Kassab Art"} 
        headline={"Original Oil Paintings by Jeanne Kassab"} 
        subcopy={"Explore abstract landscapes and layered oils, each a unique expression of light and emotion."} 
        primaryCta={{ label: "View Latest Works", onClick: scrollToFeaturedWorks }} 
        secondaryCta={{ label: "About the Artist", href: "/about", variant: "ghost" }}
        imageSrc={images.hero} 
        imageAlt="An abstract oil painting titled 'Coastal Fragment' by Jeanne Kassab, featuring muted blues and greens"
      />
    ),
    // The 'credentials' slot is part of the `public-home` skeleton but was not explicitly mapped to a section in the page brief.
    // As per the contract: "Keep every assigned slot key; do not add inventeds slots."
    // And "An empty array is a blank section."
    // Since there's no content from the page brief for this slot, we'll render it as an empty section.
    // If it were a required section without a brief match, we'd add placeholder content according to the prompt.
    credentials: (
      <CredentialStrip items={[]} />
    ),
    // Similar to 'credentials', 'features' was not explicitly mapped in the page brief.
    features: (
      <FeatureBento heading="" items={[]} />
    ),
    showcase: (
      <ProductShowcase heading="" className="mt-20 px-4 md:px-8 lg:px-12" ref={featuredWorksRef}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12 lg:gap-16">
          {[
            { 
              imageSrc: images.card1, 
              imageAlt: "Abstract oil painting 'Whispers of the Forest'", 
              title: "Whispers of the Forest", 
              href: "/artwork/whispers-of-the-forest" 
            },
            { 
              imageSrc: images.card2, 
              imageAlt: "Abstract oil painting 'Golden Hour Fields'", 
              title: "Golden Hour Fields", 
              href: "/artwork/golden-hour-fields" 
            },
            { 
              imageSrc: images.card3, 
              imageAlt: "Abstract oil painting 'Desert Bloom'", 
              title: "Desert Bloom", 
              href: "/artwork/desert-bloom" 
            },
            { 
              imageSrc: images.ambient, 
              imageAlt: "Abstract oil painting 'Mountain Serenity'", 
              title: "Mountain Serenity", 
              href: "/artwork/mountain-serenity" 
            },
            { 
              imageSrc: images.hero2, 
              imageAlt: "Abstract oil painting 'Urban Echoes'", 
              title: "Urban Echoes", 
              href: "/artwork/urban-echoes" 
            },
            { 
              imageSrc: images.hero, 
              imageAlt: "Abstract oil painting 'River Bend'", 
              title: "River Bend", 
              href: "/artwork/river-bend" 
            },
          ].map((item, index) => (
            <a key={index} href={item.href} className="group relative block w-full aspect-[4/5] overflow-hidden">
              <img 
                src={item.imageSrc} 
                alt={item.imageAlt} 
                className="w-full h-full object-cover transition-transform duration-300 ease-in-out group-hover:scale-105" 
              />
              <div className="absolute inset-0 bg-transparent group-hover:bg-text-brand/20 flex items-center justify-center p-4 transition-colors duration-300">
                <p className="font-display text-surface text-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-center">
                  {item.title}
                </p>
              </div>
            </a>
          ))}
        </div>
      </ProductShowcase>
    ),
    // Similar to 'credentials', 'testimonials' was not explicitly mapped in the page brief.
    testimonials: (
      <TestimonialRail heading="" items={[]} />
    ),
    cta: (
      <CTABand 
        className="my-20"
        heading={"Discover a piece that speaks to you?"} 
        primaryCta={{ label: "Connect with Jeanne", href: "https://wa.me/YOURPHONENUMBER?text=Hello%20Jeanne,%20I'm%20interested%20in%20your%20artworks.", target: "_blank", variant: "default" }}
      />
    ),
    footer: (
      <BrandFooter 
        brandName={"Jeanne Kassab Art"} 
        meta={`© ${currentYear} Jeanne Kassab Art`}
        links={[
          { label: "Instagram", href: "https://www.instagram.com/jeannekassabart" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="gallery-home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}