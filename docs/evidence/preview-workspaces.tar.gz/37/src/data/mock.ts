export const brand = {"name": "Jeanne Kassab Art", "tagline": "", "design_system": {"primary_color": "#0f766e", "secondary_color": "#0369a1", "background_color": "#f8fafc", "surface_color": "#ffffff", "text_color": "#042f2e", "muted_text_color": "#5f7a78", "font_family": "Source Sans 3", "display_font_family": "Fraunces", "font_import_url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap", "font_sans": "\"Source Sans 3\", \"Segoe UI\", sans-serif", "font_display": "\"Fraunces\", Georgia, serif", "brand_locked": true, "brand_brief_version": "1.0", "mood": "modern", "voice": "Warm, grounded, unhurried. Speak like a trusted studio host.", "signature": "A calm full-bleed atmosphere with Jeanne Kassab Art as the hero signal, not a card grid.", "avoid": ["purple-on-white or purple-to-indigo default themes", "Inter / Roboto / Arial as the display face", "card grids in the hero", "generic SaaS marketing copy", "inventing a second palette per page"], "rules": ["Every page inherits this palette and type stack via CSS tokens only.", "Use bg-brand / text-brand / font-display — never hardcode hex colors.", "First viewport must feature the brand name as a hero-level signal."], "recipe_id": "editorial", "hub_variant": "marketing", "hero_variant": "editorial", "feature_variant": "alternating", "recipe_prompt": "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.", "style_keywords": "Editorial · Bold ink", "border_radius": "0.39rem", "design_overlay_id": "bold_ink", "design_overlay_label": "Bold ink", "design_overlay_blurb": "High-contrast retail energy — sharp type, punchy surfaces.", "density": "punchy", "token_overrides": {"radius_ui": "0.39rem", "bg_mix": "6%", "fg_mix": "48%", "muted_mix": "34%", "border_mix": "18%", "shadow": "0 20px 40px -28px", "shadow_alpha": "40%", "glow": "11%", "card": "#ffffff", "atmosphere": "linear-gradient(135deg, color-mix(in srgb, var(--color-brand) 14%, #0f172a) 0%, transparent 42%), radial-gradient(70% 50% at 100% 0%, color-mix(in srgb, var(--color-accent) 18%, transparent), transparent 55%), linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%)"}, "font_import": "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700", "design_brief_version": "1.0", "design_brief_sealed": true},
  services: [{"name": "Jeanne Kassab Art Signature", "title": "Jeanne Kassab Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jeanne Kassab Art clients.",

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  name: "Jeanne Kassab Art",
  tagline: {},
};

export const images = {
  "hero": "https://images.pexels.com/photos/16432481/pexels-photo-16432481.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/11901266/pexels-photo-11901266.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/16397760/pexels-photo-16397760.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/2721507/pexels-photo-2721507.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/36764950/pexels-photo-36764950.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/16397788/pexels-photo-16397788.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const roles = [
  {
    "id": "customer",
    "label": "Gallery Visitor",
    "defaultPath": "/gallery",
    "icon": "users"
  },
  {
    "id": "owner",
    "label": "Jeanne Kassab (Owner)",
    "defaultPath": "/owner/dashboard",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    }
  ],
  "admin": [
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-artworks",
      "path": "/owner/artworks",
      "href": "/owner/artworks",
      "label": "Artworks"
    },
    {
      "id": "owner-artworks-new",
      "path": "/owner/artworks/new",
      "href": "/owner/artworks/new",
      "label": "New"
    },
    {
      "id": "owner-profile",
      "path": "/owner/profile",
      "href": "/owner/profile",
      "label": "Profile"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About"
    }
  ],
  "owner": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-artworks",
      "path": "/owner/artworks",
      "href": "/owner/artworks",
      "label": "Artworks"
    },
    {
      "id": "owner-artworks-new",
      "path": "/owner/artworks/new",
      "href": "/owner/artworks/new",
      "label": "New"
    },
    {
      "id": "owner-profile",
      "path": "/owner/profile",
      "href": "/owner/profile",
      "label": "Profile"
    }
  ]
};

export const seed = {
  hero: {
    eyebrow: 'Jeanne Kassab Art',
    headline: 'Jeanne Kassab Art',
    subcopy: 'A clear next step from Jeanne Kassab Art — warm, specific, and ready when you are.',
    primaryCta: { label: 'Get started', href: '#details' },
    secondaryCta: { label: 'See how it works', href: '#process' },
  },
  items: [
    { title: 'Jeanne Kassab Art signature', description: 'A dependable starting point at Jeanne Kassab Art.' },
    { title: 'Everyday essential', description: 'Built for daily use.' },
    { title: 'Guest favorite', description: 'The one people come back to Jeanne Kassab Art for.' },
  ],
  features: [
    { title: 'What Jeanne Kassab Art is known for', description: 'Concrete offerings guests can book without guessing.' },
    { title: 'Guided next step', description: 'Every section points toward a clear action.' },
    { title: 'Built for return visits', description: 'Details that make Jeanne Kassab Art easy to come back to.' },
  ],
  featuresHeading: 'What Jeanne Kassab Art offers',
  showcaseHeading: 'From Jeanne Kassab Art',
  credentialsHeading: 'Why Jeanne Kassab Art',
  credentials: [
    { title: 'Known locally', detail: 'Neighbors recommend Jeanne Kassab Art for consistent results.' },
    { title: 'Clear next steps', detail: 'Booking and follow-up stay simple from the start.' },
  ],
  trustLabels: [
    'Jeanne Kassab Art quality\', \'On schedule\', \'Repeat guests\', \'Local favorite',
  ],
  cta: {
    heading: 'Ready for Jeanne Kassab Art?',
    description: 'Tell Jeanne Kassab Art what you need — clear options, real next steps.',
    primaryLabel: 'Get started',
    primaryHref: '#details',
    secondaryLabel: 'Talk to us',
    secondaryHref: '#contact',
  },
  footer: {
    description: 'Jeanne Kassab Art — clear choices and real bookings.',
  },

  "tone": "editorial-gallery",
  "hero": {
    "eyebrow": "Jeanne Kassab Art",
    "headline": "Original Oil Paintings by Jeanne Kassab",
    "subcopy": "Explore abstract landscapes and layered oils, each a unique expression of light and emotion.",
    "primaryCta": {
      "label": "View Latest Works",
      "href": "/gallery"
    },
    "secondaryCta": {
      "label": "About the Artist",
      "href": "/about"
    }
  },
  "items": [
    {
      "title": "Abstract Landscapes",
      "description": "Evocative scenes blending dreamlike horizons with rich, textural depth."
    },
    {
      "title": "Layered Oils",
      "description": "Multi-dimensional compositions where color and light build complex narratives."
    }
  ],
  "features": [
    {
      "title": "Unparalleled Detail",
      "description": "High-resolution imagery reveals every brushstroke and texture."
    },
    {
      "title": "Direct Artist Connection",
      "description": "Inquire directly via WhatsApp for a personal consultation."
    },
    {
      "title": "Curated Collections",
      "description": "Discover works organized by theme, style, or latest additions."
    }
  ],
  "process": [
    {
      "title": "Discover",
      "description": "Browse Jeanne's curated online gallery of original oil paintings."
    },
    {
      "title": "Inquire",
      "description": "Contact Jeanne directly via WhatsApp to discuss a piece or commission."
    },
    {
      "title": "Acquire",
      "description": "Secure a unique piece of art for your collection or space."
    }
  ],
  "credentials": [
    {
      "title": "Exhibitions",
      "detail": "XYZ Gallery (2022), Art House Collective (2021)"
    }
  ],
  "testimonials": [
    {
      "quote": "Jeanne's art brings such serene beauty into a space. The online gallery perfectly captures the essence of her work.",
      "author": "Laura M.",
      "role": "Art Collector"
    }
  ],
  "treatments": [
    {
      "id": "offer-1",
      "name": "Abstract Landscapes",
      "duration": "60 min"
    },
    {
      "id": "offer-2",
      "name": "Layered Oils",
      "duration": "60 min"
    }
  ],
  "showcaseHeading": "Available works",
  "featuresHeading": "How the work is made",
  "processHeading": "From the wall to your wall",
  "credentialsHeading": "Studio record",
  "testimonialsHeading": "Collector notes",
  "cta": {
    "heading": "Found a piece that stays with you?",
    "description": "Ask about price, framing, and delivery — or arrange a studio visit.",
    "primaryLabel": "Inquire about a piece",
    "primaryHref": "/contact",
    "secondaryLabel": "See the collection",
    "secondaryHref": "/gallery"
  },
  "footer": {
    "description": "A working painter's gallery of original oils — abstract landscapes and layered studies."
  },
  "trustLabels": [
    "Original oils only",
    "Archival materials",
    "Insured crating",
    "Studio visits"
  ],
  "kpis": [
    {
      "label": "Current Paintings",
      "value": "18",
      "delta": "+2",
      "hint": "Last 30 days"
    },
    {
      "label": "Total Inquiries",
      "value": "7",
      "delta": "+3",
      "hint": "This week"
    },
    {
      "label": "Pending Responses",
      "value": "2",
      "delta": "—",
      "hint": "WhatsApp"
    }
  ],
  "activity": [
    {
      "id": "activity-1",
      "title": "New Inquiry for 'Coastal Fragment'",
      "detail": "via WhatsApp from David R.",
      "time": "5 minutes ago"
    },
    {
      "id": "activity-2",
      "title": "Updated 'Whispers of the Forest'",
      "detail": "Medium and description edited",
      "time": "Yesterday"
    },
    {
      "id": "activity-3",
      "title": "New painting 'Desert Bloom' published",
      "detail": "Visible in Gallery",
      "time": "2 days ago"
    }
  ],
  "risk": [
    {
      "id": "risk-1",
      "title": "Needs attention",
      "detail": "Evocative scenes blending dreamlike horizons with rich, textural depth.",
      "severity": "medium"
    }
  ],
  "tableRows": [
    {
      "id": "row-1",
      "name": "Abstract Landscapes",
      "status": "Open",
      "owner": "Team"
    },
    {
      "id": "row-2",
      "name": "Layered Oils",
      "status": "Open",
      "owner": "Team"
    }
  ]
};

export const aiFeatures = [
  {
    "id": "smart-image-cropping",
    "name": "Smart Image Cropping",
    "description": "Automatically suggests optimal crops for thumbnail and gallery views while preserving artistic composition.",
    "category": "scheduling",
    "surface": "scheduling",
    "demo_hint": "Ask for availability in Jeanne Kassab Art's real schedule",
    "demo_prompts": [
      "Next opening for booking",
      "Any booking SaaS or slots this weekend?",
      "Book the soonest intake"
    ],
    "placement_label": "Scheduling AI",
    "demo_results": {
      "Next opening for booking": "Best fits for “Next opening for booking”: Thu 10:00 · Fri 14:30 · Mon 09:15 — holds a seat for booking at Jeanne Kassab Art.",
      "Any booking SaaS or slots this weekend?": "Weekend openings for “Any booking SaaS or slots this weekend?”: Sat 11:00 · Sun 15:30. Capacity updates as booking SaaS or fills.",
      "Book the soonest intake": "Held the soonest match for “Book the soonest intake”. Confirmation draft ready; customer can confirm in one tap."
    },
    "placement_path": "/",
    "placement_component": "src/pages/HomePage.tsx",
    "placement_title": "Home"
  },
  {
    "id": "art-style-suggestion",
    "name": "Art Style Suggestion",
    "description": "Upon uploading a new image, suggests relevant tags or categories based on visual analysis to aid organization.",
    "category": "ops",
    "surface": "ops",
    "demo_hint": "Route ops work the way Jeanne Kassab Art runs",
    "demo_prompts": [
      "Triage new requests about intake",
      "Assign an owner for this booking issue",
      "What should the Jeanne Kassab Art team do next?"
    ],
    "placement_label": "Ops AI",
    "demo_results": {
      "Triage new requests about intake": "Routed “Triage new requests about intake” → queue + owner + checklist for intake. Status: In progress.",
      "Assign an owner for this booking issue": "Assigned “Assign an owner for this booking issue” to the best available owner with a booking checklist and due time today.",
      "What should the Jeanne Kassab Art team do next?": "Next for Jeanne Kassab Art: clear the intake backlog, confirm booking, then review tonight's handoff."
    },
    "placement_path": "/owner/dashboard",
    "placement_component": "src/pages/owner/OwnerDashboardPage.tsx",
    "placement_title": "Owner Dashboard · The Canvas Gallery"
  },
  {
    "id": "description-polishing",
    "name": "Description Polishing",
    "description": "Provides suggestions for refining or expanding painting descriptions to be more engaging and evocative.",
    "category": "ops",
    "surface": "automation",
    "demo_hint": "Route ops work the way Jeanne Kassab Art runs",
    "demo_prompts": [
      "Triage new requests about intake",
      "Assign an owner for this booking issue",
      "What should the Jeanne Kassab Art team do next?"
    ],
    "placement_label": "Ops AI",
    "demo_results": {
      "Triage new requests about intake": "Routed “Triage new requests about intake” → queue + owner + checklist for intake. Status: In progress.",
      "Assign an owner for this booking issue": "Assigned “Assign an owner for this booking issue” to the best available owner with a booking checklist and due time today.",
      "What should the Jeanne Kassab Art team do next?": "Next for Jeanne Kassab Art: clear the intake backlog, confirm booking, then review tonight's handoff."
    },
    "placement_path": "/owner/dashboard",
    "placement_component": "src/pages/owner/OwnerDashboardPage.tsx",
    "placement_title": "Owner Dashboard · The Canvas Gallery"
  }
] as const;
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;

// build-correctness guard: auto-added missing exports
export const BRAND_MANIFEST = {"brand_name": "Jeanne Kassab Art", "name": "Jeanne Kassab Art", "tagline": "", "accent": "#6366f1", "design_system": {"primary_color": "#6366f1", "secondary_color": "#0d9488", "accent": "#6366f1", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "inter", "font_import_url": "https://fonts.googleapis.com/css2?family=inter:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"}, "services": [{"id": "intro-session", "name": "Jeanne Kassab Art intro session", "description": "A welcoming first session for new guests.", "duration": "90 min", "level": "Beginner Friendly", "day": "Thursday", "status": "Open"}, {"id": "signature-workshop", "name": "Signature workshop", "description": "The core experience guests book most often.", "duration": "2 hours", "level": "All Levels", "day": "Saturday", "status": "Open"}, {"id": "advanced-studio", "name": "Advanced studio time", "description": "Deeper practice with guided feedback.", "duration": "3 hours", "level": "Intermediate", "day": "Wednesday", "status": "Full"}], "products": [{"title": "Jeanne Kassab Art essential", "description": "A dependable pick from the shop floor.", "name": "Jeanne Kassab Art essential"}, {"title": "Studio favorite", "description": "The piece guests ask about first.", "name": "Studio favorite"}]};
export const stats = [{"id": "stats-1", "name": "stats 1", "title": "stats 1", "label": "stats 1", "status": "In progress", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 1", "amount": 52, "count": 4, "date": "2026-07-29", "time": "10:00", "startDate": "2026-07-29", "endDate": "2026-07-29", "dropOffDate": "2026-07-29", "dropOffTime": "10:00", "pickupDate": "2026-07-31", "scheduledAt": "2026-07-29T10:00:00", "createdAt": "2026-07-29T10:00:00", "timestamp": "2026-07-29T10:00:00", "instructor": "Maya R.", "memberName": "Member 1", "loadType": "Bisque", "registered": 5, "capacity": 12, "isFull": false}, {"id": "stats-2", "name": "stats 2", "title": "stats 2", "label": "stats 2", "status": "Done", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 2", "amount": 64, "count": 5, "date": "2026-07-30", "time": "11:30", "startDate": "2026-07-30", "endDate": "2026-07-30", "dropOffDate": "2026-07-30", "dropOffTime": "11:30", "pickupDate": "2026-08-01", "scheduledAt": "2026-07-30T11:30:00", "createdAt": "2026-07-30T11:30:00", "timestamp": "2026-07-30T11:30:00", "instructor": "Jordan K.", "memberName": "Member 2", "loadType": "Glaze", "registered": 6, "capacity": 12, "isFull": false}, {"id": "stats-3", "name": "stats 3", "title": "stats 3", "label": "stats 3", "status": "Scheduled", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 3", "amount": 76, "count": 6, "date": "2026-07-31", "time": "12:00", "startDate": "2026-07-31", "endDate": "2026-07-31", "dropOffDate": "2026-07-31", "dropOffTime": "12:00", "pickupDate": "2026-08-02", "scheduledAt": "2026-07-31T12:00:00", "createdAt": "2026-07-31T12:00:00", "timestamp": "2026-07-31T12:00:00", "instructor": "Sam T.", "memberName": "Member 3", "loadType": "Cone 6", "registered": 7, "capacity": 12, "isFull": false}, {"id": "stats-4", "name": "stats 4", "title": "stats 4", "label": "stats 4", "status": "Open", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 4", "amount": 88, "count": 7, "date": "2026-08-01", "time": "13:30", "startDate": "2026-08-01", "endDate": "2026-08-01", "dropOffDate": "2026-08-01", "dropOffTime": "13:30", "pickupDate": "2026-08-03", "scheduledAt": "2026-08-01T13:30:00", "createdAt": "2026-08-01T13:30:00", "timestamp": "2026-08-01T13:30:00", "instructor": "Noa B.", "memberName": "Member 4", "loadType": "Raku", "registered": 8, "capacity": 12, "isFull": false}];