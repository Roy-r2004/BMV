// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Select } from '@/ui';
import { useState } from 'react';

const SKELETON_ID = "ops-list" as const;

export default function AdminBookingsPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const sampleBookings = [
    {
      id: "CPL-001",
      guestName: "John Doe",
      roomType: "Lakeside King",
      checkIn: "2023-11-01",
      checkOut: "2023-11-03",
      totalPrice: "$750.00",
      status: "Confirmed",
      addOns: "",
    },
    {
      id: "CPL-002",
      guestName: "Sarah Lee",
      roomType: "Adirondack Double",
      checkIn: "2023-11-05",
      checkOut: "2023-11-07",
      totalPrice: "$500.00",
      status: "Pending Payment",
      addOns: "",
    },
    {
      id: "CPL-003",
      guestName: "Mike & Lisa",
      roomType: "Forest View Queen",
      checkIn: "2023-12-10",
      checkOut: "2023-12-12",
      totalPrice: "$980.00",
      status: "Confirmed",
      addOns: "Restaurant, Canoe Trip",
    },
  ];

  const [searchValue, setSearchValue] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedMonth, setSelectedMonth] = useState("all");

  const filteredBookings = sampleBookings.filter(booking => {
    const searchMatch = booking.guestName.toLowerCase().includes(searchValue.toLowerCase()) ||
                        booking.id.toLowerCase().includes(searchValue.toLowerCase());
    const statusMatch = selectedStatus === "all" || booking.status === selectedStatus;
    const monthMatch = selectedMonth === "all" ||
                       new Date(booking.checkIn).toLocaleString('en-US', { month: 'long' }) === selectedMonth ||
                       new Date(booking.checkOut).toLocaleString('en-US', { month: 'long' }) === selectedMonth;
    return searchMatch && statusMatch && monthMatch;
  });

  const slots = {
    header: (
      <PageHeader
        title="Booking Management"
        description="A comprehensive list of all guest bookings, with options to view details, modify, or cancel reservations."
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search by Guest Name or Booking ID"
        searchValue={searchValue}
        onSearchChange={e => setSearchValue(e.target.value)}
        filters={[
          {
            id: "status-filter",
            label: "Status",
            render: (
              <Select
                options={[
                  { value: "all", label: "All Statuses" },
                  { value: "Confirmed", label: "Confirmed" },
                  { value: "Pending Payment", label: "Pending Payment" },
                  { value: "Cancelled", label: "Cancelled" },
                ]}
                value={selectedStatus}
                onValueChange={setSelectedStatus}
                placeholder="Select Status"
              />
            )
          },
          {
            id: "month-filter",
            label: "Check-in/out Month",
            render: (
              <Select
                options={[
                  { value: "all", label: "All Months" },
                  { value: "January", label: "January" },
                  { value: "February", label: "February" },
                  { value: "March", label: "March" },
                  { value: "April", label: "April" },
                  { value: "May", label: "May" },
                  { value: "June", label: "June" },
                  { value: "July", label: "July" },
                  { value: "August", label: "August" },
                  { value: "September", label: "September" },
                  { value: "October", label: "October" },
                  { value: "November", label: "November" },
                  { value: "December", label: "December" },
                ]}
                value={selectedMonth}
                onValueChange={setSelectedMonth}
                placeholder="Select Month"
              />
            )
          }
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "id", header: "Booking ID" },
          { key: "guestName", header: "Guest Name" },
          { key: "roomType", header: "Room Type" },
          { key: "checkIn", header: "Check-in" },
          { key: "checkOut", header: "Check-out" },
          { key: "totalPrice", header: "Total Price" },
          { key: "status", header: "Status" },
          { key: "addOns", header: "Add-ons" },
          {
            key: "actions",
            header: "Actions",
            render: (row) => (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => alert(`Viewing details for ${row.id}`)}>View Details</Button>
                <Button variant="outline" size="sm" onClick={() => alert(`Modifying ${row.id}`)}>Modify</Button>
                <Button variant="destructive" size="sm" onClick={() => alert(`Cancelling ${row.id}`)}>Cancel</Button>
              </div>
            ),
          },
        ]}
        rows={filteredBookings.map(booking => ({
          id: booking.id,
          guestName: booking.guestName,
          roomType: booking.roomType,
          checkIn: booking.checkIn,
          checkOut: booking.checkOut,
          totalPrice: booking.totalPrice,
          status: booking.status,
          addOns: booking.addOns || "N/A",
        }))}
        emptyMessage="No bookings found matching your criteria."
      />
    ),
  };

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-bookings">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}