// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, RiskQueue, ChartCard, FilterBar, DataTable, ActivityFeed } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const today = new Date();
  const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const formattedDate = today.toLocaleDateString('en-US', options);

  const slots = {
    header: (
      <PageHeader
        title={"Cedar Point Lodge Operations Dashboard"}
        description={`Welcome, Sarah! Today is ${formattedDate}.`}
        actions={[{ label: "Add New Booking", onClick: () => alert('Add New Booking clicked') }]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="Arrivals Today" value="3" delta="+1" hint="Compared to yesterday" />
        <StatCard label="Occupancy Rate" value="75%" delta="+5%" hint="Compared to last week" />
        <StatCard label="New Bookings" value="2" delta="0" hint="Since yesterday" />
      </div>
    ),
    risk: (
      <RiskQueue
        heading="Insights"
        items={[
          {
            id: "ai-availability",
            title: "Intelligent Availability Insights",
            detail: "Upcoming high-demand weekend (Sept 15-17) at 95% occupancy. Consider staffing adjustments and dynamic pricing for these dates.",
            severity: "high",
          },
        ]}
      />
    ),
    chart: (
      <ChartCard
        title="Occupancy Trend"
        type="area"
        dataKey="occupancy"
        xKey="month"
        data={[
          { month: "Jan", occupancy: 60 },
          { month: "Feb", occupancy: 55 },
          { month: "Mar", occupancy: 65 },
          { month: "Apr", occupancy: 70 },
          { month: "May", occupancy: 80 },
          { month: "Jun", occupancy: 85 },
          { month: "Jul", occupancy: 90 },
          { month: "Aug", occupancy: 88 },
          { month: "Sep", occupancy: 75 },
          { month: "Oct", occupancy: 70 },
          { month: "Nov", occupancy: 60 },
          { month: "Dec", occupancy: 68 },
        ]}
        description="Monthly occupancy rate over the last year"
        insight="Peak season aligns with summer months; plan resources accordingly."
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Filter bookings by guest name or room"
        filters={[
          { id: "all", label: "All Bookings", active: true },
          { id: "arriving", label: "Arriving Today", active: false },
          { id: "departing", label: "Departing Today", active: false },
          { id: "next7days", label: "Next 7 Days", active: false },
          { id: "special", label: "Special Requests", active: false },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "guestName", header: "Guest Name" },
          { key: "roomType", header: "Room Type" },
          { key: "checkIn", header: "Check-in" },
          { key: "checkOut", header: "Check-out" },
          { key: "specialRequests", header: "Special Requests" },
        ]}
        rows={[
          { id: "b1", guestName: "The Andersons", roomType: "Lakeside King", checkIn: "Today 3PM", checkOut: "Sep 15", specialRequests: "Early check-in" },
          { id: "b2", guestName: "Ms. Chen", roomType: "Adirondack Double", checkIn: "Sep 13", checkOut: "Today 11AM", specialRequests: "Late check-out requested" },
          { id: "b3", guestName: "Rodriguez Family", roomType: "Lakeside Suite", checkIn: "Sep 14", checkOut: "Sep 17", specialRequests: "Dinner reservation (Today 7PM)" },
          { id: "b4", guestName: "Jane Doe", roomType: "Lakeside King", checkIn: "Sep 15", checkOut: "Sep 18", specialRequests: "Canoe trip booked (Sep 16)" },
          { id: "b5", guestName: "John Smith", roomType: "Adirondack Double", checkIn: "Sep 16", checkOut: "Sep 19", specialRequests: "Sauna session booked (Sep 17)" },
        ]}
        emptyMessage="No upcoming bookings."
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "a1", title: "Guest Jane Doe booked Lakeside King", detail: "for 3 nights.", time: "5 minutes ago" },
          { id: "a2", title: "Room 8 marked available", detail: "by Manager Sarah.", time: "15 minutes ago" },
          { id: "a3", title: "The Andersons checked in", detail: "Lakeside King.", time: "1 hour ago" },
          { id: "a4", title: "New inquiry from potential guest", detail: "regarding canoe trip dates.", time: "2 hours ago" },
          { id: "a5", title: "Ms. Chen checked out", detail: "Adirondack Double.", time: "3 hours ago" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
    </OpsShell>
  );
}