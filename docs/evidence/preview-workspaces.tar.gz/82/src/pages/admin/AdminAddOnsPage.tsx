// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed, aiFeatures } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Select, Input, AiFeaturePanel } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-list" as const;
export default function AdminAddOnsPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const addOnFilters = [
    { value: "all", label: "All" },
    { value: "restaurant", label: "Restaurant" },
    { value: "sauna", label: "Sauna" },
    { value: "canoe", label: "Canoe Trip" },
  ];

  const mockAddOnData = [
    {
      id: "res-001",
      serviceType: "Restaurant",
      guestName: "John Doe",
      date: "Nov 1, 2024",
      time: "7:00 PM",
      details: "Table for 2",
      status: "Confirmed",
      room: "Rm 5"
    },
    {
      id: "res-002",
      serviceType: "Restaurant",
      guestName: "Emily R.",
      date: "Nov 1, 2024",
      time: "8:00 PM",
      details: "Table for 4",
      status: "Confirmed",
      room: "Rm 10"
    },
    {
      id: "sauna-001",
      serviceType: "Sauna",
      guestName: "Sarah L.",
      date: "Nov 2, 2024",
      time: "10:00 AM",
      details: "60-minute session",
      status: "Confirmed",
      room: "Rm 3"
    },
    {
      id: "canoe-001",
      serviceType: "Canoe Trip",
      guestName: "Mike & Lisa",
      date: "Nov 2, 2024",
      time: "9:00 AM",
      details: "Guided trip, 2 people",
      status: "Confirmed",
      room: "Rm 7"
    },
    {
      id: "res-003",
      serviceType: "Restaurant",
      guestName: "David K.",
      date: "Nov 2, 2024",
      time: "6:30 PM",
      details: "Table for 2, Window requested",
      status: "Pending",
      room: "Rm 1"
    },
    {
      id: "sauna-002",
      serviceType: "Sauna",
      guestName: "Jessica P.",
      date: "Nov 3, 2024",
      time: "2:00 PM",
      details: "30-minute session",
      status: "Confirmed",
      room: "Rm 12"
    },
  ];

  const [selectedAddOnType, setSelectedAddOnType] = useState("all");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]); // Default to today

  const filteredData = mockAddOnData.filter(item => {
    const itemDate = new Date(item.date).toISOString().split('T')[0];
    const matchesType = selectedAddOnType === "all" || item.serviceType.toLowerCase().includes(selectedAddOnType);
    const matchesDate = itemDate === selectedDate;
    return matchesType && matchesDate;
  });

  const slots = {
    header: (
      <PageHeader
        title="Add-on Reservations"
        description="Manage restaurant, sauna, and canoe trip bookings."
        actions={[{ label: "New Booking", onClick: () => alert('Open new booking form') }]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search guest name or details..."
        filters={[
          {
            id: "add-on-type",
            label: <Select
              options={addOnFilters}
              value={selectedAddOnType}
              onValueChange={setSelectedAddOnType}
              className="w-40"
              aria-label="Filter by add-on type"
            />,
            render: () => (
              <Select
                options={addOnFilters}
                value={selectedAddOnType}
                onValueChange={setSelectedAddOnType}
                className="w-40"
                aria-label="Filter by add-on type"
              />
            )
          },
          {
            id: "date-picker",
            label: <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-40"
              aria-label="Select date"
            />,
            render: () => (
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-40"
                aria-label="Select date"
              />
            )
          }
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "serviceType", header: "Service Type" },
          { key: "guestName", header: "Guest Name" },
          { key: "date", header: "Date" },
          { key: "time", header: "Time" },
          { key: "details", header: "Details" },
          { key: "status", header: "Status" },
          { key: "room", header: "Room" },
        ]}
        rows={filteredData}
        emptyMessage="No add-on reservations found for the selected criteria."
      />
    ),
  };

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-add-ons">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
          <div id="personalized-room-recommendations" data-ai-feature-panel="personalized-room-recommendations">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "personalized-room-recommendations") || { id: "personalized-room-recommendations", name: "personalized-room-recommendations" }}
          brandName={"Cedar Point Lodge"}
        />
      </div>
    </OpsShell>
  );
}