// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, FilterBar, DataTable, Button, Select, Input } from '@/ui';
import React, { useState } from 'react';

const SKELETON_ID = "ops-list" as const;

interface RoomData {
  id: string;
  roomName: string;
  roomType: 'Lakeside King' | 'Adirondack Double' | 'Forest View Queen';
  status: 'Available' | 'Booked';
  baseRate: number;
  seasonalRate?: number;
  availability: { date: string; status: 'available' | 'booked'; rate: number }[];
}

const generateMockRoomData = (): RoomData[] => {
  const rooms: RoomData[] = [];
  const roomTypes = ['Lakeside King', 'Adirondack Double', 'Forest View Queen'];
  let roomIdCounter = 1;

  for (let i = 0; i < 18; i++) {
    const type = roomTypes[Math.floor(Math.random() * roomTypes.length)];
    const baseRate = type === 'Lakeside King' ? 350 : (type === 'Adirondack Double' ? 280 : 220);
    const status = Math.random() > 0.8 ? 'Booked' : 'Available';

    const availability = [];
    for (let d = 0; d < 30; d++) { // Next 30 days
      const date = new Date();
      date.setDate(date.getDate() + d);
      const dateString = date.toISOString().split('T')[0];
      let dailyRate = baseRate;
      let dailyStatus: 'available' | 'booked' = 'available';

      // Example specific bookings for Room 5
      if (roomIdCounter === 5 && (dateString === '2024-11-01' || dateString === '2024-11-02' || dateString === '2024-11-03')) {
        dailyStatus = 'booked';
      }
      
      // Example seasonal rate for December
      if (date.getMonth() === 11) { // December (0-indexed)
        dailyRate = Math.round(baseRate * 1.10); // 10% increase
      }

      availability.push({ date: dateString, status: dailyStatus, rate: dailyRate });
    }

    rooms.push({
      id: `room-${roomIdCounter}`,
      roomName: `${type} - Room ${roomIdCounter}`,
      roomType: type as RoomData['roomType'],
      status: status,
      baseRate: baseRate,
      availability: availability,
    });
    roomIdCounter++;
  }
  return rooms;
};

const mockRoomData = generateMockRoomData();

export default function AdminRoomRatesPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [roomTypeFilter, setRoomTypeFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredRooms = mockRoomData.filter(room => {
    const matchesSearch = room.roomName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRoomType = roomTypeFilter === 'all' || room.roomType === roomTypeFilter;
    
    // Add date range filtering logic here if needed for broader table view
    // For now, availability is per room in the 'Availability Calendar' column
    return matchesSearch && matchesRoomType;
  });

  const slots = {
    header: (
      <PageHeader
        title="Room & Rate Management"
        description="View and modify room availability, pricing, and details for different dates and seasons."
        actions={[
          { label: "Bulk Rate Editor", onClick: () => alert('Bulk Rate Editor functionality goes here!'), variant: "secondary" },
          { label: "Add New Room", onClick: () => alert('Add New Room functionality goes here!') }
        ]}
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search rooms by name"
        searchValue={searchTerm}
        onSearchChange={setSearchTerm}
        filters={[
          {
            label: "Room Type",
            render: (
              <Select
                options={[
                  { value: "all", label: "All Room Types" },
                  { value: "Lakeside King", label: "Lakeside King" },
                  { value: "Adirondack Double", label: "Adirondack Double" },
                  { value: "Forest View Queen", label: "Forest View Queen" },
                ]}
                value={roomTypeFilter}
                onValueChange={setRoomTypeFilter}
                placeholder="Select room type"
                className="min-w-[180px]"
              />
            ),
          },
          {
            label: "Date Range",
            render: (
              <div className="flex gap-2">
                <Input
                  type="date"
                  value={dateRange.start}
                  onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                  aria-label="Start Date"
                />
                <Input
                  type="date"
                  value={dateRange.end}
                  onChange={(e) => setDateRange({ ...dateRange.end, end: e.target.value })}
                  aria-label="End Date"
                />
              </div>
            ),
          },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "roomName", header: "Room Name" },
          { key: "roomType", header: "Room Type" },
          { key: "status", header: "Status", render: (row) => (
            <Badge variant={row.status === 'Available' ? 'default' : 'secondary'}>
              {row.status}
            </Badge>
          )},
          { key: "baseRate", header: "Base Rate", render: (row) => `$${row.baseRate.toFixed(2)}` },
          {
            key: "seasonalRate",
            header: "Seasonal Rate",
            render: (row) => {
              const today = new Date().toISOString().split('T')[0];
              const currentAvailability = row.availability.find((item: any) => item.date === today);
              return currentAvailability && currentAvailability.rate !== row.baseRate
                ? `$${currentAvailability.rate.toFixed(2)}`
                : '—';
            },
          },
          {
            key: "availabilityCalendar",
            header: "Availability Calendar",
            render: (row) => (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => alert(`Showing calendar for ${row.roomName}`)}
                aria-label={`View availability for ${row.roomName}`}
              >
                <UiIcon name="calendar" className="w-5 h-5" />
              </Button>
            ),
          },
          {
            key: "actions",
            header: "Actions",
            render: (row) => (
              <Button
                variant="outline"
                size="sm"
                onClick={() => alert(`Editing room: ${row.roomName}`)}
              >
                Edit
              </Button>
            ),
          },
        ]}
        rows={filteredRooms}
        emptyMessage="No rooms found matching your criteria."
      />
    ),
  };

  return (
    <OpsShell brandName={"Cedar Point Lodge"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-room-rates">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </OpsShell>
  );
}

// Dummy Badge and UiIcon components to satisfy TypeScript if they're not imported directly in the scaffold.
// In a real scenario, these would be imported from '@/ui'.
function Badge({ children, variant = 'default', className = '' }: { children: React.ReactNode, variant?: 'default' | 'secondary' | 'outline' | 'destructive', className?: string }) {
  const baseClasses = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium";
  const variantClasses = {
    default: "bg-teal-100 text-teal-800", // Using brand-aligned color
    secondary: "bg-gray-100 text-gray-800",
    outline: "bg-white border border-gray-200 text-gray-700",
    destructive: "bg-red-100 text-red-800",
  };
  return <span className={`${baseClasses} ${variantClasses[variant]} ${className}`}>{children}</span>;
}

function UiIcon({ name, className = '' }: { name: string, className?: string }) {
  // This is a placeholder. In a real app, you'd render an SVG or an icon font.
  // For demonstration, we'll just return a span with the icon name.
  return <span className={`inline-block w-4 h-4 align-middle ${className}`} title={name}>{/* SVG for ${name} */}</span>;
}