// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, TestimonialRail, CTABand, BrandFooter, Button } from '@/ui';

const SKELETON_ID = "public-service" as const;
const RECIPE_ORDER = ["hero", "features", "testimonials", "cta", "footer"] as const;

export default function RestaurantPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Cedar Point Lodge"} items={seed.testimonials ?? []} />
    ),
    hero: (
      <MarketingHero
        brandName="Cedar Point Lodge"
        headline="Lakeside Dining at Cedar Point Lodge"
        subcopy="Savor locally-sourced flavors with breathtaking lake views. Our culinary philosophy centers on fresh, seasonal ingredients, thoughtfully prepared to enhance your Adirondack experience."
        primaryCta={{ label: "Make a Reservation", href: "/dining#reservation" }}
        imageSrc={images.ambient} // Using 'ambient' for dining area/dish
        imageAlt="A beautifully plated meal at Cedar Point Lodge's lakeside restaurant"
        className="text-text-brand"
      />
    ),
    features: (
      <FeatureBento
        heading="Our Culinary Delights"
        description="Experience the heart of Adirondack hospitality through our thoughtfully crafted menus."
        imagePool={[images.card1, images.card2, images.card3]}
        items={[
          {
            title: "Pan-Seared Adirondack Trout",
            description: "Freshly caught trout, pan-seared to perfection with local herbs and a lemon-butter sauce. A true taste of the region.",
            imageSrc: images.card1,
            imageAlt: "Close-up of pan-seared Adirondack trout with herbs"
          },
          {
            title: "Seasonal Harvest Risotto",
            description: "Creamy arborio rice infused with seasonal vegetables from nearby farms, finished with aged parmesan. A comforting, flavorful vegetarian option.",
            imageSrc: images.card2,
            imageAlt: "Bowl of vibrant risotto with fresh vegetables"
          },
          {
            title: "Cedar Point Lodge Burger",
            description: "Our signature burger featuring locally sourced beef, smoked gouda, crispy bacon, and a secret sauce, served on a brioche bun with hand-cut fries.",
            imageSrc: images.card3,
            imageAlt: "Gourmet burger with fries on a wooden board"
          },
          {
            title: "Dining Hours",
            description: "Join us for breakfast, lunch, and dinner. Our kitchen is open daily from 7:00 AM to 10:00 PM, ready to serve you delightful meals.",
            imageSrc: images.card1,
            imageAlt: "Restaurant interior at Cedar Point Lodge"
          },
          {
            title: "View Our Full Menu",
            description: "Explore our complete selection of appetizers, entrees, desserts, and beverages. Our menu changes seasonally to ensure the freshest ingredients.",
            imageSrc: images.card2,
            imageAlt: "A printed menu with a view of the lake in the background",
            href: "#", // Placeholder for actual PDF link
          },
        ]}
        className="py-16 md:py-24"
      />
    ),
    cta: (
      <CTABand
        heading="Reserve Your Table"
        description="Ensure your spot at our acclaimed lakeside restaurant. Use the form below to select your preferred date and time."
        primaryCta={{ label: "Make a Reservation", href: "/dining#reservation" }}
        className="py-16 md:py-24"
      >
        <div id="reservation" className="max-w-xl mx-auto mt-8 p-6 bg-surface rounded-lg shadow-lg">
          <h3 className="font-display text-2xl text-text-brand mb-4">Book a Table</h3>
          <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="res-date" className="block text-sm font-medium text-muted mb-1">Date</label>
              <input type="date" id="res-date" name="res-date" className="w-full p-2 border border-muted rounded-md bg-background text-text-brand" required />
            </div>
            <div>
              <label htmlFor="res-time" className="block text-sm font-medium text-muted mb-1">Time</label>
              <select id="res-time" name="res-time" className="w-full p-2 border border-muted rounded-md bg-background text-text-brand" required>
                <option value="18:00">6:00 PM</option>
                <option value="19:00">7:00 PM</option>
                <option value="20:00">8:00 PM</option>
              </select>
            </div>
            <div>
              <label htmlFor="res-guests" className="block text-sm font-medium text-muted mb-1">Number of Guests</label>
              <input type="number" id="res-guests" name="res-guests" min="1" max="10" defaultValue="2" className="w-full p-2 border border-muted rounded-md bg-background text-text-brand" required />
            </div>
            <div className="md:col-span-2">
              <label htmlFor="res-notes" className="block text-sm font-medium text-muted mb-1">Special Requests / Dietary Needs</label>
              <textarea id="res-notes" name="res-notes" rows={3} className="w-full p-2 border border-muted rounded-md bg-background text-text-brand"></textarea>
            </div>
            <div className="md:col-span-2">
              <Button type="submit" variant="default" className="w-full">Request Reservation</Button>
            </div>
          </form>
        </div>
      </CTABand>
    ),
    footer: (
      <BrandFooter
        brandName="Cedar Point Lodge"
        description="An eighteen-room lakeside lodge in the Adirondacks with a restaurant, a sauna and guided canoe trips. Book your unforgettable stay directly with us."
        links={[
          { label: "Rooms & Suites", href: "/rooms" },
          { label: "Sauna", href: "/sauna" },
          { label: "Canoe Trips", href: "/canoe-trips" },
          { label: "Contact Us", href: "/contact" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="restaurant-page">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}