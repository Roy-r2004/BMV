// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-service" as const;
const RECIPE_ORDER = ["hero", "features", "testimonials", "cta", "footer"] as const; // Removed testimonials as it's not needed for this page

export default function SaunaPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Cedar Point Lodge"} items={seed.testimonials ?? []} />
    ),
    hero: (
      <MarketingHero
        brandName="Cedar Point Lodge"
        headline="Rejuvenate in Our Adirondack Sauna"
        subcopy="Melt away stress and unwind after a day of adventure in our tranquil lakeside sauna. Designed for pure relaxation."
        primaryCta={{ label: "Book a Sauna Session", href: "/book-session" }}
        imageSrc={images.item7}
        imageAlt="A serene sauna with a large window overlooking a lake and forest."
        className="text-text-brand"
      />
    ),
    features: (
      <FeatureBento
        heading="Your Private Retreat"
        description="Experience the deep relaxation and therapeutic benefits of our private sauna sessions."
        items={[
          {
            title: "Private 60-Minute Sessions",
            description: "Indulge in a full hour of undisturbed tranquility. Each session is exclusively yours.",
            imageSrc: images.card1,
            imageAlt: "Interior of a clean, modern sauna with wooden benches."
          },
          {
            title: "Wellness Benefits",
            description: "Detoxify, improve circulation, and ease muscle tension after exploring the Adirondacks.",
            imageSrc: images.card2,
            imageAlt: "Steam rising inside a sauna, creating a soft, warm glow."
          },
          {
            title: "Lakeside Serenity",
            description: "Enjoy views of the glistening lake from our sauna, enhancing your connection to nature.",
            imageSrc: images.card3,
            imageAlt: "A person relaxing on a sauna bench, looking out a window at a lake."
          },
        ]}
      />
    ),
    // Testimonials slot removed as per the simplified RECIPE_ORDER
    cta: (
      <CTABand
        heading="Ready to Unwind?"
        description="Enhance your stay by adding a private sauna session to your reservation."
        primaryCta={{ label: "Book a Sauna Session", href: "/book-room#sauna" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName="Cedar Point Lodge"
        description="An eighteen-room lakeside lodge offering a sanctuary in the Adirondacks. Experience nature, comfort, and rejuvenation."
        links={[
          { label: "Rooms", href: "/rooms" },
          { label: "Restaurant", href: "/restaurant" },
          { label: "Canoe Trips", href: "/canoe-trips" },
          { label: "Contact", href: "/contact" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="sauna-page">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}