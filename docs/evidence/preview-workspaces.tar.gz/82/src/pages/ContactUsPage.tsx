// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function ContactUsPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Contact Cedar Point Lodge"}
        description={"Have questions or need assistance? Reach out to us directly. We're here to help you plan your perfect Adirondack getaway."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Call Us"}
            description={"Speak with a friendly member of our team."}
            ctaLabel={"Call Now"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Cedar Point Lodge"}
        description={"Cedar Point Lodge — Your Adirondack Haven."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="contact-us">
      </div>
      <PublicShell
      brandName={"Cedar Point Lodge"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
