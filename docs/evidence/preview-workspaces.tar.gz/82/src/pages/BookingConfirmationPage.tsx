// composed confirmation page (ConfirmStage)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, BrandFooter, ConfirmStage, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

export default function BookingConfirmationPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();

  return (
    <>
      <div className="contents" data-appspec-page="booking-confirmation">
      </div>
      <PublicShell
      brandName={"Cedar Point Lodge"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <ConfirmStage
        eyebrow={"Confirmed"}
        title={"Booking Confirmed!"}
        detail={"Confirmation on file"}
        description={"Thank you for choosing Cedar Point Lodge. We look forward to welcoming you."}
        primaryCta={{"label": "Back to home", "href": "/"}}
        nextSteps={[{"title": "Your Adirondack Escape is Set!", "description": "Confirmation Number: CPL-20241101-1234. An email with all the details has been sent to your inbox. We've reserved the Lakeside King for you from November 1st to November 3rd, 2024. Your canoe trip for two on November 2nd at 2:00 PM is also confirmed.", "ctaLabel": "View My Booking", "href": "/my-bookings/CPL-20241101-1234"}, {"title": "Explore More Experiences", "description": "Enhance your stay with a reservation at our lakeside restaurant or a rejuvenating session in our sauna. Availability is limited, so book ahead!", "ctaLabel": "Add Experiences", "href": "/experiences"}, {"title": "Prepare for Your Visit", "description": "Find useful information about Cedar Point Lodge, including directions, check-in times, and local attractions.", "ctaLabel": "Plan My Trip", "href": "/plan-your-stay"}]}
      />
      <BrandFooter
        brandName={"Cedar Point Lodge"}
        description={"© 2024 Cedar Point Lodge. All rights reserved."}
      />
          <div id="intelligent-availability-insights" data-ai-feature-panel="intelligent-availability-insights">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "intelligent-availability-insights") || { id: "intelligent-availability-insights", name: "intelligent-availability-insights" }}
          brandName={"Cedar Point Lodge"}
        />
      </div>
    </PublicShell>
    </>
  );
}
