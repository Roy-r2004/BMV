// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, TestimonialRail, CTABand, BrandFooter } from '@/ui';

const SKELETON_ID = "public-service" as const;
const RECIPE_ORDER = ["hero", "features", "testimonials", "cta", "footer"] as const; // Removed testimonials as it's not needed based on the brief

export default function CanoeTripsPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    testimonials: (
      <TestimonialRail heading={seed.testimonialsHeading ?? "Guests of Cedar Point Lodge"} items={seed.testimonials ?? []} />
    ),
    hero: (
      <MarketingHero
        brandName={"Cedar Point Lodge"}
        headline={"Guided Canoe Trips on the Lake"}
        subcopy={"Paddle through the serene waters of the Adirondacks, discover hidden coves, and observe local wildlife with our experienced guides. An unforgettable adventure awaits."}
        primaryCta={{ label: "Schedule Your Adventure", href: "/book-canoe-trip" }}
        imageSrc={images.ambient} // Using 'ambient' for the canoe on the lake image as it's the most fitting
        imageAlt="A canoe with paddlers on a calm lake surrounded by Adirondack mountains"
      />
    ),
    features: (
      <FeatureBento
        heading="Your Adirondack Paddling Experience"
        items={[
          {
            title: "2-Hour Guided Tours",
            description: "Embark on a leisurely two-hour journey across the pristine lake. Our guides lead you to scenic viewpoints and tranquil spots perfect for nature observation.",
            imageSrc: images.card1,
            imageAlt: "A guide pointing out scenery from a canoe",
          },
          {
            title: "What's Included",
            description: "All trips include quality paddles, US Coast Guard-approved life vests for all participants, and the expertise of a certified Cedar Point Lodge guide. Just bring your sense of adventure!",
            imageSrc: images.card2,
            imageAlt: "Paddles and life vests on a canoe",
          },
          {
            title: "Trip Schedule & Booking",
            description: "Trips are available Tuesday, Thursday, Saturday, and Sunday. Choose between our morning departure at 9 AM or an afternoon excursion at 2 PM. Each trip accommodates a maximum of 4 participants.",
            imageSrc: images.card3,
            imageAlt: "A calendar showing available dates for canoe trips",
          },
          {
            title: "Pricing & Meeting Point",
            description: "Our guided canoe trips are $75 per person. We'll meet you at the Cedar Point Lodge boathouse 15 minutes prior to your scheduled departure time for a brief orientation.",
            imageSrc: images.hero2, // Using hero2 for a scenic overview
            imageAlt: "A map showing the boathouse meeting point at Cedar Point Lodge",
          },
        ]}
      />
    ),
    // Testimonials slot removed as per updated RECIPE_ORDER
    cta: (
      <CTABand
        heading="Ready to Paddle the Adirondacks?"
        description="Enhance your stay at Cedar Point Lodge with an unforgettable guided canoe trip. Select your preferred date and time, and add this unique experience to your reservation."
        primaryCta={{ label: "Add to Your Booking", href: "/book#canoe-trip" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Cedar Point Lodge"}
        description={"An intimate lakeside lodge in the Adirondacks offering a serene escape with exceptional experiences."}
        links={[
          { label: "Rooms & Suites", href: "/rooms" },
          { label: "Restaurant", href: "/restaurant" },
          { label: "Sauna", href: "/sauna" },
          { label: "Contact Us", href: "/contact" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="canoe-trips-page">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}