// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed, aiFeatures } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, BookingPanel, BrandFooter, ProcessSection, Input, Button, UiIcon, AiFeaturePanel } from '@/ui';
import { useState } from 'react';

const SKELETON_ID = "public-booking" as const;
const RECIPE_ORDER = ["hero", "credentials", "booking", "footer"] as const; // Added 'process' slot

export default function BookingFormPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 3; // Guest Details, Add-ons, Payment

  // Sample Data from brief
  const roomName = "Lakeside King";
  const checkInDate = "Nov 1";
  const checkOutDate = "Nov 3";
  const numberOfNights = 2;
  const roomPrice = 900;
  const restaurantAddonPrice = 80;
  const saunaAddonPrice = 60;
  const canoeTripAddonPrice = 150;
  const totalDue = 1190;

  const [addons, setAddons] = useState({
    restaurant: false,
    sauna: false,
    canoe: false,
  });

  const handleAddonToggle = (addonName: keyof typeof addons) => {
    setAddons(prev => ({ ...prev, [addonName]: !prev[addonName] }));
  };

  const bookingSummary = (
    <div className="p-6 bg-surface rounded-lg shadow-sm font-sans text-text">
      <h3 className="font-display text-xl text-primary mb-4">Your Reservation Summary</h3>
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="font-semibold">{roomName}</span>
          <span>${roomPrice}.00</span>
        </div>
        <div className="flex justify-between text-muted text-sm">
          <span>{checkInDate} - {checkOutDate}</span>
          <span>{numberOfNights} nights</span>
        </div>
        {addons.restaurant && (
          <div className="flex justify-between">
            <span>Restaurant Reservation (Nov 1, 7 PM)</span>
            <span>${restaurantAddonPrice}.00</span>
          </div>
        )}
        {addons.sauna && (
          <div className="flex justify-between">
            <span>Sauna Session (Nov 2, 10 AM)</span>
            <span>${saunaAddonPrice}.00</span>
          </div>
        )}
        {addons.canoe && (
          <div className="flex justify-between">
            <span>Guided Canoe Trip (Nov 2, 2 people)</span>
            <span>${canoeTripAddonPrice}.00</span>
          </div>
        )}
        <div className="border-t border-muted/20 pt-4 mt-4 flex justify-between items-center text-lg font-bold">
          <span>Total Due</span>
          <span>${totalDue}.00</span>
        </div>
      </div>
    </div>
  );

  const slots = {
    hero: (
      <MarketingHero
        brandName={"Cedar Point Lodge"}
        headline={"Complete Your Reservation"}
        subcopy={"Finalize your tranquil escape. Secure your room and choose personalized experiences at Cedar Point Lodge."}
        primaryCta={{ label: "Review Booking", href: "#booking-details" }}
        imageSrc={images.hero} // Changed to a more suitable hero image
        imageAlt="A serene lakeside view at Cedar Point Lodge"
        className="mb-12"
      />
    ),
    credentials: (
      <CredentialStrip
        items={[
          { title: "Secure Booking", detail: "Your details are always protected." },
          { title: "Best Rate Guarantee", detail: "Booking direct ensures the best price." },
          { title: "Personalized Experience", detail: "Tailor your stay with our unique add-ons." },
        ]}
        className="mb-12"
      />
    ),
    process: (
      <ProcessSection
        heading="Your Reservation Journey"
        description="Follow these simple steps to confirm your stay at Cedar Point Lodge."
        steps={[
          { title: "Guest Details", description: "Tell us who you are." },
          { title: "Enhance Your Stay", description: "Add unique experiences." },
          { title: "Secure Payment", description: "Complete your booking safely." },
        ]}
        className="mb-12"
      />
    ),
    booking: (
      <BookingPanel
        heading="Finalize Your Stay"
        description="Please provide your details, select any desired add-ons, and complete your payment."
        confirmLabel="Confirm Booking"
        className="max-w-4xl mx-auto mb-12"
      >
        <div className="lg:grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Step 1: Guest Details */}
            {currentStep === 1 && (
              <div className="bg-surface p-8 rounded-lg shadow-sm">
                <h3 className="font-display text-2xl text-primary mb-6">1. Guest Details</h3>
                <form className="space-y-4">
                  <Input label="Full Name" placeholder="John Doe" required />
                  <Input label="Email Address" type="email" placeholder="john.doe@example.com" required />
                  <Input label="Phone Number" type="tel" placeholder="(555) 123-4567" required />
                  <Input label="Billing Address" placeholder="123 Lakeside Dr, Adirondacks, NY 12345" required />
                  <div className="flex items-center">
                    <Input id="create-account" type="checkbox" className="mr-2" />
                    <label htmlFor="create-account" className="text-sm text-muted">Create an account for faster future bookings</label>
                  </div>
                  <Button onClick={() => setCurrentStep(2)} className="w-full">Continue to Add-ons</Button>
                </form>
              </div>
            )}

            {/* Step 2: Add-ons Selection */}
            {currentStep === 2 && (
              <div className="bg-surface p-8 rounded-lg shadow-sm">
                <h3 className="font-display text-2xl text-primary mb-6">2. Enhance Your Stay</h3>
                <p className="text-muted mb-6">Select from our unique Cedar Point Lodge experiences.</p>
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 border border-muted/20 rounded-md">
                    <div className="flex items-center">
                      <Input id="restaurant" type="checkbox" checked={addons.restaurant} onChange={() => handleAddonToggle('restaurant')} className="mr-3" />
                      <label htmlFor="restaurant" className="text-lg font-medium text-text flex-grow">Restaurant Reservation <span className="text-sm text-muted">(Nov 1, 7 PM)</span></label>
                    </div>
                    <span className="text-primary font-semibold">${restaurantAddonPrice}.00</span>
                  </div>

                  <div className="flex items-center justify-between p-4 border border-muted/20 rounded-md">
                    <div className="flex items-center">
                      <Input id="sauna" type="checkbox" checked={addons.sauna} onChange={() => handleAddonToggle('sauna')} className="mr-3" />
                      <label htmlFor="sauna" className="text-lg font-medium text-text flex-grow">Sauna Session <span className="text-sm text-muted">(Nov 2, 10 AM)</span></label>
                    </div>
                    <span className="text-primary font-semibold">${saunaAddonPrice}.00</span>
                  </div>

                  <div className="flex items-center justify-between p-4 border border-muted/20 rounded-md">
                    <div className="flex items-center">
                      <Input id="canoe" type="checkbox" checked={addons.canoe} onChange={() => handleAddonToggle('canoe')} className="mr-3" />
                      <label htmlFor="canoe" className="text-lg font-medium text-text flex-grow">Guided Canoe Trip <span className="text-sm text-muted">(Nov 2, 2 people)</span></label>
                    </div>
                    <span className="text-primary font-semibold">${canoeTripAddonPrice}.00</span>
                  </div>
                </div>
                <div className="flex justify-between mt-8">
                  <Button variant="outline" onClick={() => setCurrentStep(1)}>Back to Details</Button>
                  <Button onClick={() => setCurrentStep(3)}>Proceed to Payment</Button>
                </div>
              </div>
            )}

            {/* Step 3: Payment Details */}
            {currentStep === 3 && (
              <div className="bg-surface p-8 rounded-lg shadow-sm">
                <h3 className="font-display text-2xl text-primary mb-6">3. Secure Payment</h3>
                <p className="text-muted mb-4">Your payment is securely processed. Accepted cards:</p>
                <div className="flex space-x-4 mb-6">
                  <UiIcon name="card-visa" className="h-8 w-auto text-muted" />
                  <UiIcon name="card-mastercard" className="h-8 w-auto text-muted" />
                  <UiIcon name="card-amex" className="h-8 w-auto text-muted" />
                </div>
                <form className="space-y-4">
                  <Input label="Credit Card Number" placeholder="XXXX XXXX XXXX XXXX" required />
                  <div className="flex space-x-4">
                    <Input label="Expiration Date" placeholder="MM/YY" className="w-1/2" required />
                    <Input label="CVC" placeholder="123" className="w-1/2" required />
                  </div>
                  <div className="flex justify-between items-center mt-6 p-4 bg-muted/5 rounded-md">
                    <span className="font-bold text-lg">Total Due:</span>
                    <span className="font-bold text-2xl text-primary">${totalDue}.00</span>
                  </div>
                  <div className="flex justify-between mt-8">
                    <Button variant="outline" onClick={() => setCurrentStep(2)}>Back to Add-ons</Button>
                    <Button type="submit" variant="default" className="text-lg px-8 py-3">Confirm & Pay</Button>
                  </div>
                </form>
              </div>
            )}
          </div>
          <div className="lg:col-span-1 mt-8 lg:mt-0 sticky top-4">
            {bookingSummary}
          </div>
        </div>
      </BookingPanel>
    ),
    footer: (
      <BrandFooter brandName={"Cedar Point Lodge"} description={"An eighteen-room lakeside lodge offering a serene escape, fine dining, and guided adventures. Book your direct Adirondack experience today."} />
    ),
  };

  return (
    <PublicShell brandName={"Cedar Point Lodge"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="booking-form">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
          <div id="dynamic-trip-itinerary-suggestions" data-ai-feature-panel="dynamic-trip-itinerary-suggestions">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "dynamic-trip-itinerary-suggestions") || { id: "dynamic-trip-itinerary-suggestions", name: "dynamic-trip-itinerary-suggestions" }}
          brandName={"Cedar Point Lodge"}
        />
      </div>
    </PublicShell>
  );
}