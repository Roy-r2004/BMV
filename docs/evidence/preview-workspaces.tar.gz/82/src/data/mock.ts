export const brand = {
  name: 'Cedar Point Lodge',
  tagline: 'Your tranquil lakeside retreat in the heart of the Adirondacks.',

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  services: [{"name": "Cedar Point Lodge Signature", "title": "Cedar Point Lodge Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Cedar Point Lodge experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Cedar Point Lodge experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Cedar", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Cedar Point Lodge clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/33534993/pexels-photo-33534993.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/9257999/pexels-photo-9257999.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/6716424/pexels-photo-6716424.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/7821340/pexels-photo-7821340.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/7821344/pexels-photo-7821344.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/30222143/pexels-photo-30222143.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item1": "https://images.pexels.com/photos/6466217/pexels-photo-6466217.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item2": "https://images.pexels.com/photos/3872908/pexels-photo-3872908.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item3": "https://images.pexels.com/photos/6394682/pexels-photo-6394682.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item4": "https://images.pexels.com/photos/9145354/pexels-photo-9145354.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item5": "https://images.pexels.com/photos/3872899/pexels-photo-3872899.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item6": "https://images.pexels.com/photos/36328107/pexels-photo-36328107.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item7": "https://images.pexels.com/photos/4820811/pexels-photo-4820811.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item8": "https://images.pexels.com/photos/9146376/pexels-photo-9146376.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "canoe-trips",
      "path": "/canoe-trips",
      "href": "/canoe-trips",
      "label": "Canoe Trips"
    },
    {
      "id": "dining",
      "path": "/dining",
      "href": "/dining",
      "label": "Dining"
    },
    {
      "id": "rooms",
      "path": "/rooms",
      "href": "/rooms",
      "label": "Rooms"
    },
    {
      "id": "sauna",
      "path": "/sauna",
      "href": "/sauna",
      "label": "Sauna"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "admin-rooms-rates",
      "path": "/admin/rooms-rates",
      "href": "/admin/rooms-rates",
      "label": "Rooms Rates"
    },
    {
      "id": "admin-bookings",
      "path": "/admin/bookings",
      "href": "/admin/bookings",
      "label": "Bookings"
    },
    {
      "id": "admin-add-ons",
      "path": "/admin/add-ons",
      "href": "/admin/add-ons",
      "label": "Add Ons"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "canoe-trips",
      "path": "/canoe-trips",
      "href": "/canoe-trips",
      "label": "Canoe Trips"
    },
    {
      "id": "dining",
      "path": "/dining",
      "href": "/dining",
      "label": "Dining"
    },
    {
      "id": "rooms",
      "path": "/rooms",
      "href": "/rooms",
      "label": "Rooms"
    }
  ],
  "lodge-manager": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "admin-rooms-rates",
      "path": "/admin/rooms-rates",
      "href": "/admin/rooms-rates",
      "label": "Rooms Rates"
    },
    {
      "id": "admin-bookings",
      "path": "/admin/bookings",
      "href": "/admin/bookings",
      "label": "Bookings"
    },
    {
      "id": "admin-add-ons",
      "path": "/admin/add-ons",
      "href": "/admin/add-ons",
      "label": "Add Ons"
    }
  ]
};

export const roles = [
  {
    "id": "customer",
    "label": "Guest",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "lodge-manager",
    "label": "Lodge Manager",
    "defaultPath": "/admin/dashboard",
    "icon": "chart"
  }
];

export const aiFeatures = [
  {
    id: 'personalized-room-recommendations',
    name: 'Personalized Room Recommendations',
    description:
      "Based on previous searches or stated preferences, suggest room types or packages that align with a guest's likely interests.",
    category: 'guest-experience',
    surface: 'recommendations',
    demo_hint: 'Simulate a guest’s preferences to get recommendations',
    demo_prompts: [
      'Suggest rooms for a couple seeking a romantic getaway in late fall',
      'Recommend family-friendly options for summer with canoe trips',
      'Show rooms for a solo traveler prioritizing peace and quiet',
    ],
    placement_label: 'Recommendations',
    demo_results: {
      'Suggest rooms for a couple seeking a romantic getaway in late fall':
        'For a romantic fall getaway, Lakeside King (Room 5) and Adirondack Suite (Room 18) are highly recommended, featuring fireplaces and private balconies.',
      'Recommend family-friendly options for summer with canoe trips':
        'Adirondack Double (Rooms 12, 14) or the Family Suite (Room 17) are ideal for families. Consider adding a guided canoe trip during booking.',
      'Show rooms for a solo traveler prioritizing peace and quiet':
        'The Forest View Queen (Room 8) or select Adirondack Single rooms offer maximum tranquility, located away from common areas.',
    },
    placement_path: '/rooms',
    placement_component: 'src/pages/RoomsOverviewPage.tsx',
    placement_title: 'Rooms & Suites - Cedar Point Lodge',
  },
  {
    id: 'dynamic-trip-itinerary-suggestions',
    name: 'Dynamic Trip Itinerary Suggestions',
    description:
      'Propose activity combinations (e.g., "Mornings at the lake, afternoon sauna relaxation, evening fine dining") based on booking dates and chosen add-ons.',
    category: 'trip-planning',
    surface: 'itinerary',
    demo_hint: 'Generate an itinerary based on a mock booking',
    demo_prompts: [
      'Create itinerary for a 3-night stay with Lakeside King, restaurant, and sauna',
      'Suggest activities for a family booking Adirondack Double, 4 nights, in July',
      'Build a relaxing weekend itinerary for a couple with no specific add-ons',
    ],
    placement_label: 'Itinerary AI',
    demo_results: {
      'Create itinerary for a 3-night stay with Lakeside King, restaurant, and sauna':
        'Day 1: Check-in, Dinner at Lakeside Dining (7 PM). Day 2: Morning hike, Afternoon Sauna (2 PM). Day 3: Lakeside breakfast, explore grounds. Day 4: Check-out.',
      'Suggest activities for a family booking Adirondack Double, 4 nights, in July':
        'Day 1: Check-in, board games. Day 2: Guided Canoe Trip (morning), lakeside picnic. Day 3: Local attractions (nearby), evening bonfire. Day 4: Fishing (morning). Day 5: Check-out.',
      'Build a relaxing weekend itinerary for a couple with no specific add-ons':
        'Friday: Check-in, quiet dinner. Saturday: Scenic drive, spa treatment, stargazing. Sunday: Brunch, gentle walk, check-out.',
    },
    placement_path: '/book',
    placement_component: 'src/pages/BookingFormPage.tsx',
    placement_title: 'Complete Your Reservation - Cedar Point Lodge',
  },
  {
    id: 'intelligent-availability-insights',
    name: 'Intelligent Availability Insights',
    description:
      'Analyze booking patterns to predict peak demand and suggest optimal pricing or staffing adjustments for lodge management.',
    category: 'operations',
    surface: 'insights',
    demo_hint: 'Request insights for upcoming periods',
    demo_prompts: [
      'Predict occupancy for next month and recommend pricing adjustments',
      'Identify potential staffing needs for the holiday season',
      'Analyze canoe trip booking trends for optimal scheduling',
    ],
    placement_label: 'Operational Insights',
    demo_results: {
      'Predict occupancy for next month and recommend pricing adjustments':
        'Next month: 85% predicted occupancy. Recommend 5% price increase for weekends, 2% discount for Tuesday/Wednesday nights to balance demand.',
      'Identify potential staffing needs for the holiday season':
        'Holiday season: Anticipate 100% occupancy. Need 2 additional restaurant staff, 1 extra spa attendant, and flexible canoe trip guides.',
      'Analyze canoe trip booking trends for optimal scheduling':
        'Canoe trips see 70% morning preference, 30% afternoon. Consider adding an early morning slot or reducing afternoon availability on weekdays.',
    },
    placement_path: '/admin',
    placement_component: 'src/pages/admin/AdminDashboardPage.tsx',
    placement_title: 'Cedar Point Lodge: Daily Operations',
  },
];

export const seed = {
  featuresHeading: 'What Cedar Point Lodge offers',
  showcaseHeading: 'From Cedar Point Lodge',
  credentialsHeading: 'Why Cedar Point Lodge',
  trustLabels: [
    'Cedar Point Lodge quality\', \'On schedule\', \'Repeat guests\', \'Local favorite',
  ],
  hero: {
    headline: 'Your Lakeside Escape Awaits in the Adirondacks',
    subcopy: 'Discover Cedar Point Lodge: where comfort meets nature, and unforgettable memories are made.',
    primaryCta: {
      label: 'Check Availability',
      href: '/rooms',
    },
    secondaryCta: {
      label: 'Explore Rooms',
      href: '/rooms',
    },
  },
  credentials: [
    { title: 'Trusted by Travelers', detail: 'Consistently rated 5-stars for service and serenity.' },
    { title: 'Adirondack Charm', detail: 'Nestled perfectly to offer both comfort and adventure.' },
    { title: 'Direct Booking Advantage', detail: 'Best rates and personalized service.' },
  ],
  features: [
    {
      title: 'Intimate Accommodations',
      description: 'Eighteen uniquely designed rooms, each a sanctuary of comfort and charm.',
      imageSrc: images.item7,
    },
    {
      title: 'Lakeside Dining',
      description: 'Enjoy locally-sourced cuisine with breathtaking lake views at our signature restaurant.',
      imageSrc: images.item3,
    },
    {
      title: 'Adirondack Sauna',
      description: 'Rejuvenate in our traditional sauna, perfect after a day of exploration.',
      imageSrc: images.item4,
    },
    {
      title: 'Guided Canoe Trips',
      description: 'Paddle the serene waters of the lake with our experienced guides.',
      imageSrc: images.item5,
    },
  ],
  showcase: [
    {
      title: 'Lakeside King Room',
      description: 'Spacious room with a plush king bed, private balcony, and panoramic views of the tranquil lake.',
      imageSrc: images.item1,
      href: '/rooms/lakeside-king',
      cta: { label: 'View Details', href: '/rooms/lakeside-king' },
    },
    {
      title: 'Adirondack Double Room',
      description: 'Cozy and comfortable, featuring two double beds, perfect for families or small groups.',
      imageSrc: images.item2,
      href: '/rooms/adirondack-double',
      cta: { label: 'View Details', href: '/rooms/adirondack-double' },
    },
  ],
  testimonials: [
    {
      quote: "A truly magical stay! The lodge is beautiful, the food exceptional, and the canoe trip was the highlight of our vacation.",
      author: "Emily R.",
      role: "Guest",
    },
    {
      quote: "Booking direct was so easy, and the personalized recommendations for our stay were spot on. Can't wait to return!",
      author: "David S.",
      role: "Guest",
    },
    {
      quote: "The sauna was incredibly relaxing after a day exploring the trails. Cedar Point Lodge offers the perfect blend of luxury and nature.",
      author: "Jessica T.",
      role: "Guest",
    },
    {
      quote: "Every detail was perfect, from the comfortable bed to the delicious breakfast. We felt truly pampered.",
      author: "Michael P.",
      role: "Guest",
    },
  ],
  testimonialsHeading: 'What Our Guests Say',
  cta: {
    heading: 'Ready for Your Adirondack Escape?',
    description: 'Book your direct stay at Cedar Point Lodge and experience serene lakeside luxury.',
    primaryLabel: 'Check Availability',
    primaryHref: '/rooms',
    secondaryLabel: 'Explore All Rooms',
    secondaryHref: '/rooms',
  },
  footer: {
    description: 'Cedar Point Lodge – Your tranquil lakeside retreat in the heart of the Adirondacks.',
  },
  opsHero: {
    headline: 'Cedar Point Lodge: Daily Operations',
    subcopy: 'A clear overview of today\'s bookings, arrivals, and guest requests.',
  },
  kpis: [
    {
      label: 'Arrivals Today',
      value: '3',
      delta: '+1',
      hint: 'since yesterday',
    },
    {
      label: 'Occupancy Rate',
      value: '75%',
      delta: '+5%',
      hint: 'for current week',
    },
    {
      label: 'New Bookings',
      value: '2',
      delta: '0',
      hint: 'in last 24h',
    },
  ],
  tableRows: [
    {
      id: 'BKL-001',
      guest: 'The Andersons',
      room: 'Lakeside King - #5',
      checkIn: 'Today, 3 PM',
      checkOut: 'Nov 7',
      status: 'Confirmed',
      request: 'Extra pillows',
    },
    {
      id: 'BKL-002',
      guest: 'Ms. Chen',
      room: 'Adirondack Double - #12',
      checkIn: 'Yesterday',
      checkOut: 'Today, 11 AM',
      status: 'Checked Out',
      request: 'Late check-out approved',
    },
    {
      id: 'BKL-003',
      guest: 'Mr. & Mrs. Rodriguez',
      room: 'Lakeside King - #6',
      checkIn: 'Nov 2, 3 PM',
      checkOut: 'Nov 5',
      status: 'Pending',
      request: 'Window seat for dining',
    },
    {
      id: 'BKL-004',
      guest: 'David & Emily Green',
      room: 'Forest View Queen - #8',
      checkIn: 'Nov 3, 3 PM',
      checkOut: 'Nov 6',
      status: 'Confirmed',
      request: 'Vegan breakfast option',
    },
    {
      id: 'BKL-005',
      guest: 'Olivia Wilson',
      room: 'Adirondack Single - #1',
      checkIn: 'Today, 3 PM',
      checkOut: 'Nov 4',
      status: 'Confirmed',
      request: 'Quiet room preferred',
    },
    {
      id: 'BKL-006',
      guest: 'Robert Johnson',
      room: 'Lakeside King - #7',
      checkIn: 'Nov 8, 3 PM',
      checkOut: 'Nov 10',
      status: 'Confirmed',
      request: 'Sauna session booked',
    },
    {
      id: 'BKL-007',
      guest: 'Sophia Lee',
      room: 'Adirondack Double - #14',
      checkIn: 'Nov 1, 3 PM',
      checkOut: 'Nov 3',
      status: 'Checked Out',
      request: 'Canoe trip reservation',
    },
    {
      id: 'BKL-008',
      guest: 'William Davis',
      room: 'Family Suite - #17',
      checkIn: 'Nov 10, 3 PM',
      checkOut: 'Nov 14',
      status: 'Pending',
      request: 'Children amenities',
    },
  ],
  activity: [
    {
      title: 'Guest Jane Doe booked Lakeside King for 3 nights.',
      detail: 'Confirmation #CP1001.',
      when: 'Just now',
    },
    {
      title: 'Room 8 (Adirondack Double) marked available.',
      detail: 'Updated by Manager Sarah.',
      when: '15 minutes ago',
    },
    {
      title: 'New inquiry from potential guest regarding canoe trip dates.',
      detail: 'Forwarded to Activities Coordinator.',
      when: '1 hour ago',
    },
    {
      title: 'Payment received for BKL-003 (Mr. & Mrs. Rodriguez).',
      detail: 'Amount: $850.00.',
      when: '2 hours ago',
    },
    {
      title: 'Restaurant reservation for The Andersons added.',
      detail: 'Table for 2 at 7 PM tonight.',
      when: '3 hours ago',
    },
    {
      title: 'Reminder sent to guests checking in tomorrow.',
      detail: '3 guests notified.',
      when: '5 hours ago',
    },
  ],
  risks: [
    {
      id: 'risk-1',
      title: 'Upcoming high-demand weekend at 95% occupancy',
      detail: 'Review staffing for restaurant and activities. Consider pre-stocking amenities.',
      severity: 'medium',
    },
    {
      id: 'risk-2',
      title: 'Forecasted heavy rain for upcoming guided canoe trips',
      detail: 'Prepare alternative indoor activities or offer rescheduling options to guests.',
      severity: 'high',
    },
    {
      id: 'risk-3',
      title: 'Sauna maintenance scheduled, potential downtime',
      detail: 'Notify guests with existing sauna bookings and offer alternative slots or compensation.',
      severity: 'low',
    },
  ],
  chartData: [
    { label: 'Jan', value: 65 },
    { label: 'Feb', value: 70 },
    { label: 'Mar', value: 75 },
    { label: 'Apr', value: 60 },
    { label: 'May', value: 80 },
    { label: 'Jun', value: 90 },
    { label: 'Jul', value: 95 },
    { label: 'Aug', value: 88 },
    { label: 'Sep', value: 78 },
    { label: 'Oct', value: 82 },
    { label: 'Nov', value: 75 },
    { label: 'Dec', value: 92 },
  ],
  items: [
    {
      id: 'lakeside-king',
      title: 'Lakeside King',
      description: 'Spacious room with a plush king bed, private balcony, and panoramic views of the tranquil lake. Includes a gas fireplace and a large ensuite bathroom with a soaking tub.',
      image: images.item1,
      medium: 'Accommodation',
      dimensions: '450 sq ft',
      price: '$450/night',
      status: 'Available',
      category: 'Premium Suites',
      amenities: [
        'King-size bed\', \'Private lakeside balcony\', \'Gas fireplace\', \'Ensuite bathroom with soaking tub',
        'High-speed Wi-Fi\', \'Flat-screen TV\', \'Mini-fridge\', \'Complimentary Adirondack coffee',
      ],
      gallery: [images.item1, images.item7, images.hero2]
    },
    {
      id: 'adirondack-double',
      title: 'Adirondack Double',
      description: 'Cozy and comfortable, featuring two double beds, perfect for families or small groups. Views of the lush forest surrounding the lodge.',
      image: images.item2,
      medium: 'Accommodation',
      dimensions: '350 sq ft',
      price: '$300/night',
      status: 'Available',
      category: 'Standard Rooms',
      amenities: [
        'Two double beds\', \'Forest view\', \'Spacious bathroom with shower',
        'High-speed Wi-Fi\', \'Flat-screen TV\', \'Mini-fridge\', \'Complimentary Adirondack coffee',
      ],
      gallery: [images.item2, images.card1, images.item6]
    },
    {
      id: 'forest-view-queen',
      title: 'Forest View Queen',
      description: 'A serene retreat with a comfortable queen bed and picturesque views of the surrounding Adirondack forest. Ideal for couples or solo travelers seeking tranquility.',
      image: images.item8,
      medium: 'Accommodation',
      dimensions: '300 sq ft',
      price: '$280/night',
      status: 'Available',
      category: 'Standard Rooms',
      amenities: [
        'Queen-size bed\', \'Forest view\', \'Ensuite bathroom with shower',
        'High-speed Wi-Fi\', \'Flat-screen TV\', \'Mini-fridge\', \'Complimentary Adirondack coffee',
      ],
      gallery: [images.item8, images.card2, images.item6]
    },
    {
      id: 'family-suite',
      title: 'Family Suite',
      description: 'Our most spacious option, designed for families with a king bed in the main area and a separate room with bunk beds. Features a large living area and partial lake views.',
      image: images.item4,
      medium: 'Accommodation',
      dimensions: '600 sq ft',
      price: '$600/night',
      status: 'Available',
      category: 'Premium Suites',
      amenities: [
        'King-size bed\', \'Bunk beds\', \'Separate living area\', \'Partial lake view',
        'Two bathrooms\', \'High-speed Wi-Fi\', \'Flat-screen TVs\', \'Mini-fridge',
        'Complimentary Adirondack coffee & snacks',
      ],
      gallery: [images.card3, images.item6, images.hero]
    }
  ],
  addOns: [
    {
      id: 'restaurant-reservation',
      name: 'Lakeside Dining Reservation',
      description: 'Book a table at our signature restaurant, offering locally-sourced cuisine with stunning lake views.',
      price: 0, // Price is per meal, not for the reservation itself
      type: 'Dining',
      capacity: 'Table for 2-8',
      availability: 'Daily, 5 PM - 9 PM',
      image: images.item3
    },
    {
      id: 'sauna-session',
      name: 'Private Sauna Session',
      description: 'Rejuvenate in our traditional Finnish sauna. Private 60-minute sessions available.',
      price: 60,
      type: 'Wellness',
      capacity: 'Up to 4 people',
      availability: 'Daily, 9 AM - 8 PM',
      image: images.item4
    },
    {
      id: 'guided-canoe-trip',
      name: 'Guided Canoe Trip',
      description: 'Explore the serene waters of the Adirondacks with an experienced guide. 2-hour trips.',
      price: 75, // Per person
      type: 'Activity',
      capacity: 'Up to 4 people per trip',
      availability: 'Tues, Thurs, Sat, Sun: 9 AM & 2 PM',
      image: images.item5
    },
  ]
,
  services: "Services — Cedar Point Lodge",
};
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;