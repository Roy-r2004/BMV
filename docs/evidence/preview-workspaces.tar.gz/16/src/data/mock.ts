export const brand = {
  name: "Jane Art Gallery",
  tagline: "Discover a curated collection of exquisite art where every canvas tells a story.",
  owner_name: "Eleanor Vance",
  about_bio_short: "Eleanor Vance is a passionate art curator and collector with over two decades of experience in the fine art world. Her keen eye for emerging talent and dedication to aesthetic excellence have shaped Jane Art Gallery into a celebrated space for contemporary works. Eleanor believes art should be accessible and inspiring, fostering a deeper connection between artist and admirer.",
  about_gallery_story: "Founded in 2008, Jane Art Gallery began as a small, intimate space dedicated to showcasing local artists. Over the years, it has grown into a renowned online gallery, carefully curating a diverse collection that spans various mediums and styles. Our mission remains steadfast: to connect art lovers with exceptional, meaningful pieces that enrich their lives and homes. We pride ourselves on a personalized and warm approach, ensuring every acquisition is a cherished experience.",
  design_system: {
    primary_color: "#0f766e",
    secondary_color: "#0369a1",
    background_color: "#f8fafc",
    surface_color: "#ffffff",
    text_color: "#042f2e",
    muted_text_color: "#5f7a78",
    font_family: "Source Sans 3",
    display_font_family: "Fraunces",
    font_import_url:
      "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    font_sans: "\"Source Sans 3\", \"Segoe UI\", sans-serif",
    font_display: "\"Fraunces\", Georgia, serif",
    brand_locked: true,
    brand_brief_version: "1.0",
    mood: "modern",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature: "A calm full-bleed atmosphere with Jane Art as the hero signal, not a card grid.",
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    recipe_id: "editorial",
    hub_variant: "marketing",
    hero_variant: "cinematic",
    feature_variant: "alternating",
    recipe_prompt:
      "RECIPE editorial: generous whitespace, serif/display headlines via font-display, fewer cards, longer subcopy, cinematic imagery with kenburns/grain, layered atmosphere, avoid dense tables on public pages, motion on every major section. TEMPLATE agency-portfolio-home: Portfolio gravity — oversized type, case imagery, sparse but rich sections. Signature moves: cinematic hero, case showcase, alternating features.",
    style_keywords: "Editorial",
    border_radius: "0.35rem",
  },

  services: [{"name": "Jane Art Gallery Signature", "title": "Jane Art Gallery Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jane Art Gallery experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jane Art Gallery experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jane", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jane Art Gallery clients.",
};

export const images = {
  hero: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1600&q=80&fit=crop&auto=format",
  hero2: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1600&q=80&fit=crop&auto=format",
  card1: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=900&q=80&fit=crop&auto=format",
  card2: "https://images.unsplash.com/photo-1553877522-43269d4ea984?w=900&q=80&fit=crop&auto=format",
  card3: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=900&q=80&fit=crop&auto=format",
  ambient: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=900&q=80&fit=crop&auto=format",
  about_owner: "https://images.unsplash.com/photo-152033376740c-2fcb0ae6013a?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fGFydGlzdCUyMHBvcnRyYWl0fGVufDB8fDB8fHww"
};

export const roles = [
  {
    "id": "ROLE-PUBLIC-VISITOR",
    "label": "Public Visitor",
    "defaultPath": "/",
    "icon": "users"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home Page"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "gallery-paintingid",
      "path": "/gallery/paintingid",
      "href": "/gallery/paintingid",
      "label": "Painting Detail Page"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Page"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    }
  ],
  "admin": [],
  "ROLE-PUBLIC-VISITOR": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home Page"
    },
    {
      "id": "gallery",
      "path": "/gallery",
      "href": "/gallery",
      "label": "Gallery"
    },
    {
      "id": "gallery-paintingid",
      "path": "/gallery/paintingid",
      "href": "/gallery/paintingid",
      "label": "Painting Detail Page"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact Page"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    }
  ]
};

export const stats = [
  { label: 'Total Sales', value: '$25,000', change: '+10% from last month' },
  { label: 'Artworks Sold', value: '50', change: '+5% from last month' },
  { label: 'New Inquiries', value: '12', change: '+20% from last month' },
  { label: 'Website Visitors', value: '1,200', change: '+15% from last month' },
];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
