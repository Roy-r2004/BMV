import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  PublicShell,
  PublicNav,
  MarketingHero,
  FeatureBento,
  ProductShowcase,
  ProcessSection,
  TestimonialRail,
  CTABand,
  BrandFooter,
  Button,
  getSkeleton,
  SkeletonComposer,
} from '@/ui';

import { brand, images } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';

// Mock data for featured and recent paintings
// In a real app, this would come from an API or comprehensive mock data
const FEATURED_PAINTINGS = [
  {
    title: 'Coastal Serenity',
    tagline: 'Featured',
    imageSrc: images.hero,
    link: '/gallery/1',
  },
  {
    title: 'Urban Echoes',
    tagline: 'Featured',
    imageSrc: images.hero2,
    link: '/gallery/2',
  },
  {
    title: 'Verdant Dream',
    tagline: 'Featured',
    imageSrc: images.ambient,
    link: '/gallery/3',
  },
];

const RECENT_WORKS = [
  {
    slug: 'sunset-over-tuscan-hills',
    title: 'Sunset Over Tuscan Hills',
    price: 3200,
    medium: 'Oil on Canvas',
    dimensions: '24 x 36 inches',
    imageSrc: images.abstract1,
    artist: 'Jane Doe',
    link: '/gallery/4',
  },
  {
    slug: 'city-at-dawn',
    title: 'City at Dawn',
    price: 1800,
    medium: 'Acrylic on Wood',
    dimensions: '30 x 40 inches',
    imageSrc: images.hero,
    artist: 'John Smith',
    link: '/gallery/5',
  },
  {
    slug: 'forest-whispers',
    title: 'Forest Whispers',
    price: 2500,
    medium: 'Watercolor',
    dimensions: '18 x 24 inches',
    imageSrc: images.ambient,
    artist: 'Emily White',
    link: '/gallery/6',
  },
  {
    slug: 'desert-solitude',
    title: 'Desert Solitude',
    price: 2900,
    medium: 'Mixed Media',
    dimensions: '20 x 28 inches',
    imageSrc: images.abstract2,
    artist: 'Michael Brown',
    link: '/gallery/7',
  },
];

const ART_FEATURES = [
  {
    title: 'Curated Collection',
    description: 'Discover hand-picked artworks from emerging and established artists.',
    icon: 'GalleryVertical',
  },
  {
    title: 'Authenticity Guaranteed',
    description: 'Each piece comes with a certificate of authenticity and provenance.',
    icon: 'FileCheck2',
  },
  {
    title: 'Secure Worldwide Shipping',
    description: 'Your art is carefully packaged and shipped with insurance globally.',
    icon: 'Package',
  },
  {
    title: 'Personalized Consultation',
    description: 'Receive expert advice on building your collection and finding the perfect piece.',
    icon: 'MessageSquare',
  },
];

const ART_PROCESS_STEPS = [
  {
    title: 'Discover',
    description: 'Browse our diverse online gallery or explore curated collections.',
  },
  {
    title: 'Connect',
    description: 'Learn about the artist behind the work and delve into their inspiration.',
  },
  {
    title: 'Acquire',
    description: 'Secure your chosen artwork with confidence through our seamless purchasing process.',
  },
  {
    title: 'Enjoy',
    description: 'Receive your artwork beautifully packaged, ready to adorn your space.',
  },
];

const ART_TESTIMONIALS = [
  {
    name: 'Sarah J.',
    title: 'Art Collector',
    quote: 'Jane Art Gallery helped me find the perfect centerpiece for my living room. The quality and service were exceptional!',
    imageSrc: images.avatar1,
  },
  {
    name: 'David L.',
    title: 'Interior Designer',
    quote: 'I rely on Jane Art Gallery for unique pieces that elevate my projects. Their selection is consistently inspiring.',
    imageSrc: images.avatar2,
  },
  {
    name: 'Emily R.',
    title: 'First-time Buyer',
    quote: 'As a new collector, I appreciated the guidance and support. My first original artwork purchase was a wonderful experience.',
    imageSrc: images.avatar3,
  },
];

const FOOTER_LINKS = [
  { label: 'Privacy Policy', href: '/privacy' },
  { label: 'Terms of Service', href: '/terms' },
];

const SKELETON_ID = 'public-home' as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const [currentFeaturedIndex, setCurrentFeaturedIndex] = useState(0);
  const skeleton = getSkeleton(SKELETON_ID);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentFeaturedIndex((prevIndex) => (prevIndex + 1) % FEATURED_PAINTINGS.length);
    }, 5000); // Change featured painting every 5 seconds
    return () => clearInterval(timer);
  }, []);

  const featured = FEATURED_PAINTINGS[currentFeaturedIndex];

  const slots = {
    hero: (
      <MarketingHero
        brandName={brand.name}
        headline={featured.title}
        subcopy={brand.tagline}
        primaryCta={{
          children: 'Explore the Collection',
          href: '/gallery',
          variant: 'default',
          size: 'lg',
        }}
        imageSrc={featured.imageSrc}
        imageAlt={featured.title}
        className="relative min-h-[70vh] flex items-center justify-center text-center text-ivory-800" // Apply text color
        eyebrow="Featured"
        data-appspec-evidence="EVIDENCE-HOME-HERO-SECTION"
      >
        {/* Layered atmosphere and texture overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-[1]"></div>
        <div className="absolute inset-0 ui-film-grain opacity-40 z-[2]"></div>
      </MarketingHero>
    ),
    features: (
      <FeatureBento
        heading="Why Choose Jane Art Gallery?"
        description="Dedicated to bringing you exquisite art and an unparalleled collecting experience."
        items={ART_FEATURES.map((feature, i) => ({
          ...feature,
          icon: <span className="h-8 w-8">{feature.icon}</span>, // Placeholder for actual icon component
        }))}
      />
    ),
    showcase: (
      <ProductShowcase
        heading="Recent Works"
        description="Discover the latest additions to our curated collection."
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {RECENT_WORKS.map((work) => (
            <Link to={work.link} key={work.slug} className="group block">
              <div className="relative overflow-hidden rounded-lg shadow-lg aspect-[3/4]">
                <img
                  src={work.imageSrc}
                  alt={work.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <h3 className="text-white text-lg font-semibold">{work.title}</h3>
                </div>
              </div>
              <p className="mt-2 text-sm text-gray-700 font-medium">{work.artist}</p>
              <p className="text-gray-900 font-bold">${work.price}</p>
            </Link>
          ))}
        </div>
      </ProductShowcase>
    ),
    process: (
      <ProcessSection
        heading="Our Simple Art Acquisition Process"
        description="Building your art collection has never been easier."
        steps={ART_PROCESS_STEPS}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading="What Our Collectors Say"
        items={ART_TESTIMONIALS.map((testimonial) => ({
          ...testimonial,
          imageSrc: testimonial.imageSrc,
          imageAlt: testimonial.name,
        }))}
      />
    ),
    cta: (
      <CTABand
        heading="Ready to Begin Your Collection?"
        description="Explore original artworks, connect with artists, and find your next cherished piece."
        primaryCta={{
          children: 'Visit the Gallery',
          href: '/gallery',
          variant: 'default',
        }}
        secondaryCta={{
          children: 'Contact Us',
          href: '/contact',
          variant: 'secondary',
        }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={brand.name}
        description="Discover a curated collection of exquisite art where every canvas tells a story."
        links={FOOTER_LINKS}
        meta="© 2024 Jane Art Gallery. All rights reserved."
      />
    ),
  };

  return (
    <PublicShell
      brandName={brand.name}
      nav={<PublicNav items={navItems} cta={navCta} />}
      footer={slots.footer} // Pass the footer slot to PublicShell
      chrome="solid"
    >
      <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
    </PublicShell>
  );
}