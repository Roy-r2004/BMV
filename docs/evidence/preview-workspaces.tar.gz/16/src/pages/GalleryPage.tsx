import React, { useState, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  PublicShell,
  MarketingHero,
  ProductShowcase,
  BrandFooter,
  Button,
  UiIcon,
  Select,
  getSkeleton,
  SkeletonComposer,
  PublicNav,
} from '@/ui';
import { brand, images } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
// Assuming publicCta is removed based on critic notes

const SKELETON_ID = 'public-catalog' as const;
const skeleton = getSkeleton(SKELETON_ID);

interface Painting {
  id: string;
  title: string;
  category: string;
  availability: 'Available' | 'Sold' | 'On Hold';
  year: number;
  price: number;
  medium: string;
  imageSrc: string;
}

const allPaintings: Painting[] = [
  {
    id: 'whisper-of-the-forest',
    title: 'Whisper of the Forest',
    category: 'Landscape',
    availability: 'Available',
    year: 2023,
    price: 3200,
    medium: 'Oil on Canvas',
    imageSrc: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=900&q=80&fit=crop&auto=format',
  },
  {
    id: 'golden-hour-fields',
    title: 'Golden Hour Fields',
    category: 'Landscape',
    availability: 'Sold',
    year: 2022,
    price: 4500,
    medium: 'Acrylic on Wood',
    imageSrc: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?w=1400&q=80&fit=crop&auto=format',
  },
  {
    id: 'abstract-serenity',
    title: 'Abstract Serenity',
    category: 'Abstract',
    availability: 'Available',
    year: 2023,
    price: 2800,
    medium: 'Mixed Media',
    imageSrc: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=1400&q=80&fit=crop&auto=format',
  },
  {
    id: 'autumns-embrace',
    title: 'Autumn\'s Embrace',
    category: 'Landscape',
    availability: 'On Hold',
    year: 2021,
    price: 3900,
    medium: 'Watercolor',
    imageSrc: 'https://images.unsplash.com/photo-1579895696144-ad7c5019a775?w=900&q=80&fit=crop&auto=format',
  },
  {
    id: 'ocean-depths',
    title: 'Ocean Depths',
    category: 'Abstract',
    availability: 'Available',
    year: 2023,
    price: 5200,
    medium: 'Oil on Linen',
    imageSrc: 'https://images.unsplash.com/photo-1516086657929-e58f00030559?w=900&q=80&fit=crop&auto=format',
  },
  {
    id: 'mountain-majesty',
    title: 'Mountain Majesty',
    category: 'Landscape',
    availability: 'Available',
    year: 2022,
    price: 6100,
    medium: 'Acrylic on Canvas',
    imageSrc: 'https://images.unsplash.com/photo-1506197603052-3afd9f867f3a?w=900&q=80&fit=crop&auto=format',
  },
  {
    id: 'portrait-of-elaine',
    title: 'Portrait of Elaine',
    category: 'Portrait',
    availability: 'Available',
    year: 2023,
    price: 8500,
    medium: 'Oil on Wood Panel',
    imageSrc: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=900&q=80&fit=crop&auto=format',
  },
  {
    id: 'still-life-with-pears',
    title: 'Still Life with Pears',
    category: 'Still Life',
    availability: 'Sold',
    year: 2021,
    price: 1200,
    medium: 'Graphite on Paper',
    imageSrc: 'https://images.unsplash.com/photo-1547496660-bf8df6891632?w=900&q=80&fit=crop&auto=format',
  },
  {
    id: 'urban-reflections',
    title: 'Urban Reflections',
    category: 'Cityscape',
    availability: 'Available',
    year: 2023,
    price: 2950,
    medium: 'Acrylic on Canvas',
    imageSrc: 'https://images.unsplash.com/photo-1506744038136-462738325bdf?w=900&q=80&fit=crop&auto=format',
  },
  {
    id: 'desert-blossom',
    title: 'Desert Blossom',
    category: 'Landscape',
    availability: 'On Hold',
    year: 2022,
    price: 3750,
    medium: 'Pastel on Paper',
    imageSrc: 'https://images.unsplash.com/photo-1518779578993-ec3579ee3cc1?w=900&q=80&fit=crop&auto=format',
  },
];

type FilterState = {
  category: string;
  availability: string;
  sortBy: string;
};

export default function GalleryPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const navigate = useNavigate();

  const [filterState, setFilterState] = useState<FilterState>({
    category: 'All',
    availability: 'All',
    sortBy: 'Default',
  });

  const categories = useMemo(() => ['All', ...new Set(allPaintings.map(p => p.category))], []);
  const availabilityOptions = useMemo(() => ['All', 'Available', 'Sold', 'On Hold'], []);
  const sortByOptions = useMemo(() => [
    'Default',
    'Year (Newest)',
    'Year (Oldest)',
    'Price (High to Low)',
    'Price (Low to High)',
  ], []);

  const filteredAndSortedPaintings = useMemo(() => {
    let result = [...allPaintings];

    if (filterState.category !== 'All') {
      result = result.filter(p => p.category === filterState.category);
    }
    if (filterState.availability !== 'All') {
      result = result.filter(p => p.availability === filterState.availability);
    }

    switch (filterState.sortBy) {
      case 'Year (Newest)':
        result.sort((a, b) => b.year - a.year);
        break;
      case 'Year (Oldest)':
        result.sort((a, b) => a.year - b.year);
        break;
      case 'Price (High to Low)':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'Price (Low to High)':
        result.sort((a, b) => a.price - b.price);
        break;
    }
    return result;
  }, [filterState.category, filterState.availability, filterState.sortBy]);

  // Handler for custom dropdowns
  const handleFilterChange = (filterType: keyof FilterState, value: string) => {
    setFilterState(prevState => ({ ...prevState, [filterType]: value }));
  };

  const slots = {
    hero: (
      <MarketingHero
        brandName={brand.name}
        headline="The Collection"
        subcopy="Explore our curated selection of fine art. Each piece tells a unique story, waiting to find its new home."
        primaryCta={{ children: 'View All Works', href: '/gallery', size: 'lg' }} // This CTA is for the hero, not navigation.
        imageSrc={images.hero}
        imageAlt="Elegant artwork in a gallery setting"
        className="text-brand-light bg-brand-base" // Apply brand-specific base color for hero
        data-appspec-evidence="EVIDENCE-GALLERY-AESTHETIC"
        // Applying subtle texture via a pseudo-element or overlay if supported by MarketingHero
        // For simplicity, direct texture or grain effect not directly applied to MarketingHero from its props.
        // Would be handled by global CSS or a custom hero component if more complex texture was needed.
      />
    ),
    showcase: (
      <ProductShowcase
        heading="Discover Available Masterpieces"
        description="Filter and sort to find the perfect addition to your collection."
        className="py-16 lg:py-24 max-w-7xl mx-auto px-6 bg-brand-base relative" // Add base background color
        data-appspec-page="PAGE-GALLERY"
      >
        {/* Subtle texture overlay for paper grain feel */}
        <div className="absolute inset-0 pointer-events-none opacity-20" style={{ backgroundImage: 'url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAADCAYAAABWKkFgAAAADklEQVQIW2NgQAOMECggCAAZUgyPAwAAAAxJREFUeJxjYIACBNMECgAAAgADpWwWjAAAAABJRU5ErkJggg==")' }}></div>

        {/* Filter and Sort Controls */}
        <div className="flex flex-wrap gap-4 justify-center md:justify-start mb-12 relative z-10" data-appspec-evidence="EVIDENCE-GALLERY-FILTER-CONTROLS">
          {/* Custom Select for Category */}
          <div className="custom-select-wrapper">
            <Select
              value={filterState.category}
              onValueChange={(value) => handleFilterChange('category', value)}
              options={categories.map(cat => ({ value: cat, label: cat }))}
              placeholder="Filter by Category"
              name="category-filter"
              id="category-filter"
              label="Category"
              className="w-48 bg-brand-surface text-brand-text font-sans border border-brand-accent-light focus:border-brand-accent rounded-sm shadow-sm
                        hover:bg-brand-accent-light transition-colors duration-200 [&>button]:py-2 [&>button]:px-4 [&>button]:text-left [&>button]:justify-between
                        [&>button]:w-full [&>button]:relative [&>button]:font-sans
                        [&>button>span:last-child]:absolute [&>button>span:last-child]:right-3
                        [&>div]:bg-brand-surface [&>div]:border [&>div]:border-brand-border [&>div]:rounded-sm"
              data-appspec-action="ACTION-APPLY-GALLERY-FILTER"
            />
          </div>

          {/* Custom Select for Availability */}
          <div className="custom-select-wrapper">
            <Select
              value={filterState.availability}
              onValueChange={(value) => handleFilterChange('availability', value)}
              options={availabilityOptions.map(opt => ({ value: opt, label: opt }))}
              placeholder="Filter by Status"
              name="availability-filter"
              id="availability-filter"
              label="Availability Status"
              className="w-48 bg-brand-surface text-brand-text font-sans border border-brand-accent-light focus:border-brand-accent rounded-sm shadow-sm
                        hover:bg-brand-accent-light transition-colors duration-200 [&>button]:py-2 [&>button]:px-4 [&>button]:text-left [&>button]:justify-between
                        [&>button]:w-full [&>button]:relative [&>button]:font-sans
                        [&>button>span:last-child]:absolute [&>button>span:last-child]:right-3
                        [&>div]:bg-brand-surface [&>div]:border [&>div]:border-brand-border [&>div]:rounded-sm"
              data-appspec-action="ACTION-APPLY-GALLERY-FILTER"
            />
          </div>

          {/* Custom Select for Sort By */}
          <div className="custom-select-wrapper" data-appspec-evidence="EVIDENCE-GALLERY-SORT-CONTROLS">
            <Select
              value={filterState.sortBy}
              onValueChange={(value) => handleFilterChange('sortBy', value)}
              options={sortByOptions.map(opt => ({ value: opt, label: opt }))}
              placeholder="Sort by"
              name="sort-by"
              id="sort-by"
              label="Sort by"
              className="w-48 bg-brand-surface text-brand-text font-sans border border-brand-accent-light focus:border-brand-accent rounded-sm shadow-sm
                        hover:bg-brand-accent-light transition-colors duration-200 [&>button]:py-2 [&>button]:px-4 [&>button]:text-left [&>button]:justify-between
                        [&>button]:w-full [&>button]:relative [&>button]:font-sans
                        [&>button>span:last-child]:absolute [&>button>span:last-child]:right-3
                        [&>div]:bg-brand-surface [&>div]:border [&>div]:border-brand-border [&>div]:rounded-sm"
              data-appspec-action="ACTION-APPLY-GALLERY-SORT"
            />
          </div>
        </div>

        {/* Artwork Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 relative z-10" data-appspec-evidence="EVIDENCE-GALLERY-LAYOUT">
          {filteredAndSortedPaintings.map((painting) => (
            <Link
              key={painting.id}
              to={`/gallery/${painting.id}`}
              className="group block rounded-lg overflow-hidden relative shadow-sm transition-all duration-300 ease-in-out bg-brand-surface hover:shadow-lg
                         border border-brand-accent-light hover:border-brand-border focus:outline-none focus:ring-2 focus:ring-brand-accent"
              data-appspec-action="ACTION-CLICK-PAINTING-CARD"
              data-appspec-item-id={painting.id}
              data-appspec-evidence="EVIDENCE-GALLERY-CARD-IMAGE EVIDENCE-GALLERY-CARD-TITLE EVIDENCE-GALLERY-CARD-PRICE"

            >
              <div className="relative w-full aspect-square overflow-hidden bg-[url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAADCAYAAABWKkFgAAAADklEQVQIW2NgQAOMECggCAAZUgyPAwAAAAxJREFUeJxjYIACBNMECgAAAgADpWwWjAAAAABJRU5ErkJggg==')] bg-repeat"> {/* Subtle repeatable paper grain texture */}
                <img
                  src={painting.imageSrc}
                  alt={painting.title}
                  className="w-full h-full object-cover transform opacity-100 group-hover:scale-105 transition-transform duration-700 ease-in-out will-change-transform"
                />
                {/* Hover overlay for medium and year */}
                <div
                  className="absolute inset-0 bg-brand-base/80 flex items-center justify-center p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500 ease-in-out"
                  data-appspec-evidence="EVIDENCE-GALLERY-CARD-HOVER-DETAILS"
                >
                  <div className="text-center">
                    <p className="font-sans text-brand-muted-text text-sm transition-all duration-300 delay-150 transform group-hover:translate-y-0 translate-y-2 opacity-0 group-hover:opacity-100 ease-in-out">
                      Medium: {painting.medium}
                    </p>
                    <p className="font-sans text-brand-muted-text text-sm mt-1 transition-all duration-300 delay-200 transform group-hover:translate-y-0 translate-y-2 opacity-0 group-hover:opacity-100 ease-in-out">
                      Year: {painting.year}
                    </p>
                  </div>
                </div>
              </div>
              <div className="p-4 bg-brand-surface relative z-10">
                <h3 className="font-display text-base-content text-lg leading-tight mb-1" style={{ color: '#2C2C2B' }}>{painting.title}</h3> {/* Playfair Display, small, #2C2C2B */}
                <p className="font-sans text-brand-text text-base" style={{ color: '#2C2C2B' }}>${painting.price.toLocaleString()}</p> {/* Open Sans, small, #2C2C2B */}
                <span className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm
                                ${painting.availability === 'Available' ? 'bg-primary/20 text-primary-dark' : ''}
                                ${painting.availability === 'Sold' ? 'bg-error/20 text-error' : ''}
                                ${painting.availability === 'On Hold' ? 'bg-warning/20 text-warning-dark' : ''}
                                  border border-current`}
                >
                  {painting.availability}
                </span>
              </div>
            </Link>
          ))}
        </div>
        {filteredAndSortedPaintings.length === 0 && (
          <div className="text-center text-brand-muted-text p-10 relative z-10">
            <p className="font-sans text-xl">No paintings found matching your criteria.</p>
          </div>
        )}
      </ProductShowcase>
    ),
    footer: (
      <BrandFooter
        brandName={brand.name}
        description={brand.tagline}
        links={[{ label: 'Privacy Policy', href: '#' }, { label: 'Terms of Service', href: '#' }]}
        meta={`© ${new Date().getFullYear()} ${brand.name}. All rights reserved.`}
        className="bg-brand-base text-brand-muted-text font-sans" // Apply beige/cream base palette
      />
    ),
  };

  return (
    <PublicShell
      brandName={brand.name}
      nav={<PublicNav items={navItems.filter(item => item.label !== 'Get Started')} />} // Filter out 'Get Started'
      footer={slots.footer}
      chrome="solid"
      className="bg-brand-base" // Ensure base page background is correct
    >
      <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
    </PublicShell>
  );
}