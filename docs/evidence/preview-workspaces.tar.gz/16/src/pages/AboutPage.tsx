// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, PageHeader, Card, BrandFooter } from '@/ui';
import { brand, images } from '@/data/mock';
// Import other necessary components if applicable here from @/ui

const SKELETON_ID = "public-utility" as const;

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={brand.name} description={brand.about_gallery_story} className="text-center py-16 lg:py-24" />
    ),
    workspace: (
      <div className="flex justify-center p-8 lg:p-12 mb-20 md:mb-24">
        <Card className="w-full max-w-2xl bg-surface p-8 rounded-lg shadow-lg shadow-brand/5 border border-brand/10 space-y-6">
          <h2 className="font-display text-3xl font-semibold text-brand mb-4">About the Gallery</h2>
          <p className="text-lg leading-relaxed text-muted-foreground whitespace-pre-wrap">
            {brand.about_gallery_story}
          </p>
          <h2 className="font-display text-3xl font-semibold text-brand mb-4">About Eleanor Vance</h2>
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <img
              src={images.about_owner}
              alt={brand.owner_name}
              className="w-32 h-32 rounded-full object-cover shadow-md flex-shrink-0"
            />
            <p className="text-lg leading-relaxed text-muted-foreground whitespace-pre-wrap">
              {brand.owner_name} is {brand.about_bio_short}
            </p>
          </div>
        </Card>
      </div>
    ),
    footer: (
      <BrandFooter brandName={brand.name} description="Discover a curated collection of exquisite art where every canvas tells a story."
        links={[{ label: 'Privacy Policy', href: '#' }, { label: 'Terms of Service', href: '#' }]}
        meta="© 2024 Jane Art Gallery. All rights reserved."
      />
    ),
  };

  return (
    <PublicShell brandName={brand.name} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}