import React, { useState, useEffect, FormEvent } from 'react';
import { useLocation } from 'react-router-dom';
import { PublicShell, PageHeader, Card, Input, Button, BrandFooter, PublicNav, SkeletonComposer, getSkeleton } from '@/ui';
import { brand, images } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';

const SKELETON_ID = 'public-utility' as const;

export default function ContactPage() {
  const skeleton = getSkeleton(SKELETON_ID);
  const location = useLocation();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const subject = queryParams.get('subject');
    if (subject) {
      setMessage(`Inquiry about: ${subject}`);
      // Set state to pre-filled for appspec
      document.body.setAttribute('data-appspec-state', 'STATE-CONTACT-FORM-PREFILLED');
    } else {
      document.body.setAttribute('data-appspec-state', 'STATE-CONTACT-LOADED');
    }
  }, [location.search]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    console.log({ name, email, message });
    // Simulate form submission
    setIsSubmitted(true);
    setName('');
    setEmail('');
    setMessage('');
    // Set state to submitted for appspec
    document.body.setAttribute('data-appspec-state', 'STATE-CONTACT-FORM-SUBMITTED');
  };

  const navItems = usePublicNavItems();
  const navCta = publicCta();

  const slots = {
    header: (
      <PageHeader
        title="Connect With Us"
        description="We look forward to hearing from you regarding our collection or any inquiries."
        className="text-center py-16 lg:py-24"
        data-appspec-evidence="EVIDENCE-CONTACT-AESTHETIC"
      />
    ),
    workspace: (
      <div className="flex justify-center p-8 lg:p-12 mb-20 md:mb-24" data-appspec-page="PAGE-CONTACT">
        <Card className="w-full max-w-xl p-8 bg-[color-mix(in_srgb,var(--color-brand)_3%,var(--color-background))] border-border-subtle shadow-lg" data-appspec-evidence="EVIDENCE-CONTACT-FORM-FIELDS">
          {isSubmitted ? (
            <div className="text-center text-muted-foreground p-8">
              <h3 className="text-2xl font-display text-brand-dark mb-4">Thank you for your message!</h3>
              <p>We have received your inquiry and will get back to you shortly.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div data-appspec-action="ACTION-FILL-CONTACT-FORM">
                <Input
                  id="name"
                  label="Your Name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Evelyn Carter"
                  className="bg-card border-border-default focus:border-brand-dark focus:ring-1 focus:ring-brand-dark h-12 text-foreground"
                  required
                />
              </div>
              <div>
                <Input
                  id="email"
                  label="Your Email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="evelyn.carter@example.com"
                  className="bg-card border-border-default focus:border-brand-dark focus:ring-1 focus:ring-brand-dark h-12 text-foreground"

                  required
                />
              </div>
              <div data-appspec-evidence="EVIDENCE-CONTACT-FORM-PREFILL">
                <Input
                  id="message"
                  label="Your Message"
                  as="textarea"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Enter your message here..."
                  rows={6}
                  className="bg-card border-border-default focus:border-brand-dark focus:ring-1 focus:ring-brand-dark text-foreground resize-y"
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-brand hover:bg-brand-dark text-white font-semibold font-display shadow-md transition-all duration-300 ease-in-out py-3"
                data-appspec-action="ACTION-SUBMIT-CONTACT-FORM"
                data-appspec-evidence="EVIDENCE-CONTACT-FORM-SUBMIT-BUTTON"
              >
                Send Message
              </Button>
            </form>
          )}
        </Card>
      </div>
    ),
    footer: (
      <BrandFooter
        brandName={brand.name}
        description="Discover a curated collection of exquisite art where every canvas tells a story."
        links={[{ label: 'Privacy Policy', href: '#' }, { label: 'Terms of Service', href: '#' }]}
        meta="© 2024 Jane Art Gallery. All rights reserved."
        className="bg-[color-mix(in_srgb,var(--color-brand)_3%,var(--color-background))]"
      />
    ),
  };

  return (
    <PublicShell
      brandName={brand.name}
      nav={<PublicNav items={navItems} cta={navCta} />}
      footer={slots.footer}
      chrome="solid"
      className="bg-background"
    >
      <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
    </PublicShell>
  );
}