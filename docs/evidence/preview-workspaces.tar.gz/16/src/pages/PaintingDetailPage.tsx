import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  PublicShell,
  MarketingHero,
  ProductShowcase,
  CTABand,
  BrandFooter,
  Button,
  PublicNav,
  UiIcon,
  getSkeleton,
  SkeletonComposer,
} from '@/ui';
import { brand, images } from '@/data/mock';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';


const SKELETON_ID = 'public-detail' as const;
const skeleton = getSkeleton(SKELETON_ID);

const currentPainting = {
  id: 'paintingid',
  title: 'Golden Hour Fields',
  description: 'An evocative abstract piece capturing the fleeting beauty of a sunset over expansive fields, rendered in warm earth tones and soft golds, hinting at both tranquility and vibrant energy.',
  medium: 'Oil on Canvas',
  dimensions: '80 x 120 x 4 cm',
  weight: '5.2 kg',
  yearCreated: '2022',
  price: '3,800',
  availability: 'Available', // Can be 'Available', 'Sold', 'On Hold'
  imageSrc: images.ambient, // Using ambient for a generic art piece
};

export default function PaintingDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const navigate = useNavigate();
  const [isZoomed, setIsZoomed] = useState(false);
  const location = useLocation();


  const handleInquireClick = () => {
    navigate(`/contact?subject=Inquiry about: ${encodeURIComponent(currentPainting.title)}`);
  };

  const handleImageClick = () => {
    setIsZoomed(!isZoomed);
  };

  const slots = {
    hero: (
      <MarketingHero
        brandName={brand.name}
        headline="Exquisite Detail, Timeless Beauty"
        subcopy="Every brushstroke tells a story. Discover the profound narrative within 'Golden Hour Fields'."
        primaryCta={{ children: 'View All Works', href: '/gallery' }}
        imageSrc={currentPainting.imageSrc}
        imageAlt={`Artwork: ${currentPainting.title}`}
        className="text-ivory"
      />
    ),
    showcase: (
      <ProductShowcase heading="" items={[]} className="py-16 lg:py-24 max-w-7xl mx-auto px-6" data-appspec-evidence="EVIDENCE-PAINTING-DETAIL-SPECS-CARD">
        <div className="grid md:grid-cols-2 gap-12 lg:gap-16 pt-8">
          {/* Artwork Spotlight */}
          <div
            className={`relative overflow-hidden rounded-lg shadow-xl shadow-brand/10 transition-all duration-300 ease-in-out group`}
            onClick={handleImageClick}
            data-appspec-evidence="EVIDENCE-PAINTING-DETAIL-IMAGE"
            data-appspec-action="ACTION-CLICK-IMAGE-TO-ZOOM"
          >
            <img
              src={currentPainting.imageSrc}
              alt={currentPainting.title}
              className={`w-full object-cover transition-transform duration-300 ease-in-out ${isZoomed ? 'scale-150 cursor-zoom-out' : 'scale-100 cursor-zoom-in'} will-change-transform ui-film-grain`}
              data-appspec-evidence={isZoomed ? "EVIDENCE-PAINTING-DETAIL-ZOOM" : "EVIDENCE-PAINTING-DETAIL-IMAGE"}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100" />
            <div className="absolute bottom-4 right-4 flex items-center bg-surface/80 text-muted-foreground px-3 py-1.5 rounded-full text-xs backdrop-blur-sm shadow-sm transition-all duration-300">
              <UiIcon name="search" className="w-3 h-3 mr-1" /> {isZoomed ? 'Zoom Out' : 'Zoom In'}
            </div>
          </div>

          {/* Gallery Label Style Information Card */}
          <div className="bg-surface p-8 rounded-lg shadow-lg shadow-brand/5 space-y-6 text-text border border-brand/10">
            <h1 className="font-display text-3xl font-semibold leading-tight text-brand mb-4">
              {currentPainting.title}
            </h1>
            <p className="text-muted-foreground text-sm leading-relaxed whitespace-pre-wrap">
              {currentPainting.description}
            </p>
            <div className="pt-4 border-t border-brand/10 space-y-3">
              <p className="text-sm">
                <strong className="font-semibold text-brand-dark">Medium:</strong> {currentPainting.medium}
              </p>
              <p className="text-sm">
                <strong className="font-semibold text-brand-dark">Dimensions:</strong> {currentPainting.dimensions}
              </p>
              <p className="text-sm">
                <strong className="font-semibold text-brand-dark">Weight:</strong> {currentPainting.weight}
              </p>
              <p className="text-sm">
                <strong className="font-semibold text-brand-dark">Year Created:</strong> {currentPainting.yearCreated}
              </p>
              <p className="text-lg">
                <strong className="font-semibold text-brand-dark">Price:</strong> {currentPainting.price}
              </p>
              <p className="text-sm flex items-center">
                <strong className="font-semibold text-brand-dark mr-2">Availability:</strong>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    currentPainting.availability === 'Available'
                      ? 'bg-brand/10 text-brand'
                      : currentPainting.availability === 'Sold'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}
                >
                  {currentPainting.availability}
                </span>
              </p>
            </div>
            <div className="pt-6">
              <Button
                variant="default"
                size="lg"
                onClick={handleInquireClick}
                className="w-full bg-brand hover:bg-brand-dark text-white font-display text-base transition-all duration-300 ease-in-out transform hover:-translate-y-0.5"
                data-appspec-action="ACTION-NAVIGATE-TO-CONTACT"
              >
                Inquire About This Piece
              </Button>
            </div>
          </div>
        </div>
      </ProductShowcase>
    ),
    cta: (
      <CTABand
        heading="Discover More Fine Art"
        description="Explore additional works from our diverse collection and find your next masterpiece."
        primaryCta={{
          children: 'Browse Gallery',
          href: '/gallery',
          variant: 'default',
        }}
      />
    ),
    footer: (
      <BrandFooter brandName={brand.name} description="Discover a curated collection of exquisite art where every canvas tells a story."
        links={[{ label: 'Privacy Policy', href: '#' }, { label: 'Terms of Service', href: '#' }]}
        meta="© 2024 Jane Art Gallery. All rights reserved."
      />
    ),
  };

  return (
    <PublicShell
      brandName={brand.name}
      nav={<PublicNav items={navItems} cta={navCta} />}
      footer={slots.footer}
      chrome="solid"
    >
      {/* Using SkeletonComposer to arrange content based on the skeleton contract */}
      <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
    </PublicShell>
  );
}