// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, PageHeader, Card, BrandFooter } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader title={"Jane Art | Contact"} description="A current view of the work that needs your attention." meta={<span className="text-sm text-muted">Today</span>} />
    ),
    workspace: (
      <Card title="Your details" description="Everything for this step in one place."><p className="text-sm text-muted">Items, totals, and confirmation details appear here.</p></Card>
    ),
    footer: (
      <BrandFooter brandName={"Jane Art"} description="Thoughtful service, clearly delivered." />
    ),
  };

  return (
    <PublicShell brandName={"Jane Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
