import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';

import AiFeaturesPage from './pages/AiFeaturesPage';
import AlignersInquiryFormPage from './pages/AlignersInquiryFormPage';
import BookPage from './pages/BookPage';
import ContactPage from './pages/ContactPage';
import DashboardPage from './pages/owner/DashboardPage';
import EmergencyFormPage from './pages/EmergencyFormPage';
import HomePage from './pages/HomePage';
import InboxPage from './pages/owner/InboxPage';
import InquiryConfirmationPage from './pages/InquiryConfirmationPage';
import InquiryDetailPage from './pages/owner/InquiryDetailPage';
import ServicesPage from './pages/ServicesPage';
import SettingsPage from './pages/owner/SettingsPage';
import TreatmentsPage from './pages/TreatmentsPage';
import { roles } from './data/mock';
import { notifyParent, registerPreviewNavigate, setupPreviewBridge } from './lib/preview-bridge';

type Role = { id: string; defaultPath?: string };

/*
 * ScrollToTop is inlined here, not imported from `src/components/ScrollToTop.tsx`.
 * assemble.write_app_tsx rewrites App.tsx from scratch in every workspace, so an
 * import would make the emitted app depend on a template file surviving the
 * copy. The template keeps its own copy for the dev app;
 * `test_the_scroll_reset_ships_one_behaviour_from_two_files` pins the two to the
 * same alias set.
 */

/** Hash aliases that should land on the inquire / contact form. */
const HASH_ALIASES: Record<string, string> = {
  contact: 'inquire',
  'contact-form': 'inquire',
  purchase: 'inquire',
  'inquire-form': 'inquire',
  enquiry: 'inquire',
  enquiries: 'inquire',
};

/**
 * Every Link/nav change lands at the top — or the hashed section when present.
 *
 * `behavior: 'instant'` because this only ever runs for a router navigation:
 * a same-page `<a href="#x">` is a native anchor, which react-router's
 * `useLocation` never sees, so it keeps the smooth in-page glide from
 * `html { scroll-behavior: smooth }`. A landing that animates from 3000px
 * while the incoming page is still mounting reads as broken, not polished.
 */
function ScrollToTop() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    const raw = (hash || '').replace(/^#/, '').trim();
    if (raw) {
      const id = HASH_ALIASES[raw] || raw;
      const scrollToHash = () => {
        const el = document.getElementById(id);
        if (!el) return false;
        // Measure the header now rather than trusting `--public-header-h`.
        // On a cold load of `/painting/1#inquire` this runs before PublicShell
        // has measured anything, so the CSS variable is still undefined and the
        // stylesheet fallback fires — request 67 landed such deep links 18px
        // *under* a 114px header, while the same anchor clicked in-page landed
        // correctly at +23. Reading the rendered header cannot race itself.
        const header = document.querySelector('[data-public-header]');
        const offset = (header ? header.getBoundingClientRect().height : 112) + 24;
        const top = el.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top: Math.max(0, top), left: 0, behavior: 'instant' });
        return true;
      };
      if (scrollToHash()) return;
      const t = window.setTimeout(() => {
        if (!scrollToHash()) window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      }, 50);
      return () => window.clearTimeout(t);
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    return undefined;
  }, [pathname, hash]);
  return null;
}

function RouteBridge() {
  const location = useLocation();
  useEffect(() => { notifyParent(location.pathname); }, [location.pathname]);
  return null;
}

function RoleBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    registerPreviewNavigate((path) => navigate(path));
    setupPreviewBridge((roleId, path) => {
      if (path) { navigate(path); return; }
      const list = (roles as Role[]) || [];
      const role = list.find((r) => r.id === roleId);
      navigate(role?.defaultPath ?? list[0]?.defaultPath ?? '/');
    });
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <ScrollToTop />
      <RouteBridge />
      <RoleBridge />
      <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/treatments" element={<TreatmentsPage />} />
          <Route path="/emergency" element={<EmergencyFormPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/treatments/clear-aligners-inquiry" element={<AlignersInquiryFormPage />} />
          <Route path="/inquiry-received" element={<InquiryConfirmationPage />} />
          <Route path="/owner/dashboard" element={<DashboardPage />} />
          <Route path="/owner/inbox" element={<InboxPage />} />
          <Route path="/owner/settings" element={<SettingsPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/book" element={<BookPage />} />
          <Route path="/book-appointment" element={<BookPage />} />
          <Route path="/book-appointments" element={<BookPage />} />
          <Route path="/owner/inquiry/:id" element={<InquiryDetailPage />} />
          <Route path="/ai-features" element={<AiFeaturesPage />} />
          <Route path="/treatments/:id" element={<AlignersInquiryFormPage />} />
          <Route path="/treatments/:slug" element={<AlignersInquiryFormPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}