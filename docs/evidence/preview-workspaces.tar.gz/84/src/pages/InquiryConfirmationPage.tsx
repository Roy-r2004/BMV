// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function InquiryConfirmationPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Inquiry Received | Northgate Dental Studio"}
        description={"Ask Northgate Dental Studio about availability, dimensions, commissions or a studio visit — we reply directly."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Send a message"}
            description={"Tell us which piece or question you have in mind and we will come back with specifics."}
            ctaLabel={"Send"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio — real replies, no contact-form limbo."}
      />
    ),
  };

  return (
    <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
  );
}
