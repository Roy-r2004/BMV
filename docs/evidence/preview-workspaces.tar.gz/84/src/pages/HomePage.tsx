// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, ProcessSection, TestimonialRail, CTABand, BrandFooter, Button, CredentialStrip, ProductShowcase } from '@/ui';
import { useState } from 'react'; // Import useState for chat widget

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const; // Added 'process' slot

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const [isChatOpen, setIsChatOpen] = useState(false);

  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Northgate Dental Studio"} items={seed.credentials ?? []} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Northgate Dental Studio"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.item1, images.item2, images.item3, images.item4, images.item5, images.item6, images.item7, images.item8][index % 8], imageAlt: item.title, badge: String((item as any).badge || (item as any).category || "Featured"), href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    hero: (
      <MarketingHero
        brandName={"Northgate Dental Studio"}
        headline={"Your Smile, Our Priority – Connecting You to Care in Leeds"}
        subcopy={"Northgate Dental Studio offers transparent, accessible dental care. Ask questions, get answers, and manage your appointments with ease."}
        primaryCta={{ label: "Ask a Question", href: "/contact" }}
        secondaryCta={{ label: "Book an Appointment", href: "https://northgatedentalstudio.com/book" }}
        imageSrc={images.hero}
        imageAlt="Bright, modern dental studio interior with chairs"
      />
    ),
    features: (
      <FeatureBento
        heading={"Quick Connect Features"}
        description="Streamlined pathways to the care you need."
        items={[
          {
            title: "Quick Chat Support",
            description: "Get instant answers to common questions.",
            imageSrc: images.card1, // Use appropriate image from available pool
            imageAlt: "Chat icon",
          },
          {
            title: "Emergency Help Line",
            description: "Dedicated forms for urgent dental needs.",
            imageSrc: images.card2, // Use appropriate image from available pool
            imageAlt: "Emergency icon",
          },
          {
            title: "Treatment Information",
            description: "Explore our services and understand your options.",
            imageSrc: images.card3, // Use appropriate image from available pool
            imageAlt: "Treatment plan icon",
          },
          {
            title: "Transparent Pricing",
            description: "Clear costs for every service, no surprises.",
            imageSrc: images.card1, // Use appropriate image from available pool
            imageAlt: "Price tag icon",
          },
          {
            title: "Online Booking & Reminders",
            description: "Manage your appointments with ease and never miss a visit.",
            imageSrc: images.card2, // Use appropriate image from available pool
            imageAlt: "Calendar icon",
          },
        ]}
      />
    ),
    process: (
      <ProcessSection
        heading="How Care Connect Works"
        description="Getting the dental care you need has never been simpler."
        steps={[
          {
            title: "Ask",
            description: "Use our secure chat or inquiry forms for any questions.",
          },
          {
            title: "Connect",
            description: "Our team or AI assistant provides swift, informed responses.",
          },
          {
            title: "Care",
            description: "Receive the information or appointment you need quickly.",
          },
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading="What Our Patients Say"
        items={[
          {
            quote: "Northgate Dental made booking so easy, and the chat feature was brilliant for a quick question about my appointment. Highly recommend!",
            author: "Sarah L.",
            role: "Patient from Leeds",
          },
          {
            quote: "I appreciated the transparency of the treatment plan and costs upfront. The online system is incredibly convenient.",
            author: "Mark T.",
            role: "Patient from Leeds",
          },
          {
            quote: "The emergency inquiry form was a lifesaver. I got a prompt response and was seen quickly. Thank you, Northgate Dental Studio!",
            author: "Emily R.",
            role: "Patient from Leeds",
          },
        ]}
      />
    ),
    cta: (
      <CTABand
        heading="Ready to Experience Hassle-Free Dental Care?"
        description="Connect with us today for transparent, accessible, and responsive dental services."
        primaryCta={{ label: "Get Started Today", href: "/contact" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio is a three-chair family dental practice in Leeds, offering comprehensive care including check-ups, hygienist visits, clear aligners, and emergency appointments. Your smile, our priority."}
        links={[
          { label: "Privacy Policy", href: "#" },
          { label: "Terms of Service", href: "#" },
          { label: "Contact Us", href: "/contact" },
        ]}
        meta={["© 2024 Northgate Dental Studio", "All rights reserved."]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Northgate Dental Studio"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />

        {/* Persistent Chat Widget */}
        <div className="fixed bottom-4 right-4 z-50">
          <Button
            variant="default"
            size="lg"
            className="rounded-full h-16 w-16 shadow-lg bg-brand text-white flex items-center justify-center"
            onClick={() => setIsChatOpen(!isChatOpen)}
            aria-label="Open chat"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-8 w-8"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
              />
            </svg>
          </Button>

          {isChatOpen && (
            <div className="absolute bottom-20 right-0 w-80 h-96 bg-surface shadow-xl rounded-lg flex flex-col">
              <div className="bg-brand text-white p-4 rounded-t-lg flex justify-between items-center">
                <h3 className="text-lg font-medium">Northgate Dental Care Connect</h3>
                <Button variant="ghost" onClick={() => setIsChatOpen(false)} className="text-white p-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </Button>
              </div>
              <div className="flex-grow p-4 overflow-y-auto text-text">
                <p className="mb-4">Hello! How can we help you today?</p>
                {/* Chat messages would go here */}
                <p className="text-sm text-muted">Type your message below...</p>
              </div>
              <div className="p-4 border-t border-muted-foreground">
                <input
                  type="text"
                  placeholder="Ask a question..."
                  className="w-full p-2 border border-muted rounded-md focus:outline-none focus:ring-2 focus:ring-brand"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </PublicShell>
  );
}