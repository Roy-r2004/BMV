// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function AlignersInquiryFormPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Clear Aligners Inquiry"}
        description={"Interested in achieving a straighter smile with clear aligners? Tell us a bit about what you're looking for, and we'll get back to you to discuss your options."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Tell Us About Your Smile Goals"}
            description={"Share what you hope to achieve with clear aligners. This helps us understand your needs and prepare for your consultation."}
            ctaLabel={"Start Inquiry"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio – Your smile, our priority."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="aligners-form">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
