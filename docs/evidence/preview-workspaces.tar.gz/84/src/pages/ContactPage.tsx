// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel, AiFeaturePanel } from '@/ui';
import { aiFeatures } from '@/data/mock';

const SKELETON_ID = "public-utility" as const;

export default function ContactPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Get In Touch with Northgate Dental Studio"}
        description={"Have a question about our services or need to schedule an appointment? Reach out to us – we're here to help."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"General Enquiry"}
            description={"For all non-urgent questions about our services, practice, or anything else."}
            ctaLabel={"Send a Message"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio – Your Family Dental Practice in Leeds. Protecting your smile, every step of the way."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="contact">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
          <div id="intelligent-inquiry-routing" data-ai-feature-panel="intelligent-inquiry-routing">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "intelligent-inquiry-routing") || { id: "intelligent-inquiry-routing", name: "intelligent-inquiry-routing" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
          <div id="automated-first-line-chat-assistant" data-ai-feature-panel="automated-first-line-chat-assistant">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "automated-first-line-chat-assistant") || { id: "automated-first-line-chat-assistant", name: "automated-first-line-chat-assistant" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
          <div id="emergency-risk-flagging" data-ai-feature-panel="emergency-risk-flagging">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "emergency-risk-flagging") || { id: "emergency-risk-flagging", name: "emergency-risk-flagging" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
          <div id="treatment-interest-pre-qualification" data-ai-feature-panel="treatment-interest-pre-qualification">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "treatment-interest-pre-qualification") || { id: "treatment-interest-pre-qualification", name: "treatment-interest-pre-qualification" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
    </PublicShell>
    </>
  );
}
