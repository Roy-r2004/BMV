// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function EmergencyFormPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    summary: (
      <Card title="Summary" description="Review everything before you confirm."><div className="space-y-3"><div className="flex items-center justify-between text-sm"><span className="text-muted">Subtotal</span><span className="font-semibold text-foreground">248</span></div><div className="flex items-center justify-between text-sm"><span className="text-muted">Service</span><span className="font-semibold text-foreground">Included</span></div><div className="flex items-center justify-between border-t border-border-subtle pt-3 text-base"><span className="font-medium text-foreground">Due today</span><span className="font-display text-xl font-semibold text-brand">248</span></div></div></Card>
    ),
    header: (
      <PageHeader
        title={"Dental Emergency | Northgate Dental Studio"}
        description={"Please use this form to report a dental emergency. We will prioritise your inquiry."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Report an Emergency"}</h3>
            <p className="text-sm leading-6 text-muted">{"If you are experiencing severe pain, swelling, or have had a dental injury, please provide us with the details below. Our team monitors these submissions closely."}</p>
            <Button href={"/"} className="mt-auto w-fit">
              {"Open"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"What Happens Next?"}</h3>
            <p className="text-sm leading-6 text-muted">{"After submitting your emergency report, our team will review it as quickly as possible. For life-threatening conditions, please call 999."}</p>
            <Button href={"/contact"} className="mt-auto w-fit">
              {"View Our Contact Information"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio – Your trusted family dental practice in Leeds."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="emergency-form">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"generic"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
