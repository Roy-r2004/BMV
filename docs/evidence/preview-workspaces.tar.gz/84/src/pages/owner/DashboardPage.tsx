// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, RiskQueue, ChartCard, FilterBar, DataTable, ActivityFeed } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function DashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title="Care Connect: Inquiry Management Dashboard"
        description="Prioritise patient needs, streamline communication, and track team efficiency."
        actions={[]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="New Inquiries" value="7" delta="+3 last 24 hours" variant="card" />
        <StatCard label="Emergencies" value="2" hint="0 High priority" variant="card" />
        <StatCard label="Average Response" value="15 min" delta="-5 min all channels" variant="card" />
        <StatCard label="Resolved Inquiries" value="18" delta="+4 today" variant="card" />
      </div>
    ),
    risk: (
      <RiskQueue
        heading="Needs Attention"
        items={[
          {
            id: "risk-emergency-1",
            title: "Unassigned Emergency Inquiry",
            detail: "Patient Sarah L. reporting severe pain. Action required immediately.",
            severity: "high",
            actionLabel: "View Details"
          },
        ]}
      />
    ),
    chart: (
      <ChartCard
        title="Inquiry Volume Trend"
        type="area"
        dataKey="value"
        xKey="day"
        data={[
          { day: "Mon", value: 10 },
          { day: "Tue", value: 14 },
          { day: "Wed", value: 12 },
          { day: "Thu", value: 18 },
          { day: "Fri", value: 15 },
          { day: "Sat", value: 9 },
          { day: "Sun", value: 7 },
        ]}
        description="Last 7 days"
        insight="Peak inquiries on Thursday"
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search inquiries..."
        filters={[
          { id: "all", label: "All", active: true },
          { id: "emergency", label: "Emergency" },
          { id: "treatment", label: "Treatment" },
          { id: "general", label: "General" },
          { id: "new", label: "New" },
          { id: "open", label: "Open" },
          { id: "pending", label: "Pending" },
          { id: "resolved", label: "Resolved" },
        ]}
        actions={[]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "type", header: "Type" },
          { key: "patient", header: "Patient" },
          { key: "description", header: "Description" },
          { key: "status", header: "Status" },
          { key: "assignedTo", header: "Assigned To" },
        ]}
        rows={[
          { id: "inq-1", type: "Emergency", patient: "Sarah L.", description: "Severe pain, broken tooth", status: "New", assignedTo: "Dr. Evans" },
          { id: "inq-2", type: "Treatment", patient: "Mark T.", description: "Interest in Clear Aligners", status: "Open", assignedTo: "Reception" },
          { id: "inq-3", type: "General", patient: "Emily V.", description: "Opening hours query", status: "Resolved", assignedTo: "AI Chat" },
          { id: "inq-4", type: "Emergency", patient: "John D.", description: "Swelling and discomfort", status: "Open", assignedTo: "Dr. Smith" },
          { id: "inq-5", type: "Treatment", patient: "Anna R.", description: "Hygienist appointment request", status: "New", assignedTo: "Reception" },
        ]}
        emptyMessage="No recent inquiries."
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "act-1", title: "Dr. Smith responded to Mark T.", time: "Just now" },
          { id: "act-2", title: "AI Chat handled Emily V.'s query.", time: "5 min ago" },
          { id: "act-3", title: "New emergency inquiry from Sarah L.", time: "15 min ago" },
          { id: "act-4", title: "Reception assigned Anna R. to Dr. Evans.", time: "30 min ago" },
          { id: "act-5", title: "Dr. Evans updated John D.'s status.", time: "1 hour ago" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Northgate Dental Studio"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="dashboard">
        {main}
      </div>
    </OpsShell>
  );
}