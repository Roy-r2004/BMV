// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Tabs, Input, Button, DataTable, Select, UiIcon } from '@/ui';
import { useState } from 'react';

const SKELETON_ID = "ops-settings" as const;

export default function SettingsPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const staffAccounts = [
    { id: '1', name: 'Dr. Eleanor Vance', email: 'eleanor.vance@northgatedental.com', role: 'Dentist', status: 'Active' },
    { id: '2', name: 'Sarah Jenkins', email: 'sarah.jenkins@northgatedental.com', role: 'Practice Manager', status: 'Active' },
    { id: '3', name: 'Mark Dawson', email: 'mark.dawson@northgatedental.com', role: 'Hygienist', status: 'Active' },
    { id: '4', name: 'Chloe Green', email: 'chloe.green@northgatedental.com', role: 'Receptionist', status: 'Active' },
  ];

  const staffColumns = [
    { accessor: 'name', header: 'Name' },
    { accessor: 'email', header: 'Email' },
    { accessor: 'role', header: 'Role' },
    { accessor: 'status', header: 'Status' },
    {
      accessor: 'actions',
      header: 'Actions',
      render: () => (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" aria-label="Edit user"><UiIcon name="Pencil" className="h-4 w-4" /></Button>
          <Button variant="destructive" size="sm" aria-label="Delete user"><UiIcon name="Trash" className="h-4 w-4" /></Button>
        </div>
      ),
    },
  ];

  const formFieldsData = [
    { id: '1', form: 'Emergency Inquiry', fieldName: 'Patient Symptoms', type: 'Textarea', required: true },
    { id: '2', form: 'Emergency Inquiry', fieldName: 'Onset Date', type: 'Date', required: true },
    { id: '3', form: 'Clear Aligners Inquiry', fieldName: 'Previous Braces?', type: 'Yes/No', required: false },
    { id: '4', form: 'Clear Aligners Inquiry', fieldName: 'Correction Type', type: 'Select', required: true },
    { id: '5', form: 'General Contact', fieldName: 'Subject', type: 'Text Input', required: true },
  ];

  const formFieldsColumns = [
    { accessor: 'form', header: 'Form Name' },
    { accessor: 'fieldName', header: 'Field Name' },
    { accessor: 'type', header: 'Type' },
    { accessor: 'required', header: 'Required', render: (row: any) => (row.required ? 'Yes' : 'No') },
    {
      accessor: 'actions',
      header: 'Actions',
      render: () => (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" aria-label="Edit field"><UiIcon name="Pencil" className="h-4 w-4" /></Button>
          <Button variant="destructive" size="sm" aria-label="Delete field"><UiIcon name="Trash" className="h-4 w-4" /></Button>
        </div>
      ),
    },
  ];

  const automatedResponses = [
    { id: '1', type: 'Chat Greeting', trigger: 'Initial contact', response: 'Hello! How can Northgate Dental Studio assist you today?' },
    { id: '2', type: 'Emergency Confirmation', trigger: 'Emergency form submission', response: 'Thank you for contacting us. We will review your emergency and get back to you shortly.' },
    { id: '3', type: 'Appointment Reminder', trigger: '24 hours before appt.', response: 'Reminder: Your appointment with Northgate Dental Studio is tomorrow at [Time].' },
  ];

  const automatedResponsesColumns = [
    { accessor: 'type', header: 'Type' },
    { accessor: 'trigger', header: 'Trigger' },
    { accessor: 'response', header: 'Response Content' },
    {
      accessor: 'actions',
      header: 'Actions',
      render: () => (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" aria-label="Edit response"><UiIcon name="Pencil" className="h-4 w-4" /></Button>
        </div>
      ),
    },
  ];

  const slots = {
    header: (
      <PageHeader title={"Settings"} />
    ),
    // The skeleton allows for only a 'header' slot directly.
    // All other content will be structured using general HTML elements within the main body.
  };

  return (
    <OpsShell brandName={"Northgate Dental Studio"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="settings">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />

        <div className="container mx-auto px-6 py-8 space-y-10 max-w-7xl">
          {/* General Settings */}
          <section className="space-y-6">
            <h2 className="font-display text-3xl text-text-brand mt-4">General Settings</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-surface p-6 rounded-lg shadow-sm">
              <div>
                <label htmlFor="practice-name" className="block text-sm font-medium text-text-brand mb-1">Practice Name</label>
                <Input id="practice-name" defaultValue="Northgate Dental Studio" className="w-full" />
              </div>
              <div>
                <label htmlFor="contact-email" className="block text-sm font-medium text-text-brand mb-1">Contact Email</label>
                <Input id="contact-email" defaultValue="info@northgatedental.com" className="w-full" />
              </div>
              <div>
                <label htmlFor="contact-phone" className="block text-sm font-medium text-text-brand mb-1">Contact Phone</label>
                <Input id="contact-phone" defaultValue="+44 113 222 3344" className="w-full" />
              </div>
              <div>
                <label htmlFor="address" className="block text-sm font-medium text-text-brand mb-1">Address</label>
                <Input id="address" as="textarea" rows={3} defaultValue="123 Dental Lane, Leeds, LS1 1AA, UK" className="w-full" />
              </div>
              <div className="md:col-span-2">
                <Button className="mt-4">Save General Settings</Button>
              </div>
            </div>
          </section>

          {/* Forms Management */}
          <section className="space-y-6">
            <h2 className="font-display text-3xl text-text-brand">Forms Management</h2>
            <div className="bg-surface p-6 rounded-lg shadow-sm">
              <DataTable columns={formFieldsColumns} rows={formFieldsData} emptyMessage="No form fields found." />
              <Button className="mt-4" variant="secondary">Add New Form Field</Button>
            </div>
          </section>

          {/* Automated Responses */}
          <section className="space-y-6">
            <h2 className="font-display text-3xl text-text-brand">Automated Responses</h2>
            <div className="bg-surface p-6 rounded-lg shadow-sm">
              <DataTable columns={automatedResponsesColumns} rows={automatedResponses} emptyMessage="No automated responses found." />
              <Button className="mt-4" variant="secondary">Add New Response</Button>
            </div>
          </section>

          {/* Staff Accounts & Permissions */}
          <section className="space-y-6">
            <h2 className="font-display text-3xl text-text-brand">Staff Accounts & Permissions</h2>
            <div className="bg-surface p-6 rounded-lg shadow-sm">
              <DataTable columns={staffColumns} rows={staffAccounts} emptyMessage="No staff accounts found." />
              <Button className="mt-4">Add New Staff Member</Button>
            </div>
          </section>

          {/* Data & Compliance */}
          <section className="space-y-6">
            <h2 className="font-display text-3xl text-text-brand">Data & Compliance</h2>
            <div className="bg-surface p-6 rounded-lg shadow-sm space-y-6">
              <div>
                <label htmlFor="data-retention" className="block text-sm font-medium text-text-brand mb-1">Data Retention Policy</label>
                <Select
                  id="data-retention"
                  options={[
                    { label: 'Indefinite', value: 'indefinite' },
                    { label: '7 Years', value: '7_years' },
                    { label: '5 Years', value: '5_years' },
                  ]}
                  defaultValue="7_years"
                  className="w-full max-w-xs"
                />
                <p className="text-sm text-muted mt-2">Automatically delete patient data after the selected period, in line with regulations.</p>
              </div>
              <div>
                <label htmlFor="audit-logging" className="block text-sm font-medium text-text-brand mb-1">Audit Logging</label>
                <Select
                  id="audit-logging"
                  options={[
                    { label: 'Enabled', value: 'enabled' },
                    { label: 'Disabled', value: 'disabled' },
                  ]}
                  defaultValue="enabled"
                  className="w-full max-w-xs"
                />
                <p className="text-sm text-muted mt-2">Records all system access and changes for security and compliance purposes.</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-text-brand mt-4">GDPR Compliance</h3>
                <p className="text-muted text-sm mt-2">
                  Northgate Dental Studio is committed to protecting patient privacy and adhering to GDPR regulations.
                  <a href="#" className="text-brand hover:underline ml-1">View our full data privacy policy.</a>
                </p>
                <Button variant="secondary" className="mt-4">Download Data Processing Agreement</Button>
              </div>
              <Button className="mt-4">Save Compliance Settings</Button>
            </div>
          </section>
        </div>
      </div>
    </OpsShell>
  );
}