// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function InquiryDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Inquiry Details"}
        description={"View and manage all communications related to a specific patient inquiry."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Update Patient Status"}
            description={"Change the inquiry's status (e.g., 'Resolved', 'Pending', 'Escalated')."}
            ctaLabel={"Update Status"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio - Care Connect | Leeds, UK"}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="inbox-detail">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
