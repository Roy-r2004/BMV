// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function InboxPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Inquiry Inbox"}
        description={"Manage all patient inquiries from Northgate Dental Care Connect."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Review New Inquiries"}
            description={"Patients are reaching out for help and information. Prioritise and respond quickly to maintain our high standard of care."}
            ctaLabel={"View New"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio – Committed to your smile."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="inbox">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
