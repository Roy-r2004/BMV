// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, BookingPanel, BrandFooter } from '@/ui';

const SKELETON_ID = "public-booking" as const;
const RECIPE_ORDER = ["hero", "credentials", "booking", "footer"] as const;

export default function BookPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName="Northgate Dental Studio"
        headline="Secure Your Visit"
        subcopy="Choose a time that works best for your schedule at Northgate Dental Studio. We look forward to welcoming you."
        primaryCta={{ label: "Book Now", href: "#booking-panel" }}
        imageSrc={images.hero}
        imageAlt="Bright, clean dental studio waiting area"
      />
    ),
    credentials: (
      <CredentialStrip
        heading="Our Commitment to Your Comfort"
        items={[
          { title: "Experienced Team", detail: "Dedicated professionals for your best care." },
          { title: "Transparent Pricing", detail: "Clear treatment plans, no surprises." },
          { title: "Modern Facilities", detail: "Three state-of-the-art chairs in Leeds." },
        ]}
      />
    ),
    booking: (
      <BookingPanel
        heading="Select Your Appointment"
        description="Please choose your desired service and an available time slot below."
        treatments={[
          { id: "checkup", name: "Routine Check-up", duration: "30 mins" },
          { id: "hygienist", name: "Hygienist Visit", duration: "45 mins" },
          { id: "aligners_consult", name: "Clear Aligners Consultation", duration: "60 mins" },
          { id: "emergency", name: "Emergency Appointment", duration: "30 mins" },
        ]}
        slots={[
          { id: "slot-2024-08-01-1000", startsAt: "2024-08-01T10:00:00", label: "10:00 AM" },
          { id: "slot-2024-08-01-1100", startsAt: "2024-08-01T11:00:00", label: "11:00 AM" },
          { id: "slot-2024-08-01-1400", startsAt: "2024-08-01T14:00:00", label: "02:00 PM" },
          { id: "slot-2024-08-02-0900", startsAt: "2024-08-02T09:00:00", label: "09:00 AM" },
          { id: "slot-2024-08-02-1300", startsAt: "2024-08-02T13:00:00", label: "01:00 PM" },
          { id: "slot-2024-08-03-1030", startsAt: "2024-08-03T10:30:00", label: "10:30 AM" },
          { id: "slot-2024-08-03-1500", startsAt: "2024-08-03T15:00:00", label: "03:00 PM" },
        ]}
        confirmLabel="Confirm Appointment"
      />
    ),
    footer: (
      <BrandFooter
        brandName="Northgate Dental Studio"
        description="Your trusted family dental practice in Leeds, ensuring healthy smiles for life."
        links={[
          { label: "Our Services", href: "/services" },
          { label: "Contact Us", href: "/contact" },
          { label: "Privacy Policy", href: "#" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Northgate Dental Studio"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="book">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}