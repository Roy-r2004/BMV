export const brand = {
  name: "Northgate Dental Studio",
  tagline: "Your trusted family dental practice in Leeds, connecting you to exceptional care.",
  design_system: {
    primary_color: "#0f766e",
    secondary_color: "#134e4a",
    background_color: "#f0fdfa",
    surface_color: "#ffffff",
    text_color: "#042f2e",
    muted_text_color: "#5f7a78",
    font_family: "Source Sans 3",
    display_font_family: "Fraunces",
    font_import_url: "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    font_sans: "\"Source Sans 3\", \"Segoe UI\", sans-serif",
    font_display: "\"Fraunces\", Georgia, serif",
    brand_locked: true,
    brand_brief_version: "1.0",
    mood: "Editorial",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature: "A calm full-bleed atmosphere with Northgate Dental Studio as the hero signal, not a card grid.",
    avoid: ["purple-on-white or purple-to-indigo default themes", "Inter / Roboto / Arial as the display face", "card grids in the hero", "generic SaaS marketing copy", "inventing a second palette per page"],
    rules: ["Every page inherits this palette and type stack via CSS tokens only.", "Use bg-brand / text-brand / font-display — never hardcode hex colors.", "First viewport must feature the brand name as a hero-level signal."],
    recipe_id: "editorial",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    recipe_prompt: "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    style_keywords: "Editorial · Calm air",
    border_radius: "0.89rem",
    design_overlay_id: "calm_air",
    design_overlay_label: "Calm air",
    design_overlay_blurb: "Airy clinical calm — soft surfaces, quiet type, low density.",
    density: "airy",
    token_overrides: {
      radius_ui: "0.89rem",
      bg_mix: "3%",
      fg_mix: "38%",
      muted_mix: "28%",
      border_mix: "12%",
      shadow: "0 28px 56px -40px",
      shadow_alpha: "22%",
      glow: "6%",
      card: "#ffffff",
      atmosphere: "radial-gradient(90% 55% at 8% -5%, color-mix(in srgb, var(--color-brand) 9%, transparent), transparent 58%), linear-gradient(180deg, #fbfcfd 0%, color-mix(in srgb, var(--color-brand) 3%, #f5f7f9) 55%, #f8fafb 100%)",
    },
    font_import: "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700",
    design_brief_version: "1.0",
    design_brief_sealed: true,
  },

  services: [{"name": "Northgate Dental Studio Signature", "title": "Northgate Dental Studio Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Northgate Dental Studio experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Northgate Dental Studio experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Northgate", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Northgate Dental Studio clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/7789678/pexels-photo-7789678.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/6812452/pexels-photo-6812452.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/31188653/pexels-photo-31188653.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/5622280/pexels-photo-5622280.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/3881290/pexels-photo-3881290.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/6627838/pexels-photo-6627838.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item1": "https://images.pexels.com/photos/7789685/pexels-photo-7789685.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item2": "https://images.pexels.com/photos/6812522/pexels-photo-6812522.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item3": "https://images.pexels.com/photos/6812481/pexels-photo-6812481.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item4": "https://images.pexels.com/photos/6528786/pexels-photo-6528786.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item5": "https://images.pexels.com/photos/5355863/pexels-photo-5355863.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item6": "https://images.pexels.com/photos/6627725/pexels-photo-6627725.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item7": "https://images.pexels.com/photos/6627694/pexels-photo-6627694.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item8": "https://images.pexels.com/photos/31786500/pexels-photo-31786500.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "services",
      "path": "/services",
      "href": "/services",
      "label": "Services"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "emergency",
      "path": "/emergency",
      "href": "/emergency",
      "label": "Emergency"
    },
    {
      "id": "inquiry-received",
      "path": "/inquiry-received",
      "href": "/inquiry-received",
      "label": "Inquiry Received"
    },
    {
      "id": "treatments",
      "path": "/treatments",
      "href": "/treatments",
      "label": "Treatments"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-inbox",
      "path": "/owner/inbox",
      "href": "/owner/inbox",
      "label": "Inbox"
    },
    {
      "id": "owner-settings",
      "path": "/owner/settings",
      "href": "/owner/settings",
      "label": "Settings"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Home"
    },
    {
      "id": "services",
      "path": "/services",
      "href": "/services",
      "label": "Services"
    },
    {
      "id": "contact",
      "path": "/contact",
      "href": "/contact",
      "label": "Contact"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "emergency",
      "path": "/emergency",
      "href": "/emergency",
      "label": "Emergency"
    },
    {
      "id": "inquiry-received",
      "path": "/inquiry-received",
      "href": "/inquiry-received",
      "label": "Inquiry Received"
    },
    {
      "id": "treatments",
      "path": "/treatments",
      "href": "/treatments",
      "label": "Treatments"
    }
  ],
  "staff": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "owner-dashboard",
      "path": "/owner/dashboard",
      "href": "/owner/dashboard",
      "label": "Dashboard"
    },
    {
      "id": "owner-inbox",
      "path": "/owner/inbox",
      "href": "/owner/inbox",
      "label": "Inbox"
    },
    {
      "id": "owner-settings",
      "path": "/owner/settings",
      "href": "/owner/settings",
      "label": "Settings"
    }
  ]
};

export const roles = [
  {
    "id": "customer",
    "label": "Patient",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "staff",
    "label": "Staff",
    "defaultPath": "/owner/dashboard",
    "icon": "chart"
  }
];

export const seed = {
  trustLabels: [
    'Northgate Dental Studio quality\', \'On schedule\', \'Repeat guests\', \'Local favorite',
  ],
  cta: {
    heading: 'Ready for Northgate Dental Studio?',
    description: 'Tell Northgate Dental Studio what you need — clear options, real next steps.',
    primaryLabel: 'Get started',
    primaryHref: '/contact#inquire',
    secondaryLabel: 'Talk to us',
    secondaryHref: '/contact#inquire',
  },
  footer: {
    description: 'Northgate Dental Studio — clear choices and a real next step.',
  },
  hero: {
    headline: "Your Smile, Our Priority – Connecting You to Care in Leeds",
    subcopy: "Northgate Dental Studio offers transparent, accessible dental care. Ask questions, get answers, and manage your appointments with ease.",
    primaryCta: { label: "Ask a Question", href: "/contact" },
    secondaryCta: { label: "Book an Appointment", href: "/book" },
  },
  credentialsHeading: "Why Northgate Dental Studio",
  credentials: [
    { title: "GDC Registered", detail: "All our dentists are registered with the General Dental Council." },
    { title: "Family Friendly", detail: "Trusted care for all ages in a welcoming environment." },
    { title: "Modern Facilities", detail: "Three state-of-the-art chairs in Leeds." },
    { title: "Transparent Pricing", detail: "Clear treatment plans, no surprises." },
  ],
  featuresHeading: "Quick Connect Features",
  features: [
    {
      title: "Quick Chat Support",
      description: "Get instant answers to common questions.",
      imageSrc: images.card1,
      imageAlt: "Chat icon",
    },
    {
      title: "Emergency Help Line",
      description: "Dedicated forms for urgent dental needs.",
      imageSrc: images.card2,
      imageAlt: "Emergency icon",
    },
    {
      title: "Treatment Information",
      description: "Explore our services and understand your options.",
      imageSrc: images.card3,
      imageAlt: "Treatment plan icon",
    },
    {
      title: "Transparent Pricing",
      description: "Clear costs for every service, no surprises.",
      imageSrc: images.card1,
      imageAlt: "Price tag icon",
    },
    {
      title: "Online Booking & Reminders",
      description: "Manage your appointments with ease and never miss a visit.",
      imageSrc: images.card2,
      imageAlt: "Calendar icon",
    },
  ],
  process: [
    { title: "Ask", description: "Use our secure chat or inquiry forms for any questions." },
    { title: "Connect", description: "Our team or AI assistant provides swift, informed responses." },
    { title: "Care", description: "Receive the information or appointment you need quickly." },
  ],
  testimonials: [
    {
      quote: "Northgate Dental made booking so easy, and the chat feature was brilliant for a quick question about my appointment. Highly recommend!",
      author: "Sarah L.",
      role: "Patient from Leeds",
    },
    {
      quote: "The emergency form truly helped when I was in pain. I got a call back within minutes, which was incredibly reassuring.",
      author: "Mark T.",
      role: "Emergency Patient",
    },
    {
      quote: "The team at Northgate Dental Studio made my clear aligner journey so easy and comfortable. I'm thrilled with my new smile!",
      author: "Sarah J.",
      role: "Clear Aligners Patient",
    },
  ],
  showcaseHeading: "Explore Our Care Options",
  items: [
    {
      id: "checkups",
      title: "Routine Check-ups & Examinations",
      description: "Comprehensive oral health assessments and preventative care for all ages.",
      badge: "Preventative",
      image: images.item1,
    },
    {
      id: "hygienist",
      title: "Hygienist Visits & Professional Cleaning",
      description: "Expert cleaning, scaling, and polishing to maintain gum health and a bright smile.",
      badge: "Maintenance",
      image: images.item2,
    },
    {
      id: "aligners",
      title: "Clear Aligners for a Straighter Smile",
      description: "Discreet and comfortable orthodontic treatment to gently correct misaligned teeth.",
      badge: "Cosmetic",
      image: images.item3,
    },
    {
      id: "emergency",
      title: "Emergency Dental Care",
      description: "Prompt attention and effective relief for urgent dental issues and pain.",
      badge: "Urgent",
      image: images.item4,
    },
    {
      id: "fillings",
      title: "Dental Fillings",
      description: "Restoring teeth damaged by decay to their original function and shape.",
      badge: "Restorative",
      image: images.item5,
    },
    {
      id: "extractions",
      title: "Tooth Extractions",
      description: "Gentle and safe removal of problematic teeth when necessary.",
      badge: "Surgical",
      image: images.item6,
    },
    {
      id: "whitening",
      title: "Professional Teeth Whitening",
      description: "Achieve a brighter, more confident smile with our safe and effective whitening treatments.",
      badge: "Cosmetic",
      image: images.item7,
    },
    {
      id: "crowns",
      title: "Crowns and Bridges",
      description: "Durable solutions to repair and replace damaged or missing teeth.",
      badge: "Restorative",
      image: images.item8,
    },
  ],
  services: [
    {
      name: "Check-ups & Examinations",
      description: "Regular check-ups to maintain your oral health.",
      duration: "30 mins",
      badge: "Routine Care",
    },
    {
      name: "Hygienist Visits",
      description: "Professional cleaning for a healthier, brighter smile.",
      duration: "45 mins",
      badge: "Preventative",
    },
    {
      name: "Clear Aligners",
      description: "Discreet orthodontic solutions for a straighter smile.",
      duration: "Consultation",
      badge: "Cosmetic",
    },
    {
      name: "Emergency Dental Care",
      description: "Prompt attention for urgent dental concerns.",
      duration: "As needed",
      badge: "Urgent",
    },
    {
      name: "Dental Fillings",
      description: "Restoring teeth damaged by decay.",
      duration: "30-60 mins",
      badge: "Restorative",
    },
    {
      name: "Root Canal Treatment",
      description: "Saving infected teeth and relieving pain.",
      duration: "60-90 mins",
      badge: "Endodontics",
    },
    {
      name: "Cosmetic Bonding",
      description: "Enhancing the appearance of chipped or discolored teeth.",
      duration: "30-60 mins",
      badge: "Cosmetic",
    },
  ],
  opsHero: {
    headline: "Care Connect: Inquiry Management Dashboard",
    subcopy: "Prioritise patient needs, streamline communication, and track team efficiency.",
  },
  kpis: [
    { label: "New Inquiries", value: "7", delta: "+3", hint: "Last 24 hours" },
    { label: "Emergencies", value: "2", delta: "0", hint: "High priority" },
    { label: "Average Response", value: "15 min", delta: "-5 min", hint: "All channels" },
    { label: "Resolved Inquiries", value: "18", delta: "+4", hint: "Today" },
  ],
  tableRows: [
    {
      id: "inc-001",
      title: "Emergency: Sarah L. (Severe Pain)",
      description: "Patient reported severe tooth pain, left side, bottom. Needs immediate attention.",
      status: "Unassigned",
      priority: "High",
      time: "5 min ago",
      assignedTo: "N/A",
      actions: ["View Details", "Assign"],
    },
    {
      id: "inc-002",
      title: "Treatment: Mark T. (Clear Aligners)",
      description: "Inquiry about cost and consultation process for clear aligners.",
      status: "New",
      priority: "Normal",
      time: "15 min ago",
      assignedTo: "Dr. Smith",
      actions: ["View Details", "Respond"],
    },
    {
      id: "inc-003",
      title: "General: Emily V. (Opening Hours)",
      description: "Question about Saturday opening hours. AI responded, awaiting confirmation.",
      status: "Awaiting Staff Review",
      priority: "Low",
      time: "30 min ago",
      assignedTo: "AI Assistant",
      actions: ["View Chat", "Resolve"],
    },
    {
      id: "inc-004",
      title: "Emergency: John P. (Broken Tooth)",
      description: "Patient experienced a sudden broken tooth during lunch. Urgent request.",
      status: "New",
      priority: "High",
      time: "45 min ago",
      assignedTo: "N/A",
      actions: ["View Details", "Assign"],
    },
    {
      id: "inc-005",
      title: "Treatment: Chloe D. (Teeth Whitening)",
      description: "Interested in professional teeth whitening. Asking about procedure and pricing.",
      status: "New",
      priority: "Normal",
      time: "1 hour ago",
      assignedTo: "Reception",
      actions: ["View Details", "Respond"],
    },
    {
      id: "inc-006",
      title: "General: David R. (Appointment Change)",
      description: "Request to reschedule an upcoming hygienist appointment.",
      status: "Open",
      priority: "Low",
      time: "2 hours ago",
      assignedTo: "Reception",
      actions: ["View Details", "Action"],
    },
    {
      id: "inc-007",
      title: "Treatment: Lisa S. (Denture Repair)",
      description: "Query regarding repair service for partial dentures.",
      status: "New",
      priority: "Normal",
      time: "3 hours ago",
      assignedTo: "Dr. Jones",
      actions: ["View Details", "Respond"],
    },
    {
      id: "inc-008",
      title: "Emergency: Paul F. (Lost Filling)",
      description: "Patient lost a filling and experiencing mild sensitivity. Looking for an urgent slot.",
      status: "New",
      priority: "Medium",
      time: "4 hours ago",
      assignedTo: "N/A",
      actions: ["View Details", "Assign"],
    },
    {
      id: "inc-009",
      title: "General: Fiona G. (Insurance Query)",
      description: "Question about accepted insurance providers.",
      status: "Resolved",
      priority: "Low",
      time: "Yesterday",
      assignedTo: "Reception",
      actions: ["View History"],
    },
    {
      id: "inc-010",
      title: "Treatment: Oliver W. (Composite Bonding)",
      description: "Inquiry about cosmetic composite bonding options.",
      status: "Open",
      priority: "Normal",
      time: "Yesterday",
      assignedTo: "Dr. Smith",
      actions: ["View Details", "Respond"],
    },
  ],
  activity: [
    { title: "Dr. Smith responded to Mark T.", detail: "Provided aligner brochure via email.", when: "2 min ago" },
    { title: "Reception assigned Emergency: Sarah L.", detail: "Assigned to Dr. Jones.", when: "5 min ago" },
    { title: "AI Chat handled Emily V.'s query", detail: "Provided opening hours and link to website.", when: "10 min ago" },
    { title: "Dr. Jones consulted on John P.'s case", detail: "Scheduled for emergency extraction.", when: "1 hour ago" },
    { title: "Reception updated David R.'s appointment", detail: "Rescheduled hygienist visit to next week.", when: "2 hours ago" },
    { title: "AI Chat provided insurance information", detail: "Fiona G. inquiry resolved.", when: "Yesterday" },
  ],
  chartData: [
    { label: "Jan", value: 25 },
    { label: "Feb", value: 30 },
    { label: "Mar", value: 45 },
    { label: "Apr", value: 40 },
    { label: "May", value: 55 },
    { label: "Jun", value: 60 },
    { label: "Jul", value: 75 },
    { label: "Aug", value: 80 },
    { label: "Sep", value: 70 },
    { label: "Oct", value: 65 },
    { label: "Nov", value: 50 },
    { label: "Dec", value: 40 },
  ],
};

export const stats = {
  totalInquiries: 85,
  resolvedToday: 18,
  averageResponseTime: "15 min",
  priorityCases: 2,
};

export const aiFeatures = [
  {
    id: "intelligent-inquiry-routing",
    name: "Intelligent Inquiry Routing",
    description: "AI analyzes keywords in form submissions and chat messages to automatically categorize inquiries (e.g., \"emergency,\" \"clear aligners,\" \"billing\") and route them to the most appropriate staff member or queue.",
    category: "workflow",
    surface: "chat",
    demo_hint: "Ask the way a real patient would ask Northgate Dental Studio",
    demo_prompts: ["I have severe pain, what should I do?", "How much do clear aligners cost?", "What are your Saturday hours?"],
    placement_label: "Customer assistant & staff support",
    demo_results: {
      "I have severe pain, what should I do?": "Northgate Dental Studio: For “I have severe pain, what should I do?” — AI immediately flags as emergency and routes to priority staff queue, providing initial first-aid advice.",
      "How much do clear aligners cost?": "Northgate Dental Studio: For “How much do clear aligners cost?” — AI routes to treatment coordinator, provides general pricing info, and offers to book a consultation.",
      "What are your Saturday hours?": "Northgate Dental Studio: For “What are your Saturday hours?” — AI provides instant answer: 'We are open from 9 AM to 1 PM on Saturdays. Please visit our contact page for full hours.'",
    },
    placement_path: "/contact",
    placement_component: "src/pages/ContactPage.tsx",
    placement_title: "Contact Us | Northgate Dental Studio",
  },
  {
    id: "automated-first-line-chat-assistant",
    name: "Automated First-Line Chat Assistant",
    description: "AI provides instant answers to common patient questions (e.g., \"What are your opening hours?\", \"Do you accept new NHS patients?\", \"What is the cost of a check-up?\") freeing up staff time for complex issues.",
    category: "customer support",
    surface: "chat",
    demo_hint: "Ask a common question to see the AI assistant in action.",
    demo_prompts: ["What are your opening hours?", "Do you accept new patients?", "What is a routine check-up cost?"],
    placement_label: "Customer assistant",
    demo_results: {
      "What are your opening hours?": "Northgate Dental Studio: Our AI assistant confirms: 'We are open Monday-Friday 8:30 AM - 5:00 PM, and Saturday 9:00 AM - 1:00 PM.'",
      "Do you accept new patients?": "Northgate Dental Studio: The AI assistant confirms: 'Yes, we are delighted to welcome new private patients. You can register online or call us.'",
      "What is a routine check-up cost?": "Northgate Dental Studio: Our AI provides an estimated cost: 'A routine check-up starts from £55. Please note prices may vary depending on your individual needs.'",
    },
    placement_path: "/contact",
    placement_component: "src/pages/ContactPage.tsx",
    placement_title: "Contact Us | Northgate Dental Studio",
  },
  {
    id: "emergency-risk-flagging",
    name: "Emergency Risk Flagging",
    description: "AI identifies phrases indicating high-priority emergencies (e.g., \"severe pain,\" \"broken tooth,\" \"swelling\") within inquiry forms and chat, immediately alerting staff.",
    category: "workflow",
    surface: "dashboard",
    demo_hint: "Submit an emergency inquiry and observe the flagging on the admin dashboard.",
    demo_prompts: ["My tooth is broken and I'm in agony.", "I have a swelling that won't go down.", "Just lost a filling, no pain but looks bad."],
    placement_label: "Staff dashboard integration",
    demo_results: {
      "My tooth is broken and I'm in agony.": "Northgate Dental Studio: AI flags this inquiry as 'CRITICAL EMERGENCY' and notifies staff via SMS/email for immediate response.",
      "I have a swelling that won't go down.": "Northgate Dental Studio: AI flags this inquiry as 'HIGH PRIORITY: Potential Infection' and moves it to the top of the staff queue.",
      "Just lost a filling, no pain but looks bad.": "Northgate Dental Studio: AI flags this as 'Urgent: Lost Filling' for next available non-emergency slot.",
    },
    placement_path: "/admin",
    placement_component: "src/pages/admin/AdminDashboardPage.tsx",
    placement_title: "Admin Dashboard | Northgate Dental Studio",
  },
  {
    id: "treatment-interest-pre-qualification",
    name: "Treatment Interest Pre-qualification",
    description: "AI can ask follow-up questions in chat for specific treatment inquiries (e.g., for clear aligners, \"Have you had braces before?\", \"Are you looking for cosmetic or functional correction?\") to gather more context before staff intervention.",
    category: "customer support",
    surface: "chat",
    demo_hint: "Ask about a specific treatment like clear aligners.",
    demo_prompts: ["Tell me about clear aligners.", "I want to get my teeth straightened.", "What are my options for a better smile?"],
    placement_label: "Customer assistant",
    demo_results: {
      "Tell me about clear aligners.": "Northgate Dental Studio: AI responds: 'Clear aligners are a discreet way to straighten your teeth. Have you had braces before, or are you looking for a consultation?'",
      "I want to get my teeth straightened.": "Northgate Dental Studio: AI asks: 'Great! Are you interested in cosmetic improvements, or are there functional issues you'd like to address?'",
      "What are my options for a better smile?": "Northgate Dental Studio: AI offers choices: 'We offer teeth whitening, veneers, and clear aligners. Which sounds most interesting to you?'",
    },
    placement_path: "/treatments/clear-aligners-inquiry",
    placement_component: "src/pages/AlignersInquiryFormPage.tsx",
    placement_title: "Clear Aligners Inquiry | Northgate Dental Studio",
  },
];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;