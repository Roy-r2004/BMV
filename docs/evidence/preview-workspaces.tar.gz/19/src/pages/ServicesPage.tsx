// directory listing scaffold — distinct from home marketing clone
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { BRAND_MANIFEST, images } from '@/data/mock';
import { PublicShell, PublicNav, PageHeader, ProductShowcase, CTABand, BrandFooter, ScheduleRail } from '@/ui';

const services = Array.isArray(BRAND_MANIFEST?.services) ? BRAND_MANIFEST.services : [];
const LISTING_BASE = "/services";

export default function ServicesPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const people = (services.length ? services : [
    { id: 'dr-1', name: 'Dr. Avery Chen', description: 'Family medicine · accepting new patients' },
    { id: 'dr-2', name: 'Dr. Jordan Miles', description: 'Pediatrics · same-week visits' },
    { id: 'dr-3', name: 'Dr. Sam Rivera', description: 'Internal medicine · telehealth available' },
  ]).map((s: any, i: number) => ({
    title: String(s.name || s.title || `Provider ${i + 1}`),
    description: String(s.description || s.specialty || s.role || 'Available for appointments'),
    imageSrc: [images.card1, images.card2, images.card3][i % 3],
    imageAlt: String(s.name || s.title || 'Provider'),
    href: `${LISTING_BASE}/${s.id || i + 1}`,
  }));

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} chrome="solid" nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton="public-catalog" data-appspec-page="services">

      <PageHeader
        title={"Services"}
        description="Browse providers, specialties, and availability — then book the right visit."
      />
      <ProductShowcase
        heading="Meet the team"
        description="Each card opens a provider profile. Book when you are ready."
        items={people}
      />

      <ScheduleRail
        heading="Ready to schedule?"
        description="Pick a time online — same team you just reviewed."
        primaryCta={{ label: "Book a visit", href: "/book-appointment" }}
        secondaryCta={{ label: "Ask AI assistant", href: "/ai-features" }}
      />
      <BrandFooter brandName={"Jeanne Kassab Art"} description="Real providers. Clear booking. Not another homepage clone." />
      </div>
    </PublicShell>
  );
}
