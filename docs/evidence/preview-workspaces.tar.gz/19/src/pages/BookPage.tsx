// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, BookingPanel, CTABand, BrandFooter, Button } from '@/ui';
import { Fragment } from 'react';

const SKELETON_ID = "public-booking" as const;
const RECIPE_ORDER = ["hero", "features", "booking", "cta", "footer"] as const;

export default function BookPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"Experience The Galerie Jeanne"}
        subcopy={"Discover a curated collection of original oil paintings. Each piece, a unique expression of layered oils and abstract landscapes, crafted by hand in Lebanon."}
        variant="atelier"
        primaryCta={{ label: "View New Arrivals", href: "#gallery" }}
        secondaryCta={{ label: "Meet the Artist", href: "/about" }}
        imageSrc={images.hero} 
        imageAlt="An abstract oil painting with layered blues and whites, characteristic of Jeanne Kassab Art."
        className="text-center font-display leading-tight"
        eyebrow="Original Oil Paintings"
      />
    ),
    features: (
      // The FeatureBento component here is a placeholder for content that aligns with the "features" slot
      // In this context, it's used to highlight aspects of the art or the gallery experience.
      <FeatureBento
        heading="A Personal Invitation to Art"
        description="Every painting is a journey, an emotion, a unique story waiting to be discovered."
        imagePool={[images.card1, images.card2, images.card3]} // Use relevant-sounding images from the data
        items={[
          {
            title: "Original Works",
            description: "Each oil painting is a one-of-a-kind creation, imbued with Jeanne's distinct artistic voice."
          },
          {
            title: "Lebanese Craftsmanship",
            description: "Hand-crafted in Lebanon, these pieces carry the soul and landscape of their origin."
          },
          {
            title: "Direct from Studio",
            description: "Acquire art directly from the artist's studio, ensuring authenticity and a personal connection."
          },
          {
            title: "Art for Collections",
            description: "Invest in timeless pieces desired by discerning collectors and interior designers worldwide."
          },
        ]}
      />
    ),
    booking: (
      // Reinterpreting BookingPanel for "The Galerie Jeanne" to facilitate artwork inquiry
      // Not a typical booking flow, but an inquiry mechanism for specific pieces or general interest.
      <BookingPanel
        heading="Inquire with Jeanne about a painting"
        description="If a piece speaks to you, connect directly with Jeanne Kassab via WhatsApp to discuss availability or commissions. We aim for a calm, gallery-led experience, not a busy marketplace."
        confirmLabel="Send Inquiry via WhatsApp"
        onConfirm={() => {
          // Placeholder for WhatsApp redirection logic if needed for a general inquiry
          // For specific artworks, this would be on the artwork detail page.
          const whatsappMessage = "Hello Jeanne, I am interested in your art. Could you tell me more?";
          window.open(`https://wa.me/?text=${encodeURIComponent(whatsappMessage)}`, '_blank');
        }}
        className="max-w-xl mx-auto p-8 bg-surface rounded-lg shadow-sm"
      >
        <div className="space-y-4">
          <Input label="Your Name" placeholder="Enter your name" />
          <Input label="Your Email (Optional)" type="email" placeholder="email@example.com" />
          <Select
            label="What is your inquiry about?"
            options={[
              { label: "A specific painting (please mention title)", value: "specific_painting" },
              { label: "General gallery interest", value: "general_interest" },
              { label: "Commissioning a new piece", value: "commission" },
              { label: "International Shipping", value: "shipping" },
            ]}
          />
          <Input as="textarea" label="Your Message" rows={4} placeholder="Tell Jeanne more about your interest..." />
          <p className="text-sm text-muted">
            Clicking "Send Inquiry via WhatsApp" will open a message draft with Jeanne directly.
          </p>
        </div>
      </BookingPanel>
    ),
    cta: (
      // CTABand reinterpreted for "The Galerie Jeanne" to prompt further exploration or direct contact
      <CTABand
        heading="Ready to Bring Art Home?"
        description="Explore the full collection or connect intimately with Jeanne Kassab to find your next significant piece."
        primaryCta={{ label: "Browse the Gallery", href: "/" }}
        secondaryCta={{ label: "Connect with Jeanne", onClick: () => {
          const whatsappMessage = "Hello Jeanne, I would like to connect about your art.";
          window.open(`https://wa.me/?text=${encodeURIComponent(whatsappMessage)}`, '_blank');
        } }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Jeanne Kassab Art showcases original oil paintings by Jeanne Kassab. Hand-crafted in Lebanon for discerning collectors worldwide."}
        links={[
          { label: "About Jeanne", href: "/about" },
          { label: "Gallery", href: "/" },
          { label: "Privacy Policy", href: "#" }, 
        ]}
        meta={
          <Fragment>
            <span>&copy; {new Date().getFullYear()} Jeanne Kassab Art. All rights reserved.</span>
            <span>Made with passion in Lebanon.</span>
          </Fragment>
        }
      />
    ),
  };

  return (
    <PublicShell 
      brandName={"Jeanne Kassab Art"} 
      nav={<PublicNav items={navItems} cta={navCta} />}
      chrome="immersive"
    >
      <div data-skeleton={skeleton.id} data-appspec-page="book">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}

// Dummy Input and Select components for the BookingPanel, as they are not globally imported but assumed from the contract's optionalProps.
// In a real scenario, these would be exported from @/ui.
const Input = ({ label, ...props }: any) => (
  <div>
    {label && <label className="block text-sm font-medium text-text mb-1">{label}</label>}
    <input
      className="block w-full px-3 py-2 border border-muted/30 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-surface text-text"
      {...props}
    />
  </div>
);

const Select = ({ label, options, ...props }: any) => (
  <div>
    {label && <label className="block text-sm font-medium text-text mb-1">{label}</label>}
    <select
      className="block w-full pl-3 pr-10 py-2 text-base border-muted/30 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md bg-surface text-text"
      {...props}
    >
      {options.map((option: any) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  </div>
);