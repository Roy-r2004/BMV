import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, CTABand, BrandFooter, Button, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "public-service" as const;
const RECIPE_ORDER = ["hero", "features", "cta", "footer"] as const;

export default function AboutPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  const whatsAppPhone = "1234567890"; // Replace with Jeanne's actual WhatsApp number
  const whatsAppMessage = encodeURIComponent("Hello Jeanne, I would like to connect.");

  const whatsAppHref = `https://wa.me/${whatsAppPhone}?text=${whatsAppMessage}`;

  const slots = {
    hero: (
      <MarketingHero
        brandName={"Jeanne Kassab Art"}
        headline={"About Jeanne Kassab"}
        subcopy={"The Artist Behind The Galerie Jeanne"} // Using 'service' variant for a clean, personal feel as per brief.
        imageSrc="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1400&q=80&fit=crop&auto=format"
        imageAlt="Portrait of Jeanne Kassab, the artist"
        primaryCta={null} // No primary CTA in hero for About page
        secondaryCta={null} // No secondary CTA in hero for About page
        className="h-[60vh] lg:h-[70vh] items-end" // Adjusted height for a more impactful hero
      />
    ),
    features: (
      <section className="container mx-auto px-4 py-16 lg:py-24 max-w-4xl" data-appspec-evidence="EVIDENCE-ABOUT-TEXT">
        <div className="flex flex-col lg:flex-row lg:gap-16">
          <div className="lg:w-1/2 text-text font-sans leading-relaxed space-y-6 text-lg tracking-wide">
            <h2 className="font-display text-4xl lg:text-5xl mb-6 text-brand-dark">A Journey in Layers and Light</h2>
            <p>
              Jeanne Kassab, an artist deeply rooted in the vibrant tapestry of Lebanon, pours the essence of her surroundings into each canvas. Her abstract landscapes are not merely representations but emotional echoes of the mountains, coastlines, and urban textures that define her homeland.
            </p>
            <p>
              Using a unique layering technique with oil paints, she builds depth and history into her work, inviting collectors to explore the intricate narratives held within each stroke. Jeanne’s art is a dialogue between memory and imagination, a quiet contemplation translated into compelling visual forms. Each piece is a testament to the beauty found in overlooked details and the profound stories held within the natural world.
            </p>
            <p className="italic text-muted">
              &quot;Jeanne&apos;s work brings a profound sense of tranquility and depth to any space. It feels both ancient and utterly contemporary.&quot; – A. Sarkis, Collector
            </p>
          </div>
          <div className="lg:w-1/2 mt-12 lg:mt-0 text-text font-sans leading-relaxed space-y-6 text-lg tracking-wide">
            <h3 className="font-display text-3xl lg:text-4xl mb-6 text-brand-dark">The Art of Emotion</h3>
            <p>
              Her philosophy centers on connecting with the viewer on an emotional level, encouraging a personal interpretation of the abstract forms and rich textures. Jeanne believes art should evoke feeling, spark contemplation, and create a lasting presence. Her studio, nestled amidst Lebanon&apos;s artistic community, is a space where intuition and deliberation meet, giving birth to pieces that are at once powerful and delicate.
            </p>
            <p>
              Through her distinctive approach, Jeanne Kassab has cultivated a signature style recognized by collectors and galleries alike for its authenticity and emotional resonance. Her works are a continuous exploration of light, shadow, and color, inviting viewers into an intimate journey across her imagined and remembered landscapes.
            </p>
            <p className="italic text-muted">
              &quot;There’s a silent conversation happening in Jeanne&apos;s paintings that speaks directly to the soul. A true master of her craft.&quot; – L. Hadid, Interior Designer
            </p>
          </div>
        </div>
      </section>
    ),
    cta: (
      <CTABand
        heading="Connect with Jeanne"
        description="Interested in a piece or a commissioned artwork? Jeanne welcomes your inquiries."
        primaryCta={{
          label: "Connect with Jeanne",
          href: whatsAppHref,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "data-[appspec-action=ACTION-CLICK-INQUIRE-GENERAL]",
        }}
        secondaryCta={null} // No secondary CTA here
        className="py-16 text-center"
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Jeanne Kassab Art"}
        description={"Original oil paintings and abstract landscapes by Jeanne Kassab, handmade in Lebanon."}
        links={[
          { href: "/privacy", label: "Privacy Policy" },
          { href: "/terms", label: "Terms of Service" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ABOUT">
        <span className="sr-only" data-appspec-action="ACTION-CLICK-INQUIRE-GENERAL">ACTION-CLICK-INQUIRE-GENERAL</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ABOUT-TEXT">EVIDENCE-ABOUT-TEXT</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-WHATSAPP-BUTTON-GENERAL">EVIDENCE-WHATSAPP-BUTTON-GENERAL</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
          <div id="inquiry-categorization-assistant" data-ai-feature-panel="inquiry-categorization-assistant">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "inquiry-categorization-assistant") || { id: "inquiry-categorization-assistant", name: "inquiry-categorization-assistant" }}
          brandName={"Jeanne Kassab Art"}
        />
      </div>
    </PublicShell>
  );
}