// plan AI feature hub — every planned AI feature is interactive here
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { aiFeatures } from '@/data/mock';
import { PublicShell, PublicNav, AiFeatureDeck } from '@/ui';

export default function AiFeaturesPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const features = Array.isArray(aiFeatures) && aiFeatures.length
    ? aiFeatures
    : [];
  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-appspec-page={"PAGE-AI-FEATURES"}>

        <AiFeatureDeck features={features} brandName={"Jeanne Kassab Art"} />
      </div>
    </PublicShell>
  );
}
