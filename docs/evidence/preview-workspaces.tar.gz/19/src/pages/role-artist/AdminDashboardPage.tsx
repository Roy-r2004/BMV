// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, FilterBar, DataTable, ChartCard, ActivityFeed, Button, UiIcon } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const artworks = [
    { id: "1", title: "Untitled Abstraction No. 3", medium: "Oil on Canvas", year: "2023", price: "USD 3,500", status: "Available" },
    { id: "2", title: "Coastal Serenity", medium: "Oil on Wood", year: "2022", price: "USD 2,800", status: "Sold" },
    { id: "3", title: "Mountain Mist", medium: "Layered Oils", year: "2024", price: "USD 4,100", status: "Available" },
    { id: "4", title: "Golden Hour", medium: "Mixed Media", year: "2023", price: "USD 3,200", status: "Available" },
    { id: "5", title: "Forest Edge", medium: "Acrylic & Oil", year: "2024", price: "USD 3,900", status: "Available" },
    { id: "6", title: "Whispers of the Sea", medium: "Oil on Canvas", year: "2023", price: "USD 3,700", status: "Available" },
    { id: "7", title: "Desert Bloom", medium: "Layered Oils", year: "2022", price: "USD 2,950", status: "Sold" },
  ];

  const slots = {
    header: (
      <PageHeader
        title="The Galerie Jeanne - Dashboard"
        actions={[
          <Button key="add-artwork" variant="outline" data-appspec-action="ACTION-NAV-TO-ADD-ARTWORK">
            Add New Artwork
          </Button>,
          <UiIcon key="profile" name="user-circle" className="h-8 w-8 text-text-muted" />,
        ]}
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="New Inquiries (Today)"
          value="2"
          delta="+1"
          hint="today"
          icon={<UiIcon name="message-circle" />}
          variant="card"
        />
        <StatCard
          label="Active Artworks"
          value="18"
          delta="-1"
          hint="status"
          icon={<UiIcon name="brush" />}
          variant="card"
        />
        <StatCard
          label="About Page Views (Week)"
          value="145"
          delta="+12%"
          hint="increase"
          icon={<UiIcon name="eye" />}
          variant="card"
        />
      </div>
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search artworks..."
        filters={[
          { id: "all", label: "All", active: true },
          { id: "available", label: "Available", active: false },
          { id: "sold", label: "Sold", active: false },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "title", header: "Title" },
          { key: "medium", header: "Medium" },
          { key: "year", header: "Year" },
          { key: "price", header: "Price" },
          { key: "status", header: "Status" },
          {
            key: "actions", header: "Actions", cell: () => (
              <div className="space-x-2">
                <Button size="sm" variant="outline">Edit</Button>
                <Button size="sm" variant="destructive">Delete</Button>
              </div>
            )
          },
        ]}
        rows={artworks.map((artwork) => ({
          ...artwork,
          status: <span className={artwork.status === "Available" ? "text-primary" : "text-text-muted"}>{artwork.status}</span>
        }))}
        data-appspec-evidence="EVIDENCE-ARTWORK-LIST-ADMIN"
      />
    ),
    chart: (
      <ChartCard
        title="Artwork Inquiry Trends"
        type="area"
        dataKey="inquiries"
        xKey="week"
        data={[
          { week: "Week 1", inquiries: 5 },
          { week: "Week 2", inquiries: 8 },
          { week: "Week 3", inquiries: 6 },
          { week: "Week 4", inquiries: 10 },
          { week: "Week 5", inquiries: 7 },
        ]}
        description="WhatsApp inquiries over the last 5 weeks"
        density="comfortable"
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "activity-1", title: "Artwork 'Golden Hour' updated by Jeanne", detail: "", time: "5 min ago" },
          { id: "activity-2", title: "New inquiry for 'Forest Edge' via WhatsApp", detail: "", time: "30 min ago" },
          { id: "activity-3", title: "About page content revised", detail: "", time: "2 hours ago" },
          { id: "activity-4", title: "Artwork 'Mountain Mist' uploaded", detail: "", time: "1 day ago" },
          { id: "activity-5", title: "New inquiry for 'Untitled Abstraction No. 3' via WhatsApp", detail: "", time: "2 days ago" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ADMIN-DASHBOARD">
        <span className="sr-only" data-appspec-action="ACTION-NAV-TO-ADD-ARTWORK">ACTION-NAV-TO-ADD-ARTWORK</span>
        <span className="sr-only" data-appspec-action="ACTION-NAV-TO-EDIT-ABOUT">ACTION-NAV-TO-EDIT-ABOUT</span>
        <span className="sr-only" data-appspec-action="ACTION-NAV-TO-AI-FEATURES">ACTION-NAV-TO-AI-FEATURES</span>
        {/* Intentionally left blank as evidence is primarily handled by explicit UI elements */}
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ADMIN-NAV">EVIDENCE-ADMIN-NAV</span> 
{main}</div>
    </OpsShell>
  );
}