// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed } from '@/data/mock';
import { OpsShell, getSkeleton, SkeletonComposer, PageHeader, Input, Button, ActivityFeed, UiIcon, AiFeaturePanel } from '@/ui';
import { useState } from 'react';

const SKELETON_ID = "ops-detail" as const;
export default function AdminArtworkEditPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);

  const [isAvailable, setIsAvailable] = useState(true); // State for availability toggle

  const slots = {
    header: (
      <PageHeader
        title={"Edit Artwork"}
        description={"Manage details and images for 'Untitled Abstraction No. 3'."}
        actions={[]}
        data-appspec-state="STATE-ADMIN-ARTWORK-EDIT-FORM"
      />
    ),
    table: (
      <div className="flex flex-col gap-6 md:flex-row md:gap-8">
        {/* Artwork Edit Form */}
        <div className="flex-1 space-y-6" data-appspec-evidence="EVIDENCE-ARTWORK-EDIT-FORM">
          <h2 className="font-display text-xl text-text">Artwork Details</h2>
          <Input id="title" label="Title" defaultValue="Untitled Abstraction No. 3" />
          <Input id="medium" label="Medium" defaultValue="Oil on Canvas" />
          <Input id="year" label="Year" defaultValue="2023" type="number" />
          <Input id="dimensions" label="Dimensions" defaultValue="100 x 80 cm" />
          <Input id="price" label="Price" defaultValue="3500" type="number" prefix='$' />

          <div className="flex items-center justify-between">
            <label htmlFor="availability-toggle" className="text-text text-sm font-medium leading-none">
              Availability
            </label>
            <button
              id="availability-toggle"
              onClick={() => setIsAvailable(!isAvailable)}
              className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                isAvailable ? 'bg-primary' : 'bg-muted'
              }`}
              role="switch"
              aria-checked={isAvailable}
            >
              <span
                className={`transform transition-transform ease-in-out duration-200 ${
                  isAvailable ? 'translate-x-6' : 'translate-x-1'
                } inline-block h-4 w-4 rounded-full bg-surface`}
              />
            </button>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="ghost">Cancel</Button>
            <Button data-appspec-action="ACTION-SAVE-ARTWORK">Save Changes</Button>
          </div>
        </div>

        {/* Image Upload & Optimization */}
        <div className="flex-1 space-y-6" data-appspec-evidence="EVIDENCE-IMAGE-UPLOAD-FIELD">
          <h2 className="font-display text-xl text-text">Artwork Images</h2>
          <div className="rounded-md border border-dashed border-gray-300 p-6 text-center">
            <UiIcon name="upload" className="mx-auto h-10 w-10 text-muted" />
            <p className="mt-2 text-sm text-text">Drag an image here, or <span className="font-medium text-primary cursor-pointer">browse</span></p>
            <p className="text-xs text-muted mt-1">Main Artwork Image</p>
            <img src="/placeholder-artwork.jpg" alt="Current Artwork" className="mt-4 mx-auto max-h-48 object-contain rounded-lg" />
          </div>
          <p className="text-xs text-muted">Automatically optimized for web display.</p>
          <Button variant="secondary" className="w-full">
            Add Additional Images
          </Button>
        </div>
      </div>
    ),
    activity: (
      <ActivityFeed
        heading="Artwork Activity Log"
        items={[
          { id: "activity-1", title: "Price updated from $3400 to $3500", detail: "(Yesterday)", time: "" },
          { id: "activity-2", title: "Image updated", detail: "(3 days ago)", time: "" },
          { id: "activity-3", title: "Status changed to Available", detail: "(1 month ago)", time: "" },
        ]}
      />
    ),
  };

  return (
    <OpsShell brandName={"Jeanne Kassab Art"} navItems={adminNavItems}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ADMIN-ARTWORK-EDIT">

        <span className="sr-only" data-appspec-action="ACTION-SAVE-ARTWORK">ACTION-SAVE-ARTWORK</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-ARTWORK-EDIT-FORM">EVIDENCE-ARTWORK-EDIT-FORM</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-IMAGE-UPLOAD-FIELD">EVIDENCE-IMAGE-UPLOAD-FIELD</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
          <div id="smart-content-suggestion-for-about-page" data-ai-feature-panel="smart-content-suggestion-for-about-page">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "smart-content-suggestion-for-about-page") || { id: "smart-content-suggestion-for-about-page", name: "smart-content-suggestion-for-about-page" }}
          brandName={"Jeanne Kassab Art"}
        />
      </div>
    </OpsShell>
  );
}