// deterministic catalogue contract scaffold

import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProductShowcase, CTABand, BrandFooter } from '@/ui';
import { usePublicNavItems, publicCta } from '@/lib/app-nav';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "showcase", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  // Override publicCta to point to the About page for general inquiries
  const customNavCta = { label: "Connect with Jeanne", href: "/about" };

  const skeleton = getSkeleton(SKELETON_ID);

  // Sample artwork data for the showcase
  const artworks = [
    {
      title: "Silent Shores",
      medium: "Oil on Canvas",
      imageSrc: "https://images.unsplash.com/photo-1579783902671-9257bb51bc23?w=900&q=80&fit=crop&auto=format",
    },
    {
      title: "Mediterranean Whisper",
      medium: "Layered Oils",
      imageSrc: "https://images.unsplash.com/photo-1549880338-65ddcdfd017b?w=900&q=80&fit=crop&auto=format",
    },
    {
      title: "Azure Hues",
      medium: "Oil on Linen",
      imageSrc: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=900&q=80&fit=crop&auto=format",
    },
    {
      title: "Desert Bloom",
      medium: "Oil on Board",
      imageSrc: "https://images.unsplash.com/photo-1502652158023-e28e08d6d601?w=900&q=80&fit=crop&auto=format",
    },
    {
      title: "Coastal Embrace",
      medium: "Layered Oils",
      imageSrc: "https://images.unsplash.com/photo-1579783900882-c0d3ce7c8b0e?w=900&q=80&fit=crop&auto=format",
    },
    {
      title: "Mountain Echoes",
      medium: "Oil on Canvas",
      imageSrc: "https://images.unsplash.com/photo-1506794851221-a53ec2dce30e?w=900&q=80&fit=crop&auto=format",
    },
  ];

  const slots = {
    hero: (
      <MarketingHero 
        brandName={"Jeanne Kassab Art"} 
        headline={<span className="font-display text-text-brand text-6xl md:text-7xl lg:text-[7rem] leading-none">Jeanne Kassab Art</span>} 
        subcopy={"Original oil paintings from Lebanon. Abstract landscapes and layered oils, made by hand."} 
        primaryCta={{label: "View The Galerie", href: "/gallery"}} 
        imageSrc={'https://images.unsplash.com/photo-1518770660439-4636190af475?w=900&q=80&fit=crop&auto=format'} 
        imageAlt="A vibrant abstract oil painting by Jeanne Kassab"
        className="text-white-brand" // Use white text for hero overlay to ensure contrast
      />
    ),
    showcase: (
      <ProductShowcase 
        heading="Latest Works" 
        description="A curated selection of new original oil paintings available now."
        items={artworks.map((artwork, index) => ({ 
          title: artwork.title, 
          description: artwork.medium, 
          imageSrc: artwork.imageSrc, 
          imageAlt: artwork.title,
          href: `/artwork/${index + 1}` // Placeholder for actual artwork detail page links
        }))} 
        className="py-12 md:py-20"
      />
    ),
    cta: (
      <CTABand 
        heading="Connect with Jeanne" 
        description="Have a question about a piece or want to discuss a commission? Jeanne is available to chat directly."
        primaryCta={{ 
          label: "Message Jeanne on WhatsApp", 
          href: `https://wa.me/YOUR_PHONE_NUMBER/?text=Hello%20Jeanne,%20I'd%20like%20to%20inquire%20about%20your%20art.`, // Replace YOUR_PHONE_NUMBER with Jeanne's WhatsApp number
          target: "_blank" 
        }} 
        secondaryCta={{ 
          label: "Learn More About the Artist", 
          href: "/about" 
        }} 
        className="bg-background-brand text-text-brand py-12 md:py-20"
      />
    ),
    footer: (
      <BrandFooter 
        brandName={"Jeanne Kassab Art"} 
        description="The Galerie Jeanne — Original fine art paintings by Jeanne Kassab, handmade in Lebanon."
        links={[
          { label: "Home", href: "/" },
          { label: "Gallery", href: "/gallery" },
          { label: "About", href: "/about" },
        ]}
        className="bg-surface-brand text-muted-brand border-t border-muted-brand/10"
      />
    ),
  };

  return (
    <PublicShell 
      brandName={"Jeanne Kassab Art"} 
      nav={<PublicNav items={navItems} cta={navCta} />}
      className="bg-background-brand"
    >
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-HOMEPAGE">
        <span className="sr-only" data-appspec-action="ACTION-CLICK-ARTWORK">ACTION-CLICK-ARTWORK</span>
        <span className="sr-only" data-appspec-action="ACTION-CLICK-ABOUT-PAGE">ACTION-CLICK-ABOUT-PAGE</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-HOMEPAGE-HERO">EVIDENCE-HOMEPAGE-HERO</span>
        <span className="sr-only" data-appspec-evidence="EVIDENCE-GALLERY-GRID">EVIDENCE-GALLERY-GRID</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}