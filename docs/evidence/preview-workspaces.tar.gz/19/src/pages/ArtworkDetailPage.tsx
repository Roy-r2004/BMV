// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, ProductShowcase, CTABand, BrandFooter, Button } from '@/ui';

const SKELETON_ID = "public-detail" as const;
const RECIPE_ORDER = ["hero", "showcase", "cta", "footer"] as const;

export default function ArtworkDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);

  // Sample artwork data (this would typically come from a dynamic source based on :id)
  const artwork = {
    title: "Untitled Abstraction No. 3",
    medium: "Oil on Canvas",
    year: "2023",
    dimensions: "100 x 80 cm",
    price: "USD 3,500",
    imageSrc: "https://images.unsplash.com/photo-1551434678-e076c223a691?w=1400&q=80&fit=crop&auto=format",
    description: "This piece captures the rugged beauty of the Lebanese mountains, with layered oils building a sense of depth and timelessness."
  };

  const whatsAppMessage = encodeURIComponent(
    `Hello Jeanne, I'm interested in *${artwork.title}*. Is it still available?`
  );
  const whatsAppLink = `https://wa.me/?text=${whatsAppMessage}`; // Replace with actual WhatsApp number if available

  const slots = {
    hero: (
      <div className="flex flex-col lg:flex-row gap-8 lg:gap-16 p-6 lg:p-12" data-appspec-evidence="EVIDENCE-ARTWORK-IMAGE">
        {/* Artwork Image */}
        <div className="lg:w-2/3">
          <img
            src={artwork.imageSrc}
            alt={artwork.title}
            className="w-full h-auto object-cover border border-gray-200"
          />
        </div>

        {/* Artwork Details */}
        <div className="lg:w-1/3 flex flex-col justify-center py-4 px-2 lg:px-0" data-appspec-evidence="EVIDENCE-ARTWORK-DETAILS">
          <h1 className="font-display text-4xl lg:text-5xl text-text mb-4">
            {artwork.title}
          </h1>
          <p className="font-sans text-muted text-lg mb-2">
            Medium: {artwork.medium}
          </p>
          <p className="font-sans text-muted text-lg mb-2">
            Year: {artwork.year}
          </p>
          <p className="font-sans text-muted text-lg mb-2">
            Dimensions: {artwork.dimensions}
          </p>
          <p className="font-sans text-text text-xl font-medium mb-6">
            Price: {artwork.price}
          </p>

          {/* About the piece (optional) */}
          {artwork.description && (
            <p className="font-sans text-muted mb-8 text-base leading-relaxed">
              {artwork.description}
            </p>
          )}

          {/* Inquiry Call to Action */}
          <Button
            variant="default"
            size="lg"
            href={whatsAppLink}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full lg:w-auto bg-brand text-white hover:bg-opacity-90 transition-colors"
            data-appspec-action="ACTION-CLICK-INQUIRE-ARTWORK"
            data-appspec-evidence="EVIDENCE-WHATSAPP-BUTTON-ARTWORK"
          >
            Inquire about this piece
          </Button>
        </div>
      </div>
    ),
    showcase: (
      <ProductShowcase heading={"More Works by Jeanne"} className="px-6 lg:px-12 py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {[{ title: "Coastal Serenity", description: "Oil on Canvas", imageSrc: images.card1 },
           { title: "Mountain Layers", description: "Oil on Wood Panel", imageSrc: images.card2 },
           { title: "Abstract Horizon", description: "Acrylic & Oil on Linen", imageSrc: images.card3 }]
          .map((item, index) => (
            <div key={index} className="flex flex-col">
              <img
                src={item.imageSrc}
                alt={item.title}
                className="w-full h-64 object-cover mb-4 border border-gray-100"
              />
              <h3 className="font-display text-xl text-text">{item.title}</h3>
              <p className="font-sans text-muted text-sm">{item.description}</p>
            </div>
          ))}
        </div>
      </ProductShowcase>
    ),
    cta: (
      <CTABand
        heading={"Experience The Galerie Jeanne"}
        description={"Connect with Jeanne directly for commissions or general inquiries."}
        primaryCta={{ label: "Connect with Jeanne", href: `https://wa.me/?text=${encodeURIComponent("Hello Jeanne, I have a general inquiry about your art.")}`, target: "_blank", rel: "noopener noreferrer" }}
        className="py-16 px-6 lg:px-12"
      />
    ),
    footer: (
      <BrandFooter brandName={"Jeanne Kassab Art"} description={"Original oil paintings by Jeanne Kassab. Handcrafted in Lebanon."} className="px-6 lg:px-12" />
    ),
  };

  return (
    <PublicShell brandName={"Jeanne Kassab Art"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="PAGE-ARTWORK-DETAIL">
        <span className="sr-only" data-appspec-evidence="EVIDENCE-WHATSAPP-APP-OPENED">WhatsApp app opened</span>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}