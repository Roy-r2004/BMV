export const RECIPE_ID = "dense-ops-ledger" as const;
