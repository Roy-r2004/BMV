export const brand = {"name": "Jeanne Kassab Art", "tagline": "", "design_system": {"primary_color": "#0f766e", "secondary_color": "#0369a1", "background_color": "#f8fafc", "surface_color": "#ffffff", "text_color": "#1c1917", "muted_text_color": "#78716c", "font_family": "Source Sans 3", "display_font_family": "Fraunces", "font_import_url": "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Source+Sans+3:wght@400;500;600;700&display=swap", "font_sans": "\"Source Sans 3\", \"Segoe UI\", sans-serif", "font_display": "\"Fraunces\", Georgia, serif", "brand_locked": true, "brand_brief_version": "1.0", "mood": "modern", "voice": "Confident and sparse. Let materials and type carry the tone.", "signature": "Editorial asymmetry and display type that could only belong to Jeanne Kassab Art.", "avoid": ["purple-on-white or purple-to-indigo default themes", "Inter / Roboto / Arial as the display face", "card grids in the hero", "generic SaaS marketing copy", "inventing a second palette per page"], "rules": ["Every page inherits this palette and type stack via CSS tokens only.", "Use bg-brand / text-brand / font-display — never hardcode hex colors.", "First viewport must feature the brand name as a hero-level signal."], "recipe_id": "dense-ops-ledger", "hub_variant": "app", "hero_variant": "compact", "feature_variant": "grid", "recipe_prompt": "RECIPE dense-ops-ledger: light ledger chrome, cash pulse first, invoice status boards, bank/books recon split. Soft paper atmosphere — never a dark trading floor or marketing hero.", "style_keywords": "Ledger ops · Soft glass", "border_radius": "0.67rem", "design_overlay_id": "soft_glass", "design_overlay_label": "Soft glass", "design_overlay_blurb": "Modern product glass — translucent cards, medium radius, brand wash.", "density": "comfortable", "token_overrides": {"radius_ui": "0.67rem", "bg_mix": "7%", "fg_mix": "40%", "muted_mix": "32%", "border_mix": "16%", "shadow": "0 22px 48px -32px", "shadow_alpha": "34%", "glow": "12%", "card": "#ffffff", "atmosphere": "radial-gradient(90% 60% at 0% 0%, color-mix(in srgb, var(--color-brand) 16%, transparent), transparent 55%), radial-gradient(55% 45% at 100% 0%, color-mix(in srgb, var(--color-accent) 12%, transparent), transparent 50%), linear-gradient(165deg, color-mix(in srgb, var(--color-brand) 8%, #f4f6f8), #f7f8fa 55%, #eef1f5)"}, "font_import": "Fraunces:opsz,wght@9..144,500;9..144,600&family=Source+Sans+3:wght@400;500;600;700", "design_brief_version": "1.0", "design_brief_sealed": true},
  services: [{"name": "Jeanne Kassab Art Signature", "title": "Jeanne Kassab Art Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Jeanne Kassab Art experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Jeanne", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Jeanne Kassab Art clients.",

  design_system: {"primary_color": "#0f766e", "secondary_color": "#0369a1", "accent": "#0f766e", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "sourcesans3", "font_import_url": "https://fonts.googleapis.com/css2?family=source+sans+3:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"},
  name: "Jeanne Kassab Art",
  tagline: {},
};

export const images = {
  "hero": "https://images.unsplash.com/photo-1518770660439-4636190af475?w=900&q=80&fit=crop&auto=format",
  "hero2": "https://images.unsplash.com/photo-1551434678-e076c223a691?w=1400&q=80&fit=crop&auto=format",
  "card1": "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1400&q=80&fit=crop&auto=format",
  "card2": "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=700&q=80&fit=crop&auto=format",
  "card3": "https://images.unsplash.com/photo-1537432376769-00f5c2f4c8d2?w=700&q=80&fit=crop&auto=format",
  "ambient": "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=700&q=80&fit=crop&auto=format"
};

export const roles = [
  {
    "id": "ROLE-COLLECTOR",
    "label": "Art Collector/Visitor",
    "defaultPath": "/",
    "icon": "users"
  },
  {
    "id": "ROLE-ARTIST",
    "label": "Jeanne Kassab (Artist/Admin)",
    "defaultPath": "/admin/dashboard",
    "icon": "users"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Homepage"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "services",
      "path": "/services",
      "href": "/services",
      "label": "Services"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    },
    {
      "id": "artwork",
      "path": "/artwork",
      "href": "/artwork",
      "label": "Artwork Detail Page"
    }
  ],
  "admin": [
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login Page"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-artwork-edit",
      "path": "/admin/artwork/edit",
      "href": "/admin/artwork/edit",
      "label": "Admin Artwork Edit Page"
    },
    {
      "id": "admin-about-edit",
      "path": "/admin/about/edit",
      "href": "/admin/about/edit",
      "label": "Admin About Page Edit"
    }
  ],
  "ROLE-COLLECTOR": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Homepage"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "services",
      "path": "/services",
      "href": "/services",
      "label": "Services"
    },
    {
      "id": "about",
      "path": "/about",
      "href": "/about",
      "label": "About Page"
    },
    {
      "id": "artwork",
      "path": "/artwork",
      "href": "/artwork",
      "label": "Artwork Detail Page"
    }
  ],
  "ROLE-ARTIST": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-login",
      "path": "/admin/login",
      "href": "/admin/login",
      "label": "Admin Login Page"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Admin Dashboard"
    },
    {
      "id": "admin-artwork-edit",
      "path": "/admin/artwork/edit",
      "href": "/admin/artwork/edit",
      "label": "Admin Artwork Edit Page"
    },
    {
      "id": "admin-about-edit",
      "path": "/admin/about/edit",
      "href": "/admin/about/edit",
      "label": "Admin About Page Edit"
    }
  ]
};

export const seed = {
  hero: {
    eyebrow: 'Jeanne Kassab Art',
    headline: 'Jeanne Kassab Art',
    subcopy: 'A clear next step from Jeanne Kassab Art — warm, specific, and ready when you are.',
    primaryCta: { label: 'Get started', href: '#details' },
    secondaryCta: { label: 'See how it works', href: '#process' },
  },
  items: [
    { title: 'Jeanne Kassab Art signature', description: 'A dependable starting point at Jeanne Kassab Art.' },
    { title: 'Everyday essential', description: 'Built for daily use.' },
    { title: 'Guest favorite', description: 'The one people come back to Jeanne Kassab Art for.' },
  ],
  features: [
    { title: 'What Jeanne Kassab Art is known for', description: 'Concrete offerings guests can book without guessing.' },
    { title: 'Guided next step', description: 'Every section points toward a clear action.' },
    { title: 'Built for return visits', description: 'Details that make Jeanne Kassab Art easy to come back to.' },
  ],
  featuresHeading: 'What Jeanne Kassab Art offers',
  showcaseHeading: 'From Jeanne Kassab Art',
  credentialsHeading: 'Why Jeanne Kassab Art',
  credentials: [
    { title: 'Known locally', detail: 'Neighbors recommend Jeanne Kassab Art for consistent results.' },
    { title: 'Clear next steps', detail: 'Booking and follow-up stay simple from the start.' },
  ],
  trustLabels: [
    'Jeanne Kassab Art quality', 'On schedule', 'Repeat guests', 'Local favorite',
  ],
  cta: {
    heading: 'Ready for Jeanne Kassab Art?',
    description: 'Tell Jeanne Kassab Art what you need — clear options, real next steps.',
    primaryLabel: 'Get started',
    primaryHref: '#details',
    secondaryLabel: 'Talk to us',
    secondaryHref: '#contact',
  },
  footer: {
    description: 'Jeanne Kassab Art — clear choices and real bookings.',
  },

  "tone": "creative",
  "hero": {
    "eyebrow": "Jeanne Kassab Art",
    "headline": "Brands that look inevitable once they exist",
    "subcopy": "Identity, product UI, and campaign systems for teams who want craft without the circus.",
    "primaryCta": {
      "label": "View selected work",
      "href": "/work"
    },
    "secondaryCta": {
      "label": "Start a project",
      "href": "/contact"
    }
  },
  "items": [
    {
      "title": "Northline identity",
      "description": "Wordmark, system, and launch kit for a regional brokerage."
    },
    {
      "title": "Peak Form product UI",
      "description": "Member booking and coach tools rebuilt around clarity."
    },
    {
      "title": "Ember Order campaign",
      "description": "Seasonal menu films and a reservation funnel that converts."
    },
    {
      "title": "Harbor Care site",
      "description": "Patient-facing site with booking and clinician bios."
    }
  ],
  "features": [
    {
      "title": "Strategy before pixels",
      "description": "Positioning and audience notes arrive before moodboards."
    },
    {
      "title": "Systems, not one-offs",
      "description": "Components and templates clients can keep shipping with."
    },
    {
      "title": "Tight feedback loops",
      "description": "Weekly reviews with decisions captured in writing."
    }
  ],
  "process": [
    {
      "title": "Discover",
      "description": "Goals, constraints, and the work that must ship first."
    },
    {
      "title": "Design",
      "description": "Directions, then a locked system — not endless variants."
    },
    {
      "title": "Deliver",
      "description": "Assets, guidelines, and handoff that engineering can use."
    }
  ],
  "credentials": [
    {
      "title": "Cross-discipline studio",
      "detail": "Brand, product, and motion under one roof."
    },
    {
      "title": "Shipped with in-house engineers",
      "detail": "Designs that survive production, not just Figma."
    }
  ],
  "testimonials": [
    {
      "quote": "They killed three directions early so we did not waste a quarter arguing taste.",
      "author": "Alex R.",
      "role": "CMO"
    },
    {
      "quote": "The handoff docs were better than most agencies' final decks.",
      "author": "Kim J.",
      "role": "Product lead"
    }
  ],
  "treatments": [
    {
      "id": "offer-1",
      "name": "Northline identity",
      "duration": "60 min"
    },
    {
      "id": "offer-2",
      "name": "Peak Form product UI",
      "duration": "60 min"
    },
    {
      "id": "offer-3",
      "name": "Ember Order campaign",
      "duration": "60 min"
    },
    {
      "id": "offer-4",
      "name": "Harbor Care site",
      "duration": "60 min"
    }
  ],
  "showcaseHeading": "Selected work",
  "featuresHeading": "How we partner",
  "processHeading": "A calm production path",
  "credentialsHeading": "Studio facts",
  "testimonialsHeading": "Client notes",
  "cta": {
    "heading": "Have a brief?",
    "description": "Tell us the outcome and timeline — we reply with fit and next steps.",
    "primaryLabel": "Start a project",
    "primaryHref": "/contact",
    "secondaryLabel": "See capabilities",
    "secondaryHref": "/services"
  },
  "footer": {
    "description": "A design studio for brands that need systems, not just pretty one-offs."
  },
  "trustLabels": [
    "Strategy first",
    "Production-ready systems",
    "Weekly decisions",
    "In-house build"
  ],
  "kpis": [
    {
      "label": "Revenue today",
      "value": "12,480",
      "delta": "+8%",
      "hint": "vs last Tuesday"
    },
    {
      "label": "Open tickets",
      "value": "14",
      "delta": "3 overdue",
      "hint": "SLA watch"
    },
    {
      "label": "Fill rate",
      "value": "86%",
      "delta": "-2%",
      "hint": "evening still soft"
    },
    {
      "label": "No-shows",
      "value": "2",
      "delta": "-1",
      "hint": "waitlist cleared 1"
    }
  ],
  "activity": [
    {
      "id": "a1",
      "title": "Ticket #482 escalated",
      "detail": "VIP walk-in waiting 12m",
      "time": "Just now"
    },
    {
      "id": "a2",
      "title": "Shift note posted",
      "detail": "Patio heaters on for 7pm",
      "time": "18m ago"
    },
    {
      "id": "a3",
      "title": "Inventory low",
      "detail": "House red under 8 bottles",
      "time": "1h ago"
    }
  ],
  "risk": [
    {
      "id": "r1",
      "title": "3 tickets past SLA",
      "detail": "Assign before dinner rush",
      "severity": "high"
    },
    {
      "id": "r2",
      "title": "Evening fill soft",
      "detail": "Push SMS for 7–8pm slots",
      "severity": "medium"
    }
  ],
  "tableRows": [
    {
      "id": "t1",
      "name": "Ticket #482 · VIP wait",
      "status": "Escalated",
      "owner": "Host lead"
    },
    {
      "id": "t2",
      "name": "Inventory · house red",
      "status": "Low",
      "owner": "Bar"
    },
    {
      "id": "t3",
      "name": "No-show · Table 12",
      "status": "Cleared",
      "owner": "Floor"
    }
  ]
};

export const aiFeatures = [
  {
    "id": "automated-image-optimization",
    "name": "Automated Image Optimization",
    "description": "Automatically resize and compress uploaded artwork images to ensure fast loading times without compromising visual quality, enhancing the gallery experience.",
    "category": "automation",
    "surface": "automation",
    "demo_hint": "Trigger the automation Jeanne Kassab Art actually needs",
    "demo_prompts": [
      "Notify the next person waiting for booking SaaS or",
      "Chase what's missing for booking",
      "Run tonight's follow-ups for Jeanne Kassab Art"
    ],
    "placement_label": "Automation",
    "demo_results": {
      "Notify the next person waiting for booking SaaS or": "Automation for “Notify the next person waiting for booking SaaS or”: message drafted, spot held for 30 minutes, next guest in line ready if they decline.",
      "Chase what's missing for booking": "Chase sequence for “Chase what's missing for booking”: reminder #1 sent about booking, escalates tomorrow if still open.",
      "Run tonight's follow-ups for Jeanne Kassab Art": "Tonight's follow-ups for Jeanne Kassab Art are queued — review → approve → run. Covers booking SaaS or and booking."
    },
    "placement_path": "/admin/about/edit",
    "placement_component": "src/pages/role-artist/AdminAboutEditPage.tsx",
    "placement_title": "Admin About Page Edit"
  },
  {
    "id": "smart-content-suggestion-for-about-page",
    "name": "Smart Content Suggestion for \"About\" Page",
    "description": "Analyze existing \"About\" page text and suggest stylistic improvements or prompt ideas to maintain a consistent editorial tone, helping Jeanne refine her narrative.",
    "category": "automation",
    "surface": "automation",
    "demo_hint": "Trigger the automation Jeanne Kassab Art actually needs",
    "demo_prompts": [
      "Notify the next person waiting for booking SaaS or",
      "Chase what's missing for booking",
      "Run tonight's follow-ups for Jeanne Kassab Art"
    ],
    "placement_label": "Automation",
    "demo_results": {
      "Notify the next person waiting for booking SaaS or": "Automation for “Notify the next person waiting for booking SaaS or”: message drafted, spot held for 30 minutes, next guest in line ready if they decline.",
      "Chase what's missing for booking": "Chase sequence for “Chase what's missing for booking”: reminder #1 sent about booking, escalates tomorrow if still open.",
      "Run tonight's follow-ups for Jeanne Kassab Art": "Tonight's follow-ups for Jeanne Kassab Art are queued — review → approve → run. Covers booking SaaS or and booking."
    },
    "placement_path": "/admin/artwork/edit",
    "placement_component": "src/pages/role-artist/AdminArtworkEditPage.tsx",
    "placement_title": "Admin Artwork Edit Page"
  },
  {
    "id": "inquiry-categorization-assistant",
    "name": "Inquiry Categorization Assistant",
    "description": "(Future consideration, as it requires WhatsApp integration beyond simple link) Automatically detect keywords in incoming WhatsApp messages (e.g., \"price,\" \"available,\" \"commission\") to help Jeanne quickly understand the intent of an inquiry.",
    "category": "chat",
    "surface": "chat",
    "demo_hint": "Ask the way a real guest would ask Jeanne Kassab Art",
    "demo_prompts": [
      "What should I know about booking SaaS or?",
      "How does booking work at Jeanne Kassab Art?",
      "Can beginners join a and price this week?"
    ],
    "placement_label": "Customer assistant",
    "demo_results": {
      "What should I know about booking SaaS or?": "Jeanne Kassab Art: For “What should I know about booking SaaS or?” — (Future consideration, as it requires WhatsApp integration beyond simple link) Automatically detect keywords in incoming WhatsApp messages (e.g., \"price,\" \"available,\" \"commission\") to help Jeanne quickly understand the intent of an inquiry Here’s the short answer, what to prepare, and when a human should join.",
      "How does booking work at Jeanne Kassab Art?": "Jeanne Kassab Art: “How does booking work at Jeanne Kassab Art?” — we walk guests through booking step by step, including timing, cost cues, and the next action to take.",
      "Can beginners join a and price this week?": "Jeanne Kassab Art: Yes — for “Can beginners join a and price this week?”, the assistant qualifies the request, shares what and price involves, and offers the best next booking path."
    },
    "placement_path": "/about",
    "placement_component": "src/pages/AboutPage.tsx",
    "placement_title": "About Page"
  }
] as const;
// build-correctness guard: auto-added missing exports
export const BRAND_MANIFEST = {"brand_name": "Jeanne Kassab Art", "name": "Jeanne Kassab Art", "tagline": "", "accent": "#6366f1", "design_system": {"primary_color": "#6366f1", "secondary_color": "#0d9488", "accent": "#6366f1", "text_color": "#0f172a", "muted_text_color": "#475569", "background_color": "#fafafa", "font_family": "inter", "font_import_url": "https://fonts.googleapis.com/css2?family=inter:wght@400;500;600;700&display=swap", "section_spacing": "4rem", "border_radius": "1rem", "card_style": "shadow (rgba(0,0,0,0.05))"}, "services": [{"id": "intro-session", "name": "Jeanne Kassab Art intro session", "description": "A welcoming first session for new guests.", "duration": "90 min", "level": "Beginner Friendly", "day": "Thursday", "status": "Open"}, {"id": "signature-workshop", "name": "Signature workshop", "description": "The core experience guests book most often.", "duration": "2 hours", "level": "All Levels", "day": "Saturday", "status": "Open"}, {"id": "advanced-studio", "name": "Advanced studio time", "description": "Deeper practice with guided feedback.", "duration": "3 hours", "level": "Intermediate", "day": "Wednesday", "status": "Full"}], "products": [{"title": "Jeanne Kassab Art essential", "description": "A dependable pick from the shop floor.", "name": "Jeanne Kassab Art essential"}, {"title": "Studio favorite", "description": "The piece guests ask about first.", "name": "Studio favorite"}]};
export const stats = [{"id": "stats-1", "name": "stats 1", "title": "stats 1", "label": "stats 1", "status": "In progress", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 1", "amount": 52, "count": 4, "date": "2026-07-27", "time": "10:00", "startDate": "2026-07-27", "endDate": "2026-07-27", "dropOffDate": "2026-07-27", "dropOffTime": "10:00", "pickupDate": "2026-07-29", "scheduledAt": "2026-07-27T10:00:00", "createdAt": "2026-07-27T10:00:00", "timestamp": "2026-07-27T10:00:00", "instructor": "Maya R.", "memberName": "Member 1", "loadType": "Bisque", "registered": 5, "capacity": 12, "isFull": false}, {"id": "stats-2", "name": "stats 2", "title": "stats 2", "label": "stats 2", "status": "Done", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 2", "amount": 64, "count": 5, "date": "2026-07-28", "time": "11:30", "startDate": "2026-07-28", "endDate": "2026-07-28", "dropOffDate": "2026-07-28", "dropOffTime": "11:30", "pickupDate": "2026-07-30", "scheduledAt": "2026-07-28T11:30:00", "createdAt": "2026-07-28T11:30:00", "timestamp": "2026-07-28T11:30:00", "instructor": "Jordan K.", "memberName": "Member 2", "loadType": "Glaze", "registered": 6, "capacity": 12, "isFull": false}, {"id": "stats-3", "name": "stats 3", "title": "stats 3", "label": "stats 3", "status": "Scheduled", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 3", "amount": 76, "count": 6, "date": "2026-07-29", "time": "12:00", "startDate": "2026-07-29", "endDate": "2026-07-29", "dropOffDate": "2026-07-29", "dropOffTime": "12:00", "pickupDate": "2026-07-31", "scheduledAt": "2026-07-29T12:00:00", "createdAt": "2026-07-29T12:00:00", "timestamp": "2026-07-29T12:00:00", "instructor": "Sam T.", "memberName": "Member 3", "loadType": "Cone 6", "registered": 7, "capacity": 12, "isFull": false}, {"id": "stats-4", "name": "stats 4", "title": "stats 4", "label": "stats 4", "status": "Open", "detail": "Sample Jeanne Kassab Art record for demo lists", "message": "stats update 4", "amount": 88, "count": 7, "date": "2026-07-30", "time": "13:30", "startDate": "2026-07-30", "endDate": "2026-07-30", "dropOffDate": "2026-07-30", "dropOffTime": "13:30", "pickupDate": "2026-08-01", "scheduledAt": "2026-07-30T13:30:00", "createdAt": "2026-07-30T13:30:00", "timestamp": "2026-07-30T13:30:00", "instructor": "Noa B.", "memberName": "Member 4", "loadType": "Raku", "registered": 8, "capacity": 12, "isFull": false}];
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
