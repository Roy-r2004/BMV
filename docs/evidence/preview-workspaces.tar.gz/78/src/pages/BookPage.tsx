// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, BookingPanel, BrandFooter } from '@/ui';

const SKELETON_ID = "public-booking" as const;
const RECIPE_ORDER = ["hero", "credentials", "booking", "footer"] as const;

export default function BookPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    hero: (
      <MarketingHero
        brandName={"Northgate Dental Studio"}
        headline={"Your Visit, Simplified."}
        subcopy={"Choose a service and find a time that works perfectly for your schedule. Your dental care, clear and convenient."}
        primaryCta={{ label: "Book an Appointment", href: "#booking-panel" }}
        imageSrc={images.hero}
        imageAlt="A calm and inviting dental surgery room, bathed in natural light."
        className="pb-16"
      />
    ),
    credentials: (
      <CredentialStrip
        heading={"Trusted Care, Unmatched Experience"}
        items={[
          { title: "Three-Chair Practice", detail: "Designed for comfort and efficiency." },
          { title: "Family-Focused", detail: "Comprehensive care for all ages." },
          { title: "Clear Pricing", detail: "No surprises, just honest costs." },
          { title: "Online Booking", detail: "24/7 convenience at your fingertips." },
        ]}
        className="py-16"
      />
    ),
    booking: (
      <BookingPanel
        heading="Find Your Perfect Slot"
        description="Select the service you need and browse available appointments. We look forward to welcoming you."
        treatments={[
          { id: "check-up", name: "Routine Check-up & Clean", duration: "60 minutes" },
          { id: "hygienist", name: "Hygienist Visit", duration: "45 minutes" },
          { id: "aligners-consult", name: "Clear Aligners Consultation", duration: "30 minutes" },
          { id: "emergency", name: "Emergency Appointment", duration: "30 minutes" },
        ]}
        slots={[
          { id: "slot-1", startsAt: "2024-07-22T09:00:00Z", label: "09:00 AM" },
          { id: "slot-2", startsAt: "2024-07-22T10:00:00Z", label: "10:00 AM" },
          { id: "slot-3", startsAt: "2024-07-22T11:00:00Z", label: "11:00 AM" },
          { id: "slot-4", startsAt: "2024-07-22T14:00:00Z", label: "02:00 PM" },
          { id: "slot-5", startsAt: "2024-07-23T09:30:00Z", label: "09:30 AM" },
          { id: "slot-6", startsAt: "2024-07-23T10:30:00Z", label: "10:30 AM" },
          { id: "slot-7", startsAt: "2024-07-24T08:00:00Z", label: "08:00 AM" },
          { id: "slot-8", startsAt: "2024-07-24T13:00:00Z", label: "01:00 PM" },
        ]}
        confirmLabel="Confirm Appointment"
        onConfirm={(details) => console.log("Booking confirmed:", details)}
        className="py-16"
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Your trusted family dental practice in Leeds, providing clear choices and comfortable care."}
        links={[
          { label: "Services", href: "/services" },

          { label: "Privacy Policy", href: "#" },
        ]}
        meta={"© 2024 Northgate Dental Studio. All rights reserved."}
        variant="columns"
      />
    ),
  };

  return (
    <PublicShell brandName={"Northgate Dental Studio"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="book">

        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}