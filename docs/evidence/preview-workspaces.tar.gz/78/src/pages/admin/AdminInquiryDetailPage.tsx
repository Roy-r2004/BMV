// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton, InquiryPanel } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function AdminInquiryDetailPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Inquiry Details"}
        description={"View and manage specific patient inquiries, update their status, and respond to requests."}
      />
    ),
    workspace: (
      <InquiryPanel
            heading={"Treatment Inquiry"}
            description={"Review and respond to specific questions about services like clear aligners or hygienist visits."}
            ctaLabel={"View Treatment Inquiries"}
          />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio: Connect & Clarify Portal Admin"}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="admin-inquiry-detail">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"contact"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
