// deterministic catalogue contract scaffold
import { useAdminNavItems } from '@/lib/app-nav';
import { seed, aiFeatures } from '@/data/mock';
import { OpsShell, getSkeleton, composeSkeletonLayout, PageHeader, StatCard, ChartCard, FilterBar, DataTable, ActivityFeed, AiFeaturePanel } from '@/ui';

const SKELETON_ID = "ops-dashboard" as const;
export default function AdminDashboardPage() {
  const adminNavItems = useAdminNavItems();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title="Connect & Clarify Dashboard"
        description="Manage patient inquiries, streamline communication, and track team responses."
      />
    ),
    kpis: (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="New Inquiries Today" value="7" delta="+2" hint="Compared to yesterday" />
        <StatCard label="Average Response Time" value="1h 15m" delta="-10m" hint="Compared to last week" />
        <StatCard label="Pending Emergencies" value="1" delta="+1" hint="Urgent attention needed" />
        <StatCard label="WhatsApp Chats Open" value="3" delta="0" hint="Active conversations" />
      </div>
    ),
    chart: (
      // The brief does not specify a chart for this dashboard,
      // but the skeleton requires a ChartCard.
      // Using a placeholder/default ChartCard.
      <ChartCard
        title="Inquiry Trends"
        type="area"
        dataKey="value"
        xKey="day"
        data={[
          { day: "Mon", value: 5 },
          { day: "Tue", value: 8 },
          { day: "Wed", value: 7 },
          { day: "Thu", value: 10 },
          { day: "Fri", value: 12 },
        ]}
        description="Inquiries received over the last 5 days"
      />
    ),
    filters: (
      <FilterBar
        searchPlaceholder="Search inquiries..."
        filters={[
          { id: "all", label: "All", active: true },
          { id: "emergency", label: "Emergency" },
          { id: "treatment", label: "Treatment" },
          { id: "quick-chat", label: "Quick Chat" },
        ]}
        actions={[
          { label: "Pending", variant: "primary" },
          { label: "Responded", variant: "secondary" },
          { label: "Booked", variant: "secondary" },
        ]}
      />
    ),
    table: (
      <DataTable
        columns={[
          { key: "type", header: "Inquiry Type" },
          { key: "patientName", header: "Patient Name" },
          { key: "subject", header: "Subject/Message Snippet" },
          { key: "submittedDate", header: "Submitted Date" },
          { key: "status", header: "Status" },
        ]}
        rows={[
          { id: "inc-1", type: "Emergency", patientName: "Sarah M.", subject: "Toothache, severe pain", submittedDate: "2 mins ago", status: "Pending" },
          { id: "inc-2", type: "Treatment", patientName: "Jamie R.", subject: "Clear aligner cost inquiry", submittedDate: "15 mins ago", status: "Pending" },
          { id: "inc-3", type: "Quick Chat", patientName: "Alex P.", subject: "Booking for hygienist?", submittedDate: "30 mins ago", status: "Responded" },
          { id: "inc-4", type: "Treatment", patientName: "Chloe B.", subject: "Question about veneers", submittedDate: "1 hour ago", status: "Pending" },
          { id: "inc-5", type: "Emergency", patientName: "David L.", subject: "Lost filling, minor discomfort", submittedDate: "2 hours ago", status: "Booked" },
          { id: "inc-6", type: "Quick Chat", patientName: "Emma S.", subject: "Practice opening hours?", submittedDate: "3 hours ago", status: "Responded" },
          { id: "inc-7", type: "Treatment", patientName: "Liam T.", subject: "Follow-up on treatment plan", submittedDate: "Yesterday", status: "Responded" },
        ]}
      />
    ),
    activity: (
      <ActivityFeed
        heading="Recent Activity"
        items={[
          { id: "act-1", title: "Chloe R. responded to Sarah M. emergency", time: "Just now" },
          { id: "act-2", title: "New Treatment Inquiry from Jamie R. submitted", time: "15 mins ago" },
          { id: "act-3", title: "Alex P.'s Quick Chat marked as Responded", time: "30 mins ago" },
          { id: "act-4", title: "Emergency booked for David L.", time: "2 hours ago" },
          { id: "act-5", title: "Emma S. Quick Chat resolved", time: "3 hours ago" },
        ]}
      />
    ),
  };

  const { main, rail } = composeSkeletonLayout(SKELETON_ID, slots);

  return (
    <OpsShell brandName={"Northgate Dental Studio"} navItems={adminNavItems} rail={rail}>
      <div data-skeleton={skeleton.id} data-appspec-page="admin-dashboard">
        {main}
      </div>
          <div id="inquiry-prioritization" data-ai-feature-panel="inquiry-prioritization">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "inquiry-prioritization") || { id: "inquiry-prioritization", name: "inquiry-prioritization" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
          <div id="smart-form-pre-fill-suggestions" data-ai-feature-panel="smart-form-pre-fill-suggestions">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "smart-form-pre-fill-suggestions") || { id: "smart-form-pre-fill-suggestions", name: "smart-form-pre-fill-suggestions" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
          <div id="automated-response-drafts" data-ai-feature-panel="automated-response-drafts">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "automated-response-drafts") || { id: "automated-response-drafts", name: "automated-response-drafts" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
          <div id="sentiment-analysis-for-emergency-requests" data-ai-feature-panel="sentiment-analysis-for-emergency-requests">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "sentiment-analysis-for-emergency-requests") || { id: "sentiment-analysis-for-emergency-requests", name: "sentiment-analysis-for-emergency-requests" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
          <div id="knowledge-base-search-for-staff" data-ai-feature-panel="knowledge-base-search-for-staff">
        <AiFeaturePanel
          feature={(aiFeatures as any).find((f: any) => f.id === "knowledge-base-search-for-staff") || { id: "knowledge-base-search-for-staff", name: "knowledge-base-search-for-staff" }}
          brandName={"Northgate Dental Studio"}
        />
      </div>
    </OpsShell>
  );
}