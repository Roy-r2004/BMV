// composed confirmation page (ConfirmStage)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, BrandFooter, ConfirmStage } from '@/ui';

export default function ConfirmationPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();

  return (
    <>
      <div className="contents" data-appspec-page="confirmation-general">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <ConfirmStage
        eyebrow={"Confirmed"}
        title={"Inquiry Sent!"}
        detail={"Confirmation on file"}
        description={"Northgate Dental Studio"}
        primaryCta={{"label": "Back to home", "href": "/"}}
        nextSteps={[{"title": "Thank You for Your Inquiry!", "description": "Your message has been successfully submitted to Northgate Dental Studio. We aim to respond to all inquiries within 1-2 business days. For urgent matters, please call us directly.", "ctaLabel": "Return to Homepage", "href": "/"}, {"title": "Need to Speak Sooner?", "description": "If your query is urgent or you require immediate assistance, please call us at our practice during opening hours.", "ctaLabel": "Call Us Now", "href": "tel:+441132456789"}, {"title": "Explore Our Services", "description": "While you wait for our response, feel free to learn more about the treatments we offer at Northgate Dental Studio.", "ctaLabel": "View Services", "href": "/services"}]}
      />
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio – Your smile, our priority. Located in Leeds."}
      />
    </PublicShell>
    </>
  );
}
