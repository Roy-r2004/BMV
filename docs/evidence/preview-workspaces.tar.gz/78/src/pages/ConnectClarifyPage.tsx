// deterministic catalogue contract scaffold
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, FeatureBento, TestimonialRail, CTABand, BrandFooter, SpotlightCard, Button, UiIcon, CredentialStrip, ProductShowcase } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function ConnectClarifyPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    credentials: (
      <CredentialStrip heading={seed.credentialsHeading ?? "Why Northgate Dental Studio"} items={seed.credentials ?? []} />
    ),
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Northgate Dental Studio"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.item1, images.item2, images.item3, images.item4, images.item5, images.item6, images.item7, images.item8][index % 8], imageAlt: item.title, badge: String((item as any).badge || (item as any).category || "Featured"), href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    hero: (
      <MarketingHero
        brandName={"Northgate Dental Studio"}
        eyebrow={"Northgate Dental Studio"}
        headline={"We're Here to Help. Clearly."}
        subcopy={"Your direct line to answers, care, and clarity at Northgate Dental Studio."}
        primaryCta={undefined} // No CTA buttons in the hero for this page as per brief
        secondaryCta={undefined} // No CTA buttons in the hero for this page as per brief
        imageSrc={images.hero}
        imageAlt="Bright, modern dental studio reception area with soft lighting"
      />
    ),
    spotlight: (
      <div className="mx-auto grid max-w-7xl gap-6 px-4 py-16 sm:grid-cols-1 md:grid-cols-3 lg:px-8">
        <Button variant="ghost" href="/connect-clarify/quick-chat" className="block text-left h-full p-0">
          <SpotlightCard
            title="Quick Chat"
            description="For general questions about our services, availability, or practice details. We’re often quicker than email for simple queries."
            icon={<UiIcon name="message-square" className="size-6 text-brand" />}
            className="h-full bg-surface text-text-brand hover:bg-brand/5 focus:ring-2 focus:ring-brand focus:ring-offset-2 transition-colors duration-200"
          />
        </Button>
        <Button variant="ghost" href="/connect-clarify/treatment-inquiry" className="block text-left h-full p-0">
          <SpotlightCard
            title="Treatment Inquiry"
            description="Have specific questions about clear aligners, a particular procedure, or understanding your treatment plan options?"
            icon={<UiIcon name="clipboard-list" className="size-6 text-brand" />}
            className="h-full bg-surface text-text-brand hover:bg-brand/5 focus:ring-2 focus:ring-brand focus:ring-offset-2 transition-colors duration-200"
          />
        </Button>
        <Button variant="ghost" href="/connect-clarify/emergency-request" className="block text-left h-full p-0">
          <SpotlightCard
            title="Emergency Request"
            description="For urgent situations needing immediate attention. Our team is here to guide you through your dental emergency."
            icon={<UiIcon name="alert-circle" className="size-6 text-brand" />}
            className="h-full bg-surface text-text-brand hover:bg-brand/5 focus:ring-2 focus:ring-brand focus:ring-offset-2 transition-colors duration-200"
          />
        </Button>
      </div>
    ),
    features: (
      <FeatureBento
        heading="Why Patients Choose Northgate Dental for Clarity"
        description="Our portal is designed around your needs, ensuring you get the right information, right when you need it."
        imagePool={[images.card1, images.card2, images.card3]}
        items={[
          { title: "Faster Answers", description: "Directly connect with our team for prompt responses to your questions and concerns." },
          { title: "Personalised Care", description: "Submit detailed inquiries that help us understand your needs before you even visit." },
          { title: "Peace of Mind", description: "Know exactly what to expect, from treatments to costs, with upfront clarity." },
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading="What Our Patients Say"
        items={[
          {
            quote: "The Connect & Clarify portal made getting answers about my aligners so easy. Quick and helpful!",
            author: "Sarah J.",
            role: "Clear Aligner Patient"
          },
          {
            quote: "Had an urgent issue, and the emergency request option was a lifesaver. Felt cared for immediately.",
            author: "Mark T.",
            role: "Emergency Patient"
          },
          {
            quote: "Always appreciate Northgate's clear communication, and this portal just makes it even better.",
            author: "Chloe D.",
            role: "Long-standing Patient"
          },
        ]}
      />
    ),
    cta: (
      <CTABand
        heading="Ready to Connect?"
        description="We're here to provide the clarity and care you deserve. Choose your path above or get in touch directly."
        primaryCta={{ label: "Contact Us", href: "/book" }}
        secondaryCta={{ label: "Back to Home", href: "/" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio — your trusted family dental practice in Leeds."}
        links={[
          { label: "Services", href: "/services" },

          { label: "Privacy Policy", href: "#" },
        ]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Northgate Dental Studio"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="connect-clarify">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}