import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { images, seed } from '@/data/mock';
import { PublicShell, getSkeleton, SkeletonComposer, PublicNav, MarketingHero, CredentialStrip, FeatureBento, ProcessSection, TestimonialRail, CTABand, BrandFooter, ProductShowcase } from '@/ui';

const SKELETON_ID = "public-home" as const;
const RECIPE_ORDER = ["hero", "credentials", "features", "showcase", "testimonials", "cta", "footer"] as const;

export default function HomePage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    showcase: (
      <ProductShowcase heading={seed.showcaseHeading ?? "From Northgate Dental Studio"} items={(seed.items ?? []).map((item, index) => ({ title: item.title, description: item.description, imageSrc: [images.item1, images.item2, images.item3, images.item4, images.item5, images.item6, images.item7, images.item8][index % 8], imageAlt: item.title, badge: String((item as any).badge || (item as any).category || "Featured"), href: `/gallery/${encodeURIComponent(String((item as any).id || (item as any).slug || index + 1))}` }))} />
    ),
    hero: (
      <MarketingHero
        brandName={"Northgate Dental Studio"}
        headline={"Your Smile, Simplified."}
        subcopy={"Connect directly with Northgate Dental for questions, emergencies, and treatment details."}
        primaryCta={{ label: "Ask a Question", href: "/connect-clarify" }}
        secondaryCta={{ label: "Book an Appointment", href: "/book" }}
        imageSrc={images.hero}
        imageAlt="Bright, modern dental office interior"
      />
    ),
    credentials: (
      <CredentialStrip
        items={[
          { title: "GDC Registered", detail: "All our practitioners are General Dental Council registered." },
          { title: "Family Friendly", detail: "Caring for smiles of all ages in Leeds." },
          { title: "Leeds Community Focused", detail: "Proudly serving our local community." }
        ]}
      />
    ),
    features: (
      <FeatureBento
        heading="Why Choose Northgate Dental Studio?"
        items={[
          { title: "Upfront Costs", description: "Clear pricing means no surprises for your treatment plan." },
          { title: "Easy Online Booking", description: "Schedule your appointments at your convenience, any time." },
          { title: "Automated Reminders", description: "Never miss an appointment with helpful reminders." }
        ]}
      />
    ),
    process: (
      <ProcessSection
        heading="Our Simple Process"
        steps={[
          { title: "Choose Your Inquiry", description: "Select from Quick Chat, Treatment Inquiry, or Emergency Request." },
          { title: "Share Your Needs", description: "Provide details relevant to your dental query or concern." },
          { title: "Get a Swift Response", description: "Our team will connect with you promptly with clarity." }
        ]}
      />
    ),
    testimonials: (
      <TestimonialRail
        heading="What Our Patients Say"
        items={[
          { quote: "Northgate Dental Studio made me feel so comfortable. The team is professional and genuinely caring.", author: "Sarah J." },
          { quote: "Booking online was a breeze, and getting my treatment plan upfront was fantastic. Highly recommend!", author: "Mark T." }
        ]}
      />
    ),
    cta: (
      <CTABand
        heading="Have a question or ready to book?"
        primaryCta={{ label: "Ask a Question", href: "/connect-clarify" }}
        secondaryCta={{ label: "Book Your Visit", href: "/book" }}
      />
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Providing quality family dental care in Leeds. Your healthy smile is our priority."}
        links={[
          { label: "Privacy Policy", href: "#" },
          { label: "Accessibility Statement", href: "#" },
          { label: "Contact Us", href: "/book" }
        ]}
        meta={["Northgate Dental Studio © 2024", "All rights reserved."]}
      />
    ),
  };

  return (
    <PublicShell brandName={"Northgate Dental Studio"} nav={<PublicNav items={navItems} cta={navCta} />}>
      <div data-skeleton={skeleton.id} data-appspec-page="public-home">
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} order={RECIPE_ORDER} />
      </div>
    </PublicShell>
  );
}