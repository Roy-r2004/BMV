// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function QuickChatRedirectPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Quick Chat with Northgate Dental"}
        description={"You're about to open a chat with Northgate Dental Studio on WhatsApp. Your message will be pre-filled for convenience. Please note: This is for general inquiries and not for emergencies."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Open WhatsApp Chat"}</h3>
            <p className="text-sm leading-6 text-muted">{"Connect directly with our team for general questions about our services, availability, or practice details."}</p>
            <Button href={"https://wa.me/447911123456?text=Hi%20Northgate%20Dental%2C%20I%20have%20a%20general%20question."} className="mt-auto w-fit">
              {"Open WhatsApp"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Need to ask a specific treatment question?"}</h3>
            <p className="text-sm leading-6 text-muted">{"For detailed inquiries about clear aligners, specific procedures, or understanding your treatment plan options, please use our dedicated Treatment Inquiry form."}</p>
            <Button href={"/connect-clarify/treatment-inquiry"} className="mt-auto w-fit">
              {"Go to Treatment Inquiry"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Emergency Dental Care"}</h3>
            <p className="text-sm leading-6 text-muted">{"If you have an urgent dental emergency, please do not use this chat. Contact us immediately by phone."}</p>
            <Button href={"/connect-clarify/emergency-request"} className="mt-auto w-fit">
              {"View Emergency Options"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio. Caring for your smile, close to home."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="quick-chat-redirect">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"generic"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
