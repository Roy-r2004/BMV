// composed public-utility page (content JSON → kit)
import { usePublicNavItems, publicCta } from '@/lib/app-nav';
import { PublicShell, PublicNav, PageHeader, BrandFooter, Card, Button, SkeletonComposer, getSkeleton } from '@/ui';

const SKELETON_ID = "public-utility" as const;

export default function EmergencyRequestPage() {
  const navItems = usePublicNavItems();
  const navCta = publicCta();
  const skeleton = getSkeleton(SKELETON_ID);
  const slots = {
    header: (
      <PageHeader
        title={"Emergency Dental Request"}
        description={"Urgent care when you need it most. For immediate assistance, please call us directly."}
      />
    ),
    workspace: (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Call Us Immediately"}</h3>
            <p className="text-sm leading-6 text-muted">{"For dental emergencies that require immediate attention during practice hours, please call our direct line."}</p>
            <Button href={"tel:+441134960001"} className="mt-auto w-fit">
              {"Call Now: 0113 496 0001"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Out-of-Hours or Less Urgent Queries"}</h3>
            <p className="text-sm leading-6 text-muted">{"If your emergency is not life-threatening and you'd like us to call you back, please complete this form. We'll be in touch as soon as possible."}</p>
            <Button href={"/connect-clarify/treatment-inquiry"} className="mt-auto w-fit">
              {"Submit Emergency Query"}
            </Button>
          </Card>
          <Card className="flex flex-col gap-3 p-5">
            <h3 className="font-display text-xl text-foreground">{"Life-Threatening Emergencies"}</h3>
            <p className="text-sm leading-6 text-muted">{"If you are experiencing a severe, life-threatening emergency (e.g., uncontrolled bleeding, difficulty breathing), please dial 999 immediately."}</p>
            <Button href={"tel:999"} className="mt-auto w-fit">
              {"Call 999"}
            </Button>
          </Card>
        </div>
    ),
    footer: (
      <BrandFooter
        brandName={"Northgate Dental Studio"}
        description={"Northgate Dental Studio – Your Family Dental Practice in Leeds. Protecting your smile, every day."}
      />
    ),
  };

  return (
    <>
      <div className="contents" data-appspec-page="emergency-request">
      </div>
      <PublicShell
      brandName={"Northgate Dental Studio"}
      chrome="solid"
      nav={<PublicNav items={navItems} cta={navCta} />}
    >
      <div data-skeleton={skeleton.id} data-utility-type={"generic"}>
        <SkeletonComposer skeletonId={SKELETON_ID} slots={slots} />
      </div>
    </PublicShell>
    </>
  );
}
