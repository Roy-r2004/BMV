export const brand = {
  name: "Northgate Dental Studio",
  tagline: "Connecting you to clarity for a healthier, happier smile.",
  accent: "#0f766e",
  accent_dark: "#0d6a62",
  accent_light: "#e0f2f1",
  font: "Source Sans 3",
  design_system: {
    primary_color: "#0f766e",
    secondary_color: "#134e4a",
    background_color: "#f0fdfa",
    surface_color: "#ffffff",
    text_color: "#042f2e",
    muted_text_color: "#5f7a78",
    font_family: "Source Sans 3",
    display_font_family: "Fraunces",
    font_import_url: "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700&display=swap",
    font_sans: "\"Source Sans 3\", \"Segoe UI\", sans-serif",
    font_display: "\"Fraunces\", Georgia, serif",
    brand_locked: true,
    brand_brief_version: "1.0",
    mood: "Editorial",
    voice: "Warm, grounded, unhurried. Speak like a trusted studio host.",
    signature: "A calm full-bleed atmosphere with Northgate Dental Studio as the hero signal, not a card grid.",
    avoid: [
      "purple-on-white or purple-to-indigo default themes",
      "Inter / Roboto / Arial as the display face",
      "card grids in the hero",
      "generic SaaS marketing copy",
      "inventing a second palette per page",
    ],
    rules: [
      "Every page inherits this palette and type stack via CSS tokens only.",
      "Use bg-brand / text-brand / font-display — never hardcode hex colors.",
      "First viewport must feature the brand name as a hero-level signal.",
    ],
    recipe_id: "editorial",
    hub_variant: "marketing",
    hero_variant: "editorial",
    feature_variant: "alternating",
    recipe_prompt:
      "RECIPE editorial (Manus-clear): brand-first hero — one name, one headline, one sentence, one CTA group, one visual plane. No cards in the hero. After the fold: credentials strip before features (trust-first). Generous whitespace, serif display for titles only (not every line italic), quiet atmosphere — avoid purple glow and sticker overlays. Motion on major sections; never dense tables on public pages.",
    style_keywords: "Editorial · Warm paper",
    border_radius: "0.91rem",
    design_overlay_id: "warm_paper",
    design_overlay_label: "Warm paper",
    design_overlay_blurb: "Service warmth — paper surfaces, friendly radius, soft glow.",
    density: "comfortable",
    token_overrides: {
      radius_ui: "0.91rem",
      bg_mix: "5%",
      fg_mix: "40%",
      muted_mix: "30%",
      border_mix: "14%",
      shadow: "0 26px 52px -38px",
      shadow_alpha: "30%",
      glow: "9%",
      card: "#fffdf9",
      atmosphere:
        "radial-gradient(85% 50% at 100% 0%, color-mix(in srgb, var(--color-accent) 12%, transparent), transparent 55%), linear-gradient(165deg, #fffaf4 0%, color-mix(in srgb, var(--color-brand) 5%, #f7f1ea) 50%, #faf7f2 100%)",
    },
    font_import:
      "Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,500&family=Source+Sans+3:wght@400;500;600;700",
    design_brief_version: "1.0",
    design_brief_sealed: true,
  },

  services: [{"name": "Northgate Dental Studio Signature", "title": "Northgate Dental Studio Signature", "description": "Flagship service with clear results and a calm, premium feel.", "image": "", "badge": "Popular", "price": 280, "duration": "60 min"}, {"name": "AI-guided consult", "title": "AI-guided consult", "description": "Personalized recommendations from your goals — then book in minutes.", "image": "", "badge": "AI", "price": 0, "duration": "15 min"}, {"name": "Member aftercare", "title": "Member aftercare", "description": "Recovery tips and check-ins so results last and WhatsApp stays quiet.", "image": "", "price": 0, "duration": "Ongoing"}, {"name": "Follow-up visit", "title": "Follow-up visit", "description": "Quick check-in to fine-tune results and keep your plan on track.", "image": "", "badge": "Care", "price": 120, "duration": "30 min"}],
  testimonials: [{"name": "Maya R.", "initials": "MR", "quote": "Finally a Northgate Dental Studio experience that feels personal — the AI consult nailed what I needed.", "text": "Finally a Northgate Dental Studio experience that feels personal — the AI consult nailed what I needed.", "role": "Client", "rating": 5}, {"name": "Jordan K.", "initials": "JK", "quote": "Booking and aftercare in one place. No more chasing answers on chat.", "text": "Booking and aftercare in one place. No more chasing answers on chat.", "role": "Member", "rating": 5}, {"name": "Sam T.", "initials": "ST", "quote": "The owner hub's no-show risk view alone paid for itself in a week.", "text": "The owner hub's no-show risk view alone paid for itself in a week.", "role": "Owner", "rating": 5}],
  client_names: ["Maya Northgate", "Jordan Cohen", "Sam Levi", "Noa Ben-David", "Alex Mizrahi", "Dana Peretz", "Client 7", "Client 8"],
  social_proof: "Trusted by over 2,400 delighted Northgate Dental Studio clients.",
};

export const images = {
  "hero": "https://images.pexels.com/photos/7789678/pexels-photo-7789678.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "hero2": "https://images.pexels.com/photos/6812452/pexels-photo-6812452.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  "card1": "https://images.pexels.com/photos/31188653/pexels-photo-31188653.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card2": "https://images.pexels.com/photos/5622280/pexels-photo-5622280.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "card3": "https://images.pexels.com/photos/3881290/pexels-photo-3881290.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "ambient": "https://images.pexels.com/photos/6627838/pexels-photo-6627838.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item1": "https://images.pexels.com/photos/6502338/pexels-photo-6502338.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item2": "https://images.pexels.com/photos/6627722/pexels-photo-6627722.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item3": "https://images.pexels.com/photos/6502551/pexels-photo-6502551.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item4": "https://images.pexels.com/photos/6502344/pexels-photo-6502344.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item5": "https://images.pexels.com/photos/4269356/pexels-photo-4269356.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item6": "https://images.pexels.com/photos/6812506/pexels-photo-6812506.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item7": "https://images.pexels.com/photos/6627689/pexels-photo-6627689.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  "item8": "https://images.pexels.com/photos/6627668/pexels-photo-6627668.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
};

export const roles = [
  {
    "id": "customer",
    "label": "Patient",
    "defaultPath": "/connect-clarify",
    "icon": "users"
  },
  {
    "id": "staff",
    "label": "Staff",
    "defaultPath": "/admin/dashboard",
    "icon": "chart"
  }
];

export const navigation = {
  "public": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Northgate Dental Studio"
    },
    {
      "id": "services",
      "path": "/services",
      "href": "/services",
      "label": "Services"
    },
    {
      "id": "connect-clarify",
      "path": "/connect-clarify",
      "href": "/connect-clarify",
      "label": "Connect & Clarify"
    },
    {
      "id": "connect-clarify-emergency-request",
      "path": "/connect-clarify/emergency-request",
      "href": "/connect-clarify/emergency-request",
      "label": "Emergency Dental Request"
    },
    {
      "id": "connect-clarify-quick-chat",
      "path": "/connect-clarify/quick-chat",
      "href": "/connect-clarify/quick-chat",
      "label": "Quick Chat"
    },
    {
      "id": "connect-clarify-treatment-inquiry",
      "path": "/connect-clarify/treatment-inquiry",
      "href": "/connect-clarify/treatment-inquiry",
      "label": "Treatment Inquiry"
    }
  ],
  "admin": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Admin Dashboard"
    }
  ],
  "customer": [
    {
      "id": "home",
      "path": "/",
      "href": "/",
      "label": "Northgate Dental Studio"
    },
    {
      "id": "services",
      "path": "/services",
      "href": "/services",
      "label": "Services"
    },
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "connect-clarify",
      "path": "/connect-clarify",
      "href": "/connect-clarify",
      "label": "Connect & Clarify"
    },
    {
      "id": "connect-clarify-emergency-request",
      "path": "/connect-clarify/emergency-request",
      "href": "/connect-clarify/emergency-request",
      "label": "Emergency Dental Request"
    },
    {
      "id": "connect-clarify-confirmation",
      "path": "/connect-clarify/confirmation",
      "href": "/connect-clarify/confirmation",
      "label": "Inquiry Sent!"
    },
    {
      "id": "connect-clarify-quick-chat",
      "path": "/connect-clarify/quick-chat",
      "href": "/connect-clarify/quick-chat",
      "label": "Quick Chat"
    }
  ],
  "staff": [
    {
      "id": "ai-features",
      "path": "/ai-features",
      "href": "/ai-features",
      "label": "AI features"
    },
    {
      "id": "admin-dashboard",
      "path": "/admin/dashboard",
      "href": "/admin/dashboard",
      "label": "Admin Dashboard"
    }
  ]
};

export const aiFeatures = [
  {
    id: "inquiry-prioritization",
    name: "Inquiry Prioritization",
    description:
      "Automatically flags and prioritizes emergency or high-intent treatment inquiries based on keywords and sentiment for faster staff response.",
    category: "scoring",
    surface: "scoring",
    demo_hint: "Score a lead the way Northgate Dental Studio would",
    demo_prompts: [
      "Score this inquiry about intake",
      "Who should we call first about follow-up?",
      "Rank today's leads for Northgate Dental Studio",
    ],
    demo_results: {
      "Score this inquiry about intake":
        "Score 86/100 for “Score this inquiry about intake” — high intent on intake. Suggested next step: call within 2 hours.",
      "Who should we call first about follow-up?":
        "Call first: the lead asking about follow-up. Reason: urgency + fit with Northgate Dental Studio's core offer.",
      "Rank today's leads for Northgate Dental Studio":
        "Lead ranking for Northgate Dental Studio: 1) intake inquiry 2) follow-up follow-up 3) browse-only. Focus staff time on the top two.",
    },
    placement_label: "Lead scoring",
    placement_path: "/admin/dashboard",
    placement_component: "src/pages/admin/AdminDashboardPage.tsx",
    placement_title: "Admin Dashboard",
  },
  {
    id: "smart-form-pre-fill-suggestions",
    name: "Smart Form Pre-fill Suggestions",
    description:
      "Suggests relevant dental services or common questions as a patient types in the 'Treatment Inquiry' form, guiding them to provide more specific details.",
    category: "automation",
    surface: "automation",
    demo_hint: "Trigger the automation Northgate Dental Studio actually needs",
    demo_prompts: [
      "Suggest questions for a 'Clear Aligners' inquiry",
      "Pre-fill form for 'New Patient Check-up'",
      "Automate follow-up for a 'Hygienist' inquiry",
    ],
    demo_results: {
      "Suggest questions for a 'Clear Aligners' inquiry":
        "Suggested questions for 'Clear Aligners' inquiry: 'What's the typical duration of treatment?', 'What are the payment options?', 'Is an initial consultation free?'",
      "Pre-fill form for 'New Patient Check-up'":
        "Form fields pre-filled: 'Service Type: New Patient Check-up', 'Preferred Date: [Next available slot]'.",
      "Automate follow-up for a 'Hygienist' inquiry":
        "Automated follow-up drafted: 'Thank you for your hygienist inquiry. Would you like to book a slot for a scale and polish? Book now at [link].'",
    },
    placement_label: "Automation",
    placement_path: "/connect-clarify/treatment-inquiry",
    placement_component: "src/pages/TreatmentInquiryPage.tsx",
    placement_title: "Treatment Inquiry",
  },
  {
    id: "automated-response-drafts",
    name: "Automated Response Drafts",
    description:
      "For common questions submitted via forms, generates a draft response for staff to review and send, saving time on repetitive answers.",
    category: "automation",
    surface: "automation",
    demo_hint: "Trigger the automation Northgate Dental Studio actually needs",
    demo_prompts: [
      "Draft response for 'Cost of check-up'",
      "Draft response for 'Emergency appointment availability'",
      "Draft response for 'Clear aligner process'",
    ],
    demo_results: {
      "Draft response for 'Cost of check-up'":
        "Draft: 'Thank you for your inquiry. A standard check-up at Northgate Dental Studio costs £X. For a detailed breakdown, please see our services page [link] or book an initial consultation.'",
      "Draft response for 'Emergency appointment availability'":
        "Draft: 'For immediate emergencies, please call us on 0113 XXX YYY. For less urgent concerns, please describe your issue and a team member will contact you as soon as possible.'",
      "Draft response for 'Clear aligner process'":
        "Draft: 'Our clear aligner process involves an initial consultation, a detailed scan, custom aligner creation, and regular check-ups. Most treatments range from X to Y months. Book a free consultation to learn more [link].'",
    },
    placement_label: "Automation",
    placement_path: "/admin/dashboard",
    placement_component: "src/pages/admin/AdminDashboardPage.tsx",
    placement_title: "Admin Dashboard",
  },
];

export const seed = {
  hero: {
    eyebrow: 'Northgate Dental Studio',
    headline: 'Northgate Dental Studio',
    subcopy: 'A clear next step from Northgate Dental Studio — warm, specific, and ready when you are.',
    primaryCta: { label: 'Explore the collection', href: '/gallery' },
    secondaryCta: { label: 'Talk to us', href: '/contact#inquire' },
  },
  cta: {
    heading: 'Ready for Northgate Dental Studio?',
    description: 'Tell Northgate Dental Studio what you need — clear options, real next steps.',
    primaryLabel: 'Get started',
    primaryHref: '/contact#inquire',
    secondaryLabel: 'Talk to us',
    secondaryHref: '/contact#inquire',
  },
  publicHero: {
    headline: "Your Smile, Simplified.",
    subcopy: "Connect directly with Northgate Dental for questions, emergencies, and treatment details.",
    primaryCta: {
      label: "Ask a Question",
      href: "/connect-clarify",
    },
    secondaryCta: {
      label: "Book an Appointment",
      href: "/book",
    },
  },
  connectClarifyHero: {
    headline: "We're Here to Help. Clearly.",
    subcopy: "Your direct line to answers, care, and clarity at Northgate Dental Studio.",
  },
  services: [
    {
      title: "Check-ups & Hygiene",
      description: "Routine care to keep your smile healthy and bright.",
    },
    {
      title: "Clear Aligners",
      description: "Discreetly straighten your teeth with modern aligner solutions.",
    },
    {
      title: "Emergency Dental Care",
      description: "Urgent attention for unexpected dental pain or injury.",
    },
  ],
  features: [
    {
      title: "Upfront Costs",
      description: "Know your treatment plan and costs before you commit.",
    },
    {
      title: "Easy Online Booking",
      description: "Schedule your next visit at your convenience, 24/7.",
    },
    {
      title: "Automated Reminders",
      description: "Never miss an appointment with timely notifications.",
    },
  ],
  process: [
    {
      title: "1. Choose Your Inquiry",
      description: "Select from Quick Chat, Treatment Inquiry, or Emergency Request.",
    },
    {
      title: "2. Share Your Needs",
      description: "Provide details through our secure forms or direct chat.",
    },
    {
      title: "3. Get a Swift Response",
      description: "Our team will connect with you promptly to clarify and assist.",
    },
  ],
  testimonials: [
    {
      quote:
        "Northgate Dental made my clear aligner journey so easy! The staff are wonderful and always quick to answer my questions.",
      author: "Sarah J.",
      role: "Patient",
    },
    {
      quote:
        "Fantastic service, especially when I needed an emergency appointment. They fit me in quickly and the team was incredibly reassuring.",
      author: "Mark T.",
      role: "Patient",
    },
    {
      quote: "The Connect & Clarify portal made it so easy to ask about clear aligners before my first visit. Such a relief to get my questions answered quickly!",
      author: "Sarah J.",
      role: "Patient",
    },
    {
      quote: "Had a toothache on Sunday; used the emergency request form. Got a call back first thing Monday. Excellent service!",
      author: "Mark T.",
      role: "Patient",
    },
    {
      quote: "Just a quick question about my appointment, and WhatsApp chat was perfect. No waiting on the phone!",
      author: "Chloe D.",
      role: "Patient",
    },
  ],
  credentials: [
    {
      title: "GDC Registered",
      detail: "All our dentists and hygienists are registered with the General Dental Council.",
    },
    {
      title: "Family Friendly",
      detail: "Caring for smiles of all ages in a welcoming environment.",
    },
    {
      title: "Leeds Community Focused",
      detail: "Proudly serving our local community.",
    },
  ],
  trustLabels: ["GDPR Compliant", "GDC Registered", "Leeds Community Focused"],
  showcaseHeading: "Explore Our Services",
  items: [
    {
      title: "Check-ups & Prevention",
      description: "Routine examinations and personalized preventative care for lasting oral health.",
      badge: "Popular"
    },
    {
      title: "Hygienist Visits",
      description: "Professional cleaning and tailored advice for a fresh, healthy smile.",
      badge: "Essential"
    },
    {
      title: "Clear Aligners",
      description: "Discreet, effective solutions for straightening your teeth with confidence.",
      badge: "Transformative"
    },
    {
      title: "Emergency Appointments",
      description: "Prompt care for unexpected dental pain or urgent concerns.",
      badge: "Urgent"
    },
  ],
  kpis: [
    { label: "New Inquiries Today", value: "7", delta: "+3", hint: "vs. yesterday" },
    { label: "Average Response Time", value: "1h 15m", delta: "-30m", hint: "past 24h" },
    { label: "Pending Emergencies", value: "1", delta: "0", hint: "high priority" },
    { label: "WhatsApp Chats Open", value: "3", delta: "+1", hint: "requiring attention" },
  ],
  tableRows: [
    {
      id: "inc001",
      title: "Treatment Inquiry: Clear Aligners",
      description: "Jamie R. (New Patient) - 'Cost & duration?'",
      status: "Pending",
      type: "Treatment Inquiry",
      patient: "Jamie R.",
      priority: "Medium",
      time: "25 min ago",
      actions: "View, Assign",
    },
    {
      id: "inc002",
      title: "Emergency Request: Toothache",
      description: "Sarah M. (Existing) - 'Severe pain, best time to call?'",
      status: "Urgent",
      type: "Emergency",
      patient: "Sarah M.",
      priority: "High",
      time: "15 min ago",
      actions: "Call Now, View",
    },
    {
      id: "inc003",
      title: "Quick Chat: General Availability",
      description: "Tom P. (New Patient) - 'Evening appointments?'",
      status: "Open",
      type: "Quick Chat",
      patient: "Tom P.",
      priority: "Low",
      time: "45 min ago",
      actions: "Reply, Close",
    },
    {
      id: "inc004",
      title: "Treatment Inquiry: Whitening",
      description: "Emily C. (Existing) - 'Is teeth whitening safe for sensitive teeth?'",
      status: "Pending",
      type: "Treatment Inquiry",
      patient: "Emily C.",
      priority: "Medium",
      time: "1h ago",
      actions: "View, Assign",
    },
    {
      id: "inc005",
      title: "Quick Chat: Directions",
      description: "David L. (New Patient) - 'Where are you located?'",
      status: "Responded",
      type: "Quick Chat",
      patient: "David L.",
      priority: "Low",
      time: "2h ago",
      actions: "Archive",
    },
    {
      id: "inc006",
      title: "Emergency Request: Lost Filling",
      description: "Chloe D. (Existing) - 'Lost a filling, no pain yet'",
      status: "Resolved",
      type: "Emergency",
      patient: "Chloe D.",
      priority: "Medium",
      time: "3h ago",
      actions: "View History",
    },
    {
      id: "inc007",
      title: "Treatment Inquiry: Veneers",
      description: "James W. (New Patient) - 'Consultation cost for veneers?'",
      status: "Pending",
      type: "Treatment Inquiry",
      patient: "James W.",
      priority: "Medium",
      time: "4h ago",
      actions: "View, Assign",
    },
    {
      id: "inc008",
      title: "Quick Chat: Payment Options",
      description: "Olivia M. (Existing) - 'Do you offer payment plans?'",
      status: "Open",
      type: "Quick Chat",
      patient: "Olivia M.",
      priority: "Low",
      time: "5h ago",
      actions: "Reply, Close",
    },
  ],
  activity: [
    {
      title: "Chloe R. responded to Sarah M. emergency",
      detail: "Suggested callback time: 10:30 AM",
      when: "Just now",
    },
    {
      title: "New Treatment Inquiry from Jamie R. submitted",
      detail: "Via website form - Clear Aligners",
      when: "5 min ago",
    },
    {
      title: "Mark L. updated status for 'Routine Check-up' (Taylor S.) to 'Booked'",
      detail: "Appointment confirmed for 2 weeks",
      when: "30 min ago",
    },
    {
      title: "Automated message sent to David L. about directions",
      detail: "Quick Chat inquiry resolved",
      when: "2 hours ago",
    },
    {
      title: "Dr. Vance reviewed James W.'s veneer inquiry",
      detail: "Assigned to treatment coordinator",
      when: "4 hours ago",
    },
  ],
  opsHero: {
    headline: "Connect & Clarify Dashboard",
    subcopy: "Manage patient inquiries, streamline communication, and track team responses.",
  },
  credentialsHeading: "Why Northgate Dental Studio",
  featuresHeading: "Why Patients Choose Northgate Dental for Clarity",
  footer: {
    brandName: "Northgate Dental Studio",
    description: "Your trusted family dental practice in Leeds, providing clear choices and comfortable care.",
    links: [
      { label: "Services", href: "/services" },
      { label: "About Us", href: "/about" },
      { label: "Contact", href: "/book" },
      { label: "Privacy Policy", href: "#" },
    ],
    meta: "© 2024 Northgate Dental Studio. All rights reserved.",
    variant: "columns",
  }
};
export const navItemsAdmin = navigation.admin;
export const adminNavItems = navigation.admin;
